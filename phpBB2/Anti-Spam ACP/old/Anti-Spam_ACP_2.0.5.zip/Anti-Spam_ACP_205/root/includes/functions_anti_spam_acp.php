<?php
/***************************************************************************
 *            functions_anti_spam_acp.php
 * 			 -------------------
 *   copyright	: (C) 2006 EXreaction
 *   email		: exreaction@lithiumstudios.org
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *
 ***************************************************************************/

/*
* ignore
*/
if ( !defined('IN_PHPBB') )
{
	die("Hacking attempt");
}

function main_profile_fields($HTTP_POST_VARS)
{
	/*
	* profile fields and $HTTP_POST_VARS variable array
	* first field is the name of it(used in the template switches)
	* second is the post variable variable name(what gets submitted when the user submits the page)
	*/
	$profile_fields = array(
		'icq'	=> $HTTP_POST_VARS['icq'],
		'aim'	=> $HTTP_POST_VARS['aim'],
		'msn'	=> $HTTP_POST_VARS['msn'],
		'yim'	=> $HTTP_POST_VARS['yim'],
		'web'	=> $HTTP_POST_VARS['website'],
		'loc'	=> $HTTP_POST_VARS['location'],
		'occ'	=> $HTTP_POST_VARS['occupation'],
		'int'	=> $HTTP_POST_VARS['interests'],
		'sig'	=> $HTTP_POST_VARS['signature']
		);

	return $profile_fields;
}

function admin_profile_fields()
{
	/*
	* profile fields and lang variable array
	* first field is the name of it(used in the database for this mod ex, 'icq' would be put in: 'as_acp_icq')
	* second is the lang variable name(the part between the '' in the $lang array, like 'ICQ' for: '$lang['ICQ']')
	* make sure you add the two rows in the phpbb_config table when adding a field as well
	*/
	$profile_fields = array(
		'icq'	=> 'ICQ',
		'aim'	=> 'AIM',
		'msn'	=> 'MSNM',
		'yim'	=> 'YIM',
		'web'	=> 'Website',
		'loc'	=> 'Location',
		'occ'	=> 'Occupation',
		'int'	=> 'Interests',
		'sig'	=> 'Signature'
		);

	return $profile_fields;
}

function admin_sync_profile_fields()
{
	/*
	* profile fields and database variable array
	* first field is the name of it(used in the database for this mod ex, 'icq' would be put in: 'as_acp_icq')
	* second is the name of the database variable in the users table(like user_icq, user_website, user_from, user_sig, etc)
	*/
	$profile_fields = array(
		'icq'	=> 'user_icq',
		'aim'	=> 'user_aim',
		'msn'	=> 'user_msnm',
		'yim'	=> 'user_yim',
		'web'	=> 'user_website',
		'loc'	=> 'user_from',
		'occ'	=> 'user_occ',
		'int'	=> 'user_interests',
		'sig'	=> 'user_sig'
		);

	return $profile_fields;
}

function get_ip() // Gets the users IP address
{
	if (isSet($_SERVER))
	{
		if (isSet($_SERVER["HTTP_X_FORWARDED_FOR"]))
		{
			$realip = $_SERVER["HTTP_X_FORWARDED_FOR"];
		}
		elseif (isSet($_SERVER["HTTP_CLIENT_IP"]))
		{
			$realip = $_SERVER["HTTP_CLIENT_IP"];
		}
		else
		{
			$realip = $_SERVER["REMOTE_ADDR"];
		}
	}
	else
	{
		if ( getenv( 'HTTP_X_FORWARDED_FOR' ) )
		{
			$realip = getenv( 'HTTP_X_FORWARDED_FOR' );
		}
		elseif ( getenv( 'HTTP_CLIENT_IP' ) )
		{
			$realip = getenv( 'HTTP_CLIENT_IP' );
		}
		else
		{
			$realip = getenv( 'REMOTE_ADDR' );
		}
	}
	return $realip;
}

function send_email($triggers, $username, $user_email, $user_ip, $notice)
{
	global $board_config, $lang, $phpbb_root_path, $phpEx;

	$email = explode(",", $board_config['as_acp_email_for_spam'], 2);
	$address = array_shift($email);
	$bcc = implode(",", $email);

	include($phpbb_root_path . 'includes/emailer.' . $phpEx);
	$emailer = new emailer($board_config['smtp_delivery']);
	$emailer->from($board_config['board_email']);
	$emailer->replyto($board_config['board_email']);
	$emailer->use_template('admin_spam_notification');
	$emailer->email_address($address);
	$emailer->bcc($bcc);
	$emailer->set_subject($lang['Spam_Attempt'] . $board_config['sitename']);

	$emailer->assign_vars(array(
		'NOTICE'			=> $notice,
		'SITENAME'			=> $board_config['sitename'], 
		'USERNAME'			=> $username,
		'IP'				=> $user_ip,
		'EMAIL'				=> $user_email,
		'TRIGGERS'			=> str_replace("%end_of_line%", "\r\n", $triggers))
		);

	$emailer->send();
	$emailer->reset();
}

function log_spam($triggers, $username, $user_id, $email, $location, $notice = '') // Logs data to spam table
{
	global $db, $board_config;

	$triggers = trim(htmlspecialchars($triggers));
	$triggers = stripslashes($triggers);
	$triggers = str_replace("'", "\'", $triggers);
	$log_triggers = str_replace('%end_of_line%', '<br/>', $triggers);
	$time = time();
	$user_id = ($user_id == 0) ? -1 : $user_id;
	$ip_address = get_ip();
	$sql = 'INSERT INTO ' . SPAM_LOG_TABLE . " (log_time, username, user_id, user_ip, user_email, location, log_triggers) 
				VALUES ('$time', '$username', '$user_id', '$ip_address', '$email', '$location', '$log_triggers')";
	if( !$db->sql_query($sql) )
	{
		message_die(GENERAL_ERROR, "Failed to update log table.");
	}
	
	if ( ($board_config['as_acp_email_for_spam'] != '') && ($board_config['as_acp_notify_on_spam'] == '1') )
	{
		send_email($triggers, $username, $email, $ip_address, $notice);
	}
}

function check_version() // Checks the version to see if it is the latest
{
	global $board_config, $lang;

	if (!$board_config['as_acp_check_version'])
	{
		return '<p style="color:red">' . $lang['version_check_disabled'] . '</p>';
	}

	$errno = 0;
	$errstr = $version_info = '';

	if ($fsock = @fsockopen('www.lithiumstudios.org', 80, $errno, $errstr, 5))
	{
		@fputs($fsock, "GET /updatecheck/anti_spam_acp_version.txt HTTP/1.1\r\n");
		@fputs($fsock, "HOST: www.lithiumstudios.org\r\n");
		@fputs($fsock, "Connection: close\r\n\r\n");

		$get_info = false;
		while (!@feof($fsock))
		{
			if ($get_info)
			{
				$version .= @fread($fsock, 1024);
			}
			else
			{
				if (@fgets($fsock, 1024) == "\r\n")
				{
					$get_info = true;
				}
			}
		}
		@fclose($fsock);

		$version = explode("\n", $version);
		$version = implode(".", $version);

		if ($version == $board_config['as_acp_version'])
		{
			$version_info = '<p style="color:green">' . $lang['AS_ACP_up_to_date'] . '</p>';
		}
		else
		{
			$version_info = '<p style="color:red">' . $lang['AS_ACP_not_up_to_date'];
			$version_info .= '<br />' . sprintf($lang['AS_ACP_Latest_Version'], $version) . ' ' . sprintf($lang['AS_ACP_Current_Version'], $board_config['as_acp_version']) . '</p>';
		}
	}
	else
	{
		if ($errstr)
		{
			$version_info = '<p style="color:red">' . sprintf($lang['Connect_socket_error'], $errstr) . '</p>';
		}
		else
		{
			$version_info = '<p>' . $lang['Socket_functions_disabled'] . '</p>';
		}
	}

	return $version_info;
}

function num_check($num) // a simple number check to make sure the number is in operating perameters(for the post count check)
{
	if ( ($num >= 1) && ($num <= 9999) )
	{
		return(true);
	}
	else
	{
		return(false);
	}
}
?>