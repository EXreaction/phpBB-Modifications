##############################################################
## MOD Title: Anti-spam ACP 2.0.5 Read_Me_First
## MOD Author: EXreaction < exreaction@lithiumstudios.org > (Nathan Guse) http://www.lithiumstudios.org
##
## MOD Description: Read Me for Anti-Spam ACP
##
## MOD Version: 2.0.5
##
## License: http://opensource.org/licenses/gpl-license.php GNU General Public License v2
##############################################################
## For security purposes, please check: http://www.phpbb.com/mods/
## for the latest version of this MOD. Although MODs are checked
## before being allowed in the MODs Database there is no guarantee
## that there are no security problems within the MOD. No support
## will be given for MODs not found within the MODs Database which
## can be found at http://www.phpbb.com/mods/
##############################################################
## Author Notes:
##	+ My official thread for this mod is here: http://www.lithiumstudios.org/phpBB3/viewtopic.php?f=10&t=4
##		- Please ask for support in the Anti-Spam ACP support forum, which is located here:
##			+ http://www.lithiumstudios.org/phpBB3/viewforum.php?f=25
##	+ If you would like to support my work, you can do so by donating.  It can take a lot of time to code and support your modifications.
##		- You can donate with PayPal here:
##		- http://tinyurl.com/ymtctj
##	+ I HIGHLY reccomend you use EasyMod to install this mod(make sure you are using the latest version of EasyMod when you do)
##		- The biggest reason for errors after installing this mod is user installation error.  If EasyMod detects an error
##			+ it will let you know before it does any changes.
##############################################################
## MOD History:
##	(yyyy-mm-dd)
##	2006-06-25
##		+ 1.0.0 Initial Release
##	2006-08-23
##		+ 1.1.0 Complete Overhaul...
##	2006-08-27
##		+ 1.1.0a Hard codded language fixed and emailer template added(was forgotten in 1.1.0)
##	2006-09-06
##		+ 1.1.01 Bug fixes, a few minor things, a bots caught watcher, and a cool version checker ^_^
##			- As long as there are no bugs found or and all of the future versions of phpBB are compatible with this mod,
##				+ this will be the last version I code(I will still support it though). :-P
##	2006-09-11
##		+ 1.1.01a Dang it...I missed a small bug. :(
##			- Thanks gpraceman for finding it.
##	2006-11-01
##		+ 1.1.02 Many fixes...
##	2006-12-06
##		+ 2.0.0 Pretty much a complete remake of the mod.  Includes many more features and bug fixes over 1.1.02.
##	2006-12-07
##		+ 2.0.0a Oopsie, I had the inactive userlist counting the active members for the pagenation instead of the inactive ones. :$
##	2006-12-21
##		+ 2.0.1 Polishing up the mod.
##	2006-12-31
##		+ Have a great new year!
##		+ More minor polishes.  Email now gets sent if something is logged instead of just during registration.
##			- unversioned update: Changed the mod to work even better with more templates(the way the finds are setup)!  Thanks Nightrider! :D
##	2007-01-12
##		+ 2.0.3 Now have the option to sync user's data to follow the current profile rules.  Also there is now the option to delete all posts or
##			- topics made by a specific user(located under User Management).
##	2007-01-21
##		+ 2.0.4 A few fixes.
##			- Now the captcha also shows during posting to guest users! :D
##	2007-01-24
##		+ 2.0.5 Some important bug fixes, update ASAP if you have 2.0.4
##			- Also, now the spam log can be sorted.
##############################################################
## Before Adding This MOD To Your Forum, You Should Back Up All Files Related To This MOD
##############################################################

#
#-----[ DIY INSTRUCTIONS ]------------------------------------------
#

If you already have an older version of Anti-Spam ACP installed, you MUST use the upgrade version
  (located in the contrib/upgrades folder) suited to what you already have installed, or you 
  will have many problems.

If you install this mod and for some reason the new Captcha only displays a broken image(or no image), 
  delete everything in the includes/fonts/ folder, then reupload the fonts and .htaccess file that come 
  with this mod in root/includes/fonts/ to includes/fonts.  The reason it probably is not working is that
  a font file is probably corrupt, so re-uploading the file should fix it.  If it doesn't, delete all the
  files in includes/fonts/ again, but this time only upload 1 font file.  See if it works then, if not try
  re-uploading the single file a few times to make sure the file is not getting corrupt when you upload it.
  If it still does not work let me know, I would like to take a look at it. :)

You will have troubles with this mod if you have other mods installed that have 
  added switches to the profile_add_body.tpl over the same places this mod adds them.  
  Either remove that mod, or don't install this one.

For Tutorials and other information on how to install this mod try out these links:

 [Tutorial] How to install a MOD
  http://www.phpbb.com/phpBB/viewtopic.php?t=61611

 Executing SQL Queries in phpMyAdmin
  http://www.phpbb.com/kb/article.php?article_id=151

 Installing a MOD in a safe way
  http://www.phpbb.com/kb/article.php?article_id=175

 Uninstalling a MOD
  http://www.phpbb.com/kb/article.php?article_id=145


Now, after reading that all I will finally tell you how to install the mod.  If you are seeing
  this in EasyMod you are probably confused, but I assure you there is a very good reason for this.

  To upgrade from an older version of Anti-Spam ACP with EasyMod: 
    Copy the correct file from contrib/upgrades to the root Anti-Spam_ACP folder in admin/mods,
    then open EasyMod and have it install that file.

  To install the full mod package with EasyMod:
    (Do NOT do this if you already have this mod installed or any version of it)
    Copy Anti-Spam_ACP.mod from the admin/mods/Anti-Spam_ACP/contrib/ folder to the root Anti-Spam_ACP/ folder in admin/mods,
    then open EasyMod and have it install that file.

  To install the full pre-modded package:
    Do NOT do this if any of the files you are asked to upload have been changed by any prior mod installed,
	  or you are using a different version of phpBB2 than what the files are for(it says the phpBB2 version in the mod install file)
    The instructions are located in contrib/Anti-Spam_ACP_pre-modified.mod(the files are in the main root/ folder).

  As for manually installing the mod, you can do what I have said above, or just use the correct install
    file, but all the files that are needed to be copied are in the main root/ folder.

  You may move the readme file to the contrib directory if you would like(if you use EasyMod) so it does not
    show this mod in the EasyMod Install page.