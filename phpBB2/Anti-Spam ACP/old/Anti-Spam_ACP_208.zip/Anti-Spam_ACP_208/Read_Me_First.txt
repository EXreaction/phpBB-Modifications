##############################################################
## MOD Title: Anti-spam ACP 2.0.8 Read_Me_First
## MOD Author: EXreaction < exreaction@lithiumstudios.org > (Nathan Guse) http://www.lithiumstudios.org
##
## MOD Description: Read Me for Anti-Spam ACP
##
## MOD Version: 2.0.8
##
## License: http://opensource.org/licenses/gpl-license.php GNU General Public License v2
##############################################################
## For security purposes, please check: http://www.phpbb.com/mods/
## for the latest version of this MOD. Although MODs are checked
## before being allowed in the MODs Database there is no guarantee
## that there are no security problems within the MOD. No support
## will be given for MODs not found within the MODs Database which
## can be found at http://www.phpbb.com/mods/
##############################################################
## Author Notes:
##	+ My official thread for this mod is here: http://www.lithiumstudios.org/phpBB3/viewtopic.php?f=10&t=4
##		- Please ask for support in the Anti-Spam ACP support forum, which is located here:
##			+ http://www.lithiumstudios.org/phpBB3/viewforum.php?f=25
##
##	+ If you would like to support my work, you can do so by donating.  It can take a lot of time to code and support your modifications.
##		- You can donate with PayPal here:
##		- http://tinyurl.com/ymtctj
##
##	+ I HIGHLY reccomend you use EasyMod to install this mod(make sure you are using the latest version of EasyMod when you do)
##		- The biggest reason for errors after installing this mod is user installation error.  If EasyMod detects an error
##			+ it will let you know before it does any changes.
##############################################################
## MOD History:
##	(yyyy-mm-dd)
##	2006-06-25
##		+ 1.0.0 Initial Release
##	2006-08-23
##		+ 1.1.0 Complete Overhaul...
##	2006-08-27
##		+ 1.1.0a Hard codded language fixed and emailer template added(was forgotten in 1.1.0)
##	2006-09-06
##		+ 1.1.01 Bug fixes, a few minor things, a bots caught watcher, and a cool version checker ^_^
##			- As long as there are no bugs found or and all of the future versions of phpBB are compatible with this mod,
##				+ this will be the last version I code(I will still support it though). :-P
##	2006-09-11
##		+ 1.1.01a Dang it...I missed a small bug. :(
##			- Thanks gpraceman for finding it.
##	2006-11-01
##		+ 1.1.02 Many fixes...
##	2006-12-06
##		+ 2.0.0 Pretty much a complete remake of the mod.  Includes many more features and bug fixes over 1.1.02.
##	2006-12-07
##		+ 2.0.0a Oopsie, I had the inactive userlist counting the active members for the pagenation instead of the inactive ones. :$
##	2006-12-21
##		+ 2.0.1 Polishing up the mod.
##	2006-12-31
##		+ Have a great new year!
##		+ More minor polishes.  Email now gets sent if something is logged instead of just during registration.
##			- unversioned update: Changed the mod to work even better with more templates(the way the finds are setup)!  Thanks Nightrider! :D
##	2007-01-12
##		+ 2.0.3 Now have the option to sync user's data to follow the current profile rules.  Also there is now the option to delete all posts or
##			- topics made by a specific user(located under User Management).
##	2007-01-21
##		+ 2.0.4 A few fixes.
##			- Now the captcha also shows during posting to guest users! :D
##	2007-01-24
##		+ 2.0.5 Some important bug fixes, update ASAP if you have 2.0.4
##			- Also, now the spam log can be sorted.
##	2007-02-04
##		+ 2.0.6 Minor bug fixes, and now more captcha options!
##			- No more manual SQL stuff anymore!  It is all done automatically! :D
##			- Rather large problem(data was not synced) found with deleting user posts/topics has now been fixed!  You can all thank Snapdragon for finding it. :)
##	2007-02-16
##		+ 2.0.7 Bug fixes
##			- Now much better support for other DB types(thanks to those who helped and tested it)
##			- Removed the new captcha that was included last time, it was not as helpful as I had hoped.
##	2007-03-11
##		+ 2.0.8 Minor bug fixes, language fixes
##			- You can thank Infarinato for the language fixes. :)
##############################################################
## Before Adding This MOD To Your Forum, You Should Back Up All Files Related To This MOD
##############################################################

#
#-----[ DIY INSTRUCTIONS ]------------------------------------------
#

This mod requires phpBB 2.0.21 or newer!  Older versions are not supported.  Premodified phpBB2
  installs(including Categories Hierarchy mod) are also not supported(the reason is some have very
  little original phpBB2 code in them, so porting my mod over would require a lot of work).

Database backends other than MySQL may act strange(I am looking at you SQL 2000), if you are using
  a database other than MySQL and are having problems, please report it on my forums, I will try to
  help you get it working.

If you already have an older version of Anti-Spam ACP installed, you MUST use the upgrade version
  (located in the contrib/upgrades folder) suited to what you already have installed, or you 
  will have many problems(and you will have to fix it yourself, find someone else to do it, or
  I can do it for a fee).

If you install this mod and for some reason the new Captcha only displays a broken image(or no image), 
  delete everything in the includes/better_captcha_fonts/ folder, then reupload the fonts and .htaccess
  file that come with this mod in root/includes/better_captcha_fonts/ to includes/better_captcha_fonts.
  The reason it probably is not working is that a font file is probably corrupt, so re-uploading the file
  should fix it.  If it doesn't, delete all the files in includes/better_captcha_fonts/ again, but this 
  time only upload 1 font file.  See if it works then, if not try re-uploading the single file a few times
  to make sure the file is not getting corrupt when you upload it.  If it still does not work let me know,
  I would like to take a look at it. :)

You will have troubles with this mod if you have other mods installed that have 
  added template switches to the profile_add_body.tpl over the same places this mod adds them.  
  Either remove that mod, or don't install this one.



Now, after reading that all I will finally tell you how to install the mod.  If you are seeing
  this in EasyMod you are probably confused, but I assure you there is a very good reason for this.

  To upgrade from an older version of Anti-Spam ACP with EasyMod:
    Upload the Anti-Spam_ACP folder to admin/mods.
    Copy the correct file from Anti-Spam_ACP/contrib/upgrades to the Anti-Spam_ACP folder.
    Open EasyMod and have it install that file.

  To install the full mod package with EasyMod:
    (Do NOT do this if you already have this mod installed or any version of it)
    Upload the Anti-Spam_ACP folder to admin/mods.
    Copy the Anti-Spam_ACP.mod file from Anti-Spam_ACP/contrib/ to the Anti-Spam_ACP folder.
    Open EasyMod and have it install that file.

  To install the full pre-modded package:
    Do NOT do this if any of the files you are asked to upload have been changed by any prior mod installed,
	  or you are using a different version of phpBB2 than what the files are for(it says the phpBB2 version in the mod install file)
    The instructions are located in contrib/Anti-Spam_ACP_pre-modified.mod(the files are in the main root/ and premod_root/ folders).

  To install the mod manually(not reccomended):
    Open Anti-Spam_ACP/contrib/Anti-Spam_ACP.mod and follow the instructions.
	The files that will need to be copied are in Anti-Spam_ACP/root/

For Tutorials and other information on how to install this mod manually try out these links:

 [Tutorial] How to install a MOD
  http://www.phpbb.com/phpBB/viewtopic.php?t=61611

 Installing a MOD in a safe way
  http://www.phpbb.com/kb/article.php?article_id=175

 Uninstalling a MOD
  http://www.phpbb.com/kb/article.php?article_id=145