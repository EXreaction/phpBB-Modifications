You will have troubles with this mod if you have other mods installed that have 
  added switches to the profile_add_body.tpl over the same places this mod adds them.  
  Either remove that mod, or don't install this one.  If both mods are important
  to you, PM or Email EXreaction, or ask for help in one of the support threads for this
  mod, together we can think of something..

If you are upgrading from an older version use the root folder in the main directory for the files.
  If you are using EasyMod to upgrade, delete the .mod file in the main directory, then copy the upgrade
  mod file from the contribs/Upgrades to the main directory, then upload it all to your mods/ folder and
  install with easymod.

To install the mod, just do what it says in the Anti-Spam ACP.mod file, or just install 
  it with easymod if you have easymod installed.  You can open any file needed(.mod, .php, .tpl)
  with any basic text editor like WordPad.  If you want something a little better than WordPad,
  I highly recommend you try out NotePad++(google it for a download link and more info).

Instead of having to do the SQL query's manually, you may run db_install.php.  For more info,
  read the notes or SQL section of the .mod file.

If you have any questions, suggestions, or would just like to say thanks, feel free to
  reply in the thread at phpbb.com, I will answer any questions I can.  If you have a good
  suggestion that could be an add-on to this mod, I might be willing to code it up for,
  and thank yous are always nice.

For Tutorials and other information on how to install this mod check out these links:

 [Tutorial] How to install a MOD
  http://www.phpbb.com/phpBB/viewtopic.php?t=61611

 Executing SQL Queries in phpMyAdmin
  http://www.phpbb.com/kb/article.php?article_id=151

 Installing a MOD in a safe way
  http://www.phpbb.com/kb/article.php?article_id=175

 Uninstalling a MOD
  http://www.phpbb.com/kb/article.php?article_id=145