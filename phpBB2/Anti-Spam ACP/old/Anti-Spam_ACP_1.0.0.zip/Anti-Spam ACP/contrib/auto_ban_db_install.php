<?php
/***************************************************************************
 *                             db_install.php
 *                            -------------------
 *   begin                : Saturday, June 24, 2006
 *   copyright            : (C) 2006 Nathan Guse
 *   email                : exreaction@gotechzilla.com
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

function _sql($sql, &$errored, &$error_ary, $echo_dot = true)
{
	global $db;

	if( !($result = $db->sql_query($sql)) )
	{  
		$errored = true;
		$error_ary['sql'][] = ( is_array($sql) ) ? $sql[$i] : $sql;
		$error_ary['error_code'][] = $db->sql_error();
	}

	if ( $echo_dot )
	{
		echo ".";
		flush();
	}

	return $result;
}

$installs_version = '1.0.0';

define('IN_PHPBB', 1);
$phpbb_root_path = './';
include($phpbb_root_path . 'extension.inc');
include($phpbb_root_path . 'config.'.$phpEx);
include($phpbb_root_path . 'includes/constants.'.$phpEx);
include($phpbb_root_path . 'includes/functions.'.$phpEx);
include($phpbb_root_path . 'includes/functions_admin.'.$phpEx);
include($phpbb_root_path . 'includes/db.'.$phpEx);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<meta http-equiv="Content-Style-Type" content="text/css">
<style type="text/css">
<!--

font,th,td,p,body { font-family: "Courier New", courier; font-size: 11pt }

a:link,a:active,a:visited { color : #006699; }
a:hover		{ text-decoration: underline; color : #DD6900;}

hr	{ height: 0px; border: solid #D1D7DC 0px; border-top-width: 1px;}

.maintitle,h1,h2	{font-weight: bold; font-size: 22px; font-family: "Trebuchet MS",Verdana, Arial, Helvetica, sans-serif; text-decoration: none; line-height : 120%; color : #000000;}

.ok {color:green}

/* Import the fancy styles for IE only (NS4.x doesn't use the @import function) */
@import url("templates/subSilver/formIE.css"); 
-->
</style>
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#006699" vlink="#5584AA">

<table width="100%" border="0" cellspacing="0" cellpadding="10" align="center"> 
	<tr>
		<td><table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td><img src="templates/subSilver/images/logo_phpBB.gif" border="0" alt="Forum Home" vspace="1" /></td>
				<td align="center" width="100%" valign="middle"><span class="maintitle">EXreaction's Auto IP Ban Bots(Anti-spam ACP Add-on) MOD: Database Updater</span></td>
			</tr>
		</table></td>
	</tr>
</table>

<br clear="all" />

<h2>Information</h2>

<?php

echo '<p>Database type &nbsp; &nbsp;:: <b>' . SQL_LAYER . '</b><br />';

echo 'EXreaction\'s Auto IP Ban Bots(Anti-spam ACP Add-on) Version:: <b>' . $installs_version . '</b></p>' ."\n";

echo '<p>This installs the necessary database sections for EXreaction\'s Auto IP Ban Bots(Anti-spam ACP Add-on) MOD.  Currently, only the MySQL aspect has been tested.  If you\'re using any other database, please report your results to EXreaction.</p>' . "\n";

//
// 
//
unset($sql);
$error_ary = array();
$errored = false;

echo "<h2>Updating data</h2>\n";
echo "<p>Progress :: <b>";
flush();

$sql = "INSERT INTO " . CONFIG_TABLE . " (config_name, config_value)
	VALUES ('IP_Ban_Bots', '0')";
	_sql($sql, $errored, $error_ary);

		echo "</b> <b class=\"ok\">Done</b><br />Result &nbsp; :: \n";

		if ( $errored )
		{
			echo " <b>Some queries failed, the statements and errors are listing below</b>\n<ul>";

			for($i = 0; $i < count($error_ary['sql']); $i++)
			{
				echo "<li>Error :: <b>" . $error_ary['error_code'][$i]['message'] . "</b><br />";
				echo "SQL &nbsp; :: <b>" . $error_ary['sql'][$i] . "</b><br /><br /></li>";
			}

			echo "</ul>\n<p>If the errors that occured don't say \"Duplicate entry\" please PM EXreaction with the details of the error, otherwise you already have those fields in your database, just ignore them.</p>\n";
		}
		else
		{
			echo "<b>No errors</b>\n";
		}


echo "<h2>Install completed</h2>\n";
echo "\n<p><b>You should now delete this file.</b></p>\n";

?>

<br clear="all" />

</body>
</html>