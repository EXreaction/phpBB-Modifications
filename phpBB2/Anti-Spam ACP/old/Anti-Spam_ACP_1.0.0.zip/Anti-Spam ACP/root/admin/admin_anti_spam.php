<?php 
define('IN_PHPBB', 1);

if( !empty($setmodules) )
{
   $filename = basename(__FILE__);
   $module['Anti Spam']['Anti Spam ACP'] = $filename;

   return;
}

$phpbb_root_path = './../';
require($phpbb_root_path . 'extension.inc');
require('./pagestart.' . $phpEx);


$sql = "SELECT *
	FROM " . CONFIG_TABLE;
if(!$result = $db->sql_query($sql))
{
	message_die(CRITICAL_ERROR, "Could not query config information", "", __LINE__, __FILE__, $sql);
}
else
{
	while( $row = $db->sql_fetchrow($result) )
	{
		$config_name = $row['config_name'];
		$config_value = $row['config_value'];
		$default_config[$config_name] = isset($HTTP_POST_VARS['submit']) ? str_replace("'", "\'", $config_value) : $config_value;
		
		$new[$config_name] = ( isset($HTTP_POST_VARS[$config_name]) ) ? $HTTP_POST_VARS[$config_name] : $default_config[$config_name];

		if( isset($HTTP_POST_VARS['submit']) )
		{
			$sql = "UPDATE " . CONFIG_TABLE . " SET
				config_value = '" . str_replace("\'", "''", $new[$config_name]) . "'
				WHERE config_name = '$config_name'";
			if( !$db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Failed to update general configuration for $config_name", "", __LINE__, __FILE__, $sql);
			}
		}
	}

	if( isset($HTTP_POST_VARS['submit']) )
	{
		$message = $lang['Config_updated'] . "<br /><br />" . sprintf($lang['Click_return_AS_ACP'], "<a href=\"" . append_sid("admin_anti_spam.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");

		message_die(GENERAL_MESSAGE, $message);
	}
	else if( isset($HTTP_POST_VARS['test_mail']) )
	{
		$spammerIPAddress = "0.0.0.0";
		
		$emailSubject   = "Notification of Spam Bot Attempt(TEST EMAIL YOU REQUESTED)";
		$emailHeader    = "From: Spam-Bot-Mod(TEST EMAIL)";
		$emailMessage   = "Spam Bot Registration Attempted(TEST EMAIL).\n\n";
		$emailMessage  .= "Spammer's IP Address = "     . $spammerIPAddress    . "\n";
		$emailMessage  .= "IP Lookup 1 = http://www.nwtools.com/default.asp?prog=express&host=" . $spammerIPAddress . "\n";
		$emailMessage  .= "IP Lookup 2 = http://whois.domaintools.com/" . $spammerIPAddress . "\n";
		$emailMessage  .= "Spammer's Username = TEST \n";
		$emailMessage  .= "Spammer's Password = TEST \n";
		$emailMessage  .= "Spammer's email address = TEST@TEST.COM\n";
		$emailMessage  .= "Spammer's Webpage URL = HTTP://WWW.TEST.COM\n";
		$emailMessage  .= "Spammer's Signature Line = TEST\n";
		mail($board_config['email_for_spam'], $emailSubject, $emailMessage, $emailHeader);

		$message = $lang['MESSAGE_SENT'] . "<br /><br />" . sprintf($lang['Click_return_AS_ACP'], "<a href=\"" . append_sid("admin_anti_spam.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");
		message_die(GENERAL_MESSAGE, $message);
	}

}
$icq_enable = ( !$new['reg_icq_disable'] ) ? "checked=\"checked\"" : "";
$icq_disable = ( $new['reg_icq_disable'] ) ? "checked=\"checked\"" : "";

$aim_enable = ( !$new['reg_aim_disable'] ) ? "checked=\"checked\"" : "";
$aim_disable = ( $new['reg_aim_disable'] ) ? "checked=\"checked\"" : "";

$msn_enable = ( !$new['reg_msn_disable'] ) ? "checked=\"checked\"" : "";
$msn_disable = ( $new['reg_msn_disable'] ) ? "checked=\"checked\"" : "";

$yahoo_enable = ( !$new['reg_yahoo_disable'] ) ? "checked=\"checked\"" : "";
$yahoo_disable = ( $new['reg_yahoo_disable'] ) ? "checked=\"checked\"" : "";

$web_enable = ( !$new['reg_web_disable'] ) ? "checked=\"checked\"" : "";
$web_disable = ( $new['reg_web_disable'] ) ? "checked=\"checked\"" : "";

$loc_enable = ( !$new['reg_loc_disable'] ) ? "checked=\"checked\"" : "";
$loc_disable = ( $new['reg_loc_disable'] ) ? "checked=\"checked\"" : "";

$occ_enable = ( !$new['reg_occ_disable'] ) ? "checked=\"checked\"" : "";
$occ_disable = ( $new['reg_occ_disable'] ) ? "checked=\"checked\"" : "";

$inter_enable = ( !$new['reg_inter_disable'] ) ? "checked=\"checked\"" : "";
$inter_disable = ( $new['reg_inter_disable'] ) ? "checked=\"checked\"" : "";

$sig_enable = ( !$new['reg_sig_disable'] ) ? "checked=\"checked\"" : "";
$sig_disable = ( $new['reg_sig_disable'] ) ? "checked=\"checked\"" : "";

$show_mail_enable = ( !$new['show_email_on_die'] ) ? "checked=\"checked\"" : "";
$show_mail_disable = ( $new['show_email_on_die'] ) ? "checked=\"checked\"" : "";

if ($board_config['AS_cut_off'] == 0)
{
	$l_disable_reg = $lang['Disable_For_Reg'];
}
else if ($board_config['AS_cut_off'] == 1)
{
	$l_disable_reg = $lang['Disable_Reg_P1'] . ' ' . $board_config['AS_cut_off'] . ' ' . $lang['Disable_Reg_P2'];
}
else
{
	$l_disable_reg = $lang['Disable_Reg_P1'] . ' ' . $board_config['AS_cut_off'] . ' ' . $lang['Disable_Reg_P2s'];
}

$template->set_filenames(array(
	'body' => 'admin/anti_spam.tpl')
);
$template->assign_vars(array(
	'ICQ_DISABLE'				=> $icq_disable,
	'ICQ_ENABLE'				=> $icq_enable, 
	'AIM_DISABLE'				=> $aim_disable,
	'AIM_ENABLE'				=> $aim_enable, 
	'MSN_DISABLE'				=> $msn_disable,
	'MSN_ENABLE'				=> $msn_enable, 
	'YAHOO_DISABLE'				=> $yahoo_disable,
	'YAHOO_ENABLE'				=> $yahoo_enable,
	'WEB_DISABLE'				=> $web_disable,
	'WEB_ENABLE'				=> $web_enable, 
	'LOC_DISABLE'				=> $loc_disable,
	'LOC_ENABLE'				=> $loc_enable, 
	'OCC_DISABLE'				=> $occ_disable,
	'OCC_ENABLE'				=> $occ_enable, 
	'INTER_DISABLE'				=> $inter_disable,
	'INTER_ENABLE'				=> $inter_enable, 
	'SIG_DISABLE'				=> $sig_disable,
	'SIG_ENABLE'				=> $sig_enable,
	'SHOW_MAIL_ENABLE'			=> $show_mail_enable,
	'SHOW_MAIL_DISABLE'			=> $show_mail_disable,
	'CUT_OFF'					=> $new['AS_cut_off'],
	'EMAIL'					=> $new['email_for_spam'],
	'L_ICQ'					=> $lang['ICQ'],
	'L_AIM'					=> $lang['AIM'],
	'L_MSN'					=> $lang['MSNM'],
	'L_YAHOO'					=> $lang['YIM'],
	'L_WEBSITE'					=> $lang['Website'],
	'L_LOCATION'				=> $lang['Location'],
	'L_OCCUPATION'				=> $lang['Occupation'],
	'L_INTERESTS'				=> $lang['Interests'],
	'L_SIGNATURE'				=> $lang['Signature'],
	'L_CUT_OFF'					=> $lang['Cut_Off'],
	'L_CUT_OFF_EXPLAIN'			=> $lang['Cut_Off_Explain'],
	'L_EMAIL_ADDRESS'				=> $lang['Email_Address'],
	'L_EMAIL_ADDRESS_EXPLAIN'		=> $lang['Email_Address_Explain'],
	'L_SHOW_MAIL'				=> $lang['Show_Email'],
	'L_SHOW_MAIL_EXPLAIN'			=> $lang['Show_Email_Explain'],
	'L_CONFIGURATION_TITLE'			=> $lang['Anti_Spam_ACP'],
	'L_ANTI_SPAM_ACP_PAGE_SETTINGS'	=> $lang['AS_Page_Settings'],
	'L_DISABLE_REG'				=> $l_disable_reg,
	'L_ENABLE_REG'				=> $lang['Always_Enable'],
	'L_YES'					=> $lang['Yes'],
	'L_NO'					=> $lang['No'],
	'L_SUBMIT'					=> $lang['Submit'],
	'L_RESET'					=> $lang['Reset'],
	'L_TEST_MAIL'				=> $lang['L_TEST_MAIL'],
	'L_TEST_MAIL_EXPLAIN'			=> $lang['L_TEST_MAIL_EXPLAIN'])
);
	
$template->pparse('body');

include('./page_footer_admin.'.$phpEx);
?>