<?php
/***************************************************************************
 *          lang_anti_spam_acp.php
 * 			 -------------------
 *   copyright	: (C) 2006 EXreaction
 *   email		: exreaction@lithiumstudios.org
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

// Common
$lang['Spam_Bot_Attempt']						= 'Spam attempt at ';

// Admin Control Panel
	// Common
		$lang['Anti_Spam_ACP']							= 'Anti-Spam ACP';
		$lang['Anti_Spam_ACP_Created_By']				= 'Created By: <a href="http://www.lithiumstudios.org" style="text-decoration:none">EXreaction</a>';
		$lang['AS_ACP_up_to_date']						= 'Your version of Anti-Spam ACP is up to date.';
		$lang['AS_ACP_not_up_to_date']					= 'You are not running the latest stable version of Anti-Spam ACP.  The latest stable version is available at <a href="http://www.lithiumstudios.org/phpBB3/viewtopic.php?f=10&t=4">Lithium Studios</a>.';
		$lang['AS_ACP_Latest_Version']					= 'The latest stable version is %s.';
		$lang['AS_ACP_Current_Version']					= 'You are running %s.';

		$lang['AS_Page_Settings']						= 'Anti-Spam ACP v%s Settings';
		$lang['Click_return_AS_ACP']					= 'Click %sHere%s to return to Anti-Spam Configuration';
		$lang['AS_ACP_Update_Error']					= 'Errors were reported, the rest of the ';

		$lang['User_id']								= 'User id';

		$lang['Num_Bots_Caught']						= 'Number of spammers stopped by this mod since installation: %s';

	// General Options
		$lang['Check_Version']							= 'Check lithiumstudios.org automatically for updates?';
		$lang['Check_Version_Explain']					= 'Automatically accesses my server and checks to see if you have the latest version(just like phpBB does).';
		$lang['Email_Address']							= 'Email Address';
		$lang['Email_Address_Explain']					= 'Email address that the spam notifications will get sent to and that will be displayed if you have show email enabled.<br/>To enter multiple email addresses use a comma between each.';
		$lang['Show_Email']								= 'Show Email';
		$lang['Show_Email_Explain']						= 'Show your email address when a user gets the message die if they enter in something we don\'t allow.<br/>If this is disabled it will just say to contact the board administrator.';
		$lang['Send_Email']								= 'Send notification email';
		$lang['Send_Email_Explain']						= 'Sends out a notification email when someone attempts to insert illegal data.';
		$lang['L_Test_Mail']							= 'Submit & Test Email';
		$lang['L_Test_Mail_Explain']					= 'Send a test email to yourself, an example of one you would get if a spammer tries to do something they are not allowed to do.';

		$lang['Test_Occupation']						= 'Email Tester';
		$lang['Test_Interests']							= 'Sending out Emails';
		$lang['Test_Signature']							= 'Thank you for testing the email feture of the Anti-Spam ACP mod.  Please visit http://www.lithiumstudios.org if you need help.';
		$lang['Test_Email_Header']						= 'You sent a test email from';
		$lang['Test_Username']							= 'Test Username';
		$lang['Test_Email']								= 'test@%s';
		$lang['Test_Message_Sent']						= 'Test email has been sent.';

	// Inactive Userlist
		$lang['Anti_Spam_ACP_Inactive_Userlist']		= 'Inactive Userlist';
		$lang['Anti_Spam_ACP_Userlist_Original_By']		= 'Created By: Milkboy31, wGEric';
		$lang['Anti_Spam_ACP_Userlist_Modified_By']		= 'Modified By: <a href="http://www.lithiumstudios.org" style="text-decoration:none">EXreaction</a>';
		$lang['Show']									= 'Show';
		$lang['Group']									= 'Group(s)';
		$lang['Find_all_posts']							= 'Find All Posts';
		$lang['User_manage']							= 'Manage';
		$lang['Select_All']								= 'Select All';
		$lang['Deselect_All']							= 'Deselect All';
		$lang['Select_one']								= 'Select One';
		$lang['Ban']									= 'Ban';
		$lang['UnBan']									= 'Un-Ban';
		$lang['Activate']								= 'Activate';

		$lang['Confirm_user_deleted']					= 'Are you sure you want to delete the selected user(s)?';
		$lang['User_deleted_successfully']				= 'User(s) deleted successfully!';
		$lang['Click_return_userlist']					= 'Click %shere%s to return to the Inactive Userlist';
		$lang['Confirm_user_ban']						= 'Are you sure you want to ban the selected user(s)?';
		$lang['User_banned_successfully']				= 'User(s) banned successfully!';
		$lang['Confirm_user_un_ban']					= 'Are you sure you want to unban the selected user(s)?';
		$lang['User_un_banned_successfully']			= 'User(s) unbanned successfully!';
		$lang['User_status_updated']					= 'User(s) status updated successfully!';

		$lang['All']									= 'All';
		$lang['Last_activity']							= 'Last Activity';
		$lang['User_level']								= 'User Level';
		$lang['Rank']									= 'Rank';
		$lang['Ascending']								= 'Ascending';
		$lang['Descending']								= 'Descending';
		$lang['Is_Banned']								= 'Banned!'; 
		$lang['Never']									= 'Never';

	// Profile Options
		$lang['Always_Off']								= 'Always Off';
		$lang['Reg_Off']								= 'Off For Registration';
		$lang['Always_On']								= 'Always On';
		$lang['Required']								= 'Required';
		$lang['By_Post_Count']							= 'Set According to Post Count';
		$lang['Post_Count']								= 'Post Count';

	// Log
		$lang['Confirm_Log_Clear']						= 'Are you sure you want to clear the log?';
		$lang['Log_Cleared']							= 'The log has been cleared successfully!';
		$lang['Clear_Log']								= 'Clear Log';
		$lang['Log_ID']									= 'Log ID';
		$lang['Date']									= 'Date';
		$lang['No_Entries_In_Log']						= 'No entries in the log.';


// registration check(includes/anti_spam_acp.php)
	$lang['Profile_Error']							= 'You incorrectly filled in the %s field.  Please go back and try again.';
	$lang['Profile_Error_Email']					= 'They incorrectly filled the %s field with "%s".';
	$lang['Not_Test_Email_Header']					= 'A user just attempted an illegal operation with their profile(while they were %s) on';
	$lang['Registering']							= 'registering';
	$lang['Editing_Profile']						= 'editing their profile';
	$lang['Registration']							= 'Registration';
	$lang['Error_With_Email']						= 'If you believe you recieved this message in error, please send an email to %s for help.';
	$lang['Error_Without_Email']					= 'If you believe you recieved this message in error, please contact the Board Administrator.';
?>