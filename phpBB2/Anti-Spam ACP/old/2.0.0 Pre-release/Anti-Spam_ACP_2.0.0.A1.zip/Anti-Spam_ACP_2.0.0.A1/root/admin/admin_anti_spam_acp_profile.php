<?php
/***************************************************************************
 *      admin_anti_spam_acp_profile.php
 *			-------------------
 *   copyright	: (C) 2006 EXreaction
 *   email		: exreaction@lithiumstudios.org
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *
 ***************************************************************************/

define('IN_PHPBB', 1);

if( !empty($setmodules) )
{
   $filename = basename(__FILE__);
   $module['Anti Spam']['Profile Options'] = $filename;

   return;
}

global $board_config, $phpEx;
$phpbb_root_path = './../';
require($phpbb_root_path . 'extension.inc');
require('./pagestart.' . $phpEx);

/*
* include the language file
*/
$language = ($userdata['user_lang'] != '') ? $userdata['user_lang'] : $board_config['default_lang'];

if (!file_exists($phpbb_root_path . 'language/lang_' . $language . '/lang_anti_spam_acp.' . $phpEx))
{
	message_die(GENERAL_MESSAGE, 'Anti-Spam ACP Mod language file does not exist: language/lang_' . $language . '/lang_anti_spam_acp.' . $phpEx);
}
include_once($phpbb_root_path . 'language/lang_' . $language . '/lang_anti_spam_acp.' . $phpEx);

function num_check($num)
{
	if ( ($num >= 1) && ($num <= 9999) )
	{
		return(true);
	}
	else
	{
		return(false);
	}
}

/*
* profile fields and lang variable array(so it will be easy to add extra sections to the check later if anyone wants)
* first field is the name of it, second is the lang variable name(the part between the '' in the $lang array, like ICQ for $lang['ICQ'])
*/
$profile_fields = array(
	'icq'	=> 'ICQ',
	'aim'	=> 'AIM',
	'msn'	=> 'MSNM',
	'yim'	=> 'YIM',
	'web'	=> 'Website',
	'loc'	=> 'Location',
	'occ'	=> 'Occupation',
	'int'	=> 'Interests',
	'sig'	=> 'Signature'
	);

// Check for new version
if ($board_config['as_acp_check_version'] == '1')
{
	$errno = 0;
	$errstr = $version_info = '';

	if ($fsock = @fsockopen('www.lithiumstudios.org', 80, $errno, $errstr, 10))
	{
		@fputs($fsock, "GET /updatecheck/anti_spam_acp_version.txt HTTP/1.1\r\n");
		@fputs($fsock, "HOST: www.lithiumstudios.org\r\n");
		@fputs($fsock, "Connection: close\r\n\r\n");

		$get_info = false;
		while (!@feof($fsock))
		{
			if ($get_info)
			{
				$version .= @fread($fsock, 1024);
			}
			else
			{
				if (@fgets($fsock, 1024) == "\r\n")
				{
					$get_info = true;
				}
			}
		}
		@fclose($fsock);

		$version = explode("\n", $version);
		$version = implode(".", $version);

		if ($version == $board_config['as_acp_version'])
		{
			$version_info = '<p style="color:green">' . $lang['AS_ACP_up_to_date'] . '</p>';
		}
		else
		{
			$version_info = '<p style="color:red">' . $lang['AS_ACP_not_up_to_date'];
			$version_info .= '<br />' . sprintf($lang['AS_ACP_Latest_Version'], $version) . ' ' . sprintf($lang['AS_ACP_Current_Version'], $board_config['as_acp_version']) . '</p>';
		}
	}
	else
	{
		if ($errstr)
		{
			$version_info = '<p style="color:red">' . sprintf($lang['Connect_socket_error'], $errstr) . '</p>';
		}
		else
		{
			$version_info = '<p>' . $lang['Socket_functions_disabled'] . '</p>';
		}
	}
}
$sql = "SELECT *
	FROM " . CONFIG_TABLE;
if(!$result = $db->sql_query($sql))
{
	message_die(CRITICAL_ERROR, "Could not query config information", "", __LINE__, __FILE__, $sql);
}
else
{
	$error = false;
	
	while( $row = $db->sql_fetchrow($result) )
	{
		$config_name = $row['config_name'];
		$config_value = $row['config_value'];
		$default_config[$config_name] = isset($HTTP_POST_VARS['submit']) ? str_replace("'", "\'", $config_value) : $config_value;
		
		$new[$config_name] = ( isset($HTTP_POST_VARS[$config_name]) ) ? $HTTP_POST_VARS[$config_name] : $default_config[$config_name];

		if( isset($HTTP_POST_VARS['submit']))
		{
			foreach ($profile_fields as $field)
			{
				// Check for illegal data and report if there is an error
				//if not legal get old data from board config
				if ( ($config_name == 'as_acp_' . $field . '_post') && (num_check($new['as_acp_' . $field . '_post']) == false) )
				{
					$error = true;
					$new['as_acp_' . $field . '_post'] = $row['config_value'];
				}
			}

			if ( ($config_name != 'sitename') && ($config_name != 'site_desc') ) // once in a while we get a very strange bug otherwise...so just skip these areas because we don't even change them
			{
				$sql = "UPDATE " . CONFIG_TABLE . " SET
					config_value = '" . str_replace("\'", "''", $new[$config_name]) . "'
					WHERE config_name = '$config_name'";
				if( !$db->sql_query($sql) )
				{
					message_die(GENERAL_ERROR, "Failed to update general configuration for $config_name", "", __LINE__, __FILE__, $sql);
				}
			}
		}
	}

	if( isset($HTTP_POST_VARS['submit']) )
	{
		if (!$error)
		{
			$message = $lang['Config_updated'] . '<br /><br />' . sprintf($lang['Click_return_AS_ACP'], "<a href=\"" . append_sid("admin_anti_spam_acp_profile.$phpEx") . "\">", "</a>") . '<br /><br />' . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");
		}
		else
		{
			$message = $lang['As_Acp_Update_Error'] . $lang['Config_updated'] . '<br /><br />' . sprintf($lang['Click_return_AS_ACP'], "<a href=\"" . append_sid("admin_anti_spam_acp_profile.$phpEx") . "\">", "</a>") . '<br /><br />' . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");
		}

		message_die(GENERAL_MESSAGE, $message);
	}
}

$template->set_filenames(array(
	'body' => 'admin/anti_spam_acp_profile.tpl')
);

foreach ($profile_fields as $field => $l_var)
{
	$template->assign_block_vars('field_row', array(
		'OFF'				=> ( $new['as_acp_' . $field] == 'off' ) ? "checked=\"checked\"" : "",
		'REG_OFF'			=> ( $new['as_acp_' . $field] == 'reg off' ) ? "checked=\"checked\"" : "",
		'POST_COUNT'		=> ( $new['as_acp_' . $field] == 'post count' ) ? "checked=\"checked\"" : "",
		'POSTS'				=> $new['as_acp_' . $field . '_post'],
		'ON'				=> ( $new['as_acp_' . $field] == 'on' ) ? "checked=\"checked\"" : "",
		'REQUIRED'			=> ( $new['as_acp_' . $field] == 'required' ) ? "checked=\"checked\"" : "",
		'NAME'				=> 'as_acp_' . $field,
		'L_TITLE'			=> $lang[$l_var])
		);
}

$template->assign_vars(array(
	'VERSION_INFO'					=> $version_info,

	'L_NUM_BOTS_CAUGHT'				=> sprintf($lang['Num_Bots_Caught'], $board_config['as_acp_bots_stopped']),
	'L_ANTI_SPAM_ACP_PAGE_SETTINGS'	=> sprintf($lang['AS_Page_Settings'], $board_config['as_acp_version']),
	'L_ANTI_SPAM_ACP'				=> $lang['Anti_Spam_ACP'],
	'L_ANTI_SPAM_ACP_CREATED_BY'	=> $lang['Anti_Spam_ACP_Created_By'],
	'L_OFF'							=> $lang['Always_Off'],
	'L_REG_OFF'						=> $lang['Reg_Off'],
	'L_ON'							=> $lang['Always_On'],
	'L_REQUIRED'					=> $lang['Required'],
	'L_POST_COUNT'					=> $lang['By_Post_Count'],
	'L_POSTS'						=> $lang['Post_Count'],
	'L_SUBMIT'						=> $lang['Submit'],
	'L_RESET'						=> $lang['Reset'],

	'S_CONFIG_ACTION'				=> append_sid("admin_anti_spam_acp_profile.$phpEx"))
	);
	
$template->pparse('body');

include('./page_footer_admin.'.$phpEx);
?>