<?php
/***************************************************************************
 *            anti_spam_acp.php
 * 			 -------------------
 *   copyright	: (C) 2006 EXreaction
 *   email		: exreaction@lithiumstudios.org
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *
 ***************************************************************************/

/*
* ignore
*/
if ( !defined('IN_PHPBB') )
{
	die("Hacking attempt");
}


/*
* include the language file
*/
$language = ($userdata['user_lang'] != '') ? $userdata['user_lang'] : $board_config['default_lang'];

if (!file_exists($phpbb_root_path . 'language/lang_' . $language . '/lang_anti_spam_acp.' . $phpEx))
{
	message_die(GENERAL_MESSAGE, 'Anti-Spam ACP Mod language file does not exist: language/lang_' . $language . '/lang_anti_spam_acp.' . $phpEx);
}
include_once($phpbb_root_path . 'language/lang_' . $language . '/lang_anti_spam_acp.' . $phpEx);


/*
* set some variables we might need
*  Using as_ prefix on variables just to make sure it doesn't get something messed up later on
*     and that my variables stay the same when I need them later
*/

$as_time = time();
$as_username = str_replace("\'", "''", phpbb_clean_username($HTTP_POST_VARS['username']));
$as_user_id = $userdata['user_id'];
$as_ip_address = get_ip();
$as_email = str_replace("\'", "''", trim(htmlspecialchars($HTTP_POST_VARS['email'])));
$as_location = $lang['During_Registration'];
$as_triggers = '';

// profile fields and post vars array(so it will be easy to add extra sections to the check later if anyone wants)
$profile_fields = array(
	'icq'	=> $HTTP_POST_VARS['icq'],
	'aim'	=> $HTTP_POST_VARS['aim'],
	'msn'	=> $HTTP_POST_VARS['msn'],
	'yim'	=> $HTTP_POST_VARS['yim'],
	'web'	=> $HTTP_POST_VARS['website'],
	'loc'	=> $HTTP_POST_VARS['location'],
	'occ'	=> $HTTP_POST_VARS['occupation'],
	'int'	=> $HTTP_POST_VARS['interests'],
	'sig'	=> $HTTP_POST_VARS['signature']
	);


/*
* functions
*/
function get_ip() // Gets the Users IP
{
	if (isSet($_SERVER))
	{
		if (isSet($_SERVER["HTTP_X_FORWARDED_FOR"]))
		{
			$realip = $_SERVER["HTTP_X_FORWARDED_FOR"];
		}
		elseif (isSet($_SERVER["HTTP_CLIENT_IP"]))
		{
			$realip = $_SERVER["HTTP_CLIENT_IP"];
		}
		else
		{
			$realip = $_SERVER["REMOTE_ADDR"];
		}
	}
	else
	{
		if ( getenv( 'HTTP_X_FORWARDED_FOR' ) )
		{
			$realip = getenv( 'HTTP_X_FORWARDED_FOR' );
		}
		elseif ( getenv( 'HTTP_CLIENT_IP' ) )
		{
			$realip = getenv( 'HTTP_CLIENT_IP' );
		}
		else
		{
			$realip = getenv( 'REMOTE_ADDR' );
		}
	}
	return $realip;
}


/*
* Ok, lets get started! :D
*/

/*
* Do the template switches...
*/
if ( ($userdata['user_level'] == ADMIN) || ($userdata['user_level'] == MOD) )
{
	foreach ($profile_fields as $field => $post_var)
	{
		$template->assign_block_vars('switch_edit_' . $field, array());
	}
	$template->assign_block_vars('switch_edit_all', array());
}
elseif ($mode == 'editprofile')
{
	$atleast_one_on = false;
	
	foreach ($profile_fields as $field => $post_var)
	{
		if ( ($board_config['as_acp_' . $field] == 'on') || ($board_config['as_acp_' . $field] == 'required') || ($board_config['as_acp_' . $field] == 'reg off') || ( ($board_config['as_acp_' . $field] == 'post count') && ($userdata['user_posts'] >= $board_config['as_acp_' . $field . '_post']) ) ) 
		{
			$template->assign_block_vars('switch_edit_' . $field, array());
			if ($board_config['as_acp_' . $field] == 'required')
			{
				$template->assign_vars(array(
					strtoupper($field) . '_REQUIRED'	=> ' *')
					);
			}
			$atleast_one_on = true;
		}
	}

	if ($atleast_one_on)
	{
		$template->assign_block_vars('switch_edit_all', array());
	}
}
elseif ($mode == 'register')
{
	$atleast_one_on = false;

	foreach ($profile_fields as $field => $post_var)
	{
		if ( ($board_config['as_acp_' . $field] == 'on') || ($board_config['as_acp_' . $field] == 'required') ) 
		{
			$template->assign_block_vars('switch_edit_' . $field, array());
			if ($board_config['as_acp_' . $field] == 'required')
			{
				$template->assign_vars(array(
					strtoupper($field) . '_REQUIRED'	=> ' *')
					);
			}
			$atleast_one_on = true;
		}
	}

	if ($atleast_one_on)
	{
		$template->assign_block_vars('switch_edit_all', array());
	}
}

/*
* check if someone didn't fill in something right
* if they have, send the email if wanted and give them a die message...
*/
if ( (isset($HTTP_POST_VARS['submit'])) && ($userdata['user_level'] != ADMIN) && ($userdata['user_level'] != MOD) )
{	
	if ($mode == 'register')
	{
		foreach ($profile_fields as $field => $post_var)
		{
			if ( ($post_var != '') && ( ($board_config['as_acp_' . $field] != 'on') && ($board_config['as_acp_' . $field] != 'required') ) )
			{
				$error = TRUE;
				$error_msg .= ( ( isset($error_msg) ) ? '<br />' : '' ) . sprintf($lang['Profile_Error'], $field);
				$as_triggers .= sprintf($lang['Profile_Error_Email'], $field, $post_var) . '%end_of_line%';
			}
			else if ( ($post_var == '') && ($board_config['as_acp_' . $field] == 'required') )
			{
				$error = TRUE;
				$error_msg .= ( ( isset($error_msg) ) ? '<br />' : '' ) . $lang['Fields_empty'];
				$as_triggers .= sprintf($lang['Profile_Error_Email_Required'], $field) . '%end_of_line%';
			}
		}
	}
	else if ($mode == 'editprofile')
	{
		foreach ($profile_fields as $field => $post_var)
		{
			if ( ($post_var != '') && ( ($board_config['as_acp_' . $field] == 'off') || ( ($board_config['as_acp_' . $field] == 'post count')  && ($userdata['user_posts'] < $board_config['as_acp_' . $field . '_post']) ) ) )
			{
				$error = TRUE;
				$error_msg .= ( ( isset($error_msg) ) ? '<br />' : '' ) . sprintf($lang['Profile_Error'], $field);
				$as_triggers .= sprintf($lang['Profile_Error_Email'], $field, $post_var) . '%end_of_line%';
			}
			else if ( ($post_var == '') && ($board_config['as_acp_' . $field] == 'required') )
			{
				$error = TRUE;
				$error_msg .= ( ( isset($error_msg) ) ? '<br />' : '' ) . $lang['Fields_empty'];
				$as_triggers .= sprintf($lang['Profile_Error_Email_Required'], $field) . '%end_of_line%';
			}
		}
	}

	$as_triggers = trim(htmlspecialchars($as_triggers));
	$as_triggers = stripslashes($as_triggers);

	if ( ($board_config['as_acp_notify_on_spam'] == '1') && ($as_triggers != '') )
	{
		include($phpbb_root_path . 'includes/emailer.' . $phpEx);
		$emailer = new emailer($board_config['smtp_delivery']);
		$emailer->from($board_config['board_email']);
		$emailer->replyto($board_config['board_email']);
		$emailer->use_template('admin_spam_notification');
		$emailer->email_address(explode(",", $HTTP_POST_VARS['as_acp_email_for_spam'], 2));
		$emailer->bcc($HTTP_POST_VARS['as_acp_email_for_spam']);
		$emailer->set_subject($lang['Spam_Bot_Attempt'] . $board_config['sitename']);

		$emailer->assign_vars(array(
			'NOTICE'		=> sprintf($lang['Not_Test_Email_Header'], ($mode == 'register') ? $lang['Registering'] : $lang['Editing_Profile']),
			'SITENAME'		=> $board_config['sitename'], 
			'USERNAME'		=> $HTTP_POST_VARS['username'],
			'IP'			=> $ip_address,
			'EMAIL'			=> $HTTP_POST_VARS['email'],
			'TRIGGERS'		=> str_replace('%end_of_line%', '\r\n', $as_triggers))
			);

		$emailer->send();
		$emailer->reset();
	}
}
?>