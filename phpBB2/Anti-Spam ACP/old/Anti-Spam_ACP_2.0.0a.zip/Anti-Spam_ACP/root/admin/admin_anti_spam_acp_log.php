<?php
/***************************************************************************
 *        admin_anti_spam_acp.php
 *			-------------------
 *   copyright	: (C) 2006 EXreaction
 *   email		: exreaction@lithiumstudios.org
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *
 ***************************************************************************/

define('IN_PHPBB', 1);

if( !empty($setmodules) )
{
   $filename = basename(__FILE__);
   $module['Anti Spam']['Spam Log'] = $filename;

   return;
}

global $board_config, $phpEx;
$phpbb_root_path = './../';
require($phpbb_root_path . 'extension.inc');
require('./pagestart.' . $phpEx);

/*
* include the language file
*/
$language = ($userdata['user_lang'] != '') ? $userdata['user_lang'] : $board_config['default_lang'];

if (!file_exists($phpbb_root_path . 'language/lang_' . $language . '/lang_anti_spam_acp.' . $phpEx))
{
	message_die(GENERAL_MESSAGE, 'Anti-Spam ACP Mod language file does not exist: language/lang_' . $language . '/lang_anti_spam_acp.' . $phpEx);
}
include_once($phpbb_root_path . 'language/lang_' . $language . '/lang_anti_spam_acp.' . $phpEx);

// Check for new version
if ($board_config['as_acp_check_version'] == '1')
{
	$errno = 0;
	$errstr = $version_info = '';

	if ($fsock = @fsockopen('www.lithiumstudios.org', 80, $errno, $errstr, 10))
	{
		@fputs($fsock, "GET /updatecheck/anti_spam_acp_version.txt HTTP/1.1\r\n");
		@fputs($fsock, "HOST: www.lithiumstudios.org\r\n");
		@fputs($fsock, "Connection: close\r\n\r\n");

		$get_info = false;
		while (!@feof($fsock))
		{
			if ($get_info)
			{
				$version .= @fread($fsock, 1024);
			}
			else
			{
				if (@fgets($fsock, 1024) == "\r\n")
				{
					$get_info = true;
				}
			}
		}
		@fclose($fsock);

		$version = explode("\n", $version);
		$version = implode(".", $version);

		if ($version == $board_config['as_acp_version'])
		{
			$version_info = '<p style="color:green">' . $lang['AS_ACP_up_to_date'] . '</p>';
		}
		else
		{
			$version_info = '<p style="color:red">' . $lang['AS_ACP_not_up_to_date'];
			$version_info .= '<br />' . sprintf($lang['AS_ACP_Latest_Version'], $version) . ' ' . sprintf($lang['AS_ACP_Current_Version'], $board_config['as_acp_version']) . '</p>';
		}
	}
	else
	{
		if ($errstr)
		{
			$version_info = '<p style="color:red">' . sprintf($lang['Connect_socket_error'], $errstr) . '</p>';
		}
		else
		{
			$version_info = '<p>' . $lang['Socket_functions_disabled'] . '</p>';
		}
	}
}

if( isset( $HTTP_POST_VARS['mode'] ) || isset( $HTTP_GET_VARS['mode'] ) )
{
	$mode = ( isset($HTTP_POST_VARS['mode']) ) ? $HTTP_POST_VARS['mode'] : $HTTP_GET_VARS['mode'];
}
else
{
	$mode = '';
}

if( isset( $HTTP_POST_VARS['confirm'] ) || isset( $HTTP_GET_VARS['confirm'] ) )
{
	$confirm = true;
}
else
{
	$confirm = false;
}

if( isset( $HTTP_POST_VARS['cancel'] ) || isset( $HTTP_GET_VARS['cancel'] ) )
{
	$cancel = true;
	$mode = '';
}
else
{
	$cancel = false;
}

if ($mode == 'delete')
{
	//
	// see if cancel has been hit and redirect if it has
	//
	if ( $cancel )
	{
		redirect('admin_anti_spam_acp_log.'.$phpEx);
	}

	//
	// check confirm and either delete or show confirm message
	//
	if ( !$confirm )
	{
		// show message
		$template->set_filenames(array(
			'body' => 'confirm_body.tpl')
		);

		$template->assign_vars(array(
			'MESSAGE_TITLE' => $lang['Delete'],
			'MESSAGE_TEXT' => $lang['Confirm_Log_Clear'],
			'U_INDEX' => '',
			'L_INDEX' => '',
			'L_YES' => $lang['Yes'],
			'L_NO' => $lang['No'],
			'S_CONFIRM_ACTION' => append_sid('admin_anti_spam_acp_log.'.$phpEx . '?mode=delete'))
			);

		$template->pparse('body');
	}
	else
	{
		$sql = "TRUNCATE TABLE " . SPAM_LOG_TABLE;
		if(!$result = $db->sql_query($sql))
		{
			message_die(CRITICAL_ERROR, "Could not clear log table.", "", __LINE__, __FILE__, $sql);
		}

		$message = $lang['Log_Cleared'] . "<br /><br />" . sprintf($lang['Click_return_AS_ACP'], "<a href=\"" . append_sid("admin_anti_spam_acp_log.$phpEx") . "\">", "</a>") . "<br /><br />" . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");
		message_die(GENERAL_MESSAGE, $message);
	}	
}
else
{
	$sql = "SELECT * FROM " . SPAM_LOG_TABLE . "
				ORDER BY log_id ASC";
	if(!$result = $db->sql_query($sql))
	{
		message_die(CRITICAL_ERROR, "Could not query log information", "", __LINE__, __FILE__, $sql);
	}

	if ($db->sql_numrows($result) == 0)
	{
		$template->assign_block_vars('no_rows', array());
	}
	else
	{
		while($row = $db->sql_fetchrow($result))
		{
			$date = create_date($board_config['default_dateformat'], $row['log_time'], $board_config['board_timezone']);
			$manage_user_url = append_sid('admin_users.'.$phpEx.'?mode=edit&amp;' . POST_USERS_URL . '=' . $row['user_id']);
			$template->assign_block_vars('log_row', array(
				'LOG_ID'			=> $row['log_id'],
				'DATE'				=> $date,
				'USERNAME'			=> ($row['user_id'] == -1) ? $row['username'] : '<a href="' . $manage_user_url . '">' . $row['username'] . '</a>',
				'LOCATION'			=> $row['location'],
				'USER_IP'			=> $row['user_ip'],
				'USER_EMAIL'		=> $row['user_email'],
				'TRIGGERS'			=> $row['log_triggers'])
				);
		}
	}

	if ($db->sql_numrows($result) >= 18)
	{
		$template->assign_block_vars('submit_top', array());
	}

	$template->set_filenames(array(
		'body' => 'admin/anti_spam_acp_log.tpl')
	);
	$template->assign_vars(array(
		'L_ANTI_SPAM_ACP'						=> $lang['Anti_Spam_ACP'],
		'L_ANTI_SPAM_ACP_CREATED_BY'			=> $lang['Anti_Spam_ACP_Created_By'],
		'VERSION_INFO'							=> $version_info,
		'S_ACTION'								=> append_sid("admin_anti_spam_acp_log.$phpEx"),

		'L_LOG_ID'								=> $lang['Log_ID'],
		'L_DATE'								=> $lang['Date'],
		'L_USERNAME'							=> $lang['Username'],
		'L_LOCATION'							=> $lang['Location'],
		'L_USER_IP'								=> $lang['IP_Address'],
		'L_USER_EMAIL'							=> $lang['Email_Address'],

		'L_NO_ROWS'								=> $lang['No_Entries_In_Log'],
		'L_SELECT'								=> $lang['Select_one'],
		'L_CLEAR_LOG'							=> $lang['Clear_Log'],
		'L_GO'									=> $lang['Go'],

		'L_NUM_BOTS_CAUGHT'						=> sprintf($lang['Num_Bots_Caught'], $board_config['as_acp_bots_stopped']))
		);

	$template->pparse('body');

	include('./page_footer_admin.'.$phpEx);
}
?>