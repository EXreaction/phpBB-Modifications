<?php 
define('IN_PHPBB', 1);

if( !empty($setmodules) )
{
   $filename = basename(__FILE__);
   $module[$lang['Anti_Spam']][$lang['Anti_Spam_ACP']] = $filename;

   return;
}

global $phpEx;
$phpbb_root_path = './../';
require($phpbb_root_path . 'extension.inc');
require('./pagestart.' . $phpEx);

function num_check($num)
{
	if ( ($num >= 1) && ($num <= 9999) )
	{
		return(true);
	}
	else
	{
		return(false);
	}
}

$sql = "SELECT *
	FROM " . CONFIG_TABLE;
if(!$result = $db->sql_query($sql))
{
	message_die(CRITICAL_ERROR, "Could not query config information", "", __LINE__, __FILE__, $sql);
}
else
{
	$error = false;
	
	while( $row = $db->sql_fetchrow($result) )
	{
		$config_name = $row['config_name'];
		$config_value = $row['config_value'];
		$default_config[$config_name] = isset($HTTP_POST_VARS['submit']) ? str_replace("'", "\'", $config_value) : $config_value;
		
		$new[$config_name] = ( isset($HTTP_POST_VARS[$config_name]) ) ? $HTTP_POST_VARS[$config_name] : $default_config[$config_name];

		if( isset($HTTP_POST_VARS['submit']) || isset($HTTP_POST_VARS['test_mail']) )
		{
			// Check for illegal data and report if there is an error
			// temp set this as false...
			//if ! legal get old data from board config
			if ( ($config_name == 'as_acp_icq_post') && (num_check($new['as_acp_icq_post']) == false) )
			{
				$error = true;
				$new['as_acp_icq_post'] = $row['config_value'];
			}
			elseif ( ($config_name == 'as_acp_aim_post') && (num_check($new['as_acp_aim_post']) == false) )
			{
				$error = true;
				$new['as_acp_aim_post'] = $row['config_value'];
			}
			elseif ( ($config_name == 'as_acp_msn_post') && (num_check($new['as_acp_msn_post']) == false) )
			{
				$error = true;
				$new['as_acp_msn_post'] = $row['config_value'];
			}
			elseif ( ($config_name == 'as_acp_yim_post') && (num_check($new['as_acp_yim_post']) == false) )
			{
				$error = true;
				$new['as_acp_yim_post'] = $row['config_value'];
			}
			elseif ( ($config_name == 'as_acp_web_post') && (num_check($new['as_acp_web_post']) == false) )
			{
				$error = true;
				$new['as_acp_web_post'] = $row['config_value'];
			}
			elseif ( ($config_name == 'as_acp_loc_post') && (num_check($new['as_acp_loc_post']) == false) )
			{
				$error = true;
				$new['as_acp_loc_post'] = $row['config_value'];
			}
			elseif ( ($config_name == 'as_acp_occ_post') && (num_check($new['as_acp_occ_post']) == false) )
			{
				$error = true;
				$new['as_acp_occ_post'] = $row['config_value'];
			}
			elseif ( ($config_name == 'as_acp_int_post') && (num_check($new['as_acp_int_post']) == false) )
			{
				$error = true;
				$new['as_acp_int_post'] = $row['config_value'];
			}
			elseif ( ($config_name == 'as_acp_sig_post') && (num_check($new['as_acp_sig_post']) == false) )
			{
				$error = true;
				$new['as_acp_sig_post'] = $row['config_value'];
			}

			$sql = "UPDATE " . CONFIG_TABLE . " SET
				config_value = '" . str_replace("\'", "''", $new[$config_name]) . "'
				WHERE config_name = '$config_name'";
			if( !$db->sql_query($sql) )
			{
				message_die(GENERAL_ERROR, "Failed to update general configuration for $config_name", "", __LINE__, __FILE__, $sql);
			}
		}
	}

	if( isset($HTTP_POST_VARS['submit']) )
	{
		if (!$error)
		{
			$message = $lang['Config_updated'] . '<br /><br />' . sprintf($lang['Click_return_AS_ACP'], "<a href=\"" . append_sid("admin_anti_spam.$phpEx") . "\">", "</a>") . '<br /><br />' . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");
		}
		else
		{
			$message = $lang['As_Acp_Update_Error'] . $lang['Config_updated'] . '<br /><br />' . sprintf($lang['Click_return_AS_ACP'], "<a href=\"" . append_sid("admin_anti_spam.$phpEx") . "\">", "</a>") . '<br /><br />' . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");
		}

		message_die(GENERAL_MESSAGE, $message);
	}
	else if( isset($HTTP_POST_VARS['test_mail']) )
	{
		include($phpbb_root_path . 'includes/functions_anti_spam_acp.'.$phpEx);

		$profile_data = array(
			'username'	=> $lang['Test_Username'],
			'password'	=> $lang['Test_Password'],
			'email'		=> sprintf($lang['Test_Email'], $board_config['server_name']),
			'ip'		=> '0.0.0.0',
			'icq'		=> '000000000',
			'aim'		=> 'AIM',
			'msn'		=> 'MSN@hotmail.com',
			'yim'		=> 'YIM',
			'web'		=> 'http://www.testwebsite.com',
			'loc'		=> $board_config['sitename'],
			'occ'		=> $lang['Test_Occupation'],
			'int'		=> $lang['Test_Interests'],
			'sig'		=> $lang['Test_Signature']
		);

		send_spam_email($profile_data, true);

		if (!$error)
		{
			$message = $lang['Message_Sent'] . '<br />' . $lang['Config_updated'] . '<br /><br />' . sprintf($lang['Click_return_AS_ACP'], "<a href=\"" . append_sid("admin_anti_spam.$phpEx") . "\">", "</a>") . '<br /><br />' . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");
		}
		else
		{
			$message = $lang['Message_Sent'] . '<br />' . $lang['As_Acp_Update_Error'] . $lang['Config_updated'] . '<br /><br />' . sprintf($lang['Click_return_AS_ACP'], "<a href=\"" . append_sid("admin_anti_spam.$phpEx") . "\">", "</a>") . '<br /><br />' . sprintf($lang['Click_return_admin_index'], "<a href=\"" . append_sid("index.$phpEx?pane=right") . "\">", "</a>");
		}

		message_die(GENERAL_MESSAGE, $message);
	}

}
$icq_off			= ( $new['as_acp_icq']	== 'off' )			? "checked=\"checked\"" : "";
$icq_reg_off		= ( $new['as_acp_icq']	== 'reg off' )		? "checked=\"checked\"" : "";
$icq_on				= ( $new['as_acp_icq']	== 'on' )			? "checked=\"checked\"" : "";
$icq_post_count		= ( $new['as_acp_icq']	== 'post count' )	? "checked=\"checked\"" : "";

$aim_off			= ( $new['as_acp_aim']	== 'off' )			? "checked=\"checked\"" : "";
$aim_reg_off		= ( $new['as_acp_aim']	== 'reg off' )		? "checked=\"checked\"" : "";
$aim_on				= ( $new['as_acp_aim']	== 'on' )			? "checked=\"checked\"" : "";
$aim_post_count		= ( $new['as_acp_aim']	== 'post count' )	? "checked=\"checked\"" : "";

$msn_off			= ( $new['as_acp_msn']	== 'off' )			? "checked=\"checked\"" : "";
$msn_reg_off		= ( $new['as_acp_msn']	== 'reg off' )		? "checked=\"checked\"" : "";
$msn_on				= ( $new['as_acp_msn']	== 'on' )			? "checked=\"checked\"" : "";
$msn_post_count		= ( $new['as_acp_msn']	== 'post count' )	? "checked=\"checked\"" : "";

$yim_off			= ( $new['as_acp_yim']	== 'off' )			? "checked=\"checked\"" : "";
$yim_reg_off		= ( $new['as_acp_yim']	== 'reg off' )		? "checked=\"checked\"" : "";
$yim_on				= ( $new['as_acp_yim']	== 'on' )			? "checked=\"checked\"" : "";
$yim_post_count		= ( $new['as_acp_yim']	== 'post count' )	? "checked=\"checked\"" : "";

$web_off			= ( $new['as_acp_web']	== 'off' )			? "checked=\"checked\"" : "";
$web_reg_off		= ( $new['as_acp_web']	== 'reg off' )		? "checked=\"checked\"" : "";
$web_on				= ( $new['as_acp_web']	== 'on' )			? "checked=\"checked\"" : "";
$web_post_count		= ( $new['as_acp_web']	== 'post count' )	? "checked=\"checked\"" : "";

$loc_off			= ( $new['as_acp_loc']	== 'off' )			? "checked=\"checked\"" : "";
$loc_reg_off		= ( $new['as_acp_loc']	== 'reg off' )		? "checked=\"checked\"" : "";
$loc_on				= ( $new['as_acp_loc']	== 'on' )			? "checked=\"checked\"" : "";
$loc_post_count		= ( $new['as_acp_loc']	== 'post count' )	? "checked=\"checked\"" : "";

$occ_off			= ( $new['as_acp_occ']	== 'off' )			? "checked=\"checked\"" : "";
$occ_reg_off		= ( $new['as_acp_occ']	== 'reg off' )		? "checked=\"checked\"" : "";
$occ_on				= ( $new['as_acp_occ']	== 'on' )			? "checked=\"checked\"" : "";
$occ_post_count		= ( $new['as_acp_occ']	== 'post count' )	? "checked=\"checked\"" : "";

$int_off			= ( $new['as_acp_int']	== 'off' )			? "checked=\"checked\"" : "";
$int_reg_off		= ( $new['as_acp_int']	== 'reg off' )		? "checked=\"checked\"" : "";
$int_on				= ( $new['as_acp_int']	== 'on' )			? "checked=\"checked\"" : "";
$int_post_count		= ( $new['as_acp_int']	== 'post count' )	? "checked=\"checked\"" : "";

$sig_off			= ( $new['as_acp_sig']	== 'off' )			? "checked=\"checked\"" : "";
$sig_reg_off		= ( $new['as_acp_sig']	== 'reg off' )		? "checked=\"checked\"" : "";
$sig_on				= ( $new['as_acp_sig']	== 'on' )			? "checked=\"checked\"" : "";
$sig_post_count		= ( $new['as_acp_sig']	== 'post count' )	? "checked=\"checked\"" : "";

$show_mail_enable	= ( $new['as_acp_show_email_on_die']	== '1' )		? "checked=\"checked\"" : "";
$show_mail_disable	= ( $new['as_acp_show_email_on_die']	== '0' )		? "checked=\"checked\"" : "";

$send_mail_enable	= ( $new['as_acp_notify_on_spam']		== '1' )		? "checked=\"checked\"" : "";
$send_mail_disable	= ( $new['as_acp_notify_on_spam']		== '0' )		? "checked=\"checked\"" : "";

$template->set_filenames(array(
	'body' => 'admin/anti_spam.tpl')
);
$template->assign_vars(array(
	'ICQ_OFF'			=> $icq_off,
	'ICQ_REG_OFF'		=> $icq_reg_off,
	'ICQ_ON'			=> $icq_on,
	'ICQ_POST_COUNT'	=> $icq_post_count,
	'ICQ_POSTS'			=> $new['as_acp_icq_post'],
	
	'AIM_OFF'			=> $aim_off,
	'AIM_REG_OFF'		=> $aim_reg_off,
	'AIM_ON'			=> $aim_on,
	'AIM_POST_COUNT'	=> $aim_post_count,
	'AIM_POSTS'			=> $new['as_acp_aim_post'],
	
	'MSN_OFF'			=> $msn_off,
	'MSN_REG_OFF'		=> $msn_reg_off,
	'MSN_ON'			=> $msn_on,
	'MSN_POST_COUNT'	=> $msn_post_count,
	'MSN_POSTS'			=> $new['as_acp_msn_post'],

	'YIM_OFF'			=> $yim_off,
	'YIM_REG_OFF'		=> $yim_reg_off,
	'YIM_ON'			=> $yim_on,
	'YIM_POST_COUNT'	=> $yim_post_count,
	'YIM_POSTS'			=> $new['as_acp_yim_post'],

	'WEB_OFF'			=> $web_off,
	'WEB_REG_OFF'		=> $web_reg_off,
	'WEB_ON'			=> $web_on,
	'WEB_POST_COUNT'	=> $web_post_count,
	'WEB_POSTS'			=> $new['as_acp_web_post'],

	'LOC_OFF'			=> $loc_off,
	'LOC_REG_OFF'		=> $loc_reg_off,
	'LOC_ON'			=> $loc_on,
	'LOC_POST_COUNT'	=> $loc_post_count,
	'LOC_POSTS'			=> $new['as_acp_loc_post'],

	'OCC_OFF'			=> $occ_off,
	'OCC_REG_OFF'		=> $occ_reg_off,
	'OCC_ON'			=> $occ_on,
	'OCC_POST_COUNT'	=> $occ_post_count,
	'OCC_POSTS'			=> $new['as_acp_occ_post'],

	'INT_OFF'			=> $int_off,
	'INT_REG_OFF'		=> $int_reg_off,
	'INT_ON'			=> $int_on,
	'INT_POST_COUNT'	=> $int_post_count,
	'INT_POSTS'			=> $new['as_acp_int_post'],
	
	'SIG_OFF'			=> $sig_off,
	'SIG_REG_OFF'		=> $sig_reg_off,
	'SIG_ON'			=> $sig_on,
	'SIG_POST_COUNT'	=> $sig_post_count,
	'SIG_POSTS'			=> $new['as_acp_sig_post'],

	'EMAIL'				=> $new['as_acp_email_for_spam'],

	'SEND_MAIL_ENABLE'	=> $send_mail_enable,
	'SEND_MAIL_DISABLE'	=> $send_mail_disable,
	
	'SHOW_MAIL_ENABLE'	=> $show_mail_enable,
	'SHOW_MAIL_DISABLE'	=> $show_mail_disable,

	'L_ICQ'							=> $lang['ICQ'],
	'L_AIM'							=> $lang['AIM'],
	'L_MSN'							=> $lang['MSNM'],
	'L_YIM'							=> $lang['YIM'],
	'L_WEBSITE'						=> $lang['Website'],
	'L_LOCATION'					=> $lang['Location'],
	'L_OCCUPATION'					=> $lang['Occupation'],
	'L_INTERESTS'					=> $lang['Interests'],
	'L_SIGNATURE'					=> $lang['Signature'],

	'L_EMAIL_ADDRESS'				=> $lang['Email_Address'],
	'L_EMAIL_ADDRESS_EXPLAIN'		=> $lang['Email_Address_Explain'],

	'L_SHOW_MAIL'					=> $lang['Show_Email'],
	'L_SHOW_MAIL_EXPLAIN'			=> $lang['Show_Email_Explain'],

	'L_SEND_MAIL'					=> $lang['Send_Email'],
	'L_SEND_MAIL_EXPLAIN'			=> $lang['Send_Email_Explain'],

	'L_TEST_MAIL'					=> $lang['L_Test_Mail'],
	'L_TEST_MAIL_EXPLAIN'			=> $lang['L_Test_Mail_Explain'],

	'L_ANTI_SPAM_ACP_PAGE_SETTINGS'	=> $lang['AS_Page_Settings'],

	'L_OFF'							=> $lang['Always_Off'],
	'L_REG_OFF'						=> $lang['Reg_Off'],
	'L_ON'							=> $lang['On'],
	'L_POST_COUNT'					=> $lang['By_Post_Count'],
	'L_POSTS'						=> $lang['Post_Count'],
	'L_YES'							=> $lang['Yes'],
	'L_NO'							=> $lang['No'],
	'L_SUBMIT'						=> $lang['Submit'],
	'L_RESET'						=> $lang['Reset'],
));
	
$template->pparse('body');

include('./page_footer_admin.'.$phpEx);
?>