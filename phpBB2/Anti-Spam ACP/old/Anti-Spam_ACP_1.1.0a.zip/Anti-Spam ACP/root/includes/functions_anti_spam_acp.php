<?php
/***************************************************************************
 *                               functions_anti_spam_acp.php
 *                            -------------------
 *   begin		: Sunday, August 27, 2006
 *   copyright	: (C) 2006 EXreaction
 *   email		: exreaction@lithiumstudios.org
 *
 *
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *
 ***************************************************************************/

/*
*   Check the inputed fields to see if they entered anything that isn't allowed
*/

function check_for_spam($profile_data, $post_count, $mode)
{
	global $board_config;
	
	$spam = false;
	
 	if ($mode == 'register')
	{
		if		( ($profile_data['icq'] != '')	&&	($board_config['as_acp_icq'] != 'on') )	{$spam=true;}
		else if ( ($profile_data['aim'] != '')	&&	($board_config['as_acp_aim'] != 'on') )	{$spam=true;}
		else if ( ($profile_data['msn'] != '')	&&	($board_config['as_acp_msn'] != 'on') )	{$spam=true;}
		else if ( ($profile_data['yim'] != '')	&&	($board_config['as_acp_aim'] != 'on') )	{$spam=true;}
		else if ( ($profile_data['web'] != '')	&&	($board_config['as_acp_web'] != 'on') )	{$spam=true;}
		else if ( ($profile_data['loc'] != '')	&&	($board_config['as_acp_loc'] != 'on') )	{$spam=true;}
		else if ( ($profile_data['occ'] != '')	&&	($board_config['as_acp_occ'] != 'on') )	{$spam=true;}
		else if ( ($profile_data['int'] != '')	&&	($board_config['as_acp_int'] != 'on') )	{$spam=true;}
		else if ( ($profile_data['sig'] != '')	&&	($board_config['as_acp_sig'] != 'on') )	{$spam=true;}
	}
	else if ($mode == 'editprofile')
	{
		if		( ($profile_data['icq'] != '')	&&	( ($board_config['as_acp_icq'] == 'off') || ( ($board_config['as_acp_icq'] == 'post count') && ($post_count < $board_config['as_acp_icq_post']) ) ) )	{$spam=true;}
		else if ( ($profile_data['aim'] != '')	&&	( ($board_config['as_acp_aim'] == 'off') || ( ($board_config['as_acp_aim'] == 'post count') && ($post_count < $board_config['as_acp_aim_post']) ) ) )	{$spam=true;}
		else if ( ($profile_data['msn'] != '')	&&	( ($board_config['as_acp_msn'] == 'off') || ( ($board_config['as_acp_msn'] == 'post count') && ($post_count < $board_config['as_acp_msn_post']) ) ) )	{$spam=true;}
		else if ( ($profile_data['yim'] != '')	&&	( ($board_config['as_acp_yim'] == 'off') || ( ($board_config['as_acp_yim'] == 'post count') && ($post_count < $board_config['as_acp_yim_post']) ) ) )	{$spam=true;}
		else if ( ($profile_data['web'] != '')	&&	( ($board_config['as_acp_web'] == 'off') || ( ($board_config['as_acp_web'] == 'post count') && ($post_count < $board_config['as_acp_web_post']) ) ) )	{$spam=true;}
		else if ( ($profile_data['loc'] != '')	&&	( ($board_config['as_acp_loc'] == 'off') || ( ($board_config['as_acp_loc'] == 'post count') && ($post_count < $board_config['as_acp_loc_post']) ) ) )	{$spam=true;}
		else if ( ($profile_data['occ'] != '')	&&	( ($board_config['as_acp_occ'] == 'off') || ( ($board_config['as_acp_occ'] == 'post count') && ($post_count < $board_config['as_acp_occ_post']) ) ) )	{$spam=true;}
		else if ( ($profile_data['int'] != '')	&&	( ($board_config['as_acp_int'] == 'off') || ( ($board_config['as_acp_int'] == 'post count') && ($post_count < $board_config['as_acp_int_post']) ) ) )	{$spam=true;}
		else if ( ($profile_data['sig'] != '')	&&	( ($board_config['as_acp_sig'] == 'off') || ( ($board_config['as_acp_sig'] == 'post count') && ($post_count < $board_config['as_acp_sig_post']) ) ) )	{$spam=true;}
	}

	return($spam);
}
 
/*
*   Send the the spam mail out
*/
function send_spam_email($profile_data, $mode, $test = false)
{
	global $board_config, $lang, $phpEx;
	include('emailer.' . $phpEx);
	
 	if ( ($board_config['as_acp_notify_on_spam'] == '1') || ($test == true) )
	{

		$triggers ='';

		if ($profile_data['icq'] != '') $triggers .= $lang['ICQ'] 			. ': '	.	$profile_data['icq'] . "\r\n";
		if ($profile_data['aim'] != '') $triggers .= $lang['AIM'] 			. ': '	.	$profile_data['aim'] . "\r\n";
		if ($profile_data['msn'] != '') $triggers .= $lang['MSNM'] 			. ': '	.	$profile_data['msn'] . "\r\n";
		if ($profile_data['yim'] != '') $triggers .= $lang['YIM']			. ': '	.	$profile_data['yim'] . "\r\n";
		if ($profile_data['web'] != '') $triggers .= $lang['Website']		. ': '	.	$profile_data['web'] . "\r\n";
		if ($profile_data['loc'] != '') $triggers .= $lang['Location']		. ': '	.	$profile_data['loc'] . "\r\n";
		if ($profile_data['occ'] != '') $triggers .= $lang['Occupation']	. ': '	.	$profile_data['occ'] . "\r\n";
		if ($profile_data['int'] != '') $triggers .= $lang['Interests']		. ': '	.	$profile_data['int'] . "\r\n";
		if ($profile_data['sig'] != '') $triggers .= $lang['Signature']		. ': '	.	$profile_data['sig'] . "\r\n";

		$notice = ($test) ? $lang['Test_Email_Header'] : sprintf($lang['Not_Test_Email_Header'], ($mode == 'register') ? $lang['Registering'] : $lang['Editing_Profile']) ;

		$emailer = new emailer($board_config['smtp_delivery']);
		$emailer->from($board_config['board_email']);
		$emailer->replyto($board_config['board_email']);
		$emailer->use_template('admin_spam_message');
		$emailer->email_address($board_config['as_acp_email_for_spam']);
		$emailer->set_subject('Spam Bot attempt at ' . $board_config['sitename']);

		$emailer->assign_vars(array(
			'NOTICE'		=> $notice,
			'SITENAME'		=> $board_config['sitename'], 
			'USERNAME'		=> $profile_data['username'],
			'IP'			=> $profile_data['ip'],
			'PASSWORD'		=> ($test == true) ? $profile_data['password'] : ($mode == 'register') ? $profile_data['password'] : $lang['Not_Avalible'],
			'EMAIL'			=> $profile_data['email'],
			'TRIGGERS'		=> $triggers
		));

		$emailer->send();
		$emailer->reset();

	}
}

/*
* Set the template switches on if they should be on...
*/

if ( ($userdata['user_level'] == ADMIN) || ($userdata['user_level'] == MOD) )
{
	$template->assign_block_vars('switch_edit_all', array());
	$template->assign_block_vars('switch_edit_icq', array());
	$template->assign_block_vars('switch_edit_aim', array());

	$template->assign_block_vars('switch_edit_msn', array());
	$template->assign_block_vars('switch_edit_yim', array());
	$template->assign_block_vars('switch_edit_web', array());
	$template->assign_block_vars('switch_edit_loc', array());
	$template->assign_block_vars('switch_edit_occ', array());
	$template->assign_block_vars('switch_edit_int', array());
	$template->assign_block_vars('switch_edit_sig', array());
}
elseif ($mode == 'editprofile')
{
	$aleast_one_on = false;

	if ( ($board_config['as_acp_icq'] == 'on') || ($board_config['as_acp_icq'] == 'reg off') || ( ($board_config['as_acp_icq'] == 'post count') && ($userdata['user_posts'] >= $board_config['as_acp_icq_post']) ) ) 
	{
		$template->assign_block_vars('switch_edit_icq', array());
		$aleast_one_on = true;
	}
	if ( ($board_config['as_acp_aim'] == 'on') || ($board_config['as_acp_aim'] == 'reg off') || ( ($board_config['as_acp_aim'] == 'post count') && ($userdata['user_posts'] >= $board_config['as_acp_aim_post']) ) )
	{
		$template->assign_block_vars('switch_edit_aim', array());
		$aleast_one_on = true;
	}
	if ( ($board_config['as_acp_msn'] == 'on') || ($board_config['as_acp_msn'] == 'reg off') || ( ($board_config['as_acp_msn'] == 'post count') && ($userdata['user_posts'] >= $board_config['as_acp_msn_post']) ) )
	{
		$template->assign_block_vars('switch_edit_msn', array());
		$aleast_one_on = true;
	}
	if ( ($board_config['as_acp_yim'] == 'on') || ($board_config['as_acp_yim'] == 'reg off') || ( ($board_config['as_acp_yim'] == 'post count') && ($userdata['user_posts'] >= $board_config['as_acp_yim_post']) ) )
	{
		$template->assign_block_vars('switch_edit_yim', array());
		$aleast_one_on = true;
	}
	if ( ($board_config['as_acp_web'] == 'on') || ($board_config['as_acp_web'] == 'reg off') || ( ($board_config['as_acp_web'] == 'post count') && ($userdata['user_posts'] >= $board_config['as_acp_web_post']) ) )
	{
		$template->assign_block_vars('switch_edit_web', array());
		$aleast_one_on = true;
	}
	if ( ($board_config['as_acp_loc'] == 'on') || ($board_config['as_acp_loc'] == 'reg off') || ( ($board_config['as_acp_loc'] == 'post count') && ($userdata['user_posts'] >= $board_config['as_acp_loc_post']) ) )
	{
		$template->assign_block_vars('switch_edit_loc', array());
		$aleast_one_on = true;
	}
	if ( ($board_config['as_acp_occ'] == 'on') || ($board_config['as_acp_occ'] == 'reg off') || ( ($board_config['as_acp_occ'] == 'post count') && ($userdata['user_posts'] >= $board_config['as_acp_occ_post']) ) )
	{
		$template->assign_block_vars('switch_edit_occ', array());
		$aleast_one_on = true;
	}
	if ( ($board_config['as_acp_int'] == 'on') || ($board_config['as_acp_int'] == 'reg off') || ( ($board_config['as_acp_int'] == 'post count') && ($userdata['user_posts'] >= $board_config['as_acp_int_post']) ) )
	{
		$template->assign_block_vars('switch_edit_int', array());
		$aleast_one_on = true;
	}
	if ( ($board_config['as_acp_sig'] == 'on') || ($board_config['as_acp_sig'] == 'reg off') || ( ($board_config['as_acp_sig'] == 'post count') && ($userdata['user_posts'] >= $board_config['as_acp_sig_post']) ) )
	{
		$template->assign_block_vars('switch_edit_sig', array());
		$aleast_one_on = true;
	}

	if ($aleast_one_on)
	{
		$template->assign_block_vars('switch_edit_all', array());
	}
}
elseif ($mode == 'register')
{
	$aleast_one_on = false;

	if ($board_config['as_acp_icq'] == 'on') 
	{
		$template->assign_block_vars('switch_edit_icq', array());
		$aleast_one_on = true;
	}
	if ($board_config['as_acp_aim'] == 'on')
	{
		$template->assign_block_vars('switch_edit_aim', array());
		$aleast_one_on = true;
	}
	if ($board_config['as_acp_msn'] == 'on')
	{
		$template->assign_block_vars('switch_edit_msn', array());
		$aleast_one_on = true;
	}
	if ($board_config['as_acp_yim'] == 'on')
	{
		$template->assign_block_vars('switch_edit_yim', array());
		$aleast_one_on = true;
	}
	if ($board_config['as_acp_web'] == 'on')
	{
		$template->assign_block_vars('switch_edit_web', array());
		$aleast_one_on = true;
	}
	if ($board_config['as_acp_loc'] == 'on')
	{
		$template->assign_block_vars('switch_edit_loc', array());
		$aleast_one_on = true;
	}
	if ($board_config['as_acp_occ'] == 'on')
	{
		$template->assign_block_vars('switch_edit_occ', array());
		$aleast_one_on = true;
	}
	if ($board_config['as_acp_int'] == 'on')
	{
		$template->assign_block_vars('switch_edit_int', array());
		$aleast_one_on = true;
	}
	if ($board_config['as_acp_sig'] == 'on')
	{
		$template->assign_block_vars('switch_edit_sig', array());
		$aleast_one_on = true;
	}

	if ($aleast_one_on)
	{
		$template->assign_block_vars('switch_edit_all', array());
	}
}

if ( ( ($mode == 'register') || ($mode=='editprofile') ) && ($userdata['user_level'] != ADMIN) && ($userdata['user_level'] != MOD) )
{	
	$profile_data = array(
		'username'	=> $HTTP_POST_VARS['username'],
		'password'	=> $HTTP_POST_VARS['new_password'],
		'email'		=> $HTTP_POST_VARS['email'],
		'ip'		=> ( !empty($HTTP_SERVER_VARS['REMOTE_ADDR']) ) ? $HTTP_SERVER_VARS['REMOTE_ADDR'] : ( ( !empty($HTTP_ENV_VARS['REMOTE_ADDR']) ) ? $HTTP_ENV_VARS['REMOTE_ADDR'] : getenv('REMOTE_ADDR') ),
		'icq'		=> $HTTP_POST_VARS['icq'],
		'aim'		=> $HTTP_POST_VARS['aim'],
		'msn'		=> $HTTP_POST_VARS['msn'],
		'yim'		=> $HTTP_POST_VARS['yim'],
		'web'		=> $HTTP_POST_VARS['website'],
		'loc'		=> $HTTP_POST_VARS['location'],
		'occ'		=> $HTTP_POST_VARS['occupation'],
		'int'		=> $HTTP_POST_VARS['interests'],
		'sig'		=> $HTTP_POST_VARS['signature']
	);
	
	$spam = check_for_spam($profile_data, $userdata['user_posts'], $mode);

	if ($spam == true)
	{
		send_spam_email($profile_data, $mode);

		if ($board_config['as_acp_show_email_on_die'] == 1)	
		{
			$email_die = sprintf($lang['Spam_Bot_Yes'], $board_config['as_acp_email_for_spam']);
		}
		else
		{
			$email_die = $lang['Spam_Bot_No'];
		}

		message_die(GENERAL_MESSAGE, $email_die);
	}
}
?>