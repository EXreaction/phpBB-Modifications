<?php
/***************************************************************************
 *                        usercp_captcha2.php
 *                            -------------------
 *   begin                : Monday January 29, 2007
 *   copyright         : (C) 2007 EXreaction, Lithium Studios
 *   email                : support@lithiumstudios.org
 ***************************************************************************/

/***************************************************************************
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 ***************************************************************************/

if ( !defined('IN_PHPBB') )
{
	die('Hacking attempt');
	exit;
}

// Do we have an id? No, then just exit
if (empty($HTTP_GET_VARS['id']))
{
	exit;
}

if( (!function_exists('imagecreate')) || (!function_exists('imagecolorallocate')) || (!function_exists('imagechar')) )
{
	require($phpbb_root_path . 'includes/usercp_confirm.' . $phpEx);
	die;
}

$confirm_id = htmlspecialchars($HTTP_GET_VARS['id']);

if (!preg_match('/^[A-Za-z0-9]+$/', $confirm_id))
{
	$confirm_id = '';
}

// Try and grab code for this id and session
$sql = 'SELECT code  
	FROM ' . CONFIRM_TABLE . " 
	WHERE session_id = '" . $userdata['session_id'] . "' 
		AND confirm_id = '$confirm_id'";
$result = $db->sql_query($sql);

// If we have a row then grab data else create a new id
if ($row = $db->sql_fetchrow($result))
{
	$db->sql_freeresult($result);
	$code = $row['code'];
}
else
{
	exit;
}

$font_size = 5;
$width = rand(250, 350);
$height = rand(40, 80);
$img = imagecreate($width,$height);
$bg = imagecolorallocate($img, rand(155, 225), rand(155, 225), rand(155, 225));
$font_color = imagecolorallocate($img, rand(0, 100), rand(0, 100), rand(0, 100));
$len = strlen($code);

$x_move = $width / ($len + 1);
$current_pos = rand(10, ($x_move / 2));

for($i=0; $i<$len; $i++)
{
	$x_pos = $current_pos + rand(15, $x_move);
	$current_pos = $x_pos;

	$ypos = rand(0, ($height - 15));
	imagechar($img, $font_size, $x_pos, $ypos, $code, $font_color);
	$code = substr($code,1);
}
header("Content-Type: image/gif");
imagegif($img);
imagedestroy($img);
?>