<?php
/**
* @package language(permissions)
* @version $Id: permissions_blog.php 485 2008-08-15 23:33:57Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*/

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Create a new category named Blog
$lang['permission_cat']['blog'] = 'Günlük';

// User Permissions
$lang = array_merge($lang, array(
	'acl_u_blogview'			=> array('lang' => 'Günlük girdilerini görüntüleebilir', 'cat' => 'blog'),
	'acl_u_blogpost'			=> array('lang' => 'Günlük girdisi ekleyebilir', 'cat' => 'blog'),
	'acl_u_blogedit'			=> array('lang' => 'Kendi Günlük girdisini değiştirebilir', 'cat' => 'blog'),
	'acl_u_blogdelete'			=> array('lang' => 'Kendi Günlük girdisini silebilir', 'cat' => 'blog'),
	'acl_u_blognoapprove'		=> array('lang' => 'Günlük girdisi onaylanma zorunluluğu yoktur', 'cat' => 'blog'),
	'acl_u_blogreport'			=> array('lang' => 'Günlük girdilerini ve yorumları raporlayabilir', 'cat' => 'blog'),
	'acl_u_blogreply'			=> array('lang' => 'Günlük girdisine yorum ekleyebilir', 'cat' => 'blog'),
	'acl_u_blogreplyedit'		=> array('lang' => 'Kendi yorumunu değiştirebilir', 'cat' => 'blog'),
	'acl_u_blogreplydelete'		=> array('lang' => 'Kendi yorumunu silebilir', 'cat' => 'blog'),
	'acl_u_blogreplynoapprove'	=> array('lang' => 'Yorumlar onay zorunluluğu olmaksızın görüntülenebilir', 'cat' => 'blog'),
	'acl_u_blogbbcode'			=> array('lang' => 'Günlük girdilerinde ve yorumlarında biçim kodları kullanabilir', 'cat' => 'blog'),
	'acl_u_blogsmilies'			=> array('lang' => 'Günlük girdilerinde ve yorumlarında ifadeleri kullanabilir', 'cat' => 'blog'),
	'acl_u_blogimg'				=> array('lang' => 'Günlük girdilerinde ve yorumlarında resim kullanabilir', 'cat' => 'blog'),
	'acl_u_blogurl'				=> array('lang' => 'Günlük girdilerinde ve yorumlarında link kullanabilir', 'cat' => 'blog'),
	'acl_u_blogflash'			=> array('lang' => 'Günlük girdilerinde ve yorumlarında flash kullanabilir', 'cat' => 'blog'),
	'acl_u_blogmoderate'		=> array('lang' => 'Günlüğündeki yorumları yönetebilir (düzenleme ve silme).', 'cat' => 'blog'),
	'acl_u_blogattach'			=> array('lang' => 'Günlük girdilerinde ve yorumlarında dosya ekleyebilir', 'cat' => 'blog'),
	'acl_u_blognolimitattach'	=> array('lang' => 'Eklenti boyut ve sınırlandırmalarını yoksayabilir', 'cat' => 'blog'),

	'acl_u_blog_create_poll'	=> array('lang' => 'Anket olşturabilir', 'cat' => 'blog'),
	'acl_u_blog_vote'			=> array('lang' => 'Ankette oy kullanabilir', 'cat' => 'blog'),
	'acl_u_blog_vote_change'	=> array('lang' => 'Anket oyunu değiştirebilir', 'cat' => 'blog'),
	'acl_u_blog_style'			=> array('lang' => 'Kendi günlüğü için farklı bir tema kullanabilir', 'cat' => 'blog'),
	'acl_u_blog_css'			=> array('lang' => 'Günlüğünde kendi istediği CSS kodlarını kullanarak kişiselleştirebilir.', 'cat' => 'blog'),
));

// Moderator Permissions
$lang = array_merge($lang, array(
	'acl_m_blogapprove'			=> array('lang' => 'Onaylanmamış Günlük girdilerini görebilir ve onaylayabilir', 'cat' => 'blog'),
	'acl_m_blogedit'			=> array('lang' => 'Günlük girdilerini düzenleyebilir', 'cat' => 'blog'),
	'acl_m_bloglockedit'		=> array('lang' => 'Günlük girdilerini düzenlemeye karşı kilitleyebilir', 'cat' => 'blog'),
	'acl_m_blogdelete'			=> array('lang' => 'Günlük girdilerini silebilir ve geri alabilir', 'cat' => 'blog'),
	'acl_m_blogreport'			=> array('lang' => 'Günlük girdi raporlarını kapatabilir ve silebilir.', 'cat' => 'blog'),
	'acl_m_blogreplyapprove'	=> array('lang' => 'Onaylanmamış yorumları görebilir ve onaylayabilir', 'cat' => 'blog'),
	'acl_m_blogreplyedit'		=> array('lang' => 'Yorumları düzenleyebilir', 'cat' => 'blog'),
	'acl_m_blogreplylockedit'	=> array('lang' => 'Yorumları düzenlemeye karşı kilitleyebilir', 'cat' => 'blog'),
	'acl_m_blogreplydelete'		=> array('lang' => 'Yorumları silebilir ve geri alabilir', 'cat' => 'blog'),
	'acl_m_blogreplyreport'		=> array('lang' => 'Yorum raporlarını silebilir veya kapatabilir', 'cat' => 'blog'),
));

// Administrator Permissions
$lang = array_merge($lang, array(
	'acl_a_blogmanage'			=> array('lang' => 'Günlük ayarlarını değiştirebilir', 'cat' => 'blog'),
	'acl_a_blogdelete'			=> array('lang' => 'Günlük girdilerini geri dönüşümsüz olarak silebilir', 'cat' => 'blog'),
	'acl_a_blogreplydelete'		=> array('lang' => 'Günlük yorumlarını geri dönüşümsüz silebilir', 'cat' => 'blog'),
));
?>