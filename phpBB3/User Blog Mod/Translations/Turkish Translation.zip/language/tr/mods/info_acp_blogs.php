<?php
/**
*
* @package phpBB3 User Blog
* @version $Id: info_acp_blogs.php 493 2008-08-28 17:43:39Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @translator muiketi - http://www.phpbbturkiye.net/memberlist.php?mode=viewprofile&u=666
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ACP_BLOGS'						=> 'Kullanıcı Günlük Eklentisi',
	'ACP_BLOG_CATEGORIES'			=> 'Günlük Kategorileri',
	'ACP_BLOG_PLUGINS'				=> 'Günlük Eklentileri',
	'ACP_BLOG_SEARCH'				=> 'Günlük Ara',
	'ACP_BLOG_SETTINGS'				=> 'Günlük Ayarları',

	'IMG_BUTTON_BLOG_NEW'			=> 'Yeni Günlük Girdisi',

	'LOG_BLOG_CATEGORY_ADD'			=> '<strong>Yeni Günlük Kategorisi Eklendi</strong><br />» %s',
	'LOG_BLOG_CATEGORY_DELETE'		=> '<strong>Günlük Kategorisi Silindi</strong><br />» %s',
	'LOG_BLOG_CATEGORY_EDIT'		=> '<strong>Günlük Kategorisi Değiştirildi</strong><br />» %s',
	'LOG_BLOG_CONFIG'				=> '<strong>Gelişmiş Günlük Ayarları</strong>',
	'LOG_BLOG_CONFIG_SEARCH'		=> '<strong>Gelişmiş Günlük Arama Ayarları/strong>',
	'LOG_BLOG_PLUGIN_DISABLED'		=> '<strong>Günlük Eklentisi Devredışı Bırakıldı</strong><br />» %s',
	'LOG_BLOG_PLUGIN_ENABLED'		=> '<strong>Günlük Eklentisi Etkinleştirildi</strong><br />» %s',
	'LOG_BLOG_PLUGIN_INSTALLED'		=> '<strong>Günlük Eklentisi Kuruldu</strong><br />» %s',
	'LOG_BLOG_PLUGIN_UNINSTALLED'	=> '<strong>Günlük Eklentisi Kaldırıldı</strong><br />» %s',
	'LOG_BLOG_PLUGIN_UPDATED'		=> '<strong>Günlük Eklentisi Güncelleştirildi</strong><br />» %s',
	'LOG_BLOG_SEARCH_INDEX_CREATED'	=> '<strong>Günlük Arama Indexi Oluşturuldu</strong>',
	'LOG_BLOG_SEARCH_INDEX_REMOVED'	=> '<strong>Günlük Arama Indexi Silindi</strong>',
));

?>