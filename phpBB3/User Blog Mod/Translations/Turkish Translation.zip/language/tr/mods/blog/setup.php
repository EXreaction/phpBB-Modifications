<?php
/**
*
* @package phpBB3 User Blog
* @version $Id: setup.php 485 2008-08-15 23:33:57Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @translator muiketi - http://www.phpbbturkiye.net/memberlist.php?mode=viewprofile&u=666
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ALREADY_INSTALLED'				=> 'Kullanıcı Günlük Eklentisi zaten kurulu.<br /><br />Kullanıcı Günlüklerine dönmek için %sburayı%s tıklayın.',
	'ALREADY_UPDATED'				=> 'Kullanıcı Günlük Eklentisinin son sürümünü kullanıyorsunuz.<br /><br />Kullanıcı Günlüklerine dönmek için %sburayı%s tıklayın.',

	'BACKUP_NOTICE'					=> 'Veritabanı güncelleştirmesi öncesi yedeğini aldığınıza emin olun. Olası bir aksaklıkta veritabanınızı geri yükleyebilirsiniz.',

	'CLEANUP'						=> 'Temizle',
	'CLEANUP_COMPLETE'				=> 'Tablolar başarıyla temizlendi.',
	'CONVERTED_BLOG_IDS_MISSING'	=> 'Dönüştürülen blog_id’leri önbellekte bulunamadı. Yükseltme için veritabanı yedeğinizi yükleyip yeniden deneyiniz.',
	'CONVERT_COMPLETE'				=> 'Dönüştürme işlemi başarıyla tamamlandı.',
	'CONVERT_FOES'					=> 'Yasaklı Listesini Dönüştür',
	'CONVERT_FOES_EXPLAIN'			=> 'weblog_blocked tablosundaki içeriği Yasaklılar olarak dönüştürür.',
	'CONVERT_FRIENDS'				=> 'Arkadaşlar Listesini Dönüştür',
	'CONVERT_FRIENDS_EXPLAIN'		=> 'weblog_friends tablosundaki içeriği Arkadaşlar olarak dönüştürür.',

	'DB_TABLE_NOT_EXIST'			=> 'Seçili veritabanında %s tablosu bulunamadı.',

	'FINAL'							=> 'Final',

	'INDEX_COMPLETE'				=> 'Günlük girdileri ve girdilere verilen yanıtlar için arama indexi oluşturuldu.',
	'INSTALL_BLOG_DB'				=> 'Kullanıcı Günlük Eklentisini Kur',
	'INSTALL_BLOG_DB_CONFIRM'		=> 'Veritabanı içeriğinin yüklenmesine hazır mısınız?',
	'INSTALL_BLOG_DB_FAIL'			=> 'Kullanıcı Günlük Eklentisi kurulamadı.<br />Lütfen aşağıdaki hata kayıtlarını EXreaction’a iletiniz:<br />',
	'INSTALL_BLOG_DB_SUCCESS'		=> 'Kullanıcı Günlük Eklentisinin veritabanı içeriği başarıyla yüklendi.<br /><br />Kullanıcı Günlüklerine dönmek için %sburayı%s tıklayın.',

	'LIMIT_EXPLAIN'					=> 'Bir seferde yaılacak işlem sayısı. Yüksek bir değer seçmeniz durumunda yükseltme işlemi başarısız olabilir, düşük bir değer seçmeniz durumunda işlem uzunca bir süre alabilir.',
	'LIMIT_INCORRECT'				=> 'PHP ayarlarınıza göre en az 100 olarak girmeniz ve 1000’den küçük olması önerilir.',

	'NEXT_PART'						=> 'Bir sonraki aşama',
	'NOT_INSTALLED'					=> 'Yükseltme işlemini yapmadan önce Kullanıcı Günlük Eklentisini kurmuş olmalısınız.',
	'NO_STAGE'						=> 'Çalışılacak aşama belirtmediniz.',

	'PRE_UPGRADE_COMPLETE'			=> 'Tüm ön-dönüştürme işlemleri başarıyla tamamlandı. Şimdi asıl işleme başlanacak. Dönüştürme işleminden sonra elle düzenlemeniz gerekecek bölümlerin olduğunu unutmayınız ve özellikle izinler sekmesini kontrol ediniz.',

	'REINDEX'						=> 'Yeniden İndeksle',
	'RESYNC'						=> 'Senkronize Et',
	'RESYNC_COMPLETE'				=> 'Kullanıcı Günlük Eklentisi Senkronize Edildi.',
	'RETURN_LAST_STEP'				=> 'Bir önceki aşamaya dönmek için tıklayın.',

	'SCHEMA_NOT_EXIST'				=> 'Veritabanı yükseltme şeması bulunamadı. Bu eklentiyi yeniden indirip sitenize yükleyiniz. Bu sorununuzu çözmediyse EXreaction ile iletişime geçiniz.',
	'SEARCH_BREAK_CONTINUE_NOTICE'	=> 'Aşama %2$s / %1$s tamamlandı, bölüm %4$s / %3$s tamamlandı, hala birkaç aşama ve bölüm var.<br />Yönlendirme işlemi otomatik olarak gerçekleşmezse aşağıdaki bağlantıyı tıklayınız.',
	'SUCCESS'						=> 'Başarılı',
	'SUCCESSFULLY_UPDATED'			=> 'Kullanıcı Günlük Eklentisi %1$s sürümüne güncellendi.<br /><br />Kullanıcı Günlüklerine dönmek için %2$burayı%3$ tıklayın.',

	'TRUNCATE_TABLES'				=> 'Varolan tabloları kısalt',
	'TRUNCATE_TABLES_EXPLAIN'		=> 'Bu durumda Kullanıcı Günlük Eklentisine ait tüm tablolar silinecektir. Eğer Hayır seçeneğini kabul ederseniz yeni veriler önceki verilerinizin üzerine yazılacak.',

	'UNINSTALL_BLOG_DB'				=> 'Kullanıcı Günlük Eklentisi Kaldır',
	'UNINSTALL_BLOG_DB_CONFIRM'		=> 'Kullanıcı Günlük Eklentisini gerçekten kaldırmak istiyor musunuz?<br /><br /><strong>Bu durumda Kullanıcı Günlük Eklentisine ait tüm veriyi kaybedeceksiniz.</strong>',
	'UNINSTALL_BLOG_DB_SUCCESS'		=> 'Kullanıcı Günlük Eklentisi veritabanından silindi. Bu işlemden sonra eklentiyi kurarken yaptığınız tüm değişiklikleri geri almalı ve eklentiye ait kalıntı bırakmamalısınız.',
	'UPDATE_INSTRUCTIONS'			=> 'Yükseltme',
	'UPDATE_INSTRUCTIONS_CONFIRM'	=> 'Bu işlemi yapmadan önce kurulum kılavuzundaki yükseltme yönergesini okuduğunuza emin olun. <br /><br />Kullanıcı Günlük Eklentisi için veritabanı yükseltmek istediğinize emin misiniz?',
	'UPGRADE_BLOGS'					=> 'Günlükleri Yükselt',
	'UPGRADE_BREAK_CONTINUE_NOTICE'	=> 'Aşama %1$s, kısım %3$s / %2$s, bölüm %5$s /%4$s tamamlandı, fakat bu bölümün tamamlanması için hala birkaç aşama ve/veya bölüm var.<br />Yönlendirme işlemi otomatik olarak gerçekleşmezse aşağıdaki bağlantıyı tıklayınız.',
	'UPGRADE_COMPLETE'				=> 'Yükseltme işlemi başarıyla tamamlandı!<br />Lütfen verilerinizin doğruluğunu kontrol ediniz.',
	'UPGRADE_LIST'					=> 'Yükseltme Listesi',
	'UPGRADE_PHP'					=> 'Bu eklentiyi çalıştırabilmeniz için PHP 5.1.0 veya üstü bir PHP kullanmalısınız.',
	'UPGRADE_REPLIES'				=> 'Yanıtları Günlüklle',

	'WELCOME_MESSAGE'				=> 'Kullanıcı Günlüklerine Hoşgeldiniz

Duyuru Başlığı:
http://lithiumstudios.org/forum/viewtopic.php?f=41&t=433

Destek sadece lithiumstudios.org sitesinde verilmektedir  Destek için şu forumu kullanabilirsiniz:
http://lithiumstudios.org/forum/viewforum.php?f=41',
	'WELCOME_SUBJECT'				=> 'Kullanıcı Günlüklerine Hoşgeldiniz',
));

?>