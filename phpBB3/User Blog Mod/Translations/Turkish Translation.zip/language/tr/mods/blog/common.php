<?php
/**
*
* @package phpBB3 User Blog
* @version $Id: common.php 485 2008-08-15 23:33:57Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @translator muiketi - http://www.phpbbturkiye.net/memberlist.php?mode=viewprofile&u=666
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'AVAILABLE_FEEDS'				=> 'Kullanılabilir Kaynaklar',

	'BLOG'							=> 'Günlük',
	'BLOGS'							=> 'Günlükler',
	'BLOG_CONTROL_PANEL'			=> 'Günlük Yönetim Paneli',
	'BLOG_CREDITS'					=> 'Günlük yaratım <a href="http://www.lithiumstudios.org/">User Blog Mod</a> &copy; EXreaction',
	'BLOG_DELETED_BY_MSG'			=> 'Bu Günlük girdisi %1$s tarafından %2$s tarihinde silindi. <b>%3$sBurayı%4$s</b> tıklayarak silme işlemini geri alabilirsiniz.',
	'BLOG_DESCRIPTION'				=> 'Günlük Açıklaması',
	'BLOG_LINKS'					=> 'Günlük Bağlantıları',
	'BLOG_MCP'						=> 'Günlük Yetkili Paneli',
	'BLOG_NOT_EXIST'				=> 'İstenilen Günlük girdisi bulunamadı.',
	'BLOG_SEARCH_BACKEND_NOT_EXIST'	=> 'Arama geri uç işlemcisi bulunamadı. Lütfen bu durumu site yöneticine bildirin.',
	'BLOG_STATS'					=> 'Günlük İstatistikleri',
	'BLOG_SUBJECT'					=> 'Günlük Konusu',
	'BLOG_TITLE'					=> 'Günlük Başlığı',

	'CATEGORIES'					=> 'Kategoriler',
	'CATEGORY'						=> 'Kategori',
	'CATEGORY_DESCRIPTION'			=> 'Kategori Açıklaması',
	'CATEGORY_NAME'					=> 'Kategori Adı',
	'CATEGORY_RULES'				=> 'Kategori Kuralları',
	'CLICK_INSTALL_BLOG'			=> 'Kullanıcı Günlük Eklentisini kurmak için %sburayı%s tıklayın.',
	'CNT_BLOGS'						=> '%s Günlük girdisi',
	'CNT_REPLIES'					=> '%s yanıt',
	'CNT_VIEWS'						=> '%s kez görüntülendi',
	'CONTINUE'						=> 'Devam Et',
	'CONTINUED'						=> 'Devam Edildi',

	'DELETE_BLOG'					=> 'Günlük Girdisini Sil',
	'DELETE_REPLY'					=> 'Yorum Sil',

	'EDIT_BLOG'						=> 'Günlük Girdisini Düzenle',
	'EDIT_REPLY'					=> 'Yanıtı Günlüklle',

	'FEED'							=> 'Kaynak',
	'FOE_PERMISSIONS'				=> 'Yasaklı İzinleri',
	'FRIEND_PERMISSIONS'			=> 'Arkadaş İzinleri',

	'GUEST_PERMISSIONS'				=> 'Ziyaretçi İzinleri',

	'LIMIT'							=> 'Sınır',

	'MUST_BE_FOUNDER'				=> 'Bu sayfaya ulaşabilmeniz için kurucu olmanız gerekmektedir.',
	'MY_BLOG'						=> 'Günlüğüm',

	'NEW_BLOG'						=> 'Yeni Günlük Girdisi',
	'NO_BLOGS'						=> 'Hiç Günlük girdisi yok.',
	'NO_BLOGS_USER'					=> 'Bu kullanıcı hiç günlük girdisi oluşturmamış.',
	'NO_BLOGS_USER_SORT_DAYS'		=> 'Bu kullanıcı son %s hiç günlük girdisi oluşturmamış.',
	'NO_CATEGORIES'					=> 'Hiç kategori yok',
	'NO_CATEGORY'					=> 'Seçili kategori bulunamadı.',
	'NO_PERMISSIONS_READ'			=> 'Bu günlüğü okuma izniniz yok.',
	'NO_REPLIES'					=> 'Hiç yorum yapılmamış.',

	'ONE_BLOG'						=> '1 günlük',
	'ONE_REPLY'						=> '1 yorum',
	'ONE_VIEW'						=> '1 kez görüntülendi',

	'PERMANENT_LINK'				=> 'Sürekli Bağlantı',
	'PLUGIN_TEMPLATE_MISSING'		=> 'Eklenti şablonu bulunamadı.',
	'POPULAR_BLOGS'					=> 'En Çok Okunan Günlük Girdileri',
	'POST_A_NEW_BLOG'				=> 'Günlük Girdisi Oluştur',
	'POST_A_NEW_REPLY'				=> 'Yorum Gönder',

	'RANDOM_BLOGS'					=> 'Rasgele Günlük Girdileri',
	'RECENT_BLOGS'					=> 'Son Günlük Girdileri',
	'REGISTERED_PERMISSIONS'		=> 'Üye İzinleri',
	'REPLIES'						=> 'Yorumlar',
	'REPLY'							=> 'Yorum',
	'REPLY_COUNT'					=> 'Yorum Sayacı',
	'REPLY_DELETED_BY_MSG'			=> 'Bu yorum %1$s tarafından %2$s tarihinde silindi. <b>%3$sBurayı%4$s</b> tıklayarak silme işlemini geri alabilirsiniz',
	'REPLY_NOT_EXIST'				=> 'Talep edilen yanıt bulunamadı.',
	'REPORT_BLOG'					=> 'Günlük Girdisini Rapor Et',
	'REPORT_REPLY'					=> 'Yorumu Rapor Et',
	'RETURN_BLOG_MAIN'				=> '%2$s kullanıcısının günlüğüne%3$s %1$geri dön',
	'RETURN_BLOG_OWN'				=> '%sGünlüğüme geri dön%s',
	'RETURN_MAIN'					=> 'Kullanıcı Günlüklerine dönmek için %sburayı%s tıklayın.',

	'SEARCH_BLOGS'					=> 'Günlükleri Ara',
	'SUBSCRIBE'						=> 'Abonelik',
	'SUBSCRIBE_BLOG'				=> 'Bu günlüğe abone ol',
	'SUBSCRIBE_USER'				=> 'Bu kullanıcının günlüğüne abone ol',
	'SUBSCRIPTION'					=> 'Abonelik',
	'SUBSCRIPTION_EXPLAIN'			=> 'Bu günlüklee ilgili yeniliklerden nasıl haberdar edilmek istediğinizi seçiniz.',
	'SUBSCRIPTION_EXPLAIN_REPLY'	=> 'Zaten bu günlüğe aboneyseniz haberdar edilmek seçeneğiniz gösterilmektedir. Dilerseniz bunu değiştirebilirsiniz.',

	'TOTAL_BLOG_ENTRIES'			=> 'Toplam Günlük Girdisi',

	'UNSUBSCRIBE'					=> 'Aboneliği Bitir',
	'UNSUBSCRIBE_BLOG'				=> 'Bu günlüğe ait aboneliği bitir',
	'UNSUBSCRIBE_USER'				=> 'Bu kullanıcıya ait aboneliği bitir',
	'USERNAMES_BLOGS'				=> '%s’nın Günlüğü',
	'USERNAMES_DELETED_BLOGS'		=> '%s’nın silinmiş girdileri',
	'USER_BLOGS'					=> 'Kullanıcı Günlükleri',
	'USER_BLOG_MOD_DISABLED'		=> 'Kullanıcı Günlük Eklentisi devredışı.',
	'USER_BLOG_RATINGS_DISABLED'	=> 'Derecelendirme sistemi devredışı.',

	'VIEW_BLOG'						=> 'Günlüğü Görüntüle',
	'VIEW_REPLY'					=> 'Yanıtı Görüntüle',

	'WARNING'						=> 'Uyarı',
));

?>