<?php
/**
*
* @package phpBB3 User Blog
* @version $Id$
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @translator muiketi - http://www.phpbbturkiye.net/memberlist.php?mode=viewprofile&u=666
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ADDING_FIRST_BLOG'					=> 'İlk günlük girdisi ekleniyor',

	'FIXING_MAX_POLL_OPTIONS'			=> 'En Fazla Anket Seçeneği Düzeltiliyor',
	'FIXING_MISSING_STYLES'				=> 'Uzun zamandır mevcut olmayan stiller siliniyor.',

	'INSTALLING_ARCHIVE_PLUGIN'			=> 'Arşiv Eklentisi Kuruluyor',

	'SETTING_DEFAULT_PERMISSIONS'		=> 'Varsayılan İzinler Ayarlanıyor',
	'SUCCESSFULLY_UPDATED_UMIL_RETURN'	=> '1.0.7 sürümüne başarıyla güncelleştirildi. Yeni kurulum sistemi sebebiyle yükseltme işlemi önce 1.0.7 sonra 1.0.8 ve üstü yükseltmeler yapılabilir. Yükseltme işlemini tamamlamak için <a href="%s">burayı</a> tıklamalısınız.',

	'USER_BLOG_MOD'						=> 'Kullanıcı Günlük Eklentisi',
	'USE_OLD_UPDATE_SCRIPT'				=> 'Sürüm güncellemesi için desteklenen sürüm 0.0.9 veya üstüdür. Bundan önceki sürüm güncellemelerini kullanarak sürümü en az 0.0.9 olarak güncelleştirdikten sonra bu güncellemeyi kullanabilirsiniz.<br />Eski sürüm güncelleme dosyasını <a href="%s">buradan</a> indirebilirsiniz.',
));

?>