<?php
/**
*
* @package phpBB3 User Blog
* @version $Id: ucp.php 485 2008-08-15 23:33:57Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @translator muiketi - http://www.phpbbturkiye.net/memberlist.php?mode=viewprofile&u=666
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'BLOG_CSS'								=> 'Günlük CSS',
	'BLOG_CSS_EXPLAIN'						=> 'Günlüğnüzün görünümü için CSS kodları ekleyebilir/oluşturabilirsiniz.',
	'BLOG_INSTANT_REDIRECT'					=> 'Doğrudan Yönlendirme',
	'BLOG_INSTANT_REDIRECT_EXPLAIN'			=> 'Bu seçenek kullanıcıya bilgilendirme sayfasını görüntülemeden doğrudan sonraki sayfaya yönlendirir.',
	'BLOG_STYLE'							=> 'Günlük Stili',
	'BLOG_STYLE_EXPLAIN'					=> 'Günlüğünüz için kullanacağınız stili seçiniz.<br />Eğer stil isminden sonra * varsa kendi özel stilinizi kullanabilirsiniz.',

	'NONE'									=> 'Hiçbiri',
	'NO_PERMISSIONS'						=> 'Günlük girdilerinizi okuyamaz ve cevaplayamaz.',

	'REPLY_PERMISSIONS'						=> 'Günlük girdilerinizi okuyabilir ve cevaplayabilir.',
	'RESYNC_PERMISSIONS'					=> 'İzinleri Senkronize Et',
	'RESYNC_PERMISSIONS_EXPLAIN'			=> 'İzinlerin senkronize etmek için burayı işaretleyin.',

	'SUBSCRIPTION_DEFAULT'					=> 'Varsayılan Abonelikler',
	'SUBSCRIPTION_DEFAULT_EXPLAIN'			=> 'İleti veya yorum yazdığınız bir gülüğe yeni ileti veya yorum yazılması durumunda bilgilendirilme şeklinizi seçiniz. Her ileti için ayrı ayrı belirleyebilirsiniz.',

	'UCP_BLOG_PERMISSIONS_EXPLAIN'			=> 'Bu panelde, günlüğünüzün izin ayarlarını değiştirebilirsiniz.<br />Pano ayarlarının sizin ayarlarınızdan öncelikli olduğunu unutmayın.',
	'UCP_BLOG_SETTINGS_EXPLAIN'				=> 'Bu panelde, günlüğünüzün temel ayarlarını değiştirebilirsiniz',
	'UCP_BLOG_TITLE_DESCRIPTION_EXPLAIN'	=> 'Burada günlüğünüzün başlığını ve açıklamasını ouşturabilirsiniz.',
	'USER_PERMISSIONS_DISABLED'				=> 'Kullanıcı izin sistemi yönetici tarafından devredışı bırakılmış.',

	'VIEW_PERMISSIONS'						=> 'Günlük girdilerinizi okuyabilir',
));

?>