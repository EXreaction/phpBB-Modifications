<?php
/**
*
* @package phpBB3 User Blog
* @version $Id: view.php 485 2008-08-15 23:33:57Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @translator muiketi - http://www.phpbbturkiye.net/memberlist.php?mode=viewprofile&u=666
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'AVERAGE_OF_RATING'				=> '%s oylamanın ortalaması',
	'AVERAGE_OF_RATINGS'			=> '%s oylamanın ortalaması',

	'CLICK_HERE_SHOW_POST'			=> 'Son ileti için tıklayınız',
	'CNT_COMMENTS'					=> '%s yorum',
	'COMMENTS'						=> 'Yorumlar',

	'DELETED_REPLY_SHOW'			=> 'Bu yorum geri alınacabilecek şekilde silindi. İçeriği görmek için tıklayınız.',

	'LAST_VISIT_BLOGS'				=> 'Son ziyaretinizden beri günlük girdileri',

	'MY_RATING'						=> 'Derecelendirmem',

	'NO_DELETED_BLOGS'				=> 'Bu kullanıcı tarafından silinmiş günlük girdisi bulunamadı.',
	'NO_DELETED_BLOGS_SORT_DAYS'	=> 'Bu kullanıcı tarafından son %s gönderilen silinmiş günlük girdisi bulunamadı.',

	'ONE_COMMENT'					=> '1 Yorum',

	'POSTED_BY_FOE'					=> 'Bu ileti yasaklı listenizde olan %s tarafından oluşturuldu.',

	'RANDOM_BLOG'					=> 'Rasgele günlük Girdisi',
	'RATE_ME'						=> '%1$s out of %2$s',
	'RECENT_COMMENTS'				=> 'Son Yorumlar',
	'REMOVE_RATING'					=> 'Oylamayı sıfırla',
	'REPLY_SHOW_NO_JS'				=> 'Bu iletiyi görüntüleyebilmeniz için tarayıcnızın Javascript motoru etkin olmalı.',
	'REPORTED'						=> 'Bu ileti rapor edilmiş. Raporu kapatmak için tıklayın.',

	'SUBCATEGORIES'					=> 'Altkategoriler',
	'SUBCATEGORY'					=> 'Altkategori',

	'TOTAL_NUMBER_OF_BLOGS'			=> 'Toplam Girdi',
	'TOTAL_NUMBER_OF_REPLIES'		=> 'Toplam Yorum',

	'UNAPPROVED'					=> 'Bu ileti onay bekliyor. Onaylamak için burayı tıklayın.',
));

?>