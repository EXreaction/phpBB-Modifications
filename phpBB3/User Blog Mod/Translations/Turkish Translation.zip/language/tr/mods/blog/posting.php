<?php
/**
*
* @package phpBB3 User Blog
* @version $Id: posting.php 485 2008-08-15 23:33:57Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @translator muiketi - http://www.phpbbturkiye.net/memberlist.php?mode=viewprofile&u=666
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ADD_BLOG'					=> 'Yeni günlük girdisi ekle',
	'APPROVE_BLOG'				=> 'Günlük Girdisini Onayla',
	'APPROVE_BLOG_CONFIRM'		=> 'Bu girdiyi onaylamak istediğinize emin misiniz?',
	'APPROVE_BLOG_SUCCESS'		=> 'Girdi başarıyla onaylandı.',
	'APPROVE_REPLY'				=> 'Yorum Onayla',
	'APPROVE_REPLY_CONFIRM'		=> 'Bu yorumu onaylamak istediğinize emin misiniz?',
	'APPROVE_REPLY_SUCCESS'		=> 'Yorum başarıyla onaylandı.',

	'BLOG_ALREADY_APPROVED'		=> 'Bu girdi zaten onaylanmış.',
	'BLOG_ALREADY_DELETED'		=> 'Bu girdi zaten silinmiş.',
	'BLOG_APPROVE_PM'			=> 'Bu Kullanıcı Günlük Eklentisi tarafından otomatik olarak eklenen bir mesajdır.<br /><br />%1$s kullanıcısı <a href="%2$s">bu günlük girdisini</a> ekledi ve yayımlanması için onay gerekiyor.<br />Günlük girdisini okumak ve gereğini uygulamak üzere girdiyi kontrol ediniz.',
	'BLOG_APPROVE_PM_SUBJECT'	=> 'Günlük Girdisinin onaylanması gerekiyor!',
	'BLOG_DELETED'				=> 'Günlük girdisi silindi.',
	'BLOG_EDIT_LOCKED'			=> 'Günlük girdisi kilitlendi.',
	'BLOG_EDIT_SUCCESS'			=> 'Günlük girdisi düzenlendi!',
	'BLOG_NEED_APPROVE'			=> 'Günlük girdiniz yayımlanmadan önce bir yönetici veya genel yetkili tarafından onaylanmalı.',
	'BLOG_NOT_DELETED'			=> 'Bu günlük girdisi silinmedi. Neden geri almaya çalışıyorsunuz?',
	'BLOG_REPORT_CONFIRM'		=> 'Bu günlük girdisini rapor etmek istediğinize emin misiniz?',
	'BLOG_REPORT_PM'			=> 'Bu Kullanıcı Günlük Eklentisi tarafından otomatik olarak eklenen bir mesajdır.<br /><br />%1$s kullanıcısı <a href="%2$s">bu günlük girdisini</a> rapor etti.<br />Günlük girdisini okumak ve gereğini uygulamak üzere girdiyi kontrol ediniz.',
	'BLOG_REPORT_PM_SUBJECT'	=> 'Günlük Girdisi Rapor Edildi!',
	'BLOG_SUBMIT_SUCCESS'		=> 'Günlük girdisi başarıyla kaydedildi!',
	'BLOG_SUBSCRIPTION_NOTICE'	=> 'Bu Kullanıcı Günlük Eklentisi tarafından otomatik olarak eklenen bir mesajdır.<br /><br /> notifying you that a comment has been made to [url=%1$s]Bu[/url] günlük girdisine %2$s kullanıcısı tarafından yeni bir yorum eklenmiştir.<br /><br />Bu türden hatırlatma mesajı almamak için [url=%3$s]burayı[/url] tıklayarak aboneliğinizi bitirebilirsiniz.',
	'BLOG_UNDELETED'			=> 'Günlük girdisi geri yüklendi.',

	'CATEGORY_EXPLAIN'			=> 'CTRL tuşunu basılı tutarak birden fazla kategori seçebilirsiniz.<br /><br />Günlük girdileri <strong>daima</strong> kişisel günlüğünüzde gösterilir.',

	'DELETE_BLOG_CONFIRM'		=> 'Bu günlük girdisini silmek istediğinize emin misiniz?',
	'DELETE_REPLY_CONFIRM'		=> 'Bu yorumu silmek istediğinize emin misiniz?',

	'EDIT_A_BLOG'				=> 'Günlük girdisini düzenle',
	'EDIT_A_REPLY'				=> 'Yorumu düzenle',

	'HARD_DELETE'				=> 'Tamamen Sil',
	'HARD_DELETE_EXPLAIN'		=> 'Eğer bu seçeneği işaretlerseniz işlemi geri alamazsınız!',

	'NO_PERMISSIONS_SINGLE'		=> 'Bu günlük girdisini okuyamaz veya yanıtlayamaz.',

	'PERMISSIONS'				=> 'İzinler',

	'REPLY_ALREADY_APPROVED'	=> 'Bu yorum zaten onaylanmış.',
	'REPLY_APPROVE_PM'			=> 'Bu Kullanıcı Günlük Eklentisi tarafından otomatik olarak eklenen bir mesajdır.<br /><br />%1$s kullanıcısı <a href="%2$s">bu yorumu</a> ekledi ve yayımlanması için onay gerekiyor.<br />Yorumu okumak ve gereğini uygulamak üzere girdiyi kontrol ediniz.',
	'REPLY_APPROVE_PM_SUBJECT'	=> 'Günlük Yorumu Onay Bekliyor!',
	'REPLY_DELETED'				=> 'Yorum silindi.',
	'REPLY_EDIT_LOCKED'			=> 'Bu yorum düzenlenmeye karşı kilitli.',
	'REPLY_EDIT_SUCCESS'		=> 'Yorum başarıyla güncelleştirildi!',
	'REPLY_NEED_APPROVE'		=> 'Yorumunuz yayımlanmadan önce bir yönetici veya genel yetkili tarafından onaylanmalı.',
	'REPLY_NOT_DELETED'			=> 'Bu yorum silinmedi. Neden geri almaya çalışıyorsunuz?',
	'REPLY_PERMISSIONS_SINGLE'	=> 'Bu günlük girdisini okuyabilir veya yanıtlayabilir.',
	'REPLY_REPORT_CONFIRM'		=> 'Bu yorumu rapor etmek istediğinize emin misiniz?',
	'REPLY_REPORT_PM'			=> 'Bu Kullanıcı Günlük Eklentisi tarafından otomatik olarak eklenen bir mesajdır.<br /><br />%1$s kullanıcısı <a href="%2$s">bu yorumu</a> rapor etti.<br />Yorumu okumak ve gereğini uygulamak üzere girdiyi kontrol ediniz.',
	'REPLY_REPORT_PM_SUBJECT'	=> 'Yorum Rapor Edildi!',
	'REPLY_SUBMIT_SUCCESS'		=> 'Yorum başarıyla kadedildi!',
	'REPLY_UNDELETED'			=> 'Yorum geri yüklendi.',

	'SUBSCRIPTION_NOTICE'		=> 'Kullanıcı Günlük Eklenisinden abonelik bilgisi',

	'UNDELETE_BLOG'				=> 'Günlük girdisini geri yükle',
	'UNDELETE_BLOG_CONFIRM'		=> 'Girdiyi geri yüklemek istediğinize emin misiniz?',
	'UNDELETE_REPLY'			=> 'Yorumu geri yükle',
	'UNDELETE_REPLY_CONFIRM'	=> 'Yorumu geri yüklemek istediğinize emin misiniz?',
	'USER_SUBSCRIPTION_NOTICE'	=> 'Bu Kullanıcı Günlük Eklentisi tarafından otomatik olarak eklenen bir mesajdır.<br /><br />%1$s tarafından yeni bir günlük girdisi oluşturuldu. Girdiyi görüntülemek için [url=%2$s]burayı[/url] tıklayınız.<br /><br />Bu türden hatırlatma mesajı almamak için [url=%3$s]burayı[/url] tıklayarak aboneliğinizi bitirebilirsiniz.',

	'VIEW_PERMISSIONS_SINGLE'	=> 'Günlük girdisini okuyabilir.',
));

?>