<?php
/**
*
* @package phpBB3 User Blog Archives
* @version $Id: archive.php 485 2008-08-15 23:33:57Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @translator muiketi - http://www.phpbbturkiye.net/memberlist.php?mode=viewprofile&u=666
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ARCHIVES'					=> 'Arşivler',

	'BLOG_ARCHIVES_DESCRIPTION'	=> 'Arşiv listesini Kullanıcı Günlüklerine ekler.',
));

?>