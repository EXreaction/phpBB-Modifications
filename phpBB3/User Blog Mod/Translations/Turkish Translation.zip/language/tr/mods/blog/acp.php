<?php
/**
*
* @package phpBB3 User Blog
* @version $Id: acp.php 485 2008-08-15 23:33:57Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @translator muiketi - http://www.phpbbturkiye.net/memberlist.php?mode=viewprofile&u=666
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ACP_BLOG_CATEGORIES_EXPLAIN'			=> 'Bu panelde günlük kategorisi ekleyebilir, değiştirebilir ve yönetebilirsiniz.',
	'ACP_BLOG_PLUGINS_EXPLAIN'				=> 'Burada Kullanıcı Günlük Eklentisi için eklentileri kurabilir, silebilir, aktif ve pasif yapabilirsiniz.<br /><br />Aynı zamanda eklentileri önem sıralamanıza göre düzenleyebilirsiniz (listede aşağı/yukarı kaydırabilirsiniz).',
	'ALLOWED_IN_BLOG'						=> 'Kullanıcı Günlüklerinde izin verilmiş',
	'ALLOW_IN_BLOG'							=> 'Kullanıcı Günlüğüne izin ver',

	'BLOG_ALWAYS_SHOW_URL'					=> 'Profilde günlük linkini daima göster',
	'BLOG_ALWAYS_SHOW_URL_EXPLAIN'			=> 'Hayır seçmeniz durumunda kullanıcı bir günlük içeriği yazana kadar profil sayfasında günlük ile ilgili link gözükmez.',
	'BLOG_ATTACHMENT_SETTINGS'				=> 'Dosya Eklenti Ayarları',
	'BLOG_ENABLE_ATTACHMENTS'				=> 'Eklenmiş Dosyalar',
	'BLOG_ENABLE_ATTACHMENTS_EXPLAIN'		=> 'Günceler ve günlük yorumları için dosya eklemeyi aktif veya pasif olarak ayarlayabilirsiniz.',
	'BLOG_ENABLE_FEEDS'						=> 'RSS/ATOM/Javascript Kaynakları',
	'BLOG_ENABLE_RATINGS'					=> 'Günlük Derecelendirme',
	'BLOG_ENABLE_RATINGS_EXPLAIN'			=> 'Günlükler için derecelendirmeyi devredışı bırak.',
	'BLOG_ENABLE_SEARCH'					=> 'Arama',
	'BLOG_ENABLE_SEARCH_EXPLAIN'			=> 'Günlüklerde arama aktif.',
	'BLOG_ENABLE_SEO'						=> 'SEO Bağlantılar',
	'BLOG_ENABLE_SEO_EXPLAIN'				=> 'Bunun için SEO modu kurulu olmalıdır aksi takdirde hayır olarak işaretleyiniz.',
	'BLOG_ENABLE_USER_PERMISSIONS'			=> 'Kullanıcı İzinleri',
	'BLOG_ENABLE_USER_PERMISSIONS_EXPLAIN'	=> 'Kullanıcı grupları için izinleri ayarlamayı unutmayınız. Yönetici ve genel yetkililer bu durumdan etkilenmeyeceklerdir.',
	'BLOG_ENABLE_ZEBRA'						=> 'Arkadaş/Yasaklı Listesi',
	'BLOG_ENABLE_ZEBRA_EXPLAIN'				=> 'Bunu devredışı bırakmanız halinde kullanıcılar arkadaş/yasaklı listesindekiler için görüntüleme izinlerini yönetemeyecekleri gibi birkaç ufak ayar daha yapamayacaklardır.',
	'BLOG_GUEST_CAPTCHA'					=> 'Ziyaretçiler cevap gönderirken Captcha doğrulamasını zorunlu kıl',
	'BLOG_INFORM'							=> 'Onay gereken repor veya iletilerde kullanıcıyı özel mesaj ile haberdar et',
	'BLOG_INFORM_EXPLAIN'					=> 'Bir günlük girdisi veya yanıtı rapor edildiğinde ya da onay gereken bir günlük girdisi veya iletisi yazıldığından özel mesaj ile bilgilendirilecek user_id’lerini giriniz. Birden fazla kullanı için virgül kullanınız ve boşluk eklemeyiniz.',
	'BLOG_MAX_ATTACHMENTS'					=> 'İleti için izin verilen en fazla dosya boyutu',
	'BLOG_MAX_ATTACHMENTS_EXPLAIN'			=> 'Kullanıcı izinlerinden istediğiniz bir kullanıcı için bu sınırı değiştirebilirsiniz.',
	'BLOG_MAX_RATING'						=> 'Derecelendirmede en çok değer',
	'BLOG_MAX_RATING_EXPLAIN'				=> 'Derecelendirme için izin verilen en çok sayısal değeri buradan ayarlayabilirsiniz.',
	'BLOG_MESSAGE_FROM'						=> 'Gönderen',
	'BLOG_MESSAGE_FROM_EXPLAIN'				=> 'Bildirimler mesajlarında görüntülenecek kullanıcıya ait user_id değeri. Eğer ilgili kullanıcı oluşturulmamışsa hata verecektir.',
	'BLOG_MIN_RATING'						=> 'Derecelendirmede en az değer',
	'BLOG_MIN_RATING_EXPLAIN'				=> 'Derecelendirme için izin verilen en az sayısal değeri buradan ayarlayabilirsiniz.',
	'BLOG_POST_VIEW_SETTINGS'				=> 'Günlük görüntüleme ve mesaj ayarları',
	'BLOG_QUICK_REPLY'						=> 'Hızlı Cevap',
	'BLOG_QUICK_REPLY_EXPLAIN'				=> 'Bir günlük görüntülenirken hızlı cevap butonunu göster.',
	'BLOG_SETTINGS'							=> 'Kullanıcı Günlük Ayarları',
	'BLOG_SETTINGS_EXPLAIN'					=> 'Kullanıcı Günlük Eklentisinin ayarlarını buradan yapabilirsiniz.',

	'CATEGORY_CREATED'						=> 'Kategori başarıyla oluşturuldu!',
	'CATEGORY_DELETE'						=> 'Kategori Sil',
	'CATEGORY_DELETED'						=> 'Kategori başarıyla silindi!',
	'CATEGORY_DELETE_EXPLAIN'				=> 'Bu kategoriyi silmek istediğinizden emin misiniz?',
	'CATEGORY_DESCRIPTION_EXPLAIN'			=> 'Kategori açıklaması.',
	'CATEGORY_EDIT_EXPLAIN'					=> 'Burada kategori ayarlarını değiştirebilirsiniz.',
	'CATEGORY_INDEX'						=> 'Kategori İndeksi',
	'CATEGORY_NAME_EMPTY'					=> 'Kategori için bir isim belirtmelisiniz',
	'CATEGORY_PARENT'						=> 'Ana Kategori',
	'CATEGORY_RULES_EXPLAIN'				=> 'Burada kategoriniz için kuralları yazabilirsiniz. Bu her bir kategoride ayrı ayrı gösterilir.',
	'CATEGORY_SETTINGS'						=> 'Kategori Ayarları',
	'CATEGORY_UPDATED'						=> 'Kategori başarıyla güncelleştirildi!',
	'CLICK_CHECK_NEW_VERSION'				=> 'Kullanıcı Günlük Eklentisinin sürüm kontrolü yapmak için %sburayı%s tıklayın.',
	'CLICK_GET_NEW_VERSION'					=> 'Kullanıcı Günlük Eklentisinin son sürümünü edinmek için %sburayı%s tıklayın.',
	'CLICK_UPDATE'							=> 'Kullanıcı Günlük Eklentisi için veritabanı güncellemesi için %sburayı%s tıklayın.',
	'CONTINUE'								=> 'Devam et',
	'COPYRIGHT'								=> 'Telif hakkı',
	'CREATE_CATEGORY'						=> 'Kategori Oluştur',

	'DATABASE_VERSION'						=> 'Veritabanı Sürümü',
	'DEFAULT_TEXT_LIMIT'					=> 'Günlük anasayfaları için karakter sınırı',
	'DEFAULT_TEXT_LIMIT_EXPLAIN'			=> 'Bu değerden çok karaktere sahip iletiler kısaltılacaktır.',
	'DELETE_SUBCATEGORIES'					=> 'Alt Kategorileri Sil',

	'EDIT_CATEGORY'							=> 'Kategoriyi Değiştir',
	'ENABLE_BLOG_CUSTOM_PROFILES'			=> 'Günlük sayfalarında özel profil alanlarını göster',
	'ENABLE_SUBSCRIPTIONS'					=> 'Kullanıcı/Günlük Abonelikleri',
	'ENABLE_SUBSCRIPTIONS_EXPLAIN'			=> 'Kayıtlı kullanıcıların günlüklerine abone olabilmesini sağlar.',
	'ENABLE_USER_BLOG'						=> 'Kullanıcı Günlük Eklentisi',
	'ENABLE_USER_BLOG_EXPLAIN'				=> 'Bu eklentiler kurulduktan sonra siz devredışı bırakmadıkça veya silmedikçe yönetim ve kullanıcı panelinde gözükecektir.',
	'ENABLE_USER_BLOG_PLUGINS'				=> 'Eklenti Sistemi',
	'ENABLE_USER_BLOG_PLUGINS_EXPLAIN'		=> 'Bunu devredışı bırakmanız halinde kurulu bileşenler çalışmayacaktır. Ayrıca ACP’de bu eklentiye ait bileşenler sekmesi görüntülenmeyecektir.',

	'FILE_VERSION'							=> 'Dosya Sürümleri',

	'INSTALLED_PLUGINS'						=> 'Kurulu Eklentiler',

	'LATEST_VERSION'						=> 'Son Sürüm',

	'MOVE_BLOGS_TO'							=> 'Günlükleri taşı',
	'MOVE_SUBCATEGORIES_TO'					=> 'Alt kategorileri taşı',

	'NOT_ALLOWED_IN_BLOG'					=> 'Kullanıcı Günlüklerine izin verilmiyor',
	'NO_DESTINATION_CATEGORY'				=> 'Hedef Kategori Belirtilmedi',
	'NO_INSTALLED_PLUGINS'					=> 'Kurulmuş Bileşen Yok',
	'NO_PARENT'								=> 'Üst Dizin Yok',
	'NO_UNINSTALLED_PLUGINS'				=> 'Silinmiş Bileşen Yok',

	'OUTPUT_CPLINKS_BLOCK'					=> 'Günlük Linkleri Özel Profil Alanlarında Gösterilsin',
	'OUTPUT_CPLINKS_BLOCK_EXPLAIN'			=> 'Hayır olarak seçmeniz durumunda özel profil alanında günlük bağlantısı gözükmeyecektir.',

	'PARENT_NOT_EXIST'						=> 'Seçilen üst dizin bulunamadı.',
	'PLUGINS_DISABLED'						=> 'Bileşenler devredışı.',
	'PLUGINS_NAME'							=> 'Bileşen Adı',
	'PLUGIN_ACTIVATE'						=> 'Etkinleştir',
	'PLUGIN_ALREADY_INSTALLED'				=> 'Seçili bileşenler zaten kurulu.',
	'PLUGIN_DEACTIVATE'						=> 'Devredışı bırak',
	'PLUGIN_INSTALL'						=> 'Kur',
	'PLUGIN_NOT_EXIST'						=> 'Seçili eklenti bulunamadı.',
	'PLUGIN_NOT_INSTALLED'					=> 'Seçili eklenti kurulmamış.',
	'PLUGIN_UNINSTALL'						=> 'Kaldır',
	'PLUGIN_UNINSTALL_CONFIRM'				=> 'Bu bileşeni silmek istediğinize emin misiniz?<br /><strong>Veritabanındaki ilgili tüm bilgiler siliecektir.</strong><br /><br />Bu eklentiyi kaldırmak için ilgili tüm değişiklikleri geri almalısınız.',
	'PLUGIN_UPDATE'							=> 'Veritabanını Günlük lleştir',

	'REMOVE_ALL_BLOGS'						=> 'Kategoriyi şimdi silebilirsiniz.',

	'SELECT_CATEGORY'						=> 'Kategori Seçiniz',

	'UNINSTALLED_PLUGINS'					=> 'Silinmiş Eklentiler',
	'USER_TEXT_LIMIT'						=> 'Kullanıcı Günlüğü için varsayılan karakter sınırı',
	'USER_TEXT_LIMIT_EXPLAIN'				=> 'Görüntülenme sayfasında görüntülenecek karakter sınırı. Günlük karakter sınırı benzeridir.',

	'VERSION'								=> 'Sürüm',
));

?>