<?php
/**
*
* @package phpBB3 User Blog
* @version $Id: misc.php 485 2008-08-15 23:33:57Z exreaction@gmail.com $
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @translator muiketi - http://www.phpbbturkiye.net/memberlist.php?mode=viewprofile&u=666
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ALREADY_SUBSCRIBED'		=> 'Zaten abonesiniz.',

	'BLOG_USER_NOT_PROVIDED'	=> 'Abone olmak istediğiniz günlüğün user_id veya blog_id verilerini girmek zorundasınız.',

	'NOT_ALLOWED_CHANGE_VOTE'	=> 'Kullandığınız oyu değiştiremezsiniz.',
	'NOT_SUBSCRIBED'			=> 'Abone değilsiniz.',

	'RESYNC_BLOG'				=> 'Günlüğü Senkronize Et',
	'RESYNC_BLOG_CONFIRM'		=> 'Tüm günlük verisini senkronize etmek istediğinize emin misiniz? Bu biraz zaman alabilir.',
	'RESYNC_BLOG_SUCCESS'		=> 'Günlük verisi başarıyla senkronize edildi.',

	'SEARCH_BLOG_ONLY'			=> 'Sadece Günlükleri Ara',
	'SEARCH_BLOG_TITLE_ONLY'	=> 'Sadece Başlıkları Ara',
	'SEARCH_TITLE_MSG'			=> 'Başlıkları ve İçerikleri Ara',
	'SUBSCRIBE_BLOG_CONFIRM'	=> 'Günlüğe yeni bir yanıt yazıldığında nasıl bilgilendirilmek istersiniz?',
	'SUBSCRIBE_BLOG_TITLE'		=> 'Günlük aboneliği',
	'SUBSCRIPTION_ADDED'		=> 'Abonelik başarıyla oluşturuldu.',
	'SUBSCRIPTION_REMOVED'		=> 'Abonellik başarıyla sonlandırıldı.',

	'UNSUBSCRIBE_BLOG_CONFIRM'	=> 'Bu günlüğe ait aboneliğinizi sonlandırmak istediğinize emin misiniz?',
	'UNSUBSCRIBE_USER_CONFIRM'	=> 'Bu kullanıcıya ait aboneliğinizi sonlandırmak istediğinize emin misiniz?',
));

?>