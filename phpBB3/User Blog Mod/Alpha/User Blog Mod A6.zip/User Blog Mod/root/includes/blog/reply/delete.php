<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// If they did not include the $reply_id give them an error...
if ($reply_id == 0)
{
	trigger_error('NO_REPLY');
}

// Was Cancel pressed? If so then redirect to the appropriate page
if ($cancel)
{
	$redirect = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;r=' . $reply_id);
	redirect($redirect);
}

// Get the reply's data, and check if there is no reply...
if ($blog_data->get_reply_data(array('reply_id' => $reply_id, 'simple' => true)) === false)
{
	trigger_error('NO_REPLY');
}

// Get the author data, setting $user_id & $blog_id to keep things shorter later
$user_id = $blog_data->reply[$reply_id]['user_id'];
$blog_id = $blog_data->reply[$reply_id]['blog_id'];
$blog_data->get_user_data($user_id);

// check to see if editing this message is locked, or if the one editing it has mod powers
if ( $blog_data->reply[$reply_id]['reply_edit_locked'] && !($auth->acl_get('m_replyedit')) && !($auth->acl_get('a_replydelete')) )
{
	trigger_error('REPLY_EDIT_LOCKED');
}
	
// check permissions
if ( !($auth->acl_get('u_blogreplydelete') && $user->data['user_id'] == $user_id) && !($auth->acl_get('m_blogdelete')) && !($auth->acl_get('a_blogreplydelete')) )
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}

$self_url = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=reply&amp;mode=delete&amp;r=' . $reply_id);
$view_user_url = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=user&amp;u=' . $user_id);
$view_reply_url = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=reply&amp;b=' . $blog_id . '#' . $reply_id);

// Setup the page header and sent the title of the page that will go into the browser header
page_header($user->lang['DELETE_REPLY']);

// Generate the breadcrumbs
$breadcrumbs = array(
	sprintf($user->lang['USERNAMES_BLOGS'], $blog_data->user[$user_id]['username']) => $view_user_url,
	$user->lang['DELETE_REPLY'] => $self_url,
	);
generate_blog_breadcrumbs($breadcrumbs);


if ( ($blog_data->reply[$reply_id]['reply_deleted'] != 0) && (!$auth->acl_get('a_blogreplydelete')) )
{
	trigger_error('REPLY_ALREADY_DELETED');
}

if (confirm_box(true))
{
	if ( ($blog_data->reply[$reply_id]['reply_deleted'] != 0) && ($auth->acl_get('a_blogreplydelete')) ) // if it has already been soft deleted, and we want to hard delete it
	{
		// delete the reply
		$sql = 'DELETE FROM ' . BLOGS_REPLY_TABLE . ' WHERE reply_id = \'' . $reply_id . '\'';
		$db->sql_query($sql);
	}
	else
	{
		// soft delete the reply
		$sql = 'UPDATE ' . BLOGS_REPLY_TABLE . ' SET reply_deleted = \'' . $user->data['user_id'] . ' \', reply_deleted_time = \'' . time() . '\' WHERE reply_id = \'' . $reply_id . '\'';
		$db->sql_query($sql);

		// update the reply count for the blog
		$sql = 'UPDATE ' . BLOGS_TABLE . ' SET blog_reply_count = blog_reply_count - 1 WHERE blog_id = \'' . $blog_id . '\'';
		$db->sql_query($sql);
	}

	meta_refresh(3, $view_user_url);

	$message = $user->lang['REPLY_DELETED'];

	if ($user->data['user_id'] == $user_id)
	{
		$message .= '<br/><br/>' . sprintf($user->lang['RETURN_BLOG_MAIN_OWN'], '<a href="' . $view_user_url . '">', '</a>');
	}
	else
	{
		$message .= '<br/><br/>' . sprintf($user->lang['RETURN_BLOG_MAIN'], '<a href="' . $view_user_url . '">', $username, '</a>');
	}

	trigger_error($message);
}
else
{
	if ( ($blog_data->reply[$reply_id]['reply_deleted'] != 0)) // if it has already been soft deleted and we are not trying to undelete
	{
		confirm_box(false, 'PERMANENTLY_DELETE_REPLY');
	}
	else
	{
		confirm_box(false, 'DELETE_REPLY');
	}
}

// they pressed No, so redirect them
redirect($view_user_url);
?>