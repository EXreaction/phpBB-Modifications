<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// Add the language Variables for viewtopic
$user->add_lang('viewtopic');

// page variables
$random = ($mode == 'random') ? true : false;
$recent = ($mode == 'recent') ? true : false;
$popular = ($mode == 'popular') ? true : false;
$all = (!$random && !$recent && !$popular) ? true : false;

$limit = intval(request_var('limit', 5));


generate_blog_breadcrumbs(array($user->lang['USER_BLOGS'] => append_sid("{$phpbb_root_path}blog.$phpEx")));
page_header($user->lang['USER_BLOGS']);

// Random Blogs
$random_blog_ids = ($random || $all) ? $blog_data->get_blog_data(array('random' => true, 'limit' => $limit)) : false;

// Recent Blogs
$recent_blog_ids = ($recent || $all) ? $blog_data->get_blog_data(array('recent' => true, 'limit' => $limit)) : false;

// Popular blogs
$popular_blog_ids = ($popular || $all) ? $blog_data->get_blog_data(array('popular' => true, 'limit' => $limit)) : false;

// get the user data from the users listed in the queue
$blog_data->get_user_data(false, true);

$template->assign_vars(array(
	'RANDOM'			=> ($random || $all) ? true : false,
	'RECENT'			=> ($recent || $all) ? true : false,
	'POPULAR'			=> ($popular || $all) ? true : false,

	'SECTION_WIDTH'		=> ($all) ? '33' : '100',
));

// Output the random blogs
if ($random_blog_ids !== false)
{
	foreach ($random_blog_ids as $id)
	{
		$user_row = $blog_data->handle_user_data($blog_data->blog[$id]['user_id']);

		$blog_row = array(
			'U_VIEW'		=> append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $id),
			'SUBJECT'		=> $blog_data->blog[$id]['blog_subject'],
			'DATE'			=> $user->format_date($blog_data->blog[$id]['blog_time']),

			'TEXT'			=> $blog_data->trim_text_length($id, false, 50, true),
		);
	
		$template->assign_block_vars('randomrow', $user_row + $blog_row);
	}
}

// Output the recent blogs
if ($recent_blog_ids !== false)
{
	foreach ($recent_blog_ids as $id)
	{
		$user_row = $blog_data->handle_user_data($blog_data->blog[$id]['user_id']);

		$blog_row = array(
			'U_VIEW'		=> append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $id),
			'SUBJECT'		=> $blog_data->blog[$id]['blog_subject'],
			'DATE'			=> $user->format_date($blog_data->blog[$id]['blog_time']),
	
			'TEXT'			=> $blog_data->trim_text_length($id, false, 50, true),
		);

		$template->assign_block_vars('recentrow', $user_row + $blog_row);
	}
}

// Output the popular blogs
if ($popular_blog_ids !== false)
{
	foreach ($popular_blog_ids as $id)
	{
		$user_row = $blog_data->handle_user_data($blog_data->blog[$id]['user_id']);

		$blog_row = array(
			'U_VIEW'		=> append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $id),
			'SUBJECT'		=> $blog_data->blog[$id]['blog_subject'],
			'DATE'			=> $user->format_date($blog_data->blog[$id]['blog_time']),
	
			'TEXT'			=> $blog_data->trim_text_length($id, false, 50, true),
		);

		$template->assign_block_vars('popularrow', $user_row + $blog_row);
	}
}

// tell the template parser what template file to use
$template->set_filenames(array(
	'body' => 'view_blog_main.html'
));
?>