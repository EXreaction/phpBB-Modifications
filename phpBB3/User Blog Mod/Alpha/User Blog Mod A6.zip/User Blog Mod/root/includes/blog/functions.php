<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

/*
* Add the links in the custom profile fields
*
* $user_id is the users id...
* $block is the name of the custom profile block we insert it into
* $user_data is extra data on the user.  If blog_count is supplied in $user_data we can skip 1 sql query
* if $grab_from_db is true we will run the query to find out how many blogs the user has if the data isn't supplied in $user_data, otherwise we won't and just display the link alone.
*/
function add_blog_links($user_id, $block, $user_data = false, $grab_from_db = false)
{
	global $db, $template, $user, $phpbb_root_path, $phpEx;

	// if they are not an anon user, and they blog_count row isn't set grab that data from the db.
	if ($user_id > 1 && !isset($user_data['blog_count']))
	{
		if ($grab_from_db)
		{
			$sql = 'SELECT blog_count FROM ' . USERS_TABLE . ' WHERE user_id = \'' . intval($user_id) . '\'';
			$result = $db->sql_query($sql);
			$user_data = $db->sql_fetchrow($result);
		}
		else
		{
			// set this to 0 so it isn't outputted later again
			$user_data['blog_count'] = 0;

			$template->assign_block_vars($block, array(
				'PROFILE_FIELD_NAME'		=> $user->lang['BLOG'],
				'PROFILE_FIELD_VALUE'		=> '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=user&amp;u=' . $user_id) . '">' . $user->lang['VIEW_BLOGS'] . '</a>',
			));
		}
	}
	
	// if they don't have any blogs don't even show the link to view them...
	if ($user_data['blog_count'] != 0)
	{
		$template->assign_block_vars($block, array(
			'PROFILE_FIELD_NAME'		=> $user->lang['BLOG'],
			'PROFILE_FIELD_VALUE'		=> '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=user&amp;u=' . $user_id) . '">' . $user->lang['VIEW_BLOGS'] . ' (' .$user_data['blog_count'] . ')</a>',
		));
	}
}

/*
* Informs users when a blog or reply was reported or needs approval
*/
function inform_approve_report($mode, $id)
{
	global $phpbb_root_path, $phpEx, $config, $user;

	// include the private messages functions page
	include_once("{$phpbb_root_path}includes/functions_privmsgs.$phpEx");

	// this will hold the address list
	$address_list = array();

	// setup out to address list
	if (!is_array($config['blog_inform']))
	{
		$address_list[$config['blog_inform']] = 'to';
	}
	else
	{
		foreach ($config['blog_inform'] as $id)
		{
			$address_list[$id] = 'to';
		}
	}

	switch ($mode)
	{
		case 'blog_report' :
			$message = sprintf($user->lang['BLOG_REPORT_PM'], $user->data['username'], append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $id));
			$subject = $user->lang['BLOG_REPORT_PM_SUBJECT'];
			break;
		case 'reply_report' :
			$message = sprintf($user->lang['REPLY_REPORT_PM'], $user->data['username'], append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;r=' . $id));
			$subject = $user->lang['REPLY_REPORT_PM_SUBJECT'];
			break;
		case 'blog_approve' :
			$message = sprintf($user->lang['BLOG_APPROVE_PM'], $user->data['username'], append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $id));
			$subject = $user->lang['BLOG_APPROVE_PM_SUBJECT'];
			break;
		case 'reply_approve' :
			$message = sprintf($user->lang['REPLY_APPROVE_PM'], $user->data['username'], append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;r=' . $id));
			$subject = $user->lang['REPLY_APPROVE_PM_SUBJECT'];
	}

	$message_parser = new parse_message();
	$message_parser->message = $message;
	$message_parser->parse(true, true, true, true, true, true, true);

	$pm_data = array(
		'from_user_id'		=> $user->data['user_id'],
		'from_username'		=> $user->data['username'],
		'address_list'		=> array('u' => $address_list),
		'icon_id'			=> 10,
		'from_user_ip'		=> '192.168.1.1',
		'enable_bbcode'		=> true,
		'enable_smilies'	=> true,
		'enable_urls'		=> true,
		'enable_sig'		=> false,
		'message'			=> $message_parser->message,
		'bbcode_bitfield'	=> $message_parser->bbcode_bitfield,
		'bbcode_uid'		=> $message_parser->bbcode_uid,
	);

	submit_pm('post', $subject, $pm_data, false);
}

/*
* Create the breadcrumbs
*/
function generate_blog_breadcrumbs($crumbs)
{
	global $template;

	foreach ($crumbs as $text => $link)
	{
		$template->assign_block_vars('navlinks', array(
			'FORUM_NAME'	=> $text,
			'U_VIEW_FORUM'	=> $link,
		));
	}
}

/*
* Generates the left side menu
*/
function generate_menu($user_id)
{
	global $db, $template, $phpbb_root_path, $phpEx, $user, $blog_data;

// output the data for the left author info menu
	$template->assign_vars($blog_data->handle_user_data($user_id));
	$blog_data->handle_user_data($user_id, 'custom_fields');

// archive menu
	// Last Month's ID(set to 0 now, will be updated in the loop)
	$last_mon = 0;

	// Count Variable
	$i = 0;

	// SQL query
	$sql = 'SELECT blog_id, blog_time, blog_subject FROM ' . BLOGS_TABLE . '
				WHERE user_id = \'' . $user_id . '\'
					AND blog_deleted = \'0\'
						ORDER BY blog_id DESC';

	$result = $db->sql_query($sql);

	while($row = $db->sql_fetchrow($result))
	{
		$date = getdate($row['blog_time']);

		// If we are starting a new month
		if ($date['mon'] != $last_mon)
		{
			// Output the month and year
			$template->assign_block_vars('archiverow', array(
				'MONTH'			=> $date['month'],
				'YEAR'			=> $date['year'],

				'S_FIRST'		=> ($i == 0) ? true : false,

				// output the counter
				'I'				=> $i,
			));
		}

		// Now output the title, view blog link, and date
		$template->assign_block_vars('archiverow.monthrow', array(
			'TITLE'			=> $row['blog_subject'],
			'U_VIEW'		=> append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=blog&amp;b=" . $row['blog_id']),
			'DATE'			=> $user->format_date($row['blog_time']),
		));

		// set the last month variable as the current month
		$last_mon = $date['mon'];

		// Increment the counter
		$i++;
	}

	// output some data
	$template->assign_vars(array(
		// are there any archives?
		'S_ARCHIVES'	=> ($i > 0) ? true : false,
	));

	$db->sql_freeresult($result);
}

/*
* This should never need to be used unless someone manually deletes blogs or replies from the database
* It is not used by the User Blog mod anywhere, but included along here if any other user needs it.
* To any potential users: Make sure you do not set this in a page where it gets ran often.  Resyncing data is a long process, especially when the number of blogs that you have is large
*
* $mode can be all, reply_count, delete_orphan_replies, or blog_count
*/
function resync_blog($mode)
{
	global $db;

	$blog_data = array();
	$reply_data = array();

	// Start by selecting all blog data that we will use
	$sql = 'SELECT blog_id, blog_reply_count FROM ' . BLOGS_TABLE . ' ORDER BY blog_id ASC';
	$result = $db->sql_query($sql);
	while($row = $db->sql_fetchrow($result))
	{
		$blog_data[$row['blog_id']] = $row;
	}
	$db->sql_freeresult($result);

	/*
	* Update & Resync the reply counts
	*/
	if ( ($mode == 'reply_count') || ($mode == 'all') )
	{
		foreach($blog_data as $row)
		{
			// count all the replies (an SQL query seems the easiest way to do it)
			$sql = 'SELECT count(reply_id) AS total 
				FROM ' . BLOGS_REPLY_TABLE . ' 
					WHERE blog_id = \'' . $row['blog_id'] . '\' 
						AND reply_deleted = \'0\' 
						AND reply_approved = \'1\'';
			$result = $db->sql_query($sql);
			$total = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);

			if ($total['total'] != $row['blog_reply_count'])
			{
				// Update the reply count
				$sql = 'UPDATE ' . BLOGS_TABLE . ' SET blog_reply_count = \'' . $total['total'] . '\' WHERE blog_id = \'' . $row['blog_id'] . '\'';
				$db->sql_query($sql);
			}
		}
	}

	/*
	* Delete's all oprhaned replies (replies where the blogs they should go under have been deleted).
	*/
	if ( ($mode == 'delete_orphan_replies') || ($mode == 'all') )
	{
		// Now get all reply data we will use
		$sql = 'SELECT reply_id, blog_id FROM ' . BLOGS_REPLY_TABLE . ' ORDER BY reply_id ASC';
		$result = $db->sql_query($sql);
		while($row = $db->sql_fetchrow($result))
		{
			// if the blog_id it attached to is not in $blog_data
			if (!(array_key_exists($row['blog_id'], $blog_data)))
			{
				$sql2 = 'DELETE FROM ' . BLOGS_REPLY_TABLE . ' WHERE reply_id = \'' . $row['reply_id'] . '\'';
				$db->sql_query($sql2);
			}
		}
		$db->sql_freeresult($result);
	}

	/*
	* Updates the blog_count for each user
	*/
	if ( ($mode == 'blog_count') || ($mode == 'all') )
	{
		// select the users data we will need
		$sql = 'SELECT user_id, blog_count FROM ' . USERS_TABLE;
		$result = $db->sql_query($sql);
		while($row = $db->sql_fetchrow($result))
		{
			// count all the replies (an SQL query seems the easiest way to do it)
			$sql2 = 'SELECT count(blog_id) AS total 
				FROM ' . BLOGS_TABLE . ' 
					WHERE user_id = \'' . $row['user_id'] . '\' 
						AND blog_deleted = \'0\' 
						AND blog_approved = \'1\'';
			$result2 = $db->sql_query($sql2);
			$total = $db->sql_fetchrow($result2);
			$db->sql_freeresult($result2);

			if ($total['total'] != $row['blog_count'])
			{
				// Update the reply count
				$sql = 'UPDATE ' . USERS_TABLE . ' SET blog_count = \'' . $total['total'] . '\' WHERE user_id = \'' . $row['user_id'] . '\'';
				$db->sql_query($sql);
			}
		}
		$db->sql_freeresult($result);
	}
}
?>