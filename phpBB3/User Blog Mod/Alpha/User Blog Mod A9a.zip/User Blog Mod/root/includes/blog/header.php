<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// Add some language variables
$user->add_lang('blog');

// include the functions file
include_once($phpbb_root_path . 'includes/blog/functions.' . $phpEx);

// Add the User Blog's Link if they can view blog's
if ($auth->acl_get('u_blogview'))
{
	$template->assign_block_vars('blog_links', array(
		'URL'		=> append_sid("{$phpbb_root_path}blog.$phpEx"),
		'CLASS'		=> 'icon-members',
		'IMG'		=> '<img src="' . $phpbb_root_path . 'styles/' . $user->theme['theme_path'] . '/theme/images/icon_mini_members.gif" />',
		'TEXT'		=> $user->lang['USER_BLOGS'],
	));
}

// Add the My Blog's Link if they can view blogs and are registered
if ($auth->acl_get('u_blogpost') || ($user->data['blog_count'] > 0 && $auth->acl_get('u_blogview')))
{
	$template->assign_block_vars('blog_links', array(
		'URL'		=> append_sid("{$phpbb_root_path}blog.$phpEx", 'u=' . $user->data['user_id']),
		'CLASS'		=> 'icon-ucp',
		'IMG'		=> '<img src="' . $phpbb_root_path . 'styles/' . $user->theme['theme_path'] . '/theme/images/icon_mini_message.gif" alt="' . $user->lang['MY_BLOGS'] . '" />',
		'TEXT'		=> $user->lang['MY_BLOGS'],
	));
}

// If we are viewing a users' profile add a link to view the users' blog in the custom profile section
if ( (request_var('mode', '') == 'viewprofile') && (request_var('u', '') != '') )
{
	add_blog_links(request_var('u', ''), 'custom_fields', false, true);
}
?>