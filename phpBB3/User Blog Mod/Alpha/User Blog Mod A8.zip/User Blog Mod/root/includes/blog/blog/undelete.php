<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// If they did not include the $blog_id give them an error...
if ($blog_id == 0)
{
	trigger_error('NO_BLOG');
}

// Was Cancel pressed? If so then redirect to the appropriate page
if ($cancel)
{
	$redirect = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $blog_id);
	redirect($redirect);
}

// Get the blog's data, and check if there is no blog...
if ($blog_data->get_blog_data(array('blog_id' => $blog_id, 'simple' => true)) === false)
{
	trigger_error('NO_BLOG');
}

// Get the author data, settings $user_id to keep things shorter later
$user_id = $blog_data->blog[$blog_id]['user_id'];
$blog_data->get_user_data($user_id);
	
// check permissions
if ( !($auth->acl_get('m_blogdelete')) && !($auth->acl_get('a_blogdelete')) )
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}

$self_url = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=blog&amp;mode=undelete&amp;b=' . $blog_id);
$view_user_url = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=user&amp;u=' . $user_id);
$view_blog_url = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $blog_id);

// Setup the page header and sent the title of the page that will go into the browser header
page_header($user->lang['UNDELETE_BLOG']);

// Generate the breadcrumbs
$breadcrumbs = array(
	sprintf($user->lang['USERNAMES_BLOGS'], $blog_data->user[$user_id]['username']) => $view_user_url,
	$user->lang['UNDELETE_BLOG'] => $self_url,
	);
generate_blog_breadcrumbs($breadcrumbs);

if ($blog_data->blog[$blog_id]['blog_deleted'] == 0) // if someone is trying to un-delete a blog and the blog is not deleted
{
	trigger_error('BLOG_NOT_DELETED');
}

if (confirm_box(true))
{
	// magically un-delete the blog ;-)
	$sql = 'UPDATE ' . BLOGS_TABLE . ' SET blog_deleted = \'0\', blog_deleted_time = \'0\' WHERE blog_id = \'' . $blog_id . '\'';
	$db->sql_query($sql);

	// Update the blog_count for the user
	$sql = 'UPDATE ' . USERS_TABLE . ' SET blog_count = blog_count + 1 WHERE user_id = \'' . $user_id . '\'';
	$db->sql_query($sql);

	meta_refresh(3, $view_blog_url);

	$message = $user->lang['BLOG_UNDELETED'];
	$message .= '<br/><br/><a href="' . $view_blog_url. '">' . $user->lang['VIEW_BLOG'] . '</a>';

	if ($user->data['user_id'] == $user_id)
	{
		$message .= '<br/><br/>' . sprintf($user->lang['RETURN_BLOG_MAIN_OWN'], '<a href="' . $view_user_url . '">', '</a>');
	}
	else
	{
		$message .= '<br/><br/>' . sprintf($user->lang['RETURN_BLOG_MAIN'], '<a href="' . $view_user_url . '">', $username, '</a>');
	}

	trigger_error($message);
}
else
{
	confirm_box(false, 'UNDELETE_BLOG');
}

// they pressed No, so redirect them
redirect($view_user_url);
?>