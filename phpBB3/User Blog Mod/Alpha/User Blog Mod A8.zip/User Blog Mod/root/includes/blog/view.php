<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// shorten some variables for later use
$deleted = ($mode == 'deleted') ? true : false; // viewing deleted blogs
$blog = ($mode == 'blog') ? true : false; // viewing a certain blog

// check permissions
if ( ((!$deleted) && (!$auth->acl_get('u_blogview'))) || ($deleted && ( (!$auth->acl_get('m_blogdelete')) || (!$auth->acl_get('a_blogdelete')) ) ) )
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}
	
// Add the language Variables for viewtopic
$user->add_lang('viewtopic');

// Get the Blog Data
if ($blog)
{
	if ($blog_id != 0)
	{
		// Try getting the blog, if it doesn't exist the function should return false, so we can check for that right away as well
		if (!$blog_data->get_blog_data(array('blog_id' => $blog_id)))
		{
			trigger_error('NO_BLOG');
		}
	}
	else if ($reply_id != 0)
	{
		// Try getting the blog_id if they only give us the reply_id
		if (!$blog_data->get_reply_data(array('reply_id' => $reply_id)))
		{
			trigger_error('NO_BLOG');
		}

		$blog_id = $blog_data->reply[$reply_id]['blog_id'];

		// Try getting the blog, if it doesn't exist the function should return false, so we can check for that right away as well
		if (!$blog_data->get_blog_data(array('blog_id' => $blog_id)))
		{
			trigger_error('NO_BLOG');
		}
	}
	else
	{
		trigger_error('NO_BLOG');
	}

	// if the blog was deleted and the person trying to view the blog is not a moderator that can view deleted blogs, give them a nice error. :P
	if ( ($blog_data->blog[$blog_id]['blog_deleted'] != 0) && (!$auth->acl_get('m_blogdelete')) )
	{
		trigger_error('BLOG_DELETED');
	}

	// for consistency
	$user_id = $blog_data->blog[$blog_id]['user_id'];
	$blog_ids = array($blog_id);
}
else
{
	// Make sure they included a user_id when they requested the page.
	if ($user_id == 0)
	{
		trigger_error('NO_USER');
	}

	// Get the blogs
	if ($deleted)
	{
		$blog_ids = $blog_data->get_blog_data(array('user_id' => $user_id, 'deleted' => true));
	}
	else
	{
		$blog_ids = $blog_data->get_blog_data(array('user_id' => $user_id));
	}
}

// Get the reply data if we need to
if ( ( ($blog) && (($blog_data->blog[$blog_id]['blog_reply_count'] > 0) ) )  ||  ( ($blog) && ($auth->acl_get('m_blogapprove')) && ($blog_data->blog[$blog_id]['blog_real_reply_count'] > 0)) )
{
	if (!$feed)
	{
		// Get the data on all of the replies
		$reply_ids = $blog_data->get_reply_data(array('blog_id' => $blog_id));
	}
}
else
{
	$reply_ids = false;
}

// Moderation/user options - Anonymous users are not allowed to edit or delete blogs
$can_edit_blog = ( ( ($auth->acl_get('u_blogedit')) && ($user->data['user_id'] == $user_id) ) || ($auth->acl_get('m_blogedit')) ) ? true : false;
$can_delete_blog = ( ( ($auth->acl_get('u_blogdelete')) && ($user->data['user_id'] == $user_id) ) || ($auth->acl_get('m_blogdelete')) || ($auth->acl_get('a_blogdelete'))) ? true : false;
$can_add = ($auth->acl_get('u_blogpost')) ? true : false;
$can_reply = ($auth->acl_get('u_blogreply')) ? true : false;

// Get the data on the author
$blog_data->get_user_data($user_id);

if (!$feed)
{
	// Generate the left menu
	generate_menu($user_id);

	// Generate the breadcrumbs, setup the page header, and setup some variables we will use...
	$breadcrumbs[sprintf($user->lang['USERNAMES_BLOGS'], $blog_data->user[$user_id]['username'])] = append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=user&amp;u=" . $user_id);
}

if ($deleted)
{
	$self_url_vars = 'page=view&amp;mode=deleted&amp;u=' . $user_id;
	$self_url = append_sid("{$phpbb_root_path}blog.$phpEx", $self_url_vars);
	$breadcrumbs[$user->lang['DELETED_BLOGS']] = $self_url;
	$title = sprintf($user->lang['USERNAMES_DELETED_BLOGS'], $blog_data->user[$user_id]['username']);
}
else if ($blog)
{
	$self_url_vars = 'page=view&amp;mode=blog&amp;b=' . $blog_id;
	$self_url = append_sid("{$phpbb_root_path}blog.$phpEx", $self_url_vars);
	$breadcrumbs[$blog_data->blog[$blog_id]['blog_subject']] = $self_url;
	$title = $user->lang['VIEW_BLOG'] .' - ' . $blog_data->blog[$blog_id]['blog_subject'];
}
else
{
	$self_url_vars = 'page=view&amp;mode=user&amp;u=' . $user_id;
	$self_url = append_sid("{$phpbb_root_path}blog.$phpEx", $self_url_vars);
	$title = sprintf($user->lang['USERNAMES_BLOGS'], $blog_data->user[$user_id]['username']);
}

if (!$feed)
{
	generate_blog_breadcrumbs($breadcrumbs);
	page_header($title);
}

// Output some data
$template->assign_vars(array(
	'POST_SUBJECT'		=> ($blog) ? $blog_data->blog[$blog_id]['blog_subject'] : '',
	'TITLE'				=> ($blog) ? $blog_data->blog[$blog_id]['blog_subject'] : '',
	'U_VIEW'			=> $self_url,

	'U_PRINT_TOPIC'		=> (!$user->data['is_bot']) ? append_sid("{$phpbb_root_path}blog.$phpEx", $self_url_vars .'&amp;view=print') : '',
	'S_PRINT_MODE'		=> $print,
	'U_BLOG'			=> ($print) ? generate_board_url() . "/blog.$phpEx?$self_url_vars" : $self_url,

	'U_ADD_BLOG'		=> ($can_add && !$deleted) ? append_sid("{$phpbb_root_path}blog.$phpEx", "page=blog&amp;mode=add") : '',
 	'U_REPLY_BLOG'		=> ($can_reply && $blog) ? append_sid("{$phpbb_root_path}blog.$phpEx", 'page=reply&amp;mode=add&amp;b=' . $blog_id) : '',

	'ADD_BLOG_IMG'		=> $phpbb_root_path . 'styles/' . $user->theme['template_path'] . '/imageset/' . $user->data['user_lang'] . '/button_blog_new.gif',
	'REPLY_BLOG_IMG'	=> $user->img('button_topic_reply', 'REPLY_TO_TOPIC'),
	'QUOTE_IMG'			=> $user->img('icon_post_quote', 'QUOTE'),
	'EDIT_IMG'			=> $user->img('icon_post_edit', 'EDIT_POST'),
	'DELETE_IMG'		=> $user->img('icon_post_delete', 'DELETE_POST'),
	'REPORT_IMG'		=> $user->img('icon_post_report', 'REPORT_POST'),
	'WARN_IMG'			=> $user->img('icon_user_warn', 'WARN_USER'),
	'UNAPPROVED_IMG'	=> $user->img('icon_topic_unapproved', 'POST_UNAPPROVED'),
	'REPORTED_IMG'		=> $user->img('icon_topic_reported', 'POST_REPORTED'),
	'MINI_POST_IMG'		=> $user->img('icon_post_target', 'POST'),

	'PROFILE_IMG'		=> $user->img('icon_user_profile', 'READ_PROFILE'),
	'PM_IMG'			=> $user->img('icon_contact_pm', 'SEND_PRIVATE_MESSAGE'),
	'EMAIL_IMG'			=> $user->img('icon_contact_email', 'SEND_EMAIL'),
	'WWW_IMG'			=> $user->img('icon_contact_www', 'VISIT_WEBSITE'),
	'MSN_IMG'			=> $user->img('icon_contact_msnm', 'MSNM'),
	'YIM_IMG'			=> $user->img('icon_contact_yahoo', 'YIM'),
	'AIM_IMG'			=> $user->img('icon_contact_aim', 'AIM'),
	'ICQ_IMG'			=> $user->img('icon_contact_icq', 'ICQ'),
	'JABBER_IMG'		=> $user->img('icon_contact_jabber', 'JABBER'),
));

if ($blog_ids !== false)
{
	// read blogs, for updating the read count
	$read_blogs = array();

	// Counter variable
	$i = 0;

	if (!$feed)
	{
		// Since the get_blog_data function returns the id's of the blogs it found, we can use $blog_data->blog[$id] this way to get the blog's data
		foreach($blog_ids as $id)
		{
			// increment the counter
			$i++;

			if (!$blog)
			{
				$blog_text = $blog_data->trim_text_length($id, false, $config['blog_text_limit']);
				$shortened = ($blog_text === false) ? false : true;
				$blog_text = ($blog_text === false) ? $blog_data->blog[$id]['blog_text'] : $blog_text;
			}
			else
			{
				$blog_text = $blog_data->blog[$id]['blog_text'];
				$shortened = false;
			}

			// put the data in an array to output later
			$blogrow = array(
				'U_VIEW'			=> append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=blog&amp;b=" . $blog_data->blog[$id]['blog_id']),
		
				'TITLE'				=> $blog_data->blog[$id]['blog_subject'],
				'DATE'				=> $user->format_date($blog_data->blog[$id]['blog_time']),
				'BLOG_MESSAGE'		=> $blog_text,
				'USER_FULL'			=> $blog_data->user[$user_id]['username_full'],
		
				'U_QUOTE'			=> ($can_reply && !$shortened) ? append_sid("{$phpbb_root_path}blog.$phpEx", 'page=reply&amp;mode=quote&amp;b=' . $blog_data->blog[$id]['blog_id']) : '',
				'U_EDIT'			=> ($can_edit_blog && !$shortened) ? append_sid("{$phpbb_root_path}blog.$phpEx", "page=blog&amp;mode=edit&amp;b=" . $blog_data->blog[$id]['blog_id']) : '',
				'U_DELETE'			=> ($can_delete_blog && !$shortened && ($blog_data->blog[$id]['deleted_message'] == '' || $auth->acl_get('a_blogdelete'))) ? append_sid("{$phpbb_root_path}blog.$phpEx", "page=blog&amp;mode=delete&amp;b=" . $blog_data->blog[$id]['blog_id']) : '',
				'U_REPORT'			=> ($auth->acl_get('u_blogreport') && !$shortened) ? append_sid("{$phpbb_root_path}blog.$phpEx", 'page=blog&amp;mode=report&amp;b=' . $id) : '',
				'U_WARN'			=> ($auth->acl_get('m_warn') && $user_id != $user->data['user_id'] && $user_id != ANONYMOUS && !$shortened) ? append_sid("{$phpbb_root_path}mcp.$phpEx", 'i=warn&amp;mode=warn_user&amp;u=' . $user_id, true, $user->session_id) : '',
				'U_APPROVE'			=> ($auth->acl_get('m_blogapprove') && $blog_data->blog[$id]['blog_approved'] == 0 && !$shortened) ? append_sid("{$phpbb_root_path}blog.$phpEx", 'page=blog&amp;mode=approve&amp;b=' . $id) : '',
				'U_DIGG'			=> (!$shortened) ? 'http://digg.com/submit?phase=2&amp;url=' . urlencode(generate_board_url() . '/blog.' . $phpEx . '?page=view&amp;mode=blog&amp;b=' . $blog_data->blog[$id]['blog_id']) : '',

				'EDITED_MESSAGE'	=> $blog_data->blog[$id]['edited_message'],
				'EDIT_REASON'		=> $blog_data->blog[$id]['edit_reason'],
				'DELETED_MESSAGE'	=> $blog_data->blog[$id]['deleted_message'],
		
				'S_UNAPPROVED'		=> ($auth->acl_get('m_blogapprove') && $blog_data->blog[$id]['blog_approved'] == 0) ? true : false,
				'S_REPORTED'		=> ($blog_data->blog[$id]['blog_reported'] && $auth->acl_get('m_blogreport')) ? true : false,
		
				// the count of views or replies
				'VIEWS'				=> ($blog_data->blog[$id]['blog_read_count'] > 1) ? sprintf($user->lang['BLOG_VIEWS'], ($user->data['user_id'] != $user_id) ? $blog_data->blog[$id]['blog_read_count'] + 1 : $blog_data->blog[$id]['blog_read_count']) : $user->lang['BLOG_VIEW'],
				'REPLIES'			=> ($blog_data->blog[$id]['blog_reply_count'] != 1) ? ($blog_data->blog[$id]['blog_reply_count'] == 0) ? sprintf($user->lang['BLOG_REPLIES'], $blog_data->blog[$id]['blog_reply_count'], '', '') : sprintf($user->lang['BLOG_REPLIES'], $blog_data->blog[$id]['blog_reply_count'], '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=blog&amp;b=" . $blog_data->blog[$id]['blog_id']) . '#replies">', '</a>') : sprintf($user->lang['BLOG_REPLY'], '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=blog&amp;b=" . $blog_data->blog[$id]['blog_id']) . '#replies">', '</a>'),
		
				// is this the last one or not?
				'S_NOT_LAST'		=> ($i < count($blog_ids)) ? true : false,
		
				'S_ROW_COUNT'		=> $i,
			);
		
			// if the message was deleted lets tell the template that
			if ($blog_data->blog[$id]['deleted_message'] != '')
			{
				$template->assign_vars(array(
					'S_DELETED'		=> true,
				));
			}

			// for updating the readcount later
			if (!$shortened)
			{
				array_push($read_blogs, $id);
			}
		
			// Now output the data to the template
			$template->assign_block_vars('blogrow', $blogrow);
		}

		// to update the read count, we are only doing this if the user is not the owner, and the user doesn't view the shortened version, and we are not viewing the deleted blogs page
		if ( ($user->data['user_id'] != $user_id) && (!$deleted) && count($read_blogs))
		{
			$sql = 'UPDATE ' . BLOGS_TABLE . ' SET blog_read_count = blog_read_count + 1 WHERE ' . $db->sql_in_set('blog_id', $read_blogs);
			$db->sql_query($sql);
		}

		// For the replies
		if ($reply_ids !== false)
		{
			// tell the template we do have replies
			$template->assign_vars(array(
				'S_REPLIES'		=> ($blog_data->reply) ? true : false,
			));

			// Counter
			$i = 0;

			// use a foreach to easily output the data
			foreach($reply_ids as $id)
			{
				if ( ($blog_data->reply[$id]['deleted_message'] == '') || $auth->acl_get('m_blogdelete') || ($auth->acl_get('a_blogreplydelete')) )
				{
					// increment the counter
					$i++;

					// output the user data to the replyrow block
					$user_replyrow = $blog_data->handle_user_data($blog_data->reply[$id]['user_id']);

					$replyrow = array(
						'TITLE'				=> censor_text($blog_data->reply[$id]['reply_subject']),
						'DATE'				=> $user->format_date($blog_data->reply[$id]['reply_time']),

						'REPLY_MESSAGE'		=> $blog_data->reply[$id]['reply_text'],

						'EDITED_MESSAGE'	=> $blog_data->reply[$id]['edited_message'],
						'EDIT_REASON'		=> $blog_data->reply[$id]['edit_reason'],
						'DELETED_MESSAGE'	=> $blog_data->reply[$id]['deleted_message'],

						'U_VIEW'			=> append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $blog_id . '#r' . $blog_data->reply[$id]['reply_id']),

						'U_QUOTE'			=> ($can_reply && ($blog_data->reply[$id]['deleted_message'] == '')) ? append_sid("{$phpbb_root_path}blog.$phpEx", 'page=reply&amp;mode=quote&amp;b=' . $blog_id . '&amp;r=' . $blog_data->reply[$id]['reply_id']) : '',
						'U_EDIT'			=> (check_blog_permissions('reply', 'edit', $id)) ? append_sid("{$phpbb_root_path}blog.$phpEx", 'page=reply&amp;mode=edit&amp;r=' . $blog_data->reply[$id]['reply_id']) : '',
						'U_DELETE'			=> (check_blog_permissions('reply', 'delete', $id)) ? append_sid("{$phpbb_root_path}blog.$phpEx", 'page=reply&amp;mode=delete&amp;r=' . $blog_data->reply[$id]['reply_id']) : '',
						'U_REPORT'			=> ($auth->acl_get('u_blogreport')) ? append_sid("{$phpbb_root_path}blog.$phpEx", 'page=reply&amp;mode=report&amp;r=' . $id) : '',
						'U_WARN'			=> ($auth->acl_get('m_warn') && $blog_data->reply[$id]['user_id'] != $user->data['user_id'] && $blog_data->reply[$id]['user_id'] != ANONYMOUS) ? append_sid("{$phpbb_root_path}mcp.$phpEx", 'i=warn&amp;mode=warn_user&amp;u=' . $blog_data->reply[$id]['user_id'], true, $user->session_id) : '',
						'U_APPROVE'			=> ($auth->acl_get('m_blogapprove') && $blog_data->reply[$id]['reply_approved'] == 0) ? append_sid("{$phpbb_root_path}blog.$phpEx", 'page=reply&amp;mode=approve&amp;r=' . $id) : '',

						'S_UNAPPROVED'		=> ($auth->acl_get('m_blogapprove') && $blog_data->reply[$id]['reply_approved'] == 0) ? true : false,
						'S_REPORTED'		=> ($blog_data->reply[$id]['reply_reported'] && $auth->acl_get('m_blogreport')) ? true : false,

						// For the anchors
						'ID'				=> $blog_data->reply[$id]['reply_id'],

						// is it the last one?
						'S_LAST'		=> ($i == count($blog_data->reply)) ? true : false,
					);

					// send the data to the template
					$template->assign_block_vars('replyrow', $user_replyrow + $replyrow);

					// output the custom fields
					$blog_data->handle_user_data($blog_data->reply[$id]['user_id'], 'replyrow.custom_fields');
				}
			}
		}
	}
	else // if $feed
	{
		feed_output($blog_ids, $feed);
	}
}

if (!$feed)
{
	// tell the template parser what template file to use
	$template->set_filenames(array(
		'body' => 'view_blog.html'
	));
}

?>