<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

/*
* Add the links in the custom profile fields
*/
function add_blog_links($user_id, $block)
{
	global $template, $user, $phpbb_root_path, $phpEx;

	$template->assign_block_vars($block, array(
		'PROFILE_FIELD_NAME'		=> $user->lang['BLOG'],
		'PROFILE_FIELD_VALUE'		=> '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=user&amp;u=' . $user_id) . '">' . $user->lang['VIEW_BLOGS'] . '</a>',
	));
}

/**
* Create the breadcrumbs
*/
function generate_blog_breadcrumbs($crumbs)
{
	global $template;

	foreach ($crumbs as $text => $link)
	{
		$template->assign_block_vars('navlinks', array(
			'FORUM_NAME'	=> $text,
			'U_VIEW_FORUM'	=> $link,
		));
	}
}

/**
* Generates the left side menu
*/
function generate_menu($user_id)
{
	global $template, $blog_data;

	// output the data
	$template->assign_vars($blog_data->handle_user_data($user_id));

	$blog_data->handle_user_data($user_id, 'custom_fields');

	archive_list($user_id);
}

/**
* Generates the archive list
*/
function archive_list($user_id)
{
	global $db, $template, $phpbb_root_path, $phpEx, $user;

	// Last Month's ID(set to 0 now, will be updated in the loop)
	$last_mon = 0;

	// Count Variable
	$i = 0;

	// SQL query
	$sql = 'SELECT blog_id, blog_time, blog_subject FROM ' . BLOGS_TABLE . '
				WHERE user_id = \'' . $user_id . '\'
					AND blog_deleted = \'0\'
						ORDER BY blog_id DESC';

	$result = $db->sql_query($sql);

	while($row = $db->sql_fetchrow($result))
	{
		$date = getdate($row['blog_time']);

		// If we are starting a new month
		if ($date['mon'] != $last_mon)
		{
			// Output the month and year
			$template->assign_block_vars('archiverow', array(
				'MONTH'			=> $date['month'],
				'YEAR'			=> $date['year'],

				'S_FIRST'		=> ($i == 0) ? true : false,

				// output the counter
				'I'				=> $i,
			));
		}

		// Now output the title, view blog link, and date
		$template->assign_block_vars('archiverow.monthrow', array(
			'TITLE'			=> $row['blog_subject'],
			'U_VIEW'		=> append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=blog&amp;b=" . $row['blog_id']),
			'DATE'			=> $user->format_date($row['blog_time']),
		));

		// set the last month variable as the current month
		$last_mon = $date['mon'];

		// Increment the counter
		$i++;
	}

	// output some data
	$template->assign_vars(array(
		// are there any archives?
		'S_ARCHIVES'	=> ($i > 0) ? true : false,
	));

	$db->sql_freeresult($result);
}

/*
* This should never need to be used unless someone manually deletes blogs or replies from the database
*/
function resync_blog($mode)
{
	global $db;

	$blog_data = array();
	$reply_data = array();

	// Start by selecting all blog data that we will use
	$sql = 'SELECT blog_id, blog_reply_count FROM ' . BLOGS_TABLE . ' ORDER BY blog_id ASC';
	$result = $db->sql_query($sql);
	while($row = $db->sql_fetchrow($result))
	{
		$blog_data[$row['blog_id']] = $row;
	}

	// Now get all reply data we will use
	$sql = 'SELECT reply_id, blog_id FROM ' . BLOGS_REPLY_TABLE . ' ORDER BY reply_id ASC';
	$result = $db->sql_query($sql);
	while($row = $db->sql_fetchrow($result))
	{
		$reply_data[$row['reply_id']] = $row;
	}

	/*
	* Update & Resync the reply counts
	*/
	if ( ($mode == 'reply_count') || ($mode == 'all') )
	{
		foreach($blog_data as $row)
		{
			// count all the replies (an SQL query seems the easiest way to do it)
			$sql2 = 'SELECT count(reply_id) AS total 
				FROM ' . BLOGS_REPLY_TABLE . ' 
					WHERE blog_id = \'' . $row['blog_id'] . '\' 
						AND reply_deleted = \'0\' 
						AND reply_approved = \'1\'';
			$result2 = $db->sql_query($sql2);
			$total = $db->sql_fetchrow($result2);

			if ($total['total'] != $row['blog_reply_count'])
			{
				// Update the reply count
				$sql = 'UPDATE ' . BLOGS_TABLE . ' SET blog_reply_count = \'' . $total['total'] . '\' WHERE blog_id = \'' . $row['blog_id'] . '\'';
				$db->sql_query($sql);
			}
		}
	}

	/*
	* Delete's all oprhaned replies (replies where the blogs they should go under have been deleted).
	*/
	if ( ($mode == 'delete_orphan_replies') || ($mode == 'all') )
	{
		foreach($reply_data as $row)
		{
			if (!(array_key_exists($row['blog_id'], $blog_data)))
			{
				$sql = 'DELETE FROM ' . BLOGS_REPLY_TABLE . ' WHERE reply_id = \'' . $row['reply_id'] . '\'';
				$db->sql_query($sql);
			}
		}
	}
}

/**
* Check permissions
* return is for whether we should just return true or false, or if we want to enforce the permissions from this function
*/
function check_permissions($page, $mode, $owner = false, $return = false)
{
	global $auth, $user;

	switch ($page)
	{
		case 'view' :
			switch ($mode)
			{
				case '' :
				case 'user' :
				case 'blog' :
					if ($auth->acl_get('u_blogview'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NO_AUTH_OPERATION');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'deleted' :
					if ($auth->acl_get('m_blogdelete'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NO_AUTH_OPERATION');
							}
							else
							{
								return false;
							}
						}
					}
				break;
			}
		break;
		case 'blog' :
			switch ($mode)
			{
				case 'add' :
					if ($auth->acl_get('u_blogpost'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box('', $user->lang['LOGIN_EXPLAIN_NEW_BLOG']);
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NO_AUTH_OPERATION');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'edit' :
					if ( ( ($auth->acl_get('u_blogedit')) && ($owner) ) || ($auth->acl_get('m_blogedit')) )
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box('', $user->lang['LOGIN_EXPLAIN_EDIT_BLOG']);
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NO_AUTH_OPERATION');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'delete' :
					if ( ( ($auth->acl_get('u_blogdelete')) && ($owner) ) || ($auth->acl_get('m_blogdelete')) || ($auth->acl_get('a_blogdelete')))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NO_AUTH_OPERATION');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'undelete' :
					if ($auth->acl_get('m_blogdelete'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NO_AUTH_OPERATION');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'report' :
					if ($auth->acl_get('u_blogreport'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NO_AUTH_OPERATION');
							}
							else
							{
								return false;
							}
						}
					}
				break;
			}
		break;
		case 'reply' :
			switch ($mode)
			{
				case 'add' :
				case 'quote' :
					if ($auth->acl_get('u_blogreply'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NO_AUTH_OPERATION');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'edit' :
					if ( ( ($auth->acl_get('u_blogreplyedit')) && ($owner) ) || ($auth->acl_get('m_blogedit')) )
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NO_AUTH_OPERATION');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'delete' :
					if ( ( ($auth->acl_get('u_blogreplydelete')) && ($owner) ) || ($auth->acl_get('m_blogdelete')) || ($auth->acl_get('a_blogreplydelete')))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NO_AUTH_OPERATION');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'undelete' :
					if ($auth->acl_get('m_blogdelete'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NO_AUTH_OPERATION');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'report' :
					if ($auth->acl_get('u_blogreport'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NO_AUTH_OPERATION');
							}
							else
							{
								return false;
							}
						}
					}
				break;
			}
		break;
	}
}
?>