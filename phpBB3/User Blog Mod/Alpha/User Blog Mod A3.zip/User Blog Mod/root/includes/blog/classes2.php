<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

/*
* Blog data class
*
* Holds all the data for all the blogs, replies, and users requested at any time for this session
* Caches the blogs, replies, and user's data for a set amount of time (configured through ACP) so we can cut down on a lot of queries
* Can output the data to directly to the template
*/
class blog_data
{
	// this is our large arrays holding all the blog, reply, and user data
	var $blog = array();
	var $reply = array();
	var $user = array();

	/*
	* TODO
	* mass selection
	* cache
	*/

	/*
	* -------------------------- BLOG DATA SECTION -----------------------------
	*/

	/*
	* get blogs
	*/
	function get_blog_data($selection_data)
	{
		global $db, $user, $phpbb_root_path, $phpEx, $auth;

		// input options
		$blog_id =		(isset($selection_data['blog_id'])) ? $selection_data['blog_id'] :		false; // select a single or if array, multiple blog(s)
		$user_id =		(isset($selection_data['user_id'])) ? $selection_data['user_id'] :		false; // select blogs by a user ID
		$deleted =		(isset($selection_data['deleted'])) ? $selection_data['deleted'] :		false; // If we want to view the deleted blogs by the user ID
		$recent =		(isset($selection_data['recent'])) ? $selection_data['recent'] :		false; // Select the recent blogs
		$random =		(isset($selection_data['random'])) ? $selection_data['random'] :		false; // Select random blogs
		$limit =		(isset($selection_data['limit'])) ? $selection_data['limit'] :			5; // the limit on how many blogs we will select
		$str_limit =	(isset($selection_data['str_limit'])) ? $selection_data['str_limit'] :	0; // the text length limit on the blogs
		$simple =		(isset($selection_data['simple'])) ? $selection_data['simple'] :		false; // if we want to parse the text or just grab it from the db

		// Setup some variables...
		$i = 0;
		$blog_ids = array();
		$view_unapproved_sql = ($auth->acl_get('m_blogapprove')) ? '' : ' AND blog_approved = \'1\'';
	
		// Get the data on the blog
		if ($user_id != false)
		{
			// update the deleted option to be a 1 or 0 instead of true/false
			$deleted_sql = ($deleted) ? ' AND blog_deleted != \'0\'' : ' AND blog_deleted = \'0\'';
	
			$sql = 'SELECT * FROM ' . BLOGS_TABLE . '
						WHERE user_id = \'' . $user_id . '\''
						. $deleted_sql
						. $view_unapproved_sql
						. '	ORDER BY blog_id DESC';
		}
		else if ($blog_id != false)
		{
			if (!is_array($blog_id))
			{
				// check if the blog already exists
				if ( (!array_key_exists($blog_id, $this->blog)) || ( (isset($this->blog[$blog_id]['simple'])) && ( ( ($this->blog[$blog_id]['simple'] == false) && ($simple == true) ) || ( ($this->blog[$id]['simple'] == true) && ($simple == false) ) ) ) )
				{
					$sql = 'SELECT * FROM ' . BLOGS_TABLE . '
								WHERE blog_id = \'' . $blog_id . '\'
									LIMIT 1';
				}
				else
				{
					return array($blog_id);
				}
			}
			else
			{
				$blogs_to_query = array();

				// check if the blog already exists
				foreach ($blog_id as $id)
				{
					if ( (!array_key_exists($id, $this->blog)) || ( (isset($this->blog[$id]['simple'])) && ( ( ($this->blog[$id]['simple'] == false) && ($simple == true) ) || ( ($this->blog[$id]['simple'] == true) && ($simple == false) ) ) ) )
					{
						array_push($blogs_to_query, $id);
					}
				}
				if (count($blogs_to_query) > 1)
				{
					// if we want to select multiple blogs...
					$first_id = array_shift($blogs_to_query);
	
					$where_sql = ' WHERE blog_id = \'' . $first_id . '\'';
					
					foreach ($blogs_to_query as $id)
					{
						$where_sql .= ' OR blog_id = \'' . $id . '\'';
					}

					$blog_ids = $blog_id;

					$sql = 'SELECT * FROM ' . BLOGS_TABLE . $where_sql;
				}
				else if (count($blogs_to_query) == 1)
				{
					$sql = 'SELECT * FROM ' . BLOGS_TABLE . '
							WHERE blog_id = \'' . $blogs_to_query[0] . '\'
								LIMIT 1';

					$blog_ids = $blog_id;
				}
				else
				{
					return $blog_id;
				}
			}
		}
		else if ($recent)
		{
			$sql = 'SELECT * FROM ' . BLOGS_TABLE
				. ' WHERE blog_deleted = \'0\''
					. $view_unapproved_sql
						. ' ORDER BY blog_id DESC
							LIMIT ' . $limit;
		}
		else if ($random)
		{ 
			$all_blog_ids = array();
			$random_ids = array();
			$i = 0;

			$sql = 'SELECT blog_id FROM ' . BLOGS_TABLE
				. ' WHERE blog_deleted = \'0\''
					. $view_unapproved_sql;

			$result = $db->sql_query($sql);
			while ($row = $db->sql_fetchrow($result))
			{
				$i++;
				$all_blog_ids[$i] = $row['blog_id'];
			}

			// if the limit is higher than the total number of blogs, just give them what we have (and shuffle it so it looks random)
			if ($limit > count($all_blog_ids))
			{
				return $this->get_blog_data(array('blog_id' => shuffle($all_blog_ids)));
			}
			else
			{
				// this is not the most efficient way to do it...but as long as the limit doesn't get too close to the total number of blogs it's fine
				// If the limit is near the total number of blogs we just hope it doesn't take too long (the user should not be requesting many random blogs anyways)
				for ($j = 0; $j < $limit; $j++)
				{
					$random_id = rand(1, $i);

					// make sure the random_id can only be picked once...
					if (!in_array($random_id , $random_ids))
					{
						array_push($random_ids, $random_id);
					}
					else
					{
						$j--;
					}
				}
			}

			return $this->get_blog_data(array('blog_id' => $random_ids));
		}
		else if ($popular)
		{
			// Make this more robust by selecting read and reply counts for all blogs,
				// then make up a nice algorithm to calculate the most popular and select those...
			$sql = 'SELECT * FROM ' . BLOGS_TABLE
				. ' WHERE blog_deleted = \'0\''
					. $view_unapproved_sql
						. ' ORDER BY blog_reply_count DESC, blog_read_count DESC 
							LIMIT ' . $limit;
		}

		$result = $db->sql_query($sql);

		if ($simple) // if we just want to grab the data and not parse any of it...
		{
			while ($row = $db->sql_fetchrow($result))
			{
				$this->blog[$row['blog_id']] = $row;
				$this->blog[$row['blog_id']]['simple'] = true;

				array_push($blog_ids, $row['blog_id']);
			}
		}
		else
		{
			while ($row = $db->sql_fetchrow($result))
			{
				$i++;

				// limiting how many we show here...don't move it to the SQL query
				if ( ($i > $limit) && ($limit > 0) )
				{
					break;
				}

				// this will set a lot of the data to start with...
				$this->blog[$row['blog_id']] = $row;

				if ($str_limit > 0)
				{
					$bbcode_bitfield = $text_only_message = '';
		
					$text_only_message = $row['blog_text'];
					// make list items visible as such
					if ($row['bbcode_uid'])
					{
						$text_only_message = str_replace('[*:' . $row['bbcode_uid'] . ']', '&sdot;&nbsp;', $text_only_message);
						// no BBCode in text only message, can't use strp_bbcode because it replaces the bbcode with spaces. :/
						$text_only_message = preg_replace("#\[\/?[a-z0-9\*\+\-]+(?:=.*?)?(?::[a-z])?(\:?" . $row['bbcode_uid'] . ")\]#", '', $text_only_message);
						$match = get_preg_expression('bbcode_htm');
						$replace = array('\1', '\2', '\1', '', '');
						
						$text_only_message = preg_replace($match, $replace, $text_only_message);
					}
		
					if (utf8_strlen($text_only_message) > ($str_limit + 3))
					{
						$row['blog_text'] = substr($text_only_message, 0, ($str_limit - 3)) . '...';
		
						// Now lets do some magic and get the smilies (and URL's?) back.
						$message_parser = new parse_message();
						$message_parser->message = $row['blog_text'];
						$message_parser->parse($row['enable_bbcode'], $row['enable_magic_url'], $row['enable_smilies']);
						$this->blog[$row['blog_id']]['blog_text'] = $message_parser->message;
						$this->blog[$row['blog_id']]['bbcode_bitfield'] = $message_parser->bbcode_bitfield;
						$this->blog[$row['blog_id']]['bbcode_uid'] = $message_parser->bbcode_uid;
						unset($message_parser);
		
						$this->blog[$row['blog_id']]['blog_text'] .= '<br/><br/><!-- m --><a href="';
						$this->blog[$row['blog_id']]['blog_text'] .= append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $row['blog_id']);
						$this->blog[$row['blog_id']]['blog_text'] .= '">[ ' . $user->lang['CONTINUED'] . ' ]</a><!-- m -->';
		
						$this->blog[$row['blog_id']]['shortened'] = true;
					}
					else
					{
						$this->blog[$row['blog_id']]['shortened'] = false;
					}
		
					unset($text_only_message);
				}
				else
				{
					$this->blog[$row['blog_id']]['shortened'] = false;
				}
		
				$this->blog[$row['blog_id']]['blog_subject'] = censor_text($this->blog[$row['blog_id']]['blog_subject']); // censor the text of the subject
		
				// Parse BBCode and prepare the message for viewing
				$bbcode_options = (($row['enable_bbcode']) ? OPTION_FLAG_BBCODE : 0) +
					(($row['enable_smilies']) ? OPTION_FLAG_SMILIES : 0) + 
					(($row['enable_magic_url']) ? OPTION_FLAG_LINKS : 0);
				$this->blog[$row['blog_id']]['blog_text'] = generate_text_for_display($row['blog_text'], $row['bbcode_uid'], $row['bbcode_bitfield'], $bbcode_options);
		
				// For Highlighting
				$hilit_words = request_var('hilit', '', true);
				$highlight_match = $highlight = '';
				if ($hilit_words)
				{
					foreach (explode(' ', trim($hilit_words)) as $word)
					{
						if (trim($word))
						{
							$highlight_match .= (($highlight_match != '') ? '|' : '') . str_replace('*', '\w*?', preg_quote($word, '#'));
						}
					}
		
					$highlight = urlencode($hilit_words);
				}
				if ($highlight_match)
				{
					$this->blog[$row['blog_id']]['blog_text'] = preg_replace('#(?!<.*)(?<!\w)(' . $highlight_match . ')(?!\w|[^<>]*(?:</s(?:cript|tyle))?>)#is', '<span class="posthilit">\1</span>', $this->blog[$row['blog_id']]['blog_text']);
				}
		
				// has the blog been edited?
				if ($row['blog_edit_count'] != 0)
				{
					$this->get_user_data($row['blog_edit_user']);
		
					if ($row['blog_edit_count'] == 1)
					{
						$this->blog[$row['blog_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $this->user[$row['blog_edit_user']]['username_full'], $user->format_date($row['blog_edit_time']), $row['blog_edit_count']);
					}
					else if ($row['blog_edit_count'] > 1)
					{
						$this->blog[$row['blog_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $this->user[$row['blog_edit_user']]['username_full'], $user->format_date($row['blog_edit_time']), $row['blog_edit_count']);
					}
		
					$this->blog[$row['blog_id']]['edit_reason'] = censor_text($row['blog_edit_reason']);
				}
				else
				{
					$this->blog[$row['blog_id']]['edited_message'] = '';
					$this->blog[$row['blog_id']]['edit_reason'] = '';
				}
		
				// has the blog been deleted?
				if ($row['blog_deleted'] != 0)
				{
					$this->get_user_data($row['blog_deleted']);
					$this->blog[$row['blog_id']]['deleted_message'] = sprintf($user->lang['BLOG_IS_DELETED'], $this->user[$row['blog_deleted']]['username_full'], $user->format_date($row['blog_deleted_time']), '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=blog&amp;mode=undelete&amp;b=" . $row['blog_id']) . '">', '</a>');
				}
				else
				{
					$this->blog[$row['blog_id']]['deleted_message'] = '';
				}

				$this->blog[$row['blog_id']]['simple'] = false;

				// make sure we don't record the same ID more than once
				if (!in_array($row['blog_id'], $blog_ids))
				{
					array_push($blog_ids, $row['blog_id']);
				}
			}
			$db->sql_freeresult($result);
		}

		// if there are no blogs, return false
		if (count($blog_ids) == 0)
		{
			return false;
		}
		else
		{
			return $blog_ids;
		}
	}

	/*
	* -------------------------- REPLY DATA SECTION -----------------------------
	*/

	/*
	* get reply data
	*/
	function get_reply_data($selection_data)
	{
		global $db, $user, $phpbb_root_path, $phpEx, $auth;

		// input options
		$blog_id =		(isset($selection_data['blog_id'])) ? $selection_data['blog_id'] :		false; // select reply data on a  single blog
		$reply_id =		(isset($selection_data['reply_id'])) ? $selection_data['reply_id'] :	false; // select a single or if array, multiple reply(s)
		$simple =		(isset($selection_data['simple'])) ? $selection_data['simple'] :		false; // if we want to parse the text or just grab it from the db

		// Setup some variables...
		$reply_ids = array();
		$view_unapproved_sql = ($auth->acl_get('m_replyapprove')) ? '' : ' AND reply_approved = \'1\'';

		if ($blog_id != false)
		{
			$sql = 'SELECT * FROM ' . BLOGS_REPLY_TABLE . '
				WHERE blog_id = \'' . $blog_id . '\'';
		}
		else if ($reply_id != false)
		{
			if (!is_array($reply_id))
			{
				// check if the reply already exists
				if ( (!array_key_exists($reply_id, $this->reply)) || ( (isset($this->reply[$reply_id]['simple'])) && ( ( ($this->reply[$reply_id]['simple'] == false) && ($simple == true) ) || ( ($this->reply[$id]['simple'] == true) && ($simple == false) ) ) ) )
				{
					$sql = 'SELECT * FROM ' . BLOGS_REPLY_TABLE . '
								WHERE reply_id = \'' . $reply_id . '\'
									LIMIT 1';
				}
				else
				{
					return array($reply_id);
				}
			}
			else
			{
				$replys_to_query = array();

				// check if the reply already exists
				foreach ($reply_id as $id)
				{
					if ( (!array_key_exists($id, $this->reply)) || ( (isset($this->reply[$id]['simple'])) && ( ( ($this->reply[$id]['simple'] == false) && ($simple == true) ) || ( ($this->reply[$id]['simple'] == true) && ($simple == false) ) ) ) )
					{
						array_push($replys_to_query, $id);
					}
				}
				if (count($replys_to_query) > 1)
				{
					// if we want to select multiple replys...
					$first_id = array_shift($replys_to_query);
	
					$where_sql = ' WHERE reply_id = \'' . $first_id . '\'';
					
					foreach ($replys_to_query as $id)
					{
						$where_sql .= ' OR reply_id = \'' . $id . '\'';
					}

					$reply_ids = $reply_id;

					$sql = 'SELECT * FROM ' . BLOGS_REPLY_TABLE . $where_sql;
				}
				else if (count($replys_to_query) == 1)
				{
					$sql = 'SELECT * FROM ' . replyS_TABLE . '
							WHERE reply_id = \'' . $replys_to_query[0] . '\'
								LIMIT 1';

					$reply_ids = $reply_id;
				}
				else
				{
					return $reply_id;
				}
			}
		}

		$result = $db->sql_query($sql);

		if ($simple) // if we just want to grab the data and not parse any of it...
		{
			while ($row = $db->sql_fetchrow($result))
			{
				$this->reply[$row['reply_id']] = $row;
				$this->reply[$row['reply_id']]['simple'] = true;

				array_push($reply_ids, $row['reply_id']);
			}
		}
		else
		{
			while ($row = $db->sql_fetchrow($result))
			{
				// this will set a lot of the data to start with...
				$this->reply[$row['reply_id']] = $row;
		
				$this->reply[$row['reply_id']]['reply_subject'] = censor_text($this->reply[$row['reply_id']]['reply_subject']); // censor the text of the subject
		
				// Parse BBCode and prepare the message for viewing
				$bbcode_options = (($row['enable_bbcode']) ? OPTION_FLAG_BBCODE : 0) +
					(($row['enable_smilies']) ? OPTION_FLAG_SMILIES : 0) + 
					(($row['enable_magic_url']) ? OPTION_FLAG_LINKS : 0);
				$this->reply[$row['reply_id']]['reply_text'] = generate_text_for_display($row['reply_text'], $row['bbcode_uid'], $row['bbcode_bitfield'], $bbcode_options);
		
				// For Highlighting
				$hilit_words = request_var('hilit', '', true);
				$highlight_match = $highlight = '';
				if ($hilit_words)
				{
					foreach (explode(' ', trim($hilit_words)) as $word)
					{
						if (trim($word))
						{
							$highlight_match .= (($highlight_match != '') ? '|' : '') . str_replace('*', '\w*?', preg_quote($word, '#'));
						}
					}
		
					$highlight = urlencode($hilit_words);
				}
				if ($highlight_match)
				{
					$this->reply[$row['reply_id']]['reply_text'] = preg_replace('#(?!<.*)(?<!\w)(' . $highlight_match . ')(?!\w|[^<>]*(?:</s(?:cript|tyle))?>)#is', '<span class="posthilit">\1</span>', $this->reply[$row['reply_id']]['reply_text']);
				}
		
				// has the reply been edited?
				if ($row['reply_edit_count'] != 0)
				{
					$this->get_user_data($row['reply_edit_user']);
		
					if ($row['reply_edit_count'] == 1)
					{
						$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $this->user[$row['reply_edit_user']]['username_full'], $user->format_date($row['reply_edit_time']), $row['reply_edit_count']);
					}
					else if ($row['reply_edit_count'] > 1)
					{
						$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $this->user[$row['reply_edit_user']]['username_full'], $user->format_date($row['reply_edit_time']), $row['reply_edit_count']);
					}
		
					$this->reply[$row['reply_id']]['edit_reason'] = censor_text($row['reply_edit_reason']);
				}
				else
				{
					$this->reply[$row['reply_id']]['edited_message'] = '';
					$this->reply[$row['reply_id']]['edit_reason'] = '';
				}
		
				// has the reply been deleted?
				if ($row['reply_deleted'] != 0)
				{
					$this->get_user_data($row['reply_deleted']);
					$this->reply[$row['reply_id']]['deleted_message'] = sprintf($user->lang['reply_IS_DELETED'], $this->user[$row['reply_deleted']]['username_full'], $user->format_date($row['reply_deleted_time']), '<a href="' . append_sid("{$phpbb_root_path}reply.$phpEx", "page=reply&amp;mode=undelete&amp;b=" . $row['reply_id']) . '">', '</a>');
				}
				else
				{
					$this->reply[$row['reply_id']]['deleted_message'] = '';
				}

				$this->reply[$row['reply_id']]['simple'] = false;

				// make sure we don't record the same ID more than once
				if (!in_array($row['reply_id'], $reply_ids))
				{
					array_push($reply_ids, $row['reply_id']);
				}
			}
			$db->sql_freeresult($result);
		}

		// if there are no replys, return false
		if (count($reply_ids) == 0)
		{
			return false;
		}
		else
		{
			return $reply_ids;
		}
	}

	/*
	* -------------------------- USER DATA SECTION -----------------------------
	*/

	// grabs the data on the user and places it in the $this->user array
	function get_user_data($user_id)
	{
		global $user, $db, $phpbb_root_path, $phpEx, $config, $auth, $cp, $bbcode;

		if (!array_key_exists($user_id, $this->user))
		{
			// Get the data on the author/user
			$sql = 'SELECT * FROM ' . USERS_TABLE . ' WHERE user_id = \'' . $user_id . '\'';
			$result = $db->sql_query($sql);
			$this->user[$user_id] = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);
	
			// view profile link
			$this->user[$user_id]['view_profile'] = append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=viewprofile&amp;u=" . $user_id);
	
			// Full username, with colour
			$this->user[$user_id]['username_full'] = get_username_string('full', $user_id, $this->user[$user_id]['username'], $this->user[$user_id]['user_colour']);
	
			// format the color correctly
			$this->user[$user_id]['user_colour'] = get_username_string('colour', $user_id, $this->user[$user_id]['username'], $this->user[$user_id]['user_colour']);
	
			// Online or offline? Basically copied from viewtopic.php
			$sql = 'SELECT session_user_id, MAX(session_time) AS online_time, MIN(session_viewonline) AS viewonline
				FROM ' . SESSIONS_TABLE . '
				WHERE session_user_id = \'' . $user_id . '\'
				GROUP BY session_user_id';
			$result = $db->sql_query($sql);
			$update_time = $config['load_online_time'] * 60;
			$status_data = $db->sql_fetchrow($result);
			$this->user[$user_id]['status'] = (time() - $update_time < $status_data['online_time'] && (($status_data['viewonline'] && $this->user[$user_id]['user_allow_viewonline']) || $auth->acl_get('u_viewonline'))) ? true : false;
		
			$db->sql_freeresult($result);
	
			// Avatar
			$this->user[$user_id]['avatar'] = ($this->user[$user_id]['user_avatar'] && $user->optionget('viewavatars')) ? '<img src="' . $phpbb_root_path . 'download.' . $phpEx . '?avatar=' . $this->user[$user_id]['user_avatar'] . '" width="' . $this->user[$user_id]['user_avatar_width'] . '" height="' . $this->user[$user_id]['user_avatar_height'] . '" alt="" />' : '';
	
			// Rank
			get_user_rank($this->user[$user_id]['user_rank'], $this->user[$user_id]['user_posts'], $this->user[$user_id]['rank_title'], $this->user[$user_id]['rank_img'], $this->user[$user_id]['rank_img_src']);
	
			// IM Links
			$this->user[$user_id]['msn_url'] = ($this->user[$user_id]['user_msnm']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=msnm&amp;u=" . $this->user[$user_id]['user_id']) : '';
			$this->user[$user_id]['yim_url'] = ($this->user[$user_id]['user_yim']) ? 'http://edit.yahoo.com/config/send_webmesg?.target=' . $this->user[$user_id]['user_yim'] . '&amp;.src=pg' : '';
			$this->user[$user_id]['aim_url'] = ($this->user[$user_id]['user_aim']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=aim&amp;u=" . $this->user[$user_id]['user_id']) : '';
			$this->user[$user_id]['icq_url'] = ($this->user[$user_id]['user_icq']) ? 'http://www.icq.com/people/webmsg.php?to=' . $this->user[$user_id]['user_icq'] : '';
			$this->user[$user_id]['jabber_url'] = ($this->user[$user_id]['user_jabber']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=jabber&amp;u=" . $this->user[$user_id]['user_id']) : '';
	
			// PM and email links
			$this->user[$user_id]['pm_url'] = ($this->user[$user_id]['user_id'] != ANONYMOUS && $config['allow_privmsg'] && $auth->acl_get('u_sendpm') && ($this->user[$user_id]['user_allow_viewemail'] || $auth->acl_gets('a_', 'm_') || $auth->acl_getf_global('m_'))) ? append_sid("{$phpbb_root_path}ucp.$phpEx", 'i=pm&amp;mode=compose&amp;u=' . $this->user[$user_id]['user_id']) : '';
			$this->user[$user_id]['email_url'] = ($config['board_email_form'] && $config['email_enable']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=email&amp;u=" . $this->user[$user_id]['user_id'])  : (($config['board_hide_emails'] && !$auth->acl_get('a_email')) ? '' : 'mailto:' . $this->user[$user_id]['user_email']);

			// Signature
			if ($config['allow_sig'] && $user->optionget('viewsigs'))
			{
				$this->user[$user_id]['user_sig'] = censor_text($this->user[$user_id]['user_sig']);
				$this->user[$user_id]['user_sig'] = str_replace("\n", '<br />', $this->user[$user_id]['user_sig']);

				if ($this->user[$user_id]['user_sig_bbcode_bitfield'])
				{
					$bbcode->bbcode_second_pass($this->user[$user_id]['user_sig'], $this->user[$user_id]['user_sig_bbcode_uid'], $this->user[$user_id]['user_sig_bbcode_bitfield']);
				}

				$this->user[$user_id]['user_sig'] = smiley_text($this->user[$user_id]['user_sig']);
			}
			else
			{
				$this->user[$user_id]['user_sig'] = '';
			}

			// get the custom profile fields if the admin wants them
			if ($config['blog_custom_profile_enable'])
			{
				// Grab all profile fields from users in id cache for later use - similar to the poster cache
				$profile_fields_cache = $cp->generate_profile_fields_template('grab', $user_id);
	
				$this->user[$user_id]['cp_row'] = (isset($profile_fields_cache[$user_id])) ? $cp->generate_profile_fields_template('show', false, $profile_fields_cache[$user_id]) : array();
			}
		}
	}
	
	// prepares the user data for output to the template, and outputs the custom profile rows when requested
	// Mostly for shortenting up code
	function handle_user_data($user_id, $output_custom = false)
	{
		global $phpbb_root_path, $phpEx, $user, $auth, $config, $template;

		if ($output_custom === false)
		{
			$output_data = array(
				'USERNAME'			=> $this->user[$user_id]['username'],
				'USER_COLOUR'		=> $this->user[$user_id]['user_colour'],
				'USER_FULL'			=> $this->user[$user_id]['username_full'],
				'U_PROFILE'			=> append_sid("{$phpbb_root_path}memberlist.$phpEx", 'mode=viewprofile&amp;u=' . $user_id),

				'SIGNATURE'			=> $this->user[$user_id]['user_sig'],

				'AVATAR'			=> $this->user[$user_id]['avatar'],

				'RANK_TITLE'		=> $this->user[$user_id]['rank_title'],
				'RANK_IMG'			=> $this->user[$user_id]['rank_img'],
				'RANK_IMG_SRC'		=> $this->user[$user_id]['rank_img_src'],

				'STATUS_IMG'		=> (($this->user[$user_id]['status']) ? $user->img('icon_user_online', 'ONLINE') : $user->img('icon_user_offline', 'OFFLINE')),
				'S_ONLINE'			=> $this->user[$user_id]['status'],

				'POSTER_POSTS'		=> $this->user[$user_id]['user_posts'],
				'POSTER_JOINED'		=> $user->format_date($this->user[$user_id]['user_regdate']),
				'POSTER_FROM'		=> $this->user[$user_id]['user_from'],

				'U_PM'				=> $this->user[$user_id]['pm_url'],
				'U_EMAIL'			=> $this->user[$user_id]['email_url'],
				'U_WWW'				=> $this->user[$user_id]['user_website'],
				'U_MSN'				=> $this->user[$user_id]['msn_url'],
				'U_YIM'				=> $this->user[$user_id]['yim_url'],
				'U_AIM'				=> $this->user[$user_id]['aim_url'],
				'U_ICQ'				=> $this->user[$user_id]['icq_url'],
				'U_JABBER'			=> $this->user[$user_id]['jabber_url'],

				'U_DELETED_LINK'	=> ($auth->acl_get('m_blogdelete')) ? '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=deleted&amp;u=" . $this->user[$user_id]['user_id']) . '">' . $user->lang['VIEW_DELETED_BLOGS'] . '</a>' : '',

				'S_CUSTOM_FIELDS'	=> (isset($this->user[$user_id]['cp_row']['blockrow'])) ? true : false,
			);

			return ($output_data);
		}
		else if ($config['blog_custom_profile_enable'])
		{
			// add the blog links in the custom fields
			add_blog_links($user_id, $output_custom);
	
			// output the custom profile fields
			if (isset($this->user[$user_id]['cp_row']['blockrow']))
			{
				foreach ($this->user[$user_id]['cp_row']['blockrow'] as $row)
				{
					$template->assign_block_vars($output_custom, array(
						'PROFILE_FIELD_NAME'	=> $row['PROFILE_FIELD_NAME'],
						'PROFILE_FIELD_VALUE'	=> $row['PROFILE_FIELD_VALUE'],
					));
				}
			}
		}
	}
}

/*
* Check permission and settings for bbcode, img, url, etc
*/
class post_options
{
	// the permissions, so I can change them later easier if need be for a different mod or whatever...
	var $auth_bbcode = false;
	var $auth_smilies = false;
	var $auth_img = false;
	var $auth_url = false;
	var $auth_flash = false;

	// whether these are allowed or not
	var $bbcode_status = false;
	var $smilies_status = false;
	var $img_status = false;
	var $url_status = false;
	var $flash_status = false;

	// whether or not they are enabled in the post
	var $enable_bbcode = false;
	var $enable_smilies = false;
	var $enable_magic_url = false;

	// automatically sets the defaults for the $auth_ vars
	function post_options()
	{
		global $auth;

		$this->auth_bbcode = $auth->acl_get('u_blogbbcode');
		$this->auth_smilies = $auth->acl_get('u_blogsmilies');
		$this->auth_img = $auth->acl_get('u_blogimg');
		$this->auth_url = $auth->acl_get('u_blogurl');
		$this->auth_flash = $auth->acl_get('u_blogflash');
	}

	// set the status to the  variables above, the enabled options are if they are enabled in the posts(by who ever is posting it)
	function set_status($bbcode, $smilies, $url)
	{
		global $config, $auth;

		$this->bbcode_status = ($config['allow_bbcode'] && $this->auth_bbcode) ? true : false;
		$this->smilies_status = ($config['allow_smilies'] && $this->auth_smilies) ? true : false;
		$this->img_status = ($this->auth_img && $this->bbcode_status) ? true : false;
		$this->url_status = ($config['allow_post_links'] && $this->auth_url && $this->bbcode_status) ? true : false;
		$this->flash_status = ($this->auth_flash && $this->bbcode_status) ? true : false;

		$this->enable_bbcode = ($this->bbcode_status && $bbcode) ? true : false;
		$this->enable_smilies = ($this->smilies_status && $smilies) ? true : false;
		$this->enable_magic_url = ($this->url_status && $url) ? true : false;
	}

	function set_in_template()
	{
		global $template, $user, $phpbb_root_path, $phpEx;

		// Assign some variables to the template parser
		$template->assign_vars(array(
			// If they hit preview or submit and got an error, or are editing their post make sure we carry their existing post info & options over
			'S_BBCODE_CHECKED'			=> ($this->enable_bbcode) ? '' : ' checked="checked"',
			'S_SMILIES_CHECKED'			=> ($this->enable_smilies) ? '' : ' checked="checked"',
			'S_MAGIC_URL_CHECKED'		=> ($this->enable_magic_url) ? '' : ' checked="checked"',

			// To show the Options: section on the bottom left
			'BBCODE_STATUS'				=> ($this->bbcode_status) ? sprintf($user->lang['BBCODE_IS_ON'], '<a href="' . append_sid("{$phpbb_root_path}faq.$phpEx", 'mode=bbcode') . '">', '</a>') : sprintf($user->lang['BBCODE_IS_OFF'], '<a href="' . append_sid("{$phpbb_root_path}faq.$phpEx", 'mode=bbcode') . '">', '</a>'),
			'IMG_STATUS'				=> ($this->img_status) ? $user->lang['IMAGES_ARE_ON'] : $user->lang['IMAGES_ARE_OFF'],
			'FLASH_STATUS'				=> ($this->flash_status) ? $user->lang['FLASH_IS_ON'] : $user->lang['FLASH_IS_OFF'],
			'SMILIES_STATUS'			=> ($this->smilies_status) ? $user->lang['SMILIES_ARE_ON'] : $user->lang['SMILIES_ARE_OFF'],
			'URL_STATUS'				=> ($this->url_status) ? $user->lang['URL_IS_ON'] : $user->lang['URL_IS_OFF'],

			// To show the option to turn each off while posting
			'S_BBCODE_ALLOWED'			=> $this->bbcode_status,
			'S_SMILIES_ALLOWED'			=> $this->smilies_status,
			'S_LINKS_ALLOWED'			=> $this->url_status,

			// To show the BBCode buttons for each on top
			'S_BBCODE_IMG'				=> $this->img_status,
			'S_BBCODE_URL'				=> $this->url_status,
			'S_BBCODE_FLASH'			=> $this->flash_status,
		));
	}
}
?>