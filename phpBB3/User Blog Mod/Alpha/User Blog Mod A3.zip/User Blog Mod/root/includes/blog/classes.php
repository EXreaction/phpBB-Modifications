<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

/*
* Blog data class
*
* Mainly for holding all of the data for all the blogs, replies, and users requested at any time for the request
*/
class blog_data
{
	// this is our large arrays holding all the blog, reply, and user data
	var $blog = array();
	var $reply = array();
	var $user = array();

	// this holds a queue of the user's data when requesting replies so we can cut down on queries
	var $queue = array();

	/*
	* -------------------------- BLOG DATA SECTION -----------------------------
	*/

	/*
	* get blogs
	* Input options are listed a few lines down.
	*/
	function get_blog_data($selection_data)
	{
		global $db, $user, $phpbb_root_path, $phpEx, $auth;

		// input options
		$blog_id =		(isset($selection_data['blog_id'])) ? $selection_data['blog_id'] :			false; // select a single or if array, multiple blog(s)
		$user_id =		(isset($selection_data['user_id'])) ? $selection_data['user_id'] :			false; // select blogs by a user ID
		$deleted =		(isset($selection_data['deleted'])) ? $selection_data['deleted'] :			false; // If we want to view the deleted blogs by the user ID
		$recent =		(isset($selection_data['recent'])) ? $selection_data['recent'] :			false; // Select the recent blogs
		$random =		(isset($selection_data['random'])) ? $selection_data['random'] :			false; // Select random blogs
		$popular = 		(isset($selection_data['popular'])) ? $selection_data['popular'] :			false; // Select popular blogs
		$reported = 	(isset($selection_data['reported'])) ? $selection_data['reported'] :		false; // Select reported blogs
		$disapproved = 	(isset($selection_data['disapproved'])) ? $selection_data['disapproved'] :	false; // Select disapproved blogs
		$limit =		(isset($selection_data['limit'])) ? $selection_data['limit'] :				5; // the limit on how many blogs we will select
		$simple =		(isset($selection_data['simple'])) ? $selection_data['simple'] :			false; // if we want to parse the text or just grab it from the db
		$force_all = 	(isset($selection_data['force_all'])) ? $selection_data['force_all'] :		false; // just in case someone wants to override my little caching thing in case they find a bug or whatnot, they can...

		// Setup some variables...
		$blog_ids = array();
		$view_unapproved_sql = ($auth->acl_get('m_blogapprove')) ? '' : ' AND blog_approved = \'1\'';
		$limit_sql = ($limit > 1) ? ' LIMIT ' . $limit : '';

		// Get the data on the blog
		if ($user_id != false)
		{
			$deleted_sql = ($deleted) ? ' AND blog_deleted != \'0\'' : ' AND blog_deleted = \'0\'';

			$sql = 'SELECT * FROM ' . BLOGS_TABLE . '
						WHERE user_id = \'' . $user_id . '\'' .
							$deleted_sql .
								$view_unapproved_sql .
									' ORDER BY blog_id DESC ' .
										$limit_sql;
		}
		else if ($blog_id != false)
		{
			if (!is_array($blog_id))
			{
				$blog_id = array($blog_id);
			}

			$blogs_to_query = array();

			// check if the blog already exists
			foreach ($blog_id as $id)
			{
				if ( $force_all || ( (!array_key_exists($id, $this->blog)) || ( (isset($this->blog[$id]['simple'])) && ( ( ($this->blog[$id]['simple'] == false) && ($simple == true) ) || ( ($this->blog[$id]['simple'] == true) && ($simple == false) ) ) ) ) && (!in_array($id, $blogs_to_query)) )
				{
					array_push($blogs_to_query, $id);
				}
				else
				{
					// since the blog was already queried once lets put it on the list of blog_ids that we grabbed that we will return later
					array_push($blog_ids, $id);
				}
			}

			if (count($blogs_to_query) == 0)
			{
				return $blog_id;
			}

			$sql = 'SELECT * FROM ' . BLOGS_TABLE . '
					WHERE ' . $db->sql_in_set('blog_id', $blogs_to_query);
		}
		else if ($recent)
		{
			$sql = 'SELECT * FROM ' . BLOGS_TABLE .
				' WHERE blog_deleted = \'0\'' .
					$view_unapproved_sql .
						' ORDER BY blog_id DESC' .
							$limit_sql;
		}
		else if ($random)
		{ 
			$all_blog_ids = array();
			$random_ids = array();
			$i = 0;

			$sql = 'SELECT blog_id FROM ' . BLOGS_TABLE .
				' WHERE blog_deleted = \'0\'' .
					$view_unapproved_sql;

			$result = $db->sql_query($sql);
			while ($row = $db->sql_fetchrow($result))
			{
				$i++;
				$all_blog_ids[$i] = $row['blog_id'];
			}

			// if the limit is higher than the total number of blogs, just give them what we have (and shuffle it so it looks random)
			if ($limit > count($all_blog_ids))
			{
				shuffle($all_blog_ids);
				$this->get_blog_data(array('blog_id' => $all_blog_ids));
				return $all_blog_ids;
			}
			else
			{
				// this is not the most efficient way to do it...but as long as the limit doesn't get too close to the total number of blogs it's fine
				// If the limit is near the total number of blogs we just hope it doesn't take too long (the user should not be requesting many random blogs anyways)
				for ($j = 0; $j < $limit; $j++)
				{
					$random_id = rand(1, $i);

					// make sure the random_id can only be picked once...
					if (!in_array($random_id , $random_ids))
					{
						array_push($random_ids, $random_id);
					}
					else
					{
						$j--;
					}
				}
			}

			$this->get_blog_data(array('blog_id' => $random_ids));
			return $random_ids;
		}
		else if ($popular)
		{
			$popular_list = array();

			$sql = 'SELECT blog_id, blog_time, blog_reply_count, blog_read_count FROM ' . BLOGS_TABLE .
				' WHERE blog_deleted = \'0\'' .
					$view_unapproved_sql;
			$result = $db->sql_query($sql);
			
			while ($row = $db->sql_fetchrow($result))
			{
				$popular_list[$row['blog_id']] = ( (($row['blog_reply_count'] * 10) + $row['blog_read_count']) / ($row['blog_time']));
			}

			arsort($popular_list);

			if (count($popular_list) == 0)
			{
				return false;
			}

			foreach ($popular_list as $id => $value)
			{
				if (count($blog_ids) >= $limit)
				{
					break;
				}
				array_push($blog_ids, $id);
			}

			$sql = 'SELECT * FROM ' . BLOGS_TABLE . '
				WHERE ' . $db->sql_in_set('blog_id', $blog_ids);
		}
		else if ($reported)
		{
			$sql = 'SELECT * FROM ' . BLOGS_TABLE . '
				WHERE blog_reported = \'1\'';
		}
		else if ($disapproved)
		{
			$sql = 'SELECT * FROM ' . BLOGS_TABLE . '
				WHERE blog_approved = \'0\'';
		}

		// check to make sure they included a mode to choose, if they didn't $sql would not have been set and we'd just get an error
		if (!isset($sql))
		{
			return false;
		}

		$result = $db->sql_query($sql);

		if ($simple) // if we just want to grab the data and not parse any of it...
		{
			while ($row = $db->sql_fetchrow($result))
			{
				$this->blog[$row['blog_id']] = $row;
				$this->blog[$row['blog_id']]['simple'] = true;

				array_push($blog_ids, $row['blog_id']);
			}
		}
		else
		{
			while ($row = $db->sql_fetchrow($result))
			{
				// this will set a lot of the data to start with...
				$this->blog[$row['blog_id']] = $row;

				// this is used sometimes...
				$this->blog[$row['blog_id']]['shortened'] = false;

				// censor the text of the subject
				$this->blog[$row['blog_id']]['blog_subject'] = censor_text($this->blog[$row['blog_id']]['blog_subject']);
		
				// Parse BBCode and prepare the message for viewing
				$bbcode_options = (($row['enable_bbcode']) ? OPTION_FLAG_BBCODE : 0) + (($row['enable_smilies']) ? OPTION_FLAG_SMILIES : 0) + (($row['enable_magic_url']) ? OPTION_FLAG_LINKS : 0);
				$this->blog[$row['blog_id']]['blog_text'] = generate_text_for_display($row['blog_text'], $row['bbcode_uid'], $row['bbcode_bitfield'], $bbcode_options);
		
				// For Highlighting
				$hilit_words = request_var('hilit', '', true);
				if ($hilit_words)
				{
					$highlight_match = $highlight = '';
					foreach (explode(' ', trim($hilit_words)) as $word)
					{
						if (trim($word))
						{
							$highlight_match .= (($highlight_match != '') ? '|' : '') . str_replace('*', '\w*?', preg_quote($word, '#'));
						}
					}
					$highlight = urlencode($hilit_words);
					if ($highlight_match)
					{
						$this->blog[$row['blog_id']]['blog_text'] = preg_replace('#(?!<.*)(?<!\w)(' . $highlight_match . ')(?!\w|[^<>]*(?:</s(?:cript|tyle))?>)#is', '<span class="posthilit">\1</span>', $this->blog[$row['blog_id']]['blog_text']);
					}
				}

				// Add the edit user to the queue, if there is one
				if ($row['blog_edit_count'] != 0)
				{
					array_push($this->queue, $row['blog_edit_user']);
				}

				// Add the deleter user to the queue, if there is one
				if ($row['blog_deleted'] != 0)
				{
					array_push($this->queue, $row['blog_deleted']);
				}

				// add the blog owners' user_ids to the queue
				array_push($this->queue, $row['user_id']);

				// make sure we set it so that it knows we are not doing the simple request if this blog is requested again
				$this->blog[$row['blog_id']]['simple'] = false;

				// make sure we don't record the same ID more than once
				if (!in_array($row['blog_id'], $blog_ids))
				{
					array_push($blog_ids, $row['blog_id']);
				}
			}
			$db->sql_freeresult($result);
		}

		// if there are no blogs, return false
		if (count($blog_ids) == 0)
		{
			return false;
		}
		else
		{
			return $blog_ids;
		}
	}

	/*
	* -------------------------- REPLY DATA SECTION -----------------------------
	*/

	/*
	* get reply data
	*/
	function get_reply_data($selection_data)
	{
		global $db, $user, $phpbb_root_path, $phpEx, $auth;

		// input options
		$blog_id =		(isset($selection_data['blog_id'])) ? $selection_data['blog_id'] :		false; // select reply data on a  single blog
		$reply_id =		(isset($selection_data['reply_id'])) ? $selection_data['reply_id'] :	false; // select a single or if array, multiple reply(s)
		$simple =		(isset($selection_data['simple'])) ? $selection_data['simple'] :		false; // if we want to parse the text or just grab it from the db

		// Setup some variables...
		$reply_ids = array();
		$view_unapproved_sql = ($auth->acl_get('m_replyapprove')) ? '' : ' AND reply_approved = \'1\'';

		if ($blog_id != false)
		{
			$sql = 'SELECT * FROM ' . BLOGS_REPLY_TABLE . '
				WHERE blog_id = \'' . $blog_id . '\'';
		}
		else if ($reply_id != false)
		{
			if (!is_array($reply_id))
			{
				// check if the reply already exists
				if ( ( (!array_key_exists($reply_id, $this->reply)) || ( (isset($this->reply[$reply_id]['simple'])) && ( ( ($this->reply[$reply_id]['simple'] == false) && ($simple == true) ) || ( ($this->reply[$reply_id]['simple'] == true) && ($simple == false) ) ) ) ) )
				{
					$sql = 'SELECT * FROM ' . BLOGS_REPLY_TABLE . '
								WHERE reply_id = \'' . $reply_id . '\'
									LIMIT 1';
				}
				else
				{
					return array($reply_id);
				}
			}
			else
			{
				$replys_to_query = array();

				// check if the reply already exists
				foreach ($reply_id as $id)
				{
					if ( (!array_key_exists($id, $this->reply)) || ( (isset($this->reply[$id]['simple'])) && ( ( ($this->reply[$id]['simple'] == false) && ($simple == true) ) || ( ($this->reply[$id]['simple'] == true) && ($simple == false) ) ) ) )
					{
						array_push($replys_to_query, $id);
					}
				}

				if (count($replys_to_query) == 0)
				{
					return $reply_id;
				}

				$sql = 'SELECT * FROM ' . BLOGS_REPLY_TABLE . '
					WHERE ' . $db->sql_in_set('reply_id', $replies_to_query);
			}
		}

		$result = $db->sql_query($sql);

		if ($simple) // if we just want to grab the data and not parse any of it...
		{
			while ($row = $db->sql_fetchrow($result))
			{
				$this->reply[$row['reply_id']] = $row;
				$this->reply[$row['reply_id']]['simple'] = true;

				array_push($reply_ids, $row['reply_id']);
			}
		}
		else
		{
			while ($row = $db->sql_fetchrow($result))
			{
				// this will set a lot of the data to start with...
				$this->reply[$row['reply_id']] = $row;
		
				$this->reply[$row['reply_id']]['reply_subject'] = censor_text($this->reply[$row['reply_id']]['reply_subject']); // censor the text of the subject
		
				// Parse BBCode and prepare the message for viewing
				$bbcode_options = (($row['enable_bbcode']) ? OPTION_FLAG_BBCODE : 0) +
					(($row['enable_smilies']) ? OPTION_FLAG_SMILIES : 0) + 
					(($row['enable_magic_url']) ? OPTION_FLAG_LINKS : 0);
				$this->reply[$row['reply_id']]['reply_text'] = generate_text_for_display($row['reply_text'], $row['bbcode_uid'], $row['bbcode_bitfield'], $bbcode_options);
		
				// For Highlighting
				$hilit_words = request_var('hilit', '', true);
				$highlight_match = $highlight = '';
				if ($hilit_words)
				{
					foreach (explode(' ', trim($hilit_words)) as $word)
					{
						if (trim($word))
						{
							$highlight_match .= (($highlight_match != '') ? '|' : '') . str_replace('*', '\w*?', preg_quote($word, '#'));
						}
					}
		
					$highlight = urlencode($hilit_words);
				}
				if ($highlight_match)
				{
					$this->reply[$row['reply_id']]['reply_text'] = preg_replace('#(?!<.*)(?<!\w)(' . $highlight_match . ')(?!\w|[^<>]*(?:</s(?:cript|tyle))?>)#is', '<span class="posthilit">\1</span>', $this->reply[$row['reply_id']]['reply_text']);
				}
		
				// has the reply been edited?
				if ($row['reply_edit_count'] != 0)
				{
					array_push($this->queue, $row['reply_edit_user']);
				}
		
				// has the reply been deleted?
				if ($row['reply_deleted'] != 0)
				{
					array_push($this->queue, $row['reply_deleted']);
				}

				// Add this user's ID to the queue, so we can cut DB queries by selecting all the user's data at once.
				array_push($this->queue, $row['user_id']);

				$this->reply[$row['reply_id']]['simple'] = false;

				// make sure we don't record the same ID more than once
				if (!in_array($row['reply_id'], $reply_ids))
				{
					array_push($reply_ids, $row['reply_id']);
				}
			}
			$db->sql_freeresult($result);
		}

		// if there are no replys, return false
		if (count($reply_ids) == 0)
		{
			return false;
		}
		else
		{
			return $reply_ids;
		}
	}

	/*
	* -------------------------- USER DATA SECTION -----------------------------
	*/

	// grabs the data on the user and places it in the $this->user array
	// if queue is true then we just grab the user_ids from the queue, otherwise we select data from just 1 user at a time.
	function get_user_data($user_id, $queue = false)
	{
		global $user, $db, $phpbb_root_path, $phpEx, $config, $auth, $cp, $bbcode;

		// if the $user_id isn't an array, make it one for consistency
		if ( ($user_id !== false) && (!is_array($user_id)) )
		{
			$user_id = array($user_id);
		}

		// if we are using the queue, set $user_id as that for consistency
		if ($queue)
		{
			$user_id = $this->queue;
		}

		// this holds the user_id's we will query
		$users_to_query = array();

		foreach ($user_id as $id)
		{
			if ( (!array_key_exists($id, $this->user)) && (!in_array($id, $users_to_query)) )
			{
				array_push($users_to_query, $id);
			}
		}

		if (count($users_to_query) == 0)
		{
			return;
		}

		// Grab all profile fields from users in id cache for later use - similar to the poster cache
		if ($config['blog_custom_profile_enable'])
		{
			$profile_fields_cache = $cp->generate_profile_fields_template('grab', $users_to_query);
		}

		// Grab user status information
		$status_data = array();
		$sql = 'SELECT session_user_id, MAX(session_time) AS online_time, MIN(session_viewonline) AS viewonline
			FROM ' . SESSIONS_TABLE . '
				WHERE ' . $db->sql_in_set('session_user_id', $users_to_query) . '
					GROUP BY session_user_id';
		$result = $db->sql_query($sql);
		while($row = $db->sql_fetchrow($result))
		{
			$status_data[$row['session_user_id']] = $row;
		}
		$db->sql_freeresult($result);
		$update_time = $config['load_online_time'] * 60;

		// Get the rest of th data on the users and parse everything we need
		$sql = 'SELECT * FROM ' . USERS_TABLE . ' WHERE ' . $db->sql_in_set('user_id', $users_to_query);
		$result = $db->sql_query($sql);

		while ($row = $db->sql_fetchrow($result))
		{
			$this->user[$row['user_id']] = $row;
	
			// view profile link
			$this->user[$row['user_id']]['view_profile'] = append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=viewprofile&amp;u=" . $row['user_id']);
	
			// Full username, with colour
			$this->user[$row['user_id']]['username_full'] = get_username_string('full', $row['user_id'], $this->user[$row['user_id']]['username'], $this->user[$row['user_id']]['user_colour']);
	
			// format the color correctly
			$this->user[$row['user_id']]['user_colour'] = get_username_string('colour', $row['user_id'], $this->user[$row['user_id']]['username'], $this->user[$row['user_id']]['user_colour']);

			// Status
			$this->user[$row['user_id']]['status'] = (isset($status_data[$row['user_id']]) && time() - $update_time < $status_data[$row['user_id']]['online_time'] && (($status_data[$row['user_id']]['viewonline'] && $this->user[$row['user_id']]['user_allow_viewonline']) || $auth->acl_get('u_viewonline'))) ? true : false;
	
			// Avatar
			$this->user[$row['user_id']]['avatar'] = ($this->user[$row['user_id']]['user_avatar'] && $user->optionget('viewavatars')) ? '<img src="' . $phpbb_root_path . 'download.' . $phpEx . '?avatar=' . $this->user[$row['user_id']]['user_avatar'] . '" width="' . $this->user[$row['user_id']]['user_avatar_width'] . '" height="' . $this->user[$row['user_id']]['user_avatar_height'] . '" alt="" />' : '';
	
			// Rank
			get_user_rank($this->user[$row['user_id']]['user_rank'], $this->user[$row['user_id']]['user_posts'], $this->user[$row['user_id']]['rank_title'], $this->user[$row['user_id']]['rank_img'], $this->user[$row['user_id']]['rank_img_src']);
	
			// IM Links
			$this->user[$row['user_id']]['msn_url'] = ($this->user[$row['user_id']]['user_msnm']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=msnm&amp;u=" . $this->user[$row['user_id']]['user_id']) : '';
			$this->user[$row['user_id']]['yim_url'] = ($this->user[$row['user_id']]['user_yim']) ? 'http://edit.yahoo.com/config/send_webmesg?.target=' . $this->user[$row['user_id']]['user_yim'] . '&amp;.src=pg' : '';
			$this->user[$row['user_id']]['aim_url'] = ($this->user[$row['user_id']]['user_aim']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=aim&amp;u=" . $this->user[$row['user_id']]['user_id']) : '';
			$this->user[$row['user_id']]['icq_url'] = ($this->user[$row['user_id']]['user_icq']) ? 'http://www.icq.com/people/webmsg.php?to=' . $this->user[$row['user_id']]['user_icq'] : '';
			$this->user[$row['user_id']]['jabber_url'] = ($this->user[$row['user_id']]['user_jabber']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=jabber&amp;u=" . $this->user[$row['user_id']]['user_id']) : '';
	
			// PM and email links
			$this->user[$row['user_id']]['pm_url'] = ($this->user[$row['user_id']]['user_id'] != ANONYMOUS && $config['allow_privmsg'] && $auth->acl_get('u_sendpm') && ($this->user[$row['user_id']]['user_allow_viewemail'] || $auth->acl_gets('a_', 'm_') || $auth->acl_getf_global('m_'))) ? append_sid("{$phpbb_root_path}ucp.$phpEx", 'i=pm&amp;mode=compose&amp;u=' . $this->user[$row['user_id']]['user_id']) : '';
			$this->user[$row['user_id']]['email_url'] = ($config['board_email_form'] && $config['email_enable']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=email&amp;u=" . $this->user[$row['user_id']]['user_id'])  : (($config['board_hide_emails'] && !$auth->acl_get('a_email')) ? '' : 'mailto:' . $this->user[$row['user_id']]['user_email']);

			// Signature
			if ($config['allow_sig'] && $user->optionget('viewsigs'))
			{
				$this->user[$row['user_id']]['user_sig'] = censor_text($this->user[$row['user_id']]['user_sig']);
				$this->user[$row['user_id']]['user_sig'] = str_replace("\n", '<br />', $this->user[$row['user_id']]['user_sig']);

				if ($this->user[$row['user_id']]['user_sig_bbcode_bitfield'])
				{
					$bbcode->bbcode_second_pass($this->user[$row['user_id']]['user_sig'], $this->user[$row['user_id']]['user_sig_bbcode_uid'], $this->user[$row['user_id']]['user_sig_bbcode_bitfield']);
				}

				$this->user[$row['user_id']]['user_sig'] = smiley_text($this->user[$row['user_id']]['user_sig']);
			}
			else
			{
				$this->user[$row['user_id']]['user_sig'] = '';
			}

			// get the custom profile fields if the admin wants them
			if ($config['blog_custom_profile_enable'])
			{
				$this->user[$row['user_id']]['cp_row'] = (isset($profile_fields_cache[$row['user_id']])) ? $cp->generate_profile_fields_template('show', false, $profile_fields_cache[$row['user_id']]) : array();
			}
		}
		$db->sql_freeresult($result);

		// if we did use the queue, reset it
		if ($queue)
		{
			unset($this->queue);
			$this->queue = array();
		}
	}
	
	// prepares the user data for output to the template, and outputs the custom profile rows when requested
	// Mostly for shortenting up code
	function handle_user_data($user_id, $output_custom = false)
	{
		global $phpbb_root_path, $phpEx, $user, $auth, $config, $template;

		if ($output_custom === false)
		{
			$output_data = array(
				'USERNAME'			=> $this->user[$user_id]['username'],
				'USER_COLOUR'		=> $this->user[$user_id]['user_colour'],
				'USER_FULL'			=> $this->user[$user_id]['username_full'],
				'U_PROFILE'			=> append_sid("{$phpbb_root_path}memberlist.$phpEx", 'mode=viewprofile&amp;u=' . $user_id),

				'SIGNATURE'			=> $this->user[$user_id]['user_sig'],

				'AVATAR'			=> $this->user[$user_id]['avatar'],

				'RANK_TITLE'		=> $this->user[$user_id]['rank_title'],
				'RANK_IMG'			=> $this->user[$user_id]['rank_img'],
				'RANK_IMG_SRC'		=> $this->user[$user_id]['rank_img_src'],

				'STATUS_IMG'		=> (($this->user[$user_id]['status']) ? $user->img('icon_user_online', 'ONLINE') : $user->img('icon_user_offline', 'OFFLINE')),
				'S_ONLINE'			=> $this->user[$user_id]['status'],

				'POSTER_POSTS'		=> $this->user[$user_id]['user_posts'],
				'POSTER_JOINED'		=> $user->format_date($this->user[$user_id]['user_regdate']),
				'POSTER_FROM'		=> $this->user[$user_id]['user_from'],

				'U_PM'				=> $this->user[$user_id]['pm_url'],
				'U_EMAIL'			=> $this->user[$user_id]['email_url'],
				'U_WWW'				=> $this->user[$user_id]['user_website'],
				'U_MSN'				=> $this->user[$user_id]['msn_url'],
				'U_YIM'				=> $this->user[$user_id]['yim_url'],
				'U_AIM'				=> $this->user[$user_id]['aim_url'],
				'U_ICQ'				=> $this->user[$user_id]['icq_url'],
				'U_JABBER'			=> $this->user[$user_id]['jabber_url'],

				'U_DELETED_LINK'	=> ($auth->acl_get('m_blogdelete')) ? '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=deleted&amp;u=" . $this->user[$user_id]['user_id']) . '">' . $user->lang['VIEW_DELETED_BLOGS'] . '</a>' : '',

				'S_CUSTOM_FIELDS'	=> (isset($this->user[$user_id]['cp_row']['blockrow'])) ? true : false,
			);

			return ($output_data);
		}
		else if ($config['blog_custom_profile_enable'])
		{
			// add the blog links in the custom fields
			add_blog_links($user_id, $output_custom);
	
			// output the custom profile fields
			if (isset($this->user[$user_id]['cp_row']['blockrow']))
			{
				foreach ($this->user[$user_id]['cp_row']['blockrow'] as $row)
				{
					$template->assign_block_vars($output_custom, array(
						'PROFILE_FIELD_NAME'	=> $row['PROFILE_FIELD_NAME'],
						'PROFILE_FIELD_VALUE'	=> $row['PROFILE_FIELD_VALUE'],
					));
				}
			}
		}
	}

	/*
	* -------------------------- OTHER SECTION -----------------------------
	*/

	/*
	* trims the length of the text of the requested blog_id and returns it
	*/
	function trim_text_length($blog_id, $str_limit)
	{
		global $phpbb_root_path, $phpEx, $user;

		$bbcode_bitfield = $text_only_message = $text = '';

		$text_only_message = $this->blog[$blog_id]['blog_text'];
		// make list items visible as such
		if ($this->blog[$blog_id]['bbcode_uid'])
		{
			$text_only_message = str_replace('[*:' . $this->blog[$blog_id]['bbcode_uid'] . ']', '&sdot;&nbsp;', $text_only_message);
			// no BBCode in text only message, can't use strp_bbcode because it replaces the bbcode with spaces. :/
			$text_only_message = preg_replace("#\[\/?[a-z0-9\*\+\-]+(?:=.*?)?(?::[a-z])?(\:?" . $this->blog[$blog_id]['bbcode_uid'] . ")\]#", '', $text_only_message);
			$match = get_preg_expression('bbcode_htm');
			$replace = array('\1', '\2', '\1', '', '');
			
			$text_only_message = preg_replace($match, $replace, $text_only_message);
		}

		if (utf8_strlen($text_only_message) > ($str_limit + 3))
		{
			$text = substr($text_only_message, 0, ($str_limit - 3)) . '...';

			// Now lets do some magic and get the smilies (and URL's?) back.
			$message_parser = new parse_message();
			$message_parser->message = $text;
			$message_parser->parse($this->blog[$blog_id]['enable_bbcode'], $this->blog[$blog_id]['enable_magic_url'], $this->blog[$blog_id]['enable_smilies']);
			$text = $message_parser->message;
			unset($message_parser);

			$text .= '<br/><br/><!-- m --><a href="';
			$text .= append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $blog_id);
			$text .= '">[ ' . $user->lang['CONTINUED'] . ' ]</a><!-- m -->';

			$this->blog[$this->blog[$blog_id]['blog_id']]['shortened'] = true;
		}
		else
		{
			$text = $this->blog[$blog_id]['blog_text'];
			$this->blog[$this->blog[$blog_id]['blog_id']]['shortened'] = false;
		}
		unset($text_only_message);

		return $text;
	}

	/*
	* Updates the blog and reply information to add edit and delete messages.
	* I have this seperate so I can grab the blogs, replies, users, then update the edit and delete data (to cut on SQL queries)
	*/
	function update_edit_delete()
	{
		global $auth, $user, $phpbb_root_path, $phpEx;

		foreach ($this->blog as $row)
		{
			if (!$row['simple'] && (!isset($row['edited_message'])) && (!isset($row['deleted_message'])) )
			{
				// has the blog been edited?
				if ($row['blog_edit_count'] != 0)
				{	
					if ($row['blog_edit_count'] == 1)
					{
						if ($auth->acl_get('u_viewprofile'))
						{
							$this->blog[$row['blog_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $this->user[$row['blog_edit_user']]['username_full'], $user->format_date($row['blog_edit_time']), $row['blog_edit_count']);
						}
						else
						{
							if ($this->user[$row['blog_edit_user']]['user_colour'] != '')
							{
								$this->blog[$row['blog_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], '<b style="color: ' . $this->user[$row['blog_edit_user']]['user_colour'] . '">' . $this->user[$row['blog_edit_user']]['username'] . '</b>', $user->format_date($row['blog_edit_time']), $row['blog_edit_count']);
							}
							else
							{
								$this->blog[$row['blog_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $this->user[$row['blog_edit_user']]['username'], $user->format_date($row['blog_edit_time']), $row['blog_edit_count']);
							}
						}
					}
					else if ($row['blog_edit_count'] > 1)
					{
						if ($auth->acl_get('u_viewprofile'))
						{
							$this->blog[$row['blog_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $this->user[$row['blog_edit_user']]['username_full'], $user->format_date($row['blog_edit_time']), $row['blog_edit_count']);
						}
						else
						{
							if ($this->user[$row['blog_edit_user']]['user_colour'] != '')
							{
								$this->blog[$row['blog_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], '<b style="color: ' . $this->user[$row['blog_edit_user']]['user_colour'] . '">' . $this->user[$row['blog_edit_user']]['username'] . '</b>', $user->format_date($row['blog_edit_time']), $row['blog_edit_count']);
							}
							else
							{
								$this->blog[$row['blog_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $this->user[$row['blog_edit_user']]['username'], $user->format_date($row['blog_edit_time']), $row['blog_edit_count']);
							}
						}
					}
		
					$this->blog[$row['blog_id']]['edit_reason'] = censor_text($row['blog_edit_reason']);
				}
				else
				{
					$this->blog[$row['blog_id']]['edited_message'] = '';
					$this->blog[$row['blog_id']]['edit_reason'] = '';
				}
	
				// has the blog been deleted?
				if ($row['blog_deleted'] != 0)
				{
					$this->blog[$row['blog_id']]['deleted_message'] = sprintf($user->lang['BLOG_IS_DELETED'], $this->user[$row['blog_deleted']]['username_full'], $user->format_date($row['blog_deleted_time']), '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=blog&amp;mode=undelete&amp;b=" . $row['blog_id']) . '">', '</a>');
				}
				else
				{
					$this->blog[$row['blog_id']]['deleted_message'] = '';
				}
			}
		}

		foreach ($this->reply as $row)
		{
			if (!$row['simple'] && (!isset($row['edited_message'])) && (!isset($row['deleted_message'])) )
			{
				// has the reply been edited?
				if ($row['reply_edit_count'] != 0)
				{	
					if ($row['reply_edit_count'] == 1)
					{
						if ($auth->acl_get('u_viewprofile'))
						{
							$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $this->user[$row['reply_edit_user']]['username_full'], $user->format_date($row['reply_edit_time']), $row['reply_edit_count']);
						}
						else
						{
							if ($this->user[$row['reply_edit_user']]['user_colour'] != '')
							{
								$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], '<b style="color: ' . $this->user[$row['reply_edit_user']]['user_colour'] . '">' . $this->user[$row['reply_edit_user']]['username'] . '</b>', $user->format_date($row['reply_edit_time']), $row['reply_edit_count']);
							}
							else
							{
								$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $this->user[$row['reply_edit_user']]['username'], $user->format_date($row['reply_edit_time']), $row['reply_edit_count']);
							}
						}
					}
					else if ($row['reply_edit_count'] > 1)
					{
						if ($auth->acl_get('u_viewprofile'))
						{
							$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $this->user[$row['reply_edit_user']]['username_full'], $user->format_date($row['reply_edit_time']), $row['reply_edit_count']);
						}
						else
						{
							if ($this->user[$row['reply_edit_user']]['user_colour'] != '')
							{
								$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], '<b style="color: ' . $this->user[$row['reply_edit_user']]['user_colour'] . '">' . $this->user[$row['reply_edit_user']]['username'] . '</b>', $user->format_date($row['reply_edit_time']), $row['reply_edit_count']);
							}
							else
							{
								$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $this->user[$row['reply_edit_user']]['username'], $user->format_date($row['reply_edit_time']), $row['reply_edit_count']);
							}
						}
					}
		
					$this->reply[$row['reply_id']]['edit_reason'] = censor_text($row['reply_edit_reason']);
				}
				else
				{
					$this->reply[$row['reply_id']]['edited_message'] = '';
					$this->reply[$row['reply_id']]['edit_reason'] = '';
				}
	
				// has the reply been deleted?
				if ($row['reply_deleted'] != 0)
				{
					$this->reply[$row['reply_id']]['deleted_message'] = sprintf($user->lang['REPLY_IS_DELETED'], $this->user[$row['reply_deleted']]['username_full'], $user->format_date($row['reply_deleted_time']), '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=reply&amp;mode=undelete&amp;r=" . $row['reply_id']) . '">', '</a>');
				}
				else
				{
					$this->reply[$row['reply_id']]['deleted_message'] = '';
				}
			}
		}
	}
}

/*
* Check permission and settings for bbcode, img, url, etc
*/
class post_options
{
	// the permissions, so I can change them later easier if need be for a different mod or whatever...
	var $auth_bbcode = false;
	var $auth_smilies = false;
	var $auth_img = false;
	var $auth_url = false;
	var $auth_flash = false;

	// whether these are allowed or not
	var $bbcode_status = false;
	var $smilies_status = false;
	var $img_status = false;
	var $url_status = false;
	var $flash_status = false;

	// whether or not they are enabled in the post
	var $enable_bbcode = false;
	var $enable_smilies = false;
	var $enable_magic_url = false;

	// automatically sets the defaults for the $auth_ vars
	function post_options()
	{
		global $auth;

		$this->auth_bbcode = $auth->acl_get('u_blogbbcode');
		$this->auth_smilies = $auth->acl_get('u_blogsmilies');
		$this->auth_img = $auth->acl_get('u_blogimg');
		$this->auth_url = $auth->acl_get('u_blogurl');
		$this->auth_flash = $auth->acl_get('u_blogflash');
	}

	// set the status to the  variables above, the enabled options are if they are enabled in the posts(by who ever is posting it)
	function set_status($bbcode, $smilies, $url)
	{
		global $config, $auth;

		$this->bbcode_status = ($config['allow_bbcode'] && $this->auth_bbcode) ? true : false;
		$this->smilies_status = ($config['allow_smilies'] && $this->auth_smilies) ? true : false;
		$this->img_status = ($this->auth_img && $this->bbcode_status) ? true : false;
		$this->url_status = ($config['allow_post_links'] && $this->auth_url && $this->bbcode_status) ? true : false;
		$this->flash_status = ($this->auth_flash && $this->bbcode_status) ? true : false;

		$this->enable_bbcode = ($this->bbcode_status && $bbcode) ? true : false;
		$this->enable_smilies = ($this->smilies_status && $smilies) ? true : false;
		$this->enable_magic_url = ($this->url_status && $url) ? true : false;
	}

	function set_in_template()
	{
		global $template, $user, $phpbb_root_path, $phpEx;

		// Assign some variables to the template parser
		$template->assign_vars(array(
			// If they hit preview or submit and got an error, or are editing their post make sure we carry their existing post info & options over
			'S_BBCODE_CHECKED'			=> ($this->enable_bbcode) ? '' : ' checked="checked"',
			'S_SMILIES_CHECKED'			=> ($this->enable_smilies) ? '' : ' checked="checked"',
			'S_MAGIC_URL_CHECKED'		=> ($this->enable_magic_url) ? '' : ' checked="checked"',

			// To show the Options: section on the bottom left
			'BBCODE_STATUS'				=> ($this->bbcode_status) ? sprintf($user->lang['BBCODE_IS_ON'], '<a href="' . append_sid("{$phpbb_root_path}faq.$phpEx", 'mode=bbcode') . '">', '</a>') : sprintf($user->lang['BBCODE_IS_OFF'], '<a href="' . append_sid("{$phpbb_root_path}faq.$phpEx", 'mode=bbcode') . '">', '</a>'),
			'IMG_STATUS'				=> ($this->img_status) ? $user->lang['IMAGES_ARE_ON'] : $user->lang['IMAGES_ARE_OFF'],
			'FLASH_STATUS'				=> ($this->flash_status) ? $user->lang['FLASH_IS_ON'] : $user->lang['FLASH_IS_OFF'],
			'SMILIES_STATUS'			=> ($this->smilies_status) ? $user->lang['SMILIES_ARE_ON'] : $user->lang['SMILIES_ARE_OFF'],
			'URL_STATUS'				=> ($this->url_status) ? $user->lang['URL_IS_ON'] : $user->lang['URL_IS_OFF'],

			// To show the option to turn each off while posting
			'S_BBCODE_ALLOWED'			=> $this->bbcode_status,
			'S_SMILIES_ALLOWED'			=> $this->smilies_status,
			'S_LINKS_ALLOWED'			=> $this->url_status,

			// To show the BBCode buttons for each on top
			'S_BBCODE_IMG'				=> $this->img_status,
			'S_BBCODE_URL'				=> $this->url_status,
			'S_BBCODE_FLASH'			=> $this->flash_status,
		));
	}
}
?>