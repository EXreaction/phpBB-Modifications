<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* TODO List
*
* PRIORITY -----------
* Main blog page
*
* NEEDS TO BE STARTED
*
* Add RSS Output Feed
* Report Blogs
* Approve Blogs
* ACP
* MCP
* SEO Url's
*
*
* NEEDS TO BE FINISHED
*
* Comments(comment more of the code)
*
*/

// Stuff required to work with phpBB3, and include some function pages that we will use later on...
define('IN_PHPBB', true);
$phpbb_root_path = './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/bbcode.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);
include($phpbb_root_path . 'includes/functions_posting.' . $phpEx);
include($phpbb_root_path . 'includes/message_parser.' . $phpEx);

if (!function_exists('add_blog_links'))
{
	include($phpbb_root_path . 'includes/blog/functions.' . $phpEx);
}

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('blog');

// get some initial data
$page = request_var('page', '');
$mode = request_var('mode', '');
$user_id = intval(request_var('u', 0));
$blog_id = intval(request_var('b', 0));
$reply_id = intval(request_var('r', 0));

$print = (request_var('view', '') == 'print') ? true : false;
$submit = (isset($_POST['post'])) ? true : false;
$preview = (isset($_POST['preview'])) ? true : false;
$cancel = (isset($_POST['cancel'])) ? true : false;

// set some initial variables that we will (almost) always use
$blog_data = array();
$author_data = array();
$breadcrumbs = array();

switch ($page)
{
	case 'view' :
		include($phpbb_root_path . 'includes/blog/view.' . $phpEx);
		break;
	case 'blog' :
		include($phpbb_root_path . 'includes/blog/blog.' . $phpEx);
		break;
	case 'reply' :
		include($phpbb_root_path . 'includes/blog/reply.' . $phpEx);
		break;
	default :
		include($phpbb_root_path . 'includes/blog/main.' . $phpEx);
		break;
}

// setup the page footer
page_footer();
?>