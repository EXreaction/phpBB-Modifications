<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/*
* TODO:
* Length limit, remove hard-codded limit
* Add RSS Output Feed
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// check to make sure they requested a legit page
if ( ($mode != 'deleted') && ($mode != 'blog') && ($mode != 'user') )
{
	trigger_error('NO_MODE');
}

// Check the permissions and make sure they can access this page
check_permissions($page, $mode);

// shorten some variables for later use
$deleted = ($mode == 'deleted') ? true : false; // viewing deleted blogs
$blog = ($mode == 'blog') ? true : false; // viewing a certain blog

// Add the language Variables for viewtopic
$user->add_lang('viewtopic');

// Get the Blog Data
if ($blog)
{
	// Get the blog data
	$blog_data = get_blogs($blog_id);

	// If the blog requested doesnt exist
	if (!$blog_data)
	{
		trigger_error('NO_BLOG');
	}

	// if the blog was deleted and the person trying to view the blog is not a moderator that can view deleted blogs, give them a nice error. :P
	if ( ($blog_data[1]['deleted_message'] != '') && (!$auth->acl_get('m_blogdelete')) )
	{
		trigger_error('BLOG_DELETED');
	}

	// for consistency
	$user_id = $blog_data[1]['user_id'];
}
else
{
	// Make sure they included a user_id when they requested the page.
	if ($user_id == 0)
	{
		trigger_error('NO_USER');
	}

	// Get the blogs
	if ($deleted)
	{
		$blog_data = get_blogs(false, $user_id, true, 0, 100);
	}
	else
	{
		$blog_data = get_blogs(false, $user_id, false, 5, 100);
	}
}

// Moderation/user options
$can_edit = check_permissions('blog', 'edit', ($user->data['user_id'] == $user_id), true);
$can_delete = check_permissions('blog', 'delete', ($user->data['user_id'] == $user_id), true);
$can_add = check_permissions('blog', 'add', false, true);
$can_reply = check_permissions('reply', 'add', false, true);

// Get the data on the author of these blogs (mainly for the left menu)
$author_data = get_user_data($user_id);

// Generate the left menu
generate_menu($author_data);

// Generate the breadcrumbs, setup the page header, and setup some variables we will use...
$breadcrumbs[sprintf($user->lang['USERNAMES_BLOGS'], $author_data['username'])] = append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=user&amp;u=" . $user_id);

if ($deleted)
{
	$self_url_vars = 'page=view&amp;mode=deleted&amp;u=' . $user_id;
	$self_url = append_sid("{$phpbb_root_path}blog.$phpEx", $self_url_vars);
	$breadcrumbs[$user->lang['DELETED_BLOGS']] = $self_url;
	$title = sprintf($user->lang['USERNAMES_DELETED_BLOGS'], $author_data['username']);
}
else if ($blog)
{
	$self_url_vars = 'page=view&amp;mode=blog&amp;b=' . $blog_id;
	$self_url = append_sid("{$phpbb_root_path}blog.$phpEx", $self_url_vars);
	$breadcrumbs[$blog_data[1]['blog_subject']] = $self_url;
	$title = $user->lang['VIEW_BLOG'] .' - ' . $blog_data[1]['blog_subject'];
}
else
{
	$self_url_vars = 'page=view&amp;mode=user&amp;u=' . $user_id;
	$self_url = append_sid("{$phpbb_root_path}blog.$phpEx", $self_url_vars);
	$title = sprintf($user->lang['USERNAMES_BLOGS'], $author_data['username']);
}

generate_blog_breadcrumbs($breadcrumbs);
page_header($title);

// Output some data
$template->assign_vars(array(
	'TITLE'				=> ($blog) ? $blog_data[1]['blog_subject'] : '',
	'U_VIEW'			=> $self_url,

	'U_PRINT_BLOG'		=> append_sid("{$phpbb_root_path}blog.$phpEx", $self_url_vars .'&amp;view=print'),
	'S_PRINT_MODE'		=> $print,
	'U_BLOG'			=> ($print) ? generate_board_url() . "/blog.$phpEx?$self_url_vars" : '',

	'U_ADD_BLOG'		=> ($can_add && !$deleted) ? append_sid("{$phpbb_root_path}blog.$phpEx", "page=blog&amp;mode=add") : '',
	'U_REPLY_BLOG'		=> ($can_reply && $blog) ? append_sid("{$phpbb_root_path}blog.$phpEx", 'page=reply&amp;mode=add&amp;b=' . $blog_id) : '',

	'ADD_BLOG_IMG'		=> '<img src="' . $phpbb_root_path . 'styles/' . $user->theme['template_path'] . '/imageset/' . $user->data['user_lang'] . '/button_blog_new.gif">',
	'REPLY_BLOG_IMG'	=> $user->img('button_topic_reply', 'REPLY_TO_TOPIC'),
	'EDIT_IMG'			=> $user->img('icon_post_edit', 'EDIT_POST'),
	'DELETE_IMG'		=> $user->img('icon_post_delete', 'DELETE_POST'),
	'UNAPPROVED_IMG'	=> $user->img('icon_topic_unapproved', 'POST_UNAPPROVED'),
	'REPORTED_IMG'		=> $user->img('icon_topic_reported', 'POST_REPORTED'),
	'MINI_POST_IMG'		=> $user->img('icon_post_target', 'POST'),

	// output the mode so we can use it in if statements in the templates
	'MODE'				=> $mode,
));

// For the left blog info menu
if ($blog)
{
	// left blog info section
	$template->assign_vars(array(
		'S_BLOG_INFO_MENU'	=> true,
		'DATE'				=> $user->format_date($blog_data[1]['blog_time']),
		'VIEWS'				=> sprintf($user->lang['BLOG_VIEWS'], ($user->data['user_id'] != $user_id) ? $blog_data[1]['blog_read_count'] + 1 : $blog_data[1]['blog_read_count']), // Make sure we get the real view count, so we add one if the viewer isnt the owner... ;-)
		'IP'				=> ($auth->acl_get('m_blogview')) ? $blog_data[1]['user_ip'] : '',
	));
}

// If there are blogs, output the data
if ($blog_data)
{
	// Counter variable
	$i = 0;

	// Since the get_blogs function returns a 3D array we do a foreach of the main array as $row and then use the array in $row to output the single blog's data
	foreach($blog_data as $row)
	{
		// increment the counter
		$i++;

		// put the data in an array to output later
		$blogrow = array(
			'U_VIEW'			=> append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=blog&amp;b=" . $row['blog_id']),

			'TITLE'				=> $row['blog_subject'],
			'DATE'				=> $user->format_date($row['blog_time']),
			'BLOG_MESSAGE'		=> $row['blog_text'],

			'EDITED_MESSAGE'	=> $row['edited_message'],
			'EDIT_REASON'		=> $row['edit_reason'],
			'DELETED_MESSAGE'	=> $row['deleted_message'],

			'S_BLOG_UNAPPROVED' => '',
			'U_MCP_APPROVE'		=> '',
			'S_BLOG_REPORTED'	=> '',
			'U_MCP_REPORT'		=> '',

			// the count of views or replies
			'VIEWS'				=> ($row['blog_read_count'] > 1) ? sprintf($user->lang['BLOG_VIEWS'], ($user->data['user_id'] != $author_data['user_id']) ? $row['blog_read_count'] + 1 : $row['blog_read_count']) : $user->lang['BLOG_VIEW'],
			'REPLIES'			=> ($row['blog_reply_count'] != 1) ? sprintf($user->lang['BLOG_REPLIES'], $row['blog_reply_count'], '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=blog&amp;b=" . $row['blog_id']) . '">', '</a>') : sprintf($user->lang['BLOG_REPLY'], '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=blog&amp;b=" . $row['blog_id']) . '">', '</a>'),

			// is this the last one or not?
			'S_NOT_LAST'		=> ($i < count($blog_data)) ? true : false,
		);

		// These are only used in viewing a single blog
		if ($blog)
		{
			$blogrow['U_SUBMIT_DIGG'] = 'http://digg.com/submit?phase=2&url=' . urlencode(generate_board_url() . '/blog.' . $phpEx . '?page=view&mode=blog&b=' . $blog_id);
			$blogrow['U_EDIT'] = ($can_edit) ? append_sid("{$phpbb_root_path}blog.$phpEx", "page=blog&amp;mode=edit&amp;b=$blog_id") : '';
			$blogrow['U_DELETE'] = ($can_delete) ? append_sid("{$phpbb_root_path}blog.$phpEx", "page=blog&amp;mode=delete&amp;b=$blog_id") : '';
		}

		// Now output the data to the template
		$template->assign_block_vars('blogrow', $blogrow);

		// to update the read count, we are only doing this if the user is not the owner, and the user doesn't view the shortened version, and we are not viewing the deleted blogs page
		if ( ($user->data['user_id'] != $user_id) && (!$row['shortened']) && (!$deleted) )
		{
			$sql = 'UPDATE ' . BLOGS_TABLE . ' SET blog_read_count = blog_read_count + 1 WHERE blog_id = \'' . $row['blog_id'] . '\'';

			// At some time this should be setup to do a multi update...if that is possible...
			if (!($result = $db->sql_query($sql)))
			{
				trigger_error('Could not update the read count in the Blogs table');
			}
		}
	}
}

// For the replies
if ($blog)
{
	// Get the data on all of the replies
	$reply_data = get_replies($blog_id);

	// are there any replies?  If so output the data
	if ($reply_data)
	{
		// tell the template we do have replies
		$template->assign_vars(array(
			'S_REPLIES'		=> ($reply_data) ? true : false,
		));

		// Counter
		$i = 0;

		// use a foreach to easily output the data
		foreach($reply_data as $row)
		{
			if ( ($row['deleted_message'] == '') || ($auth->acl_get('m_blogreplydelete')) )
			{
				// increment the counter
				$i++;

				// output data to the replyrow block
				$template->assign_block_vars('replyrow', array(
					'USERNAME'			=> $row['username'],
					'USER_COLOUR'		=> $row['user_colour'],
					'U_PROFILE'			=> append_sid("{$phpbb_root_path}memberlist.$phpEx", 'mode=viewprofile&amp;u=' . $row['user_id']),

					'DATE'				=> $user->format_date($row['reply_time']),

					'REPLY_MESSAGE'		=> $row['reply_text'],

					'EDITED_MESSAGE'	=> $row['edited_message'],
					'EDIT_REASON'		=> $row['edit_reason'],
					'DELETED_MESSAGE'	=> $row['deleted_message'],

					'U_VIEW'			=> append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $blog_id . '#' . $row['reply_id']),

					// For the anchors
					'ID'				=> $row['reply_id'],

					'U_EDIT'			=> (check_permissions('reply', 'edit', ($user->data['user_id'] == $row['user_id']), true)) ? append_sid("{$phpbb_root_path}blog.$phpEx", 'page=reply&amp;mode=edit&amp;r=' . $row['reply_id']) : '',
					'U_DELETE'			=> (check_permissions('reply', 'delete', ($user->data['user_id'] == $row['user_id']), true)) ? append_sid("{$phpbb_root_path}blog.$phpEx", 'page=reply&amp;mode=delete&amp;r=' . $row['reply_id']) : '',

					// is it the last one?
					'S_LAST'		=> ($i == count($reply_data)) ? true : false,
				));
			}
		}
	}
}

// tell the template parser what template file to use
$template->set_filenames(array(
	'body' => 'view_blog.html'
));
?>