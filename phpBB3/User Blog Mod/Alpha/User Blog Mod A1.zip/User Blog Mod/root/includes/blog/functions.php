<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

/*
* Add the links in the custom profile fields
*/
function add_blog_links($user_id, $block)
{
	global $template, $user, $phpbb_root_path, $phpEx;

	$template->assign_block_vars($block, array(
		'PROFILE_FIELD_NAME'		=> $user->lang['BLOG'],
		'PROFILE_FIELD_VALUE'		=> '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=user&amp;u=' . $user_id) . '">' . $user->lang['VIEW_BLOG'] . '</a>',
	));
}

/*
* Check permission and settings for bbcode, img, url, etc
* I have never actually made a class to use before, so I am doing it now to learn more about them(and I think this will work best anyways)
*/
class post_options
{
	// the permissions, so I can change them later easier if need be for a different mod or whatever...
	var $auth_bbcode = false;
	var $auth_smilies = false;
	var $auth_img = false;
	var $auth_url = false;
	var $auth_flash = false;

	// whether these are allowed or not
	var $bbcode_status = false;
	var $smilies_status = false;
	var $img_status = false;
	var $url_status = false;
	var $flash_status = false;

	// whether or not they are enabled in the post
	var $enable_bbcode = false;
	var $enable_smilies = false;
	var $enable_magic_url = false;

	// automatically sets the defaults for the $auth_ vars
	function post_options()
	{
		global $auth;

		$this->auth_bbcode = $auth->acl_get('u_blogbbcode');
		$this->auth_smilies = $auth->acl_get('u_blogsmilies');
		$this->auth_img = $auth->acl_get('u_blogimg');
		$this->auth_url = $auth->acl_get('u_blogurl');
		$this->auth_flash = $auth->acl_get('u_blogflash');
	}

	// set the status to the  variables above, the enabled options are if they are enabled in the posts(by who ever is posting it)
	function set_status($bbcode, $smilies, $url)
	{
		global $config, $auth;

		$this->bbcode_status = ($config['allow_bbcode'] && $this->auth_bbcode) ? true : false;
		$this->smilies_status = ($config['allow_smilies'] && $this->auth_smilies) ? true : false;
		$this->img_status = ($this->auth_img && $this->bbcode_status) ? true : false;
		$this->url_status = ($config['allow_post_links'] && $this->auth_url && $this->bbcode_status) ? true : false;
		$this->flash_status = ($this->auth_flash && $this->bbcode_status) ? true : false;

		$this->enable_bbcode = ($this->bbcode_status && $bbcode) ? true : false;
		$this->enable_smilies = ($this->smilies_status && $smilies) ? true : false;
		$this->enable_magic_url = ($this->url_status && $url) ? true : false;
	}

	function set_in_template()
	{
		global $template, $user, $phpbb_root_path, $phpEx;

		// Assign some variables to the template parser
		$template->assign_vars(array(
			// If they hit preview or submit and got an error, or are editing their post make sure we carry their existing post info & options over
			'S_BBCODE_CHECKED'			=> ($this->enable_bbcode) ? '' : ' checked="checked"',
			'S_SMILIES_CHECKED'			=> ($this->enable_smilies) ? '' : ' checked="checked"',
			'S_MAGIC_URL_CHECKED'		=> ($this->enable_magic_url) ? '' : ' checked="checked"',

			// To show the Options: section on the bottom left
			'BBCODE_STATUS'				=> ($this->bbcode_status) ? sprintf($user->lang['BBCODE_IS_ON'], '<a href="' . append_sid("{$phpbb_root_path}faq.$phpEx", 'mode=bbcode') . '">', '</a>') : sprintf($user->lang['BBCODE_IS_OFF'], '<a href="' . append_sid("{$phpbb_root_path}faq.$phpEx", 'mode=bbcode') . '">', '</a>'),
			'IMG_STATUS'				=> ($this->img_status) ? $user->lang['IMAGES_ARE_ON'] : $user->lang['IMAGES_ARE_OFF'],
			'FLASH_STATUS'				=> ($this->flash_status) ? $user->lang['FLASH_IS_ON'] : $user->lang['FLASH_IS_OFF'],
			'SMILIES_STATUS'			=> ($this->smilies_status) ? $user->lang['SMILIES_ARE_ON'] : $user->lang['SMILIES_ARE_OFF'],
			'URL_STATUS'				=> ($this->url_status) ? $user->lang['URL_IS_ON'] : $user->lang['URL_IS_OFF'],

			// To show the option to turn each off while posting
			'S_BBCODE_ALLOWED'			=> $this->bbcode_status,
			'S_SMILIES_ALLOWED'			=> $this->smilies_status,
			'S_LINKS_ALLOWED'			=> $this->url_status,

			// To show the BBCode buttons for each on top
			'S_BBCODE_IMG'				=> $this->img_status,
			'S_BBCODE_URL'				=> $this->url_status,
			'S_BBCODE_FLASH'			=> $this->flash_status,
		));
	}
}


/*
* get blogs
* if blog_id is true then we are just grabbing 1 blog if not we grab all from the user id
* if deleted is true we only grab the deleted messages, otherwise do not show deleted messages
* limit is to limit the number we grab if we select by user_id, if the var coming in is less than 1, then there is no limit
*/
function get_blogs($blog_id, $user_id = false, $deleted = false, $limit = 5, $str_limit = 0)
{
	/*
	* TODO
	* Move limit from the SELECT sql to count in the while loop
	* Check if user can view non-approved messages
	*/
	global $db, $user, $phpbb_root_path, $phpEx;

	$i = 0;
	$blog_data = array();

	// Get the data on the blog
	if ($user_id != false)
	{
		// update the deleted option to be a 1 or 0 instead of true/false
		$deleted_sql = ($deleted) ? 'AND blog_deleted != \'0\'' : 'AND blog_deleted = \'0\'';

		// if they want a limit, put it in, else dont have one
		$limit_sql = ($limit >= 1) ? 'LIMIT ' . $limit : '';

		$sql = 'SELECT * FROM ' . BLOGS_TABLE . '
					WHERE user_id = \'' . $user_id . '\' '
					. $deleted_sql . '
						ORDER BY blog_id DESC ' .
							$limit_sql;
	}
	else
	{
		$sql = 'SELECT * FROM ' . BLOGS_TABLE . '
					WHERE blog_id = \'' . $blog_id . '\'
						LIMIT 1';
	}
	$result = $db->sql_query($sql);

	while($row = $db->sql_fetchrow($result))
	{
		$i++;

		if ($str_limit > 0)
		{
			$bbcode_bitfield = $text_only_message = '';

			$text_only_message = $row['blog_text'];
			// make list items visible as such
			if ($row['bbcode_uid'])
			{
				$text_only_message = str_replace('[*:' . $row['bbcode_uid'] . ']', '&sdot;&nbsp;', $text_only_message);
				// no BBCode in text only message, can't use strp_bbcode because it replaces the bbcode with spaces. :/
				$text_only_message = preg_replace("#\[\/?[a-z0-9\*\+\-]+(?:=.*?)?(?::[a-z])?(\:?" . $row['bbcode_uid'] . ")\]#", '', $text_only_message);
				$match = get_preg_expression('bbcode_htm');
				$replace = array('\1', '\2', '\1', '', '');
				
				$text_only_message = preg_replace($match, $replace, $text_only_message);
			}

			if (utf8_strlen($text_only_message) > ($str_limit + 3))
			{
				$row['blog_text'] = substr($text_only_message, 0, ($str_limit - 3)) . '...';

				// Now lets do some magic and get the smilies (and URL's?) back.
				$message_parser = new parse_message();
				$message_parser->message = $row['blog_text'];
				$message_parser->parse($row['enable_bbcode'], $row['enable_magic_url'], $row['enable_smilies']);
				$row['blog_text'] = $message_parser->message;
				$row['bbcode_bitfield'] = $message_parser->bbcode_bitfield;
				$row['bbcode_uid'] = $message_parser->bbcode_uid;
				unset($message_parser);

				$row['blog_text'] .= '<br/><br/><!-- m --><a href="';
				$row['blog_text'] .= append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $row['blog_id']);
				$row['blog_text'] .= '">[ ' . $user->lang['CONTINUED'] . ' ]</a><!-- m -->';

				$blog_data[$i]['shortened'] = true;
			}
			else
			{
				$blog_data[$i]['shortened'] = false;
			}

			unset($text_only_message);
		}
		else
		{
			$blog_data[$i]['shortened'] = false;
		}

		$blog_data[$i]['blog_id'] = $row['blog_id'];
		$blog_data[$i]['user_id'] = $row['user_id'];
		$blog_data[$i]['user_ip'] = $row['user_ip'];
		$blog_data[$i]['blog_time'] = $row['blog_time'];
		$blog_data[$i]['blog_approved'] = $row['blog_approved'];
		$blog_data[$i]['blog_reported'] = $row['blog_reported'];
		$blog_data[$i]['blog_subject'] = censor_text($row['blog_subject']); // censor the text of the subject

		// Parse BBCode and prepare the message for viewing
		$bbcode_options = (($row['enable_bbcode']) ? OPTION_FLAG_BBCODE : 0) +
			(($row['enable_smilies']) ? OPTION_FLAG_SMILIES : 0) + 
			(($row['enable_magic_url']) ? OPTION_FLAG_LINKS : 0);
		$blog_data[$i]['blog_text'] = generate_text_for_display($row['blog_text'], $row['bbcode_uid'], $row['bbcode_bitfield'], $bbcode_options);

		// For Highlighting
		$hilit_words = request_var('hilit', '', true);
		$highlight_match = $highlight = '';
		if ($hilit_words)
		{
			foreach (explode(' ', trim($hilit_words)) as $word)
			{
				if (trim($word))
				{
					$highlight_match .= (($highlight_match != '') ? '|' : '') . str_replace('*', '\w*?', preg_quote($word, '#'));
				}
			}

			$highlight = urlencode($hilit_words);
		}
		if ($highlight_match)
		{
			$blog_data[$i]['blog_text'] = preg_replace('#(?!<.*)(?<!\w)(' . $highlight_match . ')(?!\w|[^<>]*(?:</s(?:cript|tyle))?>)#is', '<span class="posthilit">\1</span>', $blog_data[$i]['blog_text']);
		}

		// has the blog been edited?
		if ($row['blog_edit_count'] != 0)
		{
			$editor_data = get_user_data($row['blog_edit_user'], 'username, user_colour');
			$colour = ($editor_data['user_colour'] != '') ? ' style="color: ' . $editor_data['user_colour'] . '"' : '';
			$username = '<a href="' . $editor_data['view_profile'] . '"><b' . $colour . '>' . $editor_data['username'] . '</b></a>';

			if ($row['blog_edit_count'] == 1)
			{
				$blog_data[$i]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $username, $user->format_date($row['blog_edit_time']), $row['blog_edit_count']);
			}
			else if ($row['blog_edit_count'] > 1)
			{
				$blog_data[$i]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $username, $user->format_date($row['blog_edit_time']), $row['blog_edit_count']);
			}

			$blog_data[$i]['edit_reason'] = censor_text($row['blog_edit_reason']);
		}
		else
		{
			$blog_data[$i]['edited_message'] = '';
			$blog_data[$i]['edit_reason'] = '';
		}

		// has the blog been deleted?
		if ($row['blog_deleted'] != 0)
		{
			$deleter_data = get_user_data($row['blog_deleted'], 'username, user_colour');
			$colour = ($deleter_data['user_colour'] != '') ? ' style="color: ' . $deleter_data['user_colour'] . '"' : '';
			$username = '<a href="' . $deleter_data['view_profile'] . '"><b' . $colour . '>' . $deleter_data['username'] . '</b></a>';
			$blog_data[$i]['deleted_message'] = sprintf($user->lang['BLOG_IS_DELETED'], $username, $user->format_date($row['blog_deleted_time']), '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=blog&amp;mode=undelete&amp;b=" . $row['blog_id']) . '">', '</a>');
		}
		else
		{
			$blog_data[$i]['deleted_message'] = '';
		}

		$blog_data[$i]['blog_edit_locked'] = $row['blog_edit_locked'];
		$blog_data[$i]['blog_read_count'] = $row['blog_read_count'];
		$blog_data[$i]['blog_reply_count'] = $row['blog_reply_count'];
	}
	$db->sql_freeresult($result);

	// if there are no blogs, return false
	if (count($blog_data) == 0)
	{
		return false;
	}

	return $blog_data;
}

/*
* get replies
* if deleted is true we only grab the deleted messages, otherwise do not show deleted messages(this does not get checked for viewing a single blog)
*/
function get_replies($blog_id)
{
	/*
	* TODO
	* Check if user can view non-approved messages
	*/
	global $db, $user, $phpbb_root_path, $phpEx, $auth;

	// setting up some variables
	$i = 0;
	$author_data = array();
	$reply_data = array();

	// Add the language Variables for viewtopic
	$user->add_lang('viewtopic');

	// if the user can not view deleted replies, don't select them.
	$deleted_sql = ($auth->acl_get('m_blogreplydelete')) ? '' : ' AND reply_deleted = \'0\'';

	// Grab the replies
	$sql = 'SELECT * FROM ' . BLOGS_REPLY_TABLE . '
				WHERE blog_id = \'' . $blog_id . '\'' .
					$deleted_sql;
	$result = $db->sql_query($sql);

	while($row = $db->sql_fetchrow($result))
	{
		$i++;

		// get some info on the author, we are storing this in an array, so if the author of this reply replies again we do not have to run any queries.
		if (!array_key_exists($row['user_id'], $author_data))
		{
			$author_data[$row['user_id']] = get_user_data($row['user_id'], 'username, user_colour');
		}

		$reply_data[$i]['reply_id'] = $row['reply_id'];
		$reply_data[$i]['user_id'] = $row['user_id'];
		$reply_data[$i]['user_ip'] = $row['user_ip'];
		$reply_data[$i]['username'] = $author_data[$row['user_id']]['username'];
		$reply_data[$i]['user_colour'] = $author_data[$row['user_id']]['user_colour'];
		$reply_data[$i]['reply_time'] = $row['reply_time'];
		$reply_data[$i]['reply_approved'] = $row['reply_approved'];
		$reply_data[$i]['reply_reported'] = $row['reply_reported'];
		$reply_data[$i]['reply_subject'] = censor_text($row['reply_subject']); // censor the text of the subject

		// Parse BBCode and prepare the message for viewing
		$bbcode_options = (($row['enable_bbcode']) ? OPTION_FLAG_BBCODE : 0) +
			(($row['enable_smilies']) ? OPTION_FLAG_SMILIES : 0) + 
			(($row['enable_magic_url']) ? OPTION_FLAG_LINKS : 0);
		$reply_data[$i]['reply_text'] = generate_text_for_display($row['reply_text'], $row['bbcode_uid'], $row['bbcode_bitfield'], $bbcode_options);

		// For Highlighting
		$hilit_words = request_var('hilit', '', true);
		$highlight_match = $highlight = '';
		if ($hilit_words)
		{
			foreach (explode(' ', trim($hilit_words)) as $word)
			{
				if (trim($word))
				{
					$highlight_match .= (($highlight_match != '') ? '|' : '') . str_replace('*', '\w*?', preg_quote($word, '#'));
				}
			}

			$highlight = urlencode($hilit_words);
		}
		if ($highlight_match)
		{
			$reply_data[$i]['reply_text'] = preg_replace('#(?!<.*)(?<!\w)(' . $highlight_match . ')(?!\w|[^<>]*(?:</s(?:cript|tyle))?>)#is', '<span class="posthilit">\1</span>', $reply_data[$i]['reply_text']);
		}

		// has the blog been edited?
		if ($row['reply_edit_count'] != 0)
		{
			if (!array_key_exists($row['reply_edit_user'], $author_data))
			{
				$author_data[$row['reply_edit_user']] = get_user_data($row['reply_edit_user'], 'username, user_colour');
			}
			$colour = ($author_data[$row['reply_edit_user']]['user_colour'] != '') ? ' style="color: ' . $author_data[$row['reply_edit_user']]['user_colour'] . '"' : '';
			$username = '<a href="' . $author_data[$row['reply_edit_user']]['view_profile'] . '"><b' . $colour . '>' . $author_data[$row['reply_edit_user']]['username'] . '</b></a>';

			if ($row['reply_edit_count'] == 1)
			{
				$reply_data[$i]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $username, $user->format_date($row['reply_edit_time']), $row['reply_edit_count']);
			}
			else if ($row['reply_edit_count'] > 1)
			{
				$reply_data[$i]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $username, $user->format_date($row['reply_edit_time']), $row['reply_edit_count']);
			}

			$reply_data[$i]['edit_reason'] = censor_text($row['reply_edit_reason']);
		}
		else
		{
			$reply_data[$i]['edited_message'] = '';
			$reply_data[$i]['edit_reason'] = '';
		}

		// has the reply been deleted?
		if ($row['reply_deleted'] != 0)
		{
			if (!array_key_exists($row['reply_deleted'], $author_data))
			{
				$author_data[$row['reply_deleted']] = get_user_data($row['reply_deleted'], 'username, user_colour');
			}
			$colour = ($author_data[$row['reply_deleted']]['user_colour'] != '') ? ' style="color: ' . $author_data[$row['reply_deleted']]['user_colour'] . '"' : '';
			$username = '<a href="' . $author_data[$row['reply_deleted']]['view_profile'] . '"><b' . $colour . '>' . $author_data[$row['reply_deleted']]['username'] . '</b></a>';
			$reply_data[$i]['deleted_message'] = sprintf($user->lang['REPLY_IS_DELETED'], $username, $user->format_date($row['reply_deleted_time']), '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=reply&amp;mode=undelete&amp;r=" . $row['reply_id']) . '">', '</a>');
		}
		else
		{
			$reply_data[$i]['deleted_message'] = '';
		}

		$reply_data[$i]['reply_edit_locked'] = $row['reply_edit_locked'];
	}
	$db->sql_freeresult($result);

	// if there are no replies, return false
	if (count($reply_data) == 0)
	{
		return false;
	}

	return $reply_data;
}

/*
* get author/user data
* request is for if we want specific data or everything.
*/
function get_user_data($user_id, $request = '*')
{
	global $user, $db, $phpbb_root_path, $phpEx;

	// if the user id is the same as the user id being requested, we can skip a (or a few) SQL query :D
	if ($user_id != $user->data['user_id'])
	{
		// Get the data on the author/user
		$sql = 'SELECT ' . $request . ' FROM ' . USERS_TABLE . ' WHERE user_id = \'' . $user_id . '\'';
		$result = $db->sql_query($sql);
		$user_data = $db->sql_fetchrow($result);
		$db->sql_freeresult($result);
	}
	else
	{
		$user_data = $user->data;
	}

	// view profile link
	$user_data['view_profile'] = append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=viewprofile&amp;u=" . $user_id);

	// correct the user colour if it has been requested
	if ( (array_key_exists('user_colour', $user_data)) && (array_key_exists('username', $user_data)) )
	{
		$user_data['user_colour'] = get_username_string('colour', $user_id, $user_data['username'], $user_data['user_colour']);
	}

	return $user_data;
}

/**
* Create the breadcrumbs
*/
function generate_blog_breadcrumbs($crumbs)
{
	global $template;

	foreach ($crumbs as $text => $link)
	{
		$template->assign_block_vars('navlinks', array(
			'FORUM_NAME'	=> $text,
			'U_VIEW_FORUM'	=> $link,
		));
	}
}

/**
* Generates the left side menu
*/
function generate_menu($author_data)
{
	about_author_menu($author_data);

	archive_list($author_data['user_id']);
}

/**
* Generates the author data section
*/
function about_author_menu($author_data)
{
	global $phpbb_root_path, $phpEx, $config, $user, $db, $template, $auth;

		// Rank
		$rank_title = $rank_img = $rank_img_src = '';
		get_user_rank($author_data['user_rank'], $author_data['user_posts'], $rank_title, $rank_img, $rank_img_src);

		// Avatar
		if ($author_data['user_avatar'] && $user->optionget('viewavatars'))
		{
			$avatar_img = '';

			switch ($author_data['user_avatar_type'])
			{
				case AVATAR_UPLOAD:
					$avatar_img = $config['avatar_path'] . '/';
				break;

				case AVATAR_GALLERY:
					$avatar_img = $config['avatar_gallery_path'] . '/';
				break;
			}

			$avatar_img .= $author_data['user_avatar'];
			$avatar = '<img src="' . $avatar_img . '" width="' . $author_data['user_avatar_width'] . '" height="' . $author_data['user_avatar_height'] . '" alt="" />';
		}
		else
		{
			$avatar = '';
		}

		// Online or offline? Basically copied from viewtopic.php
		$sql = 'SELECT session_user_id, MAX(session_time) AS online_time, MIN(session_viewonline) AS viewonline
			FROM ' . SESSIONS_TABLE . '
			WHERE session_user_id = \'' . $author_data['user_id'] . '\'
			GROUP BY session_user_id';
		$result = $db->sql_query($sql);
		$update_time = $config['load_online_time'] * 60;
		$status_data = $db->sql_fetchrow($result);
		$status = (time() - $update_time < $status_data['online_time'] && (($status_data['viewonline'] && $author_data['user_allow_viewonline']) || $auth->acl_get('u_viewonline'))) ? true : false;

	$db->sql_freeresult($result);

		// IM Links
		$msn_url = append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=msnm&amp;u=" . $author_data['user_id']);
		$yim_url = 'http://edit.yahoo.com/config/send_webmesg?.target=' . $author_data['user_yim'] . '&amp;.src=pg';
		$aim_url = append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=aim&amp;u=" . $author_data['user_id']);
		$icq_url = 'http://www.icq.com/people/webmsg.php?to=' . $author_data['user_icq'];
		$jabber_url = append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=jabber&amp;u=" . $author_data['user_id']);

		// output the data
		$template->assign_vars(array(
			'AUTHOR_COLOUR'		=> $author_data['user_colour'],
			'AUTHOR'			=> $author_data['username'],
			'U_VIEW_PROFILE'	=> $author_data['view_profile'],
			'RANK_TITLE'		=> $rank_title,
			'RANK_IMG'			=> $rank_img,
			'RANK_IMG_SRC'		=> $rank_img_src,
			'AVATAR'			=> $avatar,
			'STATUS'			=> (($status) ? $user->img('icon_user_online', 'ONLINE') : $user->img('icon_user_offline', 'OFFLINE')),

			'PROFILE'			=> '<a href="' . $author_data['view_profile'] . '">' . $user->img('icon_user_profile', 'READ_PROFILE') . '</a>',
			'PM'				=> ($author_data['user_id'] != ANONYMOUS && $config['allow_privmsg'] && $auth->acl_get('u_sendpm') && ($author_data['user_allow_viewemail'] || $auth->acl_gets('a_', 'm_') || $auth->acl_getf_global('m_'))) ? '<a href="' . append_sid("{$phpbb_root_path}ucp.$phpEx", 'i=pm&amp;mode=compose&amp;u=' . $author_data['user_id']) . '">' . $user->img('icon_contact_pm', 'SEND_PRIVATE_MESSAGE') . '</a>' : '',
			'EMAIL'				=> ($config['board_email_form'] && $config['email_enable']) ? '<a href="' . append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=email&amp;u=" . $author_data['user_id'])  . '">' . $user->img('icon_contact_email', 'SEND_EMAIL') . '</a>' : (($config['board_hide_emails'] && !$auth->acl_get('a_email')) ? '' : '<a href="' . 'mailto:' . $author_data['user_email']  . '">' . $user->img('icon_contact_email', 'SEND_EMAIL') . '</a>'),
			'WWW'				=> ($author_data['user_website']) ? '<a href="' . $author_data['user_website'] . '">' . $user->img('icon_contact_www', 'VISIT_WEBSITE') . '</a>' : '',
			'MSN'				=> ($author_data['user_msnm']) ? '<a href="' . $msn_url . '" onclick="popup(\'' . $msn_url . '\', 550, 320); return false">' . $user->img('icon_contact_msnm', 'MSNM') . '</a>' : '',
			'YIM'				=> ($author_data['user_yim']) ? '<a href="' . $yim_url . '" onclick="popup(\'' . $yim_url . '\', 780, 550); return false">' . $user->img('icon_contact_yahoo', 'YIM') . '</a>' : '',
			'AIM'				=> ($author_data['user_aim']) ? '<a href="' . $aim_url . '" onclick="popup(\'' . $aim_url . '\', 550, 320); return false">' . $user->img('icon_contact_aim', 'AIM') . '</a>' : '',
			'ICQ'				=> ($author_data['user_icq']) ? '<a href="' . $icq_url . '" onclick="popup(\'' . $icq_url . '\', 550, 320); return false">' . $user->img('icon_contact_icq', 'ICQ') . '</a>' : '',
			'JABBER'			=> ($author_data['user_jabber']) ? '<a href="' . $jabber_url . '" onclick="popup(\'' . $jabber_url . '\', 550, 320); return false">' . $user->img('icon_contact_jabber', 'JABBER') . '</a>': '',

			// The URL to view the deleted blogs
			'U_DELETED_LINK'	=> ($auth->acl_get('m_blogdelete')) ? '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=deleted&amp;u=" . $author_data['user_id']) . '">' . $user->lang['VIEW_DELETED_BLOGS'] . '</a>' : '',
		));
}

/**
* Generates the archive list
*/
function archive_list($user_id)
{
// possibly change for the most recent month?
// Show last 3 months open and the last 5 blogs in each month(after 5 show the More... link).
// After 3 months, any months within the 6 months since today are displayed, but closed

// After 6 months show the years with an open button and have it start up the way the above is for displaying.

// Use javascript to open/close each section

	global $db, $template, $phpbb_root_path, $phpEx, $user;

	// Last Month's ID(set to 0 now, will be updated in the loop)
	$last_mon = 0;

	// Count Variable
	$i = 0;

	// SQL query
	$sql = 'SELECT blog_id, blog_time, blog_subject FROM ' . BLOGS_TABLE . '
				WHERE user_id = \'' . $user_id . '\'
					AND blog_deleted = \'0\'
						ORDER BY blog_id DESC';

	$result = $db->sql_query($sql);

	while($row = $db->sql_fetchrow($result))
	{
		// Using php's getdate function.  Must add the usertimezone minus the server timezone times 3600 to get seconds too the blog time to get the correct time according to the user's timezone
		$date = getdate($row['blog_time'] + ((($user->data['user_timezone'] * 100) - date("O"))* 3600));

		// If we are starting a new month
		if ($date['mon'] != $last_mon)
		{
			// Output the month and year
			$template->assign_block_vars('archiverow', array(
				'MONTH'			=> $date['month'],
				'YEAR'			=> $date['year'],

				'S_FIRST'		=> ($i == 0) ? true : false,
			));
		}

		// Now output the title, view blog link, and date
		$template->assign_block_vars('archiverow.monthrow', array(
			'TITLE'			=> $row['blog_subject'],
			'U_VIEW'		=> append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=blog&amp;b=" . $row['blog_id']),
			'DATE'			=> $user->format_date($row['blog_time']),
		));

		// set the last month variable as the current month
		$last_mon = $date['mon'];

		// Increment the counter
		$i++;
	}

	// output some data
	$template->assign_vars(array(
		// are there any archives?
		'S_ARCHIVES'	=> ($i > 0) ? true : false,
	));

	$db->sql_freeresult($result);
}

/*
* This should never need to be used unless someone manually deletes blogs from the database
*/
function resync_blog($mode = 'all')
{
	global $db;

	$blog_data = array();
	$reply_data = array();

	// Start by selecting all blog data that we will use
	$sql = 'SELECT blog_id, blog_reply_count FROM ' . BLOGS_TABLE . ' ORDER BY blog_id ASC';
	$result = $db->sql_query($sql);
	while($row = $db->sql_fetchrow($result))
	{
		$blog_data[$row['blog_id']] = $row;
	}

	// Now get all reply data we will use
	$sql = 'SELECT reply_id, blog_id FROM ' . BLOGS_REPLY_TABLE . ' ORDER BY reply_id ASC';
	$result = $db->sql_query($sql);
	while($row = $db->sql_fetchrow($result))
	{
		$reply_data[$row['reply_id']] = $row;
	}

	if ( ($mode == 'reply_count') || ($mode == 'all') )
	{
		/*
		* Update & Resync the reply counts
		*/

		foreach($blog_data as $row)
		{
			// count all the replies (an SQL query seems the easiest way to do it)
			$sql2 = 'SELECT count(reply_id) AS total 
				FROM ' . BLOGS_REPLY_TABLE . ' 
					WHERE blog_id = \'' . $row['blog_id'] . '\' 
						AND reply_deleted = \'0\' 
						AND reply_approved = \'1\'';
			$result2 = $db->sql_query($sql2);
			$total = $db->sql_fetchrow($result2);

			if ($total['total'] != $row['blog_reply_count'])
			{
				// Update the reply count
				$sql = 'UPDATE ' . BLOGS_TABLE . ' SET blog_reply_count = \'' . $total['total'] . '\' WHERE blog_id = \'' . $row['blog_id'] . '\'';
				$db->sql_query($sql);
			}
		}
	}

	if ( ($mode == 'delete_orphan_replies') || ($mode == 'all') )
	{
		/*
		* Delete's all oprhaned replies (replies where the blogs they should go under have been deleted).
		*/

		foreach($reply_data as $row)
		{
			if (!(array_key_exists($row['blog_id'], $blog_data)))
			{
				$sql = 'DELETE FROM ' . BLOGS_REPLY_TABLE . ' WHERE reply_id = \'' . $row['reply_id'] . '\'';
				$db->sql_query($sql);
			}
		}
	}
}

/**
* Check permissions
* return is for whether we should just return true or false, or if we want to enforce the permissions from this function
*/

// TODO: comment the code

function check_permissions($page, $mode, $owner = false, $return = false)
{
	global $auth, $user;

	switch ($page)
	{
		case 'view' :
			switch ($mode)
			{
				case '' :
				case 'user' :
					if ($auth->acl_get('u_blogview'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NOT_AUTHORIZED');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'deleted' :
					if ($auth->acl_get('m_blogdelete'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NOT_AUTHORIZED');
							}
							else
							{
								return false;
							}
						}
					}
				break;
			}
		break;
		case 'blog' :
			switch ($mode)
			{
				case 'add' :
					if ($auth->acl_get('u_blogpost'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box('', $user->lang['LOGIN_EXPLAIN_NEW_BLOG']);
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NOT_AUTHORIZED');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'edit' :
					if ( ( ($auth->acl_get('u_blogedit')) && ($owner) ) || ($auth->acl_get('m_blogedit')) )
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box('', $user->lang['LOGIN_EXPLAIN_EDIT_BLOG']);
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NOT_AUTHORIZED');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'delete' :
					if ( ( ($auth->acl_get('u_blogdelete')) && ($owner) ) || ($auth->acl_get('m_blogdelete')) )
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NOT_AUTHORIZED');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'undelete' :
					if ($auth->acl_get('m_blogdelete'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NOT_AUTHORIZED');
							}
							else
							{
								return false;
							}
						}
					}
				break;
			}
		break;
		case 'reply' :
			switch ($mode)
			{
				case 'add' :
					if ($auth->acl_get('u_blogreply'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NOT_AUTHORIZED');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'edit' :
					if ( ( ($auth->acl_get('u_blogreplyedit')) && ($owner) ) || ($auth->acl_get('m_blogreplyedit')) )
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NOT_AUTHORIZED');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'delete' :
					if ( ( ($auth->acl_get('u_blogreplydelete')) && ($owner) ) || ($auth->acl_get('m_blogreplydelete')) )
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NOT_AUTHORIZED');
							}
							else
							{
								return false;
							}
						}
					}
				break;
				case 'undelete' :
					if ($auth->acl_get('m_blogreplydelete'))
					{
						if ($return)
						{
							return true;
						}
					}
					else
					{
						if (!$user->data['is_registered'])
						{
							if (!$return)
							{
								login_box();
							}
						}
						else
						{
							if (!$return)
							{
								trigger_error('NOT_AUTHORIZED');
							}
							else
							{
								return false;
							}
						}
					}
				break;
			}
		break;
	}
}
?>