<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

/*
*  Check blog permissions
*
* @IN
* $page is the page requested - blog, reply, mcp, install, upgrade, update, dev, resync
* $mode is the mode requested - depends on the $page requested
* $return is if you would like this function to return true or false (if they have permission or not).  If it is false we give them a login box if they are not logged in, or give them the NO_AUTH error message
* $blog_id is the blog_id requested (needed for some things, like blog edit, delete, etc
* $reply_id is the reply_id requested, used for the same reason as $blog_id
*
* @OUT
* IF $return is true -  returns:
*	true if the user is authorized to do the requested action
*	false if the user is not authorized to do the requested action
*
* Warning: Code below may be confusing (which is why I made the comments above so extensive)! :D
*/
function check_blog_permissions($page, $mode, $return = false, $blog_id = 0, $reply_id = 0)
{
	global $user, $auth, $blog_data;

	// lets automatically give founders ALL permissions
	if ($user->data['user_type'] == USER_FOUNDER)
	{
		return true;
	}

	$is_auth = false;
	$founder = false;

	switch ($page)
	{
		case 'blog' :
			switch ($mode)
			{
				case 'add' :
					$is_auth = ($auth->acl_get('u_blogpost')) ? true : false;
					break;
				case 'edit' :
					$is_auth = ($user->data['user_id'] != ANONYMOUS && ($auth->acl_get('u_blogedit') && ($user->data['user_id'] == $blog_data->blog[$blog_id]['user_id']) ) || $auth->acl_get('m_blogedit')) ? true : false;
					break;
				case 'delete' :
					if ($blog_data->blog[$blog_id]['blog_deleted'] == 0 || $auth->acl_get('a_blogdelete'))
					{
						$is_auth = ($user->data['user_id'] != ANONYMOUS && ($auth->acl_get('u_blogdelete') && $user->data['user_id'] == $blog_data->blog[$blog_id]['user_id']) || $auth->acl_get('m_blogdelete') || $auth->acl_get('a_blogdelete')) ? true : false;
					}
					break;
				case 'undelete' :
					$is_auth = ($auth->acl_get('m_blogdelete') || $auth->acl_get('a_blogdelete')) ? true : false;
					break;
				case 'report' :
					$is_auth = ($auth->acl_get('u_blogreport')) ? true : false;
					break;
				case 'approve' :
					$is_auth = ($auth->acl_get('m_blogapprove')) ? true : false;
					break;
				case 'rate' :
				default :
					$is_auth = ($auth->acl_get('u_blogview')) ? true : false;
			}
			break;
		case 'reply' :
			switch ($mode)
			{
				case 'add' :
				case 'quote' :
						$is_auth = ($auth->acl_get('u_blogreply')) ? true : false;
					break;
				case 'edit' :
					$is_auth = (($user->data['user_id'] != ANONYMOUS) && ( ( ($auth->acl_get('u_blogreplyedit')) && ($user->data['user_id'] == $blog_data->reply[$reply_id]['user_id']) ) || ($auth->acl_get('m_blogreplyedit')) )) ? true : false;
					break;
				case 'delete' :
					if ($blog_data->reply[$reply_id]['reply_deleted'] == 0 || $auth->acl_get('a_blogreplydelete'))
					{
						$is_auth = ($user->data['user_id'] != ANONYMOUS && ($auth->acl_gets('a_blogreplydelete', 'm_blogreplydelete') || ($auth->acl_get('u_blogreplydelete') && $user->data['user_id'] == $blog_data->reply[$reply_id]['user_id']) ) ) ? true : false;
					}
					break;
				case 'undelete' :
					$is_auth = ($auth->acl_get('m_blogreplydelete') || $auth->acl_get('a_blogreplydelete')) ? true : false;
					break;
				case 'report' :
					$is_auth = ($auth->acl_get('u_blogreport')) ? true : false;
					break;
				case 'approve' :
					$is_auth = ($auth->acl_get('m_blogreplyapprove')) ? true : false;
					break;
				default :
					$is_auth = ($auth->acl_get('u_blogview')) ? true : false;
			}
			break;
		case 'mcp' :
			$is_auth = ($auth->acl_gets('m_blogapprove', 'acl_m_blogreport')) ? true : false;
			break;
		case 'install' :
		case 'update' :
		case 'upgrade' :
		case 'dev' :
		case 'resync' :
			$is_auth = ($user->data['user_type'] == USER_FOUNDER) ? true : false;
			$founder = true;
			break;
		default :
			$is_auth = ($auth->acl_get('u_blogview')) ? true : false;
	}

	if (!$return)
	{
		if (!$is_auth)
		{
			if (!$user->data['is_registered'])
			{
				login_box();
			}
			else
			{
				if ($founder)
				{
					trigger_error('MUST_BE_FOUNDER');
				}
				else
				{
					trigger_error('NO_AUTH_OPERATION');
				}
			}
		}
	}
	else
	{
		return $is_auth;
	}
}
?>