<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* TODO List
*
* PRIORITY -----------
* functions to output data to mini boxes for recent, popular, etc on blogs
* Main blog page
*
*
* NEEDS TO BE STARTED
*
* Add RSS Output Feed
* Report Blogs/Replies
* Approve Blogs/Replies
* Warn for blogs/replies
* ACP config options
* MCP - Info, etc
* SEO Url's
* temporary cache system (time definable in ACP) to cache user, blog, and reply data.  Auto-update the cache if editing blog or reply.
* optimize selecting of user data by doing a mass select at the begining (don't know how I will exactly do this yet)
* follow ignore post rules (by foe)
*
*
* NEEDS TO BE FINISHED
*
* Comments(comment more of the code)
*
*
* OTHER
*/

/*
* BUG List
*
* Permissions for viewing dropdown box profile & etc
*
*/

// Stuff required to work with phpBB3, and include some function pages that we will use later on...
define('IN_PHPBB', true);
$phpbb_root_path = './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/bbcode.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);
include($phpbb_root_path . 'includes/functions_posting.' . $phpEx);
include($phpbb_root_path . 'includes/message_parser.' . $phpEx);

// Quick config settings, later these must go in the ACP ------------------------------------------------------------------------------------
$config['blog_custom_profile_enable'] = true;
$config['blog_text_limit'] = 100;

if (!function_exists('add_blog_links'))
{
	include($phpbb_root_path . 'includes/blog/functions.' . $phpEx);
	include($phpbb_root_path . 'includes/blog/classes.' . $phpEx);
}

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('blog');

// get some initial data
$page = request_var('page', '');
$mode = request_var('mode', '');
$user_id = intval(request_var('u', 0));
$blog_id = intval(request_var('b', 0));
$reply_id = intval(request_var('r', 0));

$print = (request_var('view', '') == 'print') ? true : false;
$submit = (isset($_POST['post'])) ? true : false;
$preview = (isset($_POST['preview'])) ? true : false;
$cancel = (isset($_POST['cancel'])) ? true : false;

// set some initial variables that we will (almost) always use
$blog_data = array();
$user_data = array();
$breadcrumbs = array();

// setup our data class
$blog_data = new blog_data;

switch ($page)
{
	case 'view' :
		include($phpbb_root_path . 'includes/blog/view.' . $phpEx);
		break;
	case 'blog' :
		include($phpbb_root_path . 'includes/blog/blog.' . $phpEx);
		break;
	case 'reply' :
		include($phpbb_root_path . 'includes/blog/reply.' . $phpEx);
		break;
	default :
		include($phpbb_root_path . 'includes/blog/main.' . $phpEx);
		break;
}

// setup the page footer
page_footer();
?>