<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// check to make sure they requested a legit page
if ( ($mode != 'add') && ($mode != 'edit') && ($mode != 'delete') && ($mode != 'undelete') )
{
	trigger_error('NO_MODE');
}

// Was Cancel pressed? If so then redirect to the appropriate page
if ($cancel)
{
	$redirect = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $blog_id);
	redirect($redirect);
}

// Add the language Variables for posting
$user->add_lang('posting');

// shorten some variables for later use
$add = ($mode == 'add') ? true : false; // add mode
$edit = ($mode == 'edit') ? true : false; // edit mode
$delete = ($mode == 'delete') ? true : false; // delete the blog
$undelete = ($mode == 'undelete') ? true : false; // undelete the blog

// set up the error variable
$error = array();

// some extra things that are needed to be done in edit, delete, and undelete mode...
if ($edit || $delete || $undelete)
{
	// If they did not include the $blog_id give them an error...
	if ($blog_id == 0)
	{
		trigger_error('NO_BLOG');
	}

	// Get the blogs, and check if there is no blog...
	if (!$blog_data->get_blogs($blog_id, false, false, 0, 0, true))
	{
		trigger_error('NO_BLOG');
	}

	// Set the $user_id variable for consistency later
	$user_id = $blog_data->blog[$blog_id]['user_id'];

	// Get the author data, $username is used for consistency
	$blog_data->get_user_data($user_id);
	$username = $blog_data->user[$user_id]['username'];

	// check to see if editing this message is locked, or if the one editing it has mod powers
	if ( ($edit || $delete) && $blog_data->blog[$blog_id]['blog_edit_locked'] && (!$auth->acl_get('m_blogedit')) )
	{
		trigger_error('BLOG_EDIT_LOCKED');
	}

	// Make sure they have the permission to get to this page.
	check_permissions($page, $mode, ($user->data['user_id'] == $user_id));
}

// setup some more misc stuff
if ($add)
{
	// Make sure they have the permission to get to this page.
	check_permissions($page, $mode);

	// Set the $user_id and $username variable for consistency later
	$user_id = $user->data['user_id'];
	$username = $user->data['username'];

	$lang_var = 'ADD_BLOG';
	$self_url_vars = 'page=blog&amp;mode=add';
}	
else if ($edit)
{
	$lang_var = 'EDIT_BLOG';
	$self_url_vars = 'page=blog&amp;mode=edit&amp;b=' . $blog_id;
}
else if ($delete)
{	
	$lang_var = 'DELETE_BLOG';
	$self_url_vars = 'page=blog&amp;mode=delete&amp;b=' . $blog_id;
}
else if ($undelete)
{	
	$lang_var = 'UNDELETE_BLOG';
	$self_url_vars = 'page=blog&amp;mode=undelete&amp;b=' . $blog_id;
}

// to shorten code up later
$self_url = append_sid("{$phpbb_root_path}blog.$phpEx", $self_url_vars);
$view_user_url = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=user&amp;u=' . $user_id);
if (!$add) // with add mode the blog ID isn't set yet...it will be after we submit to the DB, but we will set that later.
{
	$view_blog_url = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $blog_id);
}

// Setup the page header and sent the title of the page that will go into the browser header
page_header($user->lang[$lang_var]);

// Generate the breadcrumbs
$breadcrumbs = array(
	sprintf($user->lang['USERNAMES_BLOGS'], $username) => $view_user_url,
	$user->lang[$lang_var] => $self_url,
	);
generate_blog_breadcrumbs($breadcrumbs);


// here is the main part for add and edit modes...
if ($add || $edit)
{
	if ($edit)
	{
		// if they are previewing, or trying to submit let us setup some variables we will check later...
		if ($preview || $submit)
		{
			$original_subject = $blog_data->blog[$blog_id]['blog_subject'];
			$original_text = $blog_data->blog[$blog_id]['blog_text'];
			decode_message($original_text, $blog_data->blog[$blog_id]['bbcode_uid']);
		}

		// can they delete the blog?  Setting this for later.
		$can_delete = check_permissions('blog', 'delete', ($user->data['user_id'] == $user_id) ? true : false, true);
	}
	else
	{
		// this variable is only used in edit mode, but we are setting it here to avoid errors later.
		$can_delete = false;
	}

	// Posting permissions
	$post_options = new post_options;

	// If they select edit mode and didn't submit or hit preview(means they came directly from the view blog page)
	if ( ($edit) && (!$submit) && (!$preview) )
	{
		// Setup the message so we can import it to the edit page
		decode_message($blog_data->blog[$blog_id]['blog_text'], $blog_data->blog[$blog_id]['bbcode_uid']);
		$post_options->set_status($blog_data->blog[$blog_id]['enable_bbcode'], $blog_data->blog[$blog_id]['enable_smilies'], $blog_data->blog[$blog_id]['enable_magic_url']);
	}
	else
	{
		// see if they tried submitting a message or suject(if they hit preview or submit) put it in an array for consistency with the edit mode
		$blog_data->blog[$blog_id]['blog_subject'] = request_var('subject', '', true);
		$blog_data->blog[$blog_id]['blog_text'] = request_var('message', '', true);

		$post_options->set_status(!isset($_POST['disable_bbcode']), !isset($_POST['disable_smilies']), !isset($_POST['disable_magic_url']));
	}

	// Set the options up in the template
	$post_options->set_in_template();

	// If they are trying to preview or submit the message
	if ( ($submit) || ($preview) )
	{
		// set up the message parser to parse BBCode, Smilies, etc
		$message_parser = new parse_message();
		$message_parser->message = $blog_data->blog[$blog_id]['blog_text'];
		$message_parser->parse($post_options->enable_bbcode, $post_options->enable_magic_url, $post_options->enable_smilies, $post_options->img_status, $post_options->flash_status, $post_options->bbcode_status, $post_options->url_status);

		// If they did not include a subject, give them the empty subject error
		if ($blog_data->blog[$blog_id]['blog_subject'] == '')
		{
			$error[] = $user->lang['EMPTY_SUBJECT'];
		}

		// If any errors were reported by the message parser add those as well
		if (sizeof($message_parser->warn_msg))
		{
			$error[] = implode('<br />', $message_parser->warn_msg);
		}
	}

	// if they did not submit or they have an error
	if ( (!$submit) || (sizeof($error)) )
	{
		// if they are trying to preview the message and do not have an error
		if ( ($preview) && (!sizeof($error)) )
		{
			// output some data to the template parser
			$template->assign_vars(array(
				'S_DISPLAY_PREVIEW'			=> true,
				'PREVIEW_SUBJECT'			=> censor_text($blog_data->blog[$blog_id]['blog_subject']),
				'PREVIEW_MESSAGE'			=> $message_parser->format_display($post_options->enable_bbcode, $post_options->enable_magic_url, $post_options->enable_smilies, false),
				'POST_DATE'					=> ($edit) ? $user->format_date($blog_data->blog[$blog_id]['blog_time']) : $user->format_date(time()),
			));
		}

		// Generate smiley listing
		generate_smilies('inline', false);

		// Assign some variables to the template parser
		$template->assign_vars(array(
			// If we have any limit on the number of chars a user can enter display that, otherwise don't
			'L_MESSAGE_BODY_EXPLAIN'	=> (intval($config['max_post_chars'])) ? sprintf($user->lang['MESSAGE_BODY_EXPLAIN'], intval($config['max_post_chars'])) : '',

			// If they hit preview or submit and got an error, or are editing their post make sure we carry their existing post info & options over
			'SUBJECT'					=> $blog_data->blog[$blog_id]['blog_subject'],
			'MESSAGE'					=> $blog_data->blog[$blog_id]['blog_text'],

			// if there are any errors report them
			'ERROR'						=> (sizeof($error)) ? implode('<br />', $error) : '',

			// for editing
			'S_EDIT_REASON'				=> $edit,

			// Delete check box
			'S_DELETE_ALLOWED'			=> ($edit && $can_delete) ? true : false,
			'L_DELETE_POST'				=> $user->lang['DELETE_BLOG'],
			'L_DELETE_POST_WARN'		=> $user->lang['DELETE_BLOG_WARN'],

			// The post action...
			'S_POST_ACTION'				=> $self_url,
		));

		// Tell the template parser what template file to use
		$template->set_filenames(array(
			'body' => 'posting_body.html'
		));
	}
	else // user submitted and there are no errors
	{
		if ($edit)
		{
			// this should not be set, but lets unset it just in case
			unset($sql_data);

			// lets check if they actually edited the text.  If they did not, don't do any SQL queries to update it.
			if ( ($original_subject != $blog_data->blog[$blog_id]['blog_subject']) || (request_var('edit_reason', '', true) != '') || ($original_text != $blog_data->blog[$blog_id]['blog_text']) )
			{
				$sql_data = array(
					'blog_subject'		=> $blog_data->blog[$blog_id]['blog_subject'],
					'blog_text'			=> $message_parser->message,
					'blog_checksum'		=> md5($message_parser->message),
					'blog_approved' 	=> $auth->acl_get('u_blognoapprove'),
					'enable_bbcode' 	=> $post_options->enable_bbcode,
					'enable_smilies'	=> $post_options->enable_smilies,
					'enable_magic_url'	=> $post_options->enable_magic_url,
					'bbcode_bitfield'	=> $message_parser->bbcode_bitfield,
					'bbcode_uid'		=> $message_parser->bbcode_uid,
					'blog_edit_time'	=> time(),
					'blog_edit_reason'	=> request_var('edit_reason', '', true),
					'blog_edit_user'	=> $user->data['user_id'],
					'blog_edit_count'	=> $blog_data->blog[$blog_id]['blog_edit_count'] + 1,
				);

				// Only update the IP address if the user editing is the owner
				if ($user->data['user_id'] == $user_id)
				{
					$sql_data['user_ip'] = $user->data['user_ip'];
				}
			}

			// add the delete section to the array if it was deleted, if it was already deleted ignore
			if ( (!$blog_data->blog[$blog_id]['blog_deleted']) && (isset($_POST['delete'])) && $can_delete)
			{
				$sql_data['blog_deleted'] = $user->data['user_id'];
				$sql_data['blog_deleted_time'] = time();
			}

			if (isset($sql_data))
			{
				// the update query
				$sql = 'UPDATE ' . BLOGS_TABLE . '
					SET ' . $db->sql_build_array('UPDATE', $sql_data) . '
					WHERE blog_id = \'' . $blog_id . '\'';

				// run the query
				$db->sql_query($sql);
			}
		}
		else
		{
			// insert array, not all of these really need to be inserted, since some are what the fields are as default, but I want it this way. :P
			$sql_data = array(
				'user_id' 			=> $user->data['user_id'],
				'user_ip'			=> $user->data['user_ip'],
				'blog_time'			=> time(),
				'blog_subject'		=> $blog_data->blog[$blog_id]['blog_subject'],
				'blog_text'			=> $message_parser->message,
				'blog_checksum'		=> md5($message_parser->message),
				'blog_approved' 	=> $auth->acl_get('u_blognoapprove'),
				'blog_reported'		=> 0,
				'enable_bbcode' 	=> $post_options->enable_bbcode,
				'enable_smilies'	=> $post_options->enable_smilies,
				'enable_magic_url'	=> $post_options->enable_magic_url,
				'bbcode_bitfield'	=> $message_parser->bbcode_bitfield,
				'bbcode_uid'		=> $message_parser->bbcode_uid,
				'blog_edit_time'	=> 0,
				'blog_edit_reason'	=> '',
				'blog_edit_user'	=> 0,
				'blog_edit_count'	=> 0,
				'blog_edit_locked'	=> 0,
				'blog_deleted'		=> 0,
				'blog_deleted_time'	=> 0,
				'blog_read_count'	=> 1,
				'blog_reply_count'	=> 0,
			);

			// insert query
			$sql = 'INSERT INTO ' . BLOGS_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);

			// run the query
			$db->sql_query($sql);
		}

		// we no longer need the message parser
		unset($message_parser);

		if ($add) // now that the blog_id is set for add mode...
		{
			$blog_id = $db->sql_nextid();
			$view_blog_url = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $blog_id);
		}

		// the confirm message & redirect
		if ( (isset($_POST['delete'])) && $can_delete )
		{
			$message = $user->lang['BLOG_DELETED'] . '<br/><br/><a href="' . $view_user_url . '">';

			// if the user editing is not the user that wrote it in the first place, show them a return blog main link with the owner's name in it
			if ($user->data['user_id'] == $user_id)
			{
				$message .= sprintf($user->lang['RETURN_BLOG_MAIN_OWN'], '<a href="' . $view_user_url . '">', '</a>');
			}
			else
			{
				$message .= sprintf($user->lang['RETURN_BLOG_MAIN'], '<a href="' . $view_user_url . '">', $username, '</a>');
			}

			// redirect
			meta_refresh(3, $view_user_url);
		}
		else
		{
			$message = (!$auth->acl_get('u_blognoapprove')) ? $user->lang['BLOG_NEED_APPROVE'] . '<br /><br />' : ''; 
			$message .= '<a href="' . $view_blog_url . '">' . $user->lang['VIEW_BLOG'] . '</a><br/><br/>';

			// if the user editing is not the user that wrote it in the first place, show them a return blog main link with the owner's name in it
			if ($user->data['user_id'] == $user_id)
			{
				$message .= sprintf($user->lang['RETURN_BLOG_MAIN_OWN'], '<a href="' . $view_user_url . '">', '</a>');
			}
			else
			{
				$message .= sprintf($user->lang['RETURN_BLOG_MAIN'], '<a href="' . $view_user_url . '">', $username, '</a>');
			}

			// redirect
			meta_refresh(3, $view_blog_url);
		}

		trigger_error($message);
	}
}
else if ($delete || $undelete)
{
	if ( ($blog_data->blog[$blog_id]['blog_deleted'] != 0) && (!$undelete) && (!$auth->acl_get('a_blogdelete')) ) // or if the blog has already been deleted and someone is trying to delete it
	{
		trigger_error('BLOG_ALREADY_DELETED');
	}
	else if ( ($blog_data->blog[$blog_id]['blog_deleted'] == 0) && $undelete ) // or if someone is trying to un-delete a blog and the blog is not deleted
	{
		trigger_error('BLOG_NOT_DELETED');
	}

	if (confirm_box(true))
	{
		if ( ($blog_data->blog[$blog_id]['blog_deleted'] != 0) && (!$undelete) ) // if it has already been soft deleted and we are not trying to undelete
		{
			// delete the blog
			$sql = 'DELETE FROM ' . BLOGS_TABLE . ' WHERE blog_id = \'' . $blog_id . '\'';
			$db->sql_query($sql);

			// delete the replies
			$sql = 'DELETE FROM ' . BLOGS_REPLY_TABLE . ' WHERE blog_id = \'' . $blog_id . '\'';
			$db->sql_query($sql);
		}
		elseif (!$undelete)
		{
			// *delete* the blog
			$sql = 'UPDATE ' . BLOGS_TABLE . ' SET blog_deleted = \'' . $user->data['user_id'] . ' \', blog_deleted_time = \'' . time() . '\' WHERE blog_id = \'' . $blog_id . '\'';
			$db->sql_query($sql);
		}
		else
		{
			// magically un-delete the blog ;-)
			$sql = 'UPDATE ' . BLOGS_TABLE . ' SET blog_deleted = \'0\', blog_deleted_time = \'0\' WHERE blog_id = \'' . $blog_id . '\'';
			$db->sql_query($sql);
		}

		meta_refresh(3, ($undelete) ? $view_blog_url : $view_user_url);

		$message = (!$undelete) ? $user->lang['BLOG_DELETED'] : $user->lang['BLOG_UNDELETED'];
		if ($undelete)
		{
			$message .= '<br/><br/><a href="' . $view_blog_url. '">' . $user->lang['VIEW_BLOG'] . '</a>';
		}

		if ($user->data['user_id'] == $user_id)
		{
			$message .= '<br/><br/>' . sprintf($user->lang['RETURN_BLOG_MAIN_OWN'], '<a href="' . $view_user_url . '">', '</a>');
		}
		else
		{
			$message .= '<br/><br/>' . sprintf($user->lang['RETURN_BLOG_MAIN'], '<a href="' . $view_user_url . '">', $username, '</a>');
		}

		trigger_error($message);
	}
	else
	{
		if ( ($blog_data->blog[$blog_id]['blog_deleted'] != 0) && (!$undelete) ) // if it has already been soft deleted and we are not trying to undelete
		{
			confirm_box(false, 'PERMANENTLY_DELETE_BLOG');
		}
		elseif (!$undelete)
		{
			confirm_box(false, 'DELETE_BLOG');
		}
		else
		{
			confirm_box(false, 'UNDELETE_BLOG');
		}
	}

	// they pressed No, so redirect them
	redirect($view_user_url);
}
?>