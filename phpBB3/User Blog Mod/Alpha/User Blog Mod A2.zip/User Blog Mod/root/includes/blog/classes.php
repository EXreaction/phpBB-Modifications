<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

/*
* Check permission and settings for bbcode, img, url, etc
*/
class post_options
{
	// the permissions, so I can change them later easier if need be for a different mod or whatever...
	var $auth_bbcode = false;
	var $auth_smilies = false;
	var $auth_img = false;
	var $auth_url = false;
	var $auth_flash = false;

	// whether these are allowed or not
	var $bbcode_status = false;
	var $smilies_status = false;
	var $img_status = false;
	var $url_status = false;
	var $flash_status = false;

	// whether or not they are enabled in the post
	var $enable_bbcode = false;
	var $enable_smilies = false;
	var $enable_magic_url = false;

	// automatically sets the defaults for the $auth_ vars
	function post_options()
	{
		global $auth;

		$this->auth_bbcode = $auth->acl_get('u_blogbbcode');
		$this->auth_smilies = $auth->acl_get('u_blogsmilies');
		$this->auth_img = $auth->acl_get('u_blogimg');
		$this->auth_url = $auth->acl_get('u_blogurl');
		$this->auth_flash = $auth->acl_get('u_blogflash');
	}

	// set the status to the  variables above, the enabled options are if they are enabled in the posts(by who ever is posting it)
	function set_status($bbcode, $smilies, $url)
	{
		global $config, $auth;

		$this->bbcode_status = ($config['allow_bbcode'] && $this->auth_bbcode) ? true : false;
		$this->smilies_status = ($config['allow_smilies'] && $this->auth_smilies) ? true : false;
		$this->img_status = ($this->auth_img && $this->bbcode_status) ? true : false;
		$this->url_status = ($config['allow_post_links'] && $this->auth_url && $this->bbcode_status) ? true : false;
		$this->flash_status = ($this->auth_flash && $this->bbcode_status) ? true : false;

		$this->enable_bbcode = ($this->bbcode_status && $bbcode) ? true : false;
		$this->enable_smilies = ($this->smilies_status && $smilies) ? true : false;
		$this->enable_magic_url = ($this->url_status && $url) ? true : false;
	}

	function set_in_template()
	{
		global $template, $user, $phpbb_root_path, $phpEx;

		// Assign some variables to the template parser
		$template->assign_vars(array(
			// If they hit preview or submit and got an error, or are editing their post make sure we carry their existing post info & options over
			'S_BBCODE_CHECKED'			=> ($this->enable_bbcode) ? '' : ' checked="checked"',
			'S_SMILIES_CHECKED'			=> ($this->enable_smilies) ? '' : ' checked="checked"',
			'S_MAGIC_URL_CHECKED'		=> ($this->enable_magic_url) ? '' : ' checked="checked"',

			// To show the Options: section on the bottom left
			'BBCODE_STATUS'				=> ($this->bbcode_status) ? sprintf($user->lang['BBCODE_IS_ON'], '<a href="' . append_sid("{$phpbb_root_path}faq.$phpEx", 'mode=bbcode') . '">', '</a>') : sprintf($user->lang['BBCODE_IS_OFF'], '<a href="' . append_sid("{$phpbb_root_path}faq.$phpEx", 'mode=bbcode') . '">', '</a>'),
			'IMG_STATUS'				=> ($this->img_status) ? $user->lang['IMAGES_ARE_ON'] : $user->lang['IMAGES_ARE_OFF'],
			'FLASH_STATUS'				=> ($this->flash_status) ? $user->lang['FLASH_IS_ON'] : $user->lang['FLASH_IS_OFF'],
			'SMILIES_STATUS'			=> ($this->smilies_status) ? $user->lang['SMILIES_ARE_ON'] : $user->lang['SMILIES_ARE_OFF'],
			'URL_STATUS'				=> ($this->url_status) ? $user->lang['URL_IS_ON'] : $user->lang['URL_IS_OFF'],

			// To show the option to turn each off while posting
			'S_BBCODE_ALLOWED'			=> $this->bbcode_status,
			'S_SMILIES_ALLOWED'			=> $this->smilies_status,
			'S_LINKS_ALLOWED'			=> $this->url_status,

			// To show the BBCode buttons for each on top
			'S_BBCODE_IMG'				=> $this->img_status,
			'S_BBCODE_URL'				=> $this->url_status,
			'S_BBCODE_FLASH'			=> $this->flash_status,
		));
	}
}

/*
* Blog data class
*
* Holds all the data for all the blogs, replies, and users requested at any time for this session
* Caches the blogs, replies, and user's data for a set amount of time (configured through ACP) so we can cut down on a lot of queries
* Can output the data to directly to the template
*/
class blog_data
{
	// this is our large arrays holding all the blog, reply, and user data
	var $blog = array();
	var $reply = array();
	var $user = array();

	/*
	* TODO
	*
	* mass selection
	* cache
	*/

	/*
	* -------------------------- BLOG DATA SECTION -----------------------------
	*/

	/*
	* get blogs
	* if blog_id is true then we are just grabbing 1 blog if not we grab all from the user id
	* if deleted is true we only grab the deleted messages, otherwise do not show deleted messages
	* limit is to limit the number we grab if we select by user_id, if the var coming in is less than 1, then there is no limit
	* simple is for if we just want to quick grab the data and not parse any of it
	*/
	function get_blogs($blog_id, $user_id = false, $deleted = false, $limit = 5, $str_limit = 0, $simple = false)
	{
		/*
		* TODO
		* Move limit from the SELECT sql to count in the while loop
		* Check if user can view non-approved messages
		*/
		global $db, $user, $phpbb_root_path, $phpEx;
	
		$i = 0;
	
		// Get the data on the blog
		if ($user_id != false)
		{
			// update the deleted option to be a 1 or 0 instead of true/false
			$deleted_sql = ($deleted) ? 'AND blog_deleted != \'0\'' : 'AND blog_deleted = \'0\'';
	
			// if they want a limit, put it in, else dont have one
			$limit_sql = ($limit >= 1) ? 'LIMIT ' . $limit : '';
	
			$sql = 'SELECT * FROM ' . BLOGS_TABLE . '
						WHERE user_id = \'' . $user_id . '\' '
						. $deleted_sql . '
							ORDER BY blog_id DESC ' .
								$limit_sql;
		}
		else
		{
			$sql = 'SELECT * FROM ' . BLOGS_TABLE . '
						WHERE blog_id = \'' . $blog_id . '\'
							LIMIT 1';
		}
		$result = $db->sql_query($sql);

		if ($simple)
		{
			$this->blog[$blog_id] = $db->sql_fetchrow($result);
		}
		else
		{
			while ($row = $db->sql_fetchrow($result))
			{
				$i++;
		
				if ($str_limit > 0)
				{
					$bbcode_bitfield = $text_only_message = '';
		
					$text_only_message = $row['blog_text'];
					// make list items visible as such
					if ($row['bbcode_uid'])
					{
						$text_only_message = str_replace('[*:' . $row['bbcode_uid'] . ']', '&sdot;&nbsp;', $text_only_message);
						// no BBCode in text only message, can't use strp_bbcode because it replaces the bbcode with spaces. :/
						$text_only_message = preg_replace("#\[\/?[a-z0-9\*\+\-]+(?:=.*?)?(?::[a-z])?(\:?" . $row['bbcode_uid'] . ")\]#", '', $text_only_message);
						$match = get_preg_expression('bbcode_htm');
						$replace = array('\1', '\2', '\1', '', '');
						
						$text_only_message = preg_replace($match, $replace, $text_only_message);
					}
		
					if (utf8_strlen($text_only_message) > ($str_limit + 3))
					{
						$row['blog_text'] = substr($text_only_message, 0, ($str_limit - 3)) . '...';
		
						// Now lets do some magic and get the smilies (and URL's?) back.
						$message_parser = new parse_message();
						$message_parser->message = $row['blog_text'];
						$message_parser->parse($row['enable_bbcode'], $row['enable_magic_url'], $row['enable_smilies']);
						$row['blog_text'] = $message_parser->message;
						$row['bbcode_bitfield'] = $message_parser->bbcode_bitfield;
						$row['bbcode_uid'] = $message_parser->bbcode_uid;
						unset($message_parser);
		
						$row['blog_text'] .= '<br/><br/><!-- m --><a href="';
						$row['blog_text'] .= append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $row['blog_id']);
						$row['blog_text'] .= '">[ ' . $user->lang['CONTINUED'] . ' ]</a><!-- m -->';
		
						$this->blog[$i]['shortened'] = true;
					}
					else
					{
						$this->blog[$i]['shortened'] = false;
					}
		
					unset($text_only_message);
				}
				else
				{
					$this->blog[$i]['shortened'] = false;
				}
		
				$this->blog[$i]['blog_id'] = $row['blog_id'];
				$this->blog[$i]['user_id'] = $row['user_id'];
				$this->blog[$i]['user_ip'] = $row['user_ip'];
				$this->blog[$i]['blog_time'] = $row['blog_time'];
				$this->blog[$i]['blog_approved'] = $row['blog_approved'];
				$this->blog[$i]['blog_reported'] = $row['blog_reported'];
				$this->blog[$i]['blog_subject'] = censor_text($row['blog_subject']); // censor the text of the subject
		
				// Parse BBCode and prepare the message for viewing
				$bbcode_options = (($row['enable_bbcode']) ? OPTION_FLAG_BBCODE : 0) +
					(($row['enable_smilies']) ? OPTION_FLAG_SMILIES : 0) + 
					(($row['enable_magic_url']) ? OPTION_FLAG_LINKS : 0);
				$this->blog[$i]['blog_text'] = generate_text_for_display($row['blog_text'], $row['bbcode_uid'], $row['bbcode_bitfield'], $bbcode_options);
		
				// For Highlighting
				$hilit_words = request_var('hilit', '', true);
				$highlight_match = $highlight = '';
				if ($hilit_words)
				{
					foreach (explode(' ', trim($hilit_words)) as $word)
					{
						if (trim($word))
						{
							$highlight_match .= (($highlight_match != '') ? '|' : '') . str_replace('*', '\w*?', preg_quote($word, '#'));
						}
					}
		
					$highlight = urlencode($hilit_words);
				}
				if ($highlight_match)
				{
					$this->blog[$i]['blog_text'] = preg_replace('#(?!<.*)(?<!\w)(' . $highlight_match . ')(?!\w|[^<>]*(?:</s(?:cript|tyle))?>)#is', '<span class="posthilit">\1</span>', $this->blog[$i]['blog_text']);
				}
		
				// has the blog been edited?
				if ($row['blog_edit_count'] != 0)
				{
					$this->get_user_data($row['blog_edit_user']);
		
					if ($row['blog_edit_count'] == 1)
					{
						$this->blog[$i]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $this->user[$row['blog_edit_user']]['username_full'], $user->format_date($row['blog_edit_time']), $row['blog_edit_count']);
					}
					else if ($row['blog_edit_count'] > 1)
					{
						$this->blog[$i]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $this->user[$row['blog_edit_user']]['username_full'], $user->format_date($row['blog_edit_time']), $row['blog_edit_count']);
					}
		
					$this->blog[$i]['edit_reason'] = censor_text($row['blog_edit_reason']);
				}
				else
				{
					$this->blog[$i]['edited_message'] = '';
					$this->blog[$i]['edit_reason'] = '';
				}
		
				// has the blog been deleted?
				if ($row['blog_deleted'] != 0)
				{
					$this->get_user_data($row['blog_deleted']);
					$this->blog[$i]['deleted_message'] = sprintf($user->lang['BLOG_IS_DELETED'], $this->user[$row['blog_deleted']]['username_full'], $user->format_date($row['blog_deleted_time']), '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=blog&amp;mode=undelete&amp;b=" . $row['blog_id']) . '">', '</a>');
				}
				else
				{
					$this->blog[$i]['deleted_message'] = '';
				}
		
				$this->blog[$i]['blog_edit_locked'] = $row['blog_edit_locked'];
				$this->blog[$i]['blog_read_count'] = $row['blog_read_count'];
				$this->blog[$i]['blog_reply_count'] = $row['blog_reply_count'];
			}
			$db->sql_freeresult($result);
		}
	
		// if there are no blogs, return false
		if (count($this->blog) == 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	/*
	* -------------------------- REPLY DATA SECTION -----------------------------
	*/

	/*
	* get replies
	* if deleted is true we only grab the deleted messages, otherwise do not show deleted messages(this does not get checked for viewing a single blog)
	*/
	function get_replies($blog_id)
	{
		/*
		* TODO
		* Check if user can view non-approved messages
		*/
		global $db, $user, $phpbb_root_path, $phpEx, $auth;
	
		// setting up some variables
		$i = 0;
	
		// Add the language Variables for viewtopic
		$user->add_lang('viewtopic');
	
		// if the user can not view deleted replies, don't select them.
		$deleted_sql = ($auth->acl_get('m_blogreplydelete')) ? '' : ' AND reply_deleted = \'0\'';
	
		// Grab the replies
		$sql = 'SELECT * FROM ' . BLOGS_REPLY_TABLE . '
					WHERE blog_id = \'' . $blog_id . '\'' .
						$deleted_sql;
		$result = $db->sql_query($sql);
	
		while($row = $db->sql_fetchrow($result))
		{
			$i++;
	
			$this->get_user_data($row['user_id']);
	
			$this->reply[$i]['reply_id'] = $row['reply_id'];
			$this->reply[$i]['user_id'] = $row['user_id'];
			$this->reply[$i]['user_ip'] = $row['user_ip'];
			$this->reply[$i]['reply_time'] = $row['reply_time'];
			$this->reply[$i]['reply_approved'] = $row['reply_approved'];
			$this->reply[$i]['reply_reported'] = $row['reply_reported'];
			$this->reply[$i]['reply_subject'] = censor_text($row['reply_subject']); // censor the text of the subject
	
			// Parse BBCode and prepare the message for viewing
			$bbcode_options = (($row['enable_bbcode']) ? OPTION_FLAG_BBCODE : 0) +
				(($row['enable_smilies']) ? OPTION_FLAG_SMILIES : 0) + 
				(($row['enable_magic_url']) ? OPTION_FLAG_LINKS : 0);
			$this->reply[$i]['reply_text'] = generate_text_for_display($row['reply_text'], $row['bbcode_uid'], $row['bbcode_bitfield'], $bbcode_options);
	
			// For Highlighting
			$hilit_words = request_var('hilit', '', true);
			$highlight_match = $highlight = '';
			if ($hilit_words)
			{
				foreach (explode(' ', trim($hilit_words)) as $word)
				{
					if (trim($word))
					{
						$highlight_match .= (($highlight_match != '') ? '|' : '') . str_replace('*', '\w*?', preg_quote($word, '#'));
					}
				}
	
				$highlight = urlencode($hilit_words);
			}
			if ($highlight_match)
			{
				$this->reply[$i]['reply_text'] = preg_replace('#(?!<.*)(?<!\w)(' . $highlight_match . ')(?!\w|[^<>]*(?:</s(?:cript|tyle))?>)#is', '<span class="posthilit">\1</span>', $this->reply[$i]['reply_text']);
			}
	
			// has the blog been edited?
			if ($row['reply_edit_count'] != 0)
			{
				$this->get_user_data($row['reply_edit_user']);
	
				if ($row['reply_edit_count'] == 1)
				{
					$this->reply[$i]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $this->user[$row['reply_edit_user']]['username_full'], $user->format_date($row['reply_edit_time']), $row['reply_edit_count']);
				}
				else if ($row['reply_edit_count'] > 1)
				{
					$this->reply[$i]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $this->user[$row['reply_edit_user']]['username_full'], $user->format_date($row['reply_edit_time']), $row['reply_edit_count']);
				}
	
				$this->reply[$i]['edit_reason'] = censor_text($row['reply_edit_reason']);
			}
			else
			{
				$this->reply[$i]['edited_message'] = '';
				$this->reply[$i]['edit_reason'] = '';
			}
	
			// has the reply been deleted?
			if ($row['reply_deleted'] != 0)
			{
				$this->get_user_data($row['reply_deleted']);
	
				$this->reply[$i]['deleted_message'] = sprintf($user->lang['REPLY_IS_DELETED'], $this->user[$row['reply_deleted']]['username_full'], $user->format_date($row['reply_deleted_time']), '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=reply&amp;mode=undelete&amp;r=" . $row['reply_id']) . '">', '</a>');
			}
			else
			{
				$this->reply[$i]['deleted_message'] = '';
			}
	
			$this->reply[$i]['reply_edit_locked'] = $row['reply_edit_locked'];
		}
		$db->sql_freeresult($result);
	
		// if there are no replies, return false
		if (count($this->reply) == 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	/*
	* -------------------------- USER DATA SECTION -----------------------------
	*/

	// grabs the data on the user and places it in the $this->user array
	function get_user_data($user_id)
	{
		global $user, $db, $phpbb_root_path, $phpEx, $config, $auth;

		$bbcode = new bbcode;

		if (!array_key_exists($user_id, $this->user))
		{
			// Get the data on the author/user
			$sql = 'SELECT * FROM ' . USERS_TABLE . ' WHERE user_id = \'' . $user_id . '\'';
			$result = $db->sql_query($sql);
			$this->user[$user_id] = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);
	
			// view profile link
			$this->user[$user_id]['view_profile'] = append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=viewprofile&amp;u=" . $user_id);
	
			// Full username, with colour
			$this->user[$user_id]['username_full'] = get_username_string('full', $user_id, $this->user[$user_id]['username'], $this->user[$user_id]['user_colour']);
	
			// format the color correctly
			$this->user[$user_id]['user_colour'] = get_username_string('colour', $user_id, $this->user[$user_id]['username'], $this->user[$user_id]['user_colour']);
	
			// Online or offline? Basically copied from viewtopic.php
			$sql = 'SELECT session_user_id, MAX(session_time) AS online_time, MIN(session_viewonline) AS viewonline
				FROM ' . SESSIONS_TABLE . '
				WHERE session_user_id = \'' . $user_id . '\'
				GROUP BY session_user_id';
			$result = $db->sql_query($sql);
			$update_time = $config['load_online_time'] * 60;
			$status_data = $db->sql_fetchrow($result);
			$this->user[$user_id]['status'] = (time() - $update_time < $status_data['online_time'] && (($status_data['viewonline'] && $this->user[$user_id]['user_allow_viewonline']) || $auth->acl_get('u_viewonline'))) ? true : false;
		
			$db->sql_freeresult($result);
	
			// Avatar
			$this->user[$user_id]['avatar'] = ($this->user[$user_id]['user_avatar'] && $user->optionget('viewavatars')) ? '<img src="' . $phpbb_root_path . 'download.' . $phpEx . '?avatar=' . $this->user[$user_id]['user_avatar'] . '" width="' . $this->user[$user_id]['user_avatar_width'] . '" height="' . $this->user[$user_id]['user_avatar_height'] . '" alt="" />' : '';
	
			// Rank
			get_user_rank($this->user[$user_id]['user_rank'], $this->user[$user_id]['user_posts'], $this->user[$user_id]['rank_title'], $this->user[$user_id]['rank_img'], $this->user[$user_id]['rank_img_src']);
	
			// IM Links
			$this->user[$user_id]['msn_url'] = ($this->user[$user_id]['user_msnm']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=msnm&amp;u=" . $this->user[$user_id]['user_id']) : '';
			$this->user[$user_id]['yim_url'] = ($this->user[$user_id]['user_yim']) ? 'http://edit.yahoo.com/config/send_webmesg?.target=' . $this->user[$user_id]['user_yim'] . '&amp;.src=pg' : '';
			$this->user[$user_id]['aim_url'] = ($this->user[$user_id]['user_aim']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=aim&amp;u=" . $this->user[$user_id]['user_id']) : '';
			$this->user[$user_id]['icq_url'] = ($this->user[$user_id]['user_icq']) ? 'http://www.icq.com/people/webmsg.php?to=' . $this->user[$user_id]['user_icq'] : '';
			$this->user[$user_id]['jabber_url'] = ($this->user[$user_id]['user_jabber']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=jabber&amp;u=" . $this->user[$user_id]['user_id']) : '';
	
			// PM and email links
			$this->user[$user_id]['pm_url'] = ($this->user[$user_id]['user_id'] != ANONYMOUS && $config['allow_privmsg'] && $auth->acl_get('u_sendpm') && ($this->user[$user_id]['user_allow_viewemail'] || $auth->acl_gets('a_', 'm_') || $auth->acl_getf_global('m_'))) ? append_sid("{$phpbb_root_path}ucp.$phpEx", 'i=pm&amp;mode=compose&amp;u=' . $this->user[$user_id]['user_id']) : '';
			$this->user[$user_id]['email_url'] = ($config['board_email_form'] && $config['email_enable']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=email&amp;u=" . $this->user[$user_id]['user_id'])  : (($config['board_hide_emails'] && !$auth->acl_get('a_email')) ? '' : 'mailto:' . $this->user[$user_id]['user_email']);

			// Signature
			if ($config['allow_sig'] && $user->optionget('viewsigs'))
			{
				$this->user[$user_id]['user_sig'] = censor_text($this->user[$user_id]['user_sig']);
				$this->user[$user_id]['user_sig'] = str_replace("\n", '<br />', $this->user[$user_id]['user_sig']);

				if ($this->user[$user_id]['user_sig_bbcode_bitfield'])
				{
					$bbcode->bbcode_second_pass($this->user[$user_id]['user_sig'], $this->user[$user_id]['user_sig_bbcode_uid'], $this->user[$user_id]['user_sig_bbcode_bitfield']);
				}

				$this->user[$user_id]['user_sig'] = smiley_text($this->user[$user_id]['user_sig']);
			}
			else
			{
				$this->user[$user_id]['user_sig'] = '';
			}

			// get the custom profile fields if the admin wants them
			if ($config['blog_custom_profile_enable'])
			{
				if (!class_exists('custom_profile_admin'))
				{
					include($phpbb_root_path . 'includes/functions_profile_fields.' . $phpEx);
				}
				$cp = new custom_profile();
	
				// Grab all profile fields from users in id cache for later use - similar to the poster cache
				$profile_fields_cache = $cp->generate_profile_fields_template('grab', $user_id);
	
				$this->user[$user_id]['cp_row'] = (isset($profile_fields_cache[$user_id])) ? $cp->generate_profile_fields_template('show', false, $profile_fields_cache[$user_id]) : array();
			}
		}
	}
	
	// prepares the user data for output to the template, and outputs the custom profile rows when requested
	// Mostly for shortenting up code
	function handle_user_data($user_id, $output_custom = false)
	{
		global $phpbb_root_path, $phpEx, $user, $auth, $config, $template;

		if ($output_custom === false)
		{
			$output_data = array(
				'USERNAME'			=> $this->user[$user_id]['username'],
				'USER_COLOUR'		=> $this->user[$user_id]['user_colour'],
				'USER_FULL'			=> $this->user[$user_id]['username_full'],
				'U_PROFILE'			=> append_sid("{$phpbb_root_path}memberlist.$phpEx", 'mode=viewprofile&amp;u=' . $user_id),

				'SIGNATURE'			=> $this->user[$user_id]['user_sig'],

				'AVATAR'			=> $this->user[$user_id]['avatar'],

				'RANK_TITLE'		=> $this->user[$user_id]['rank_title'],
				'RANK_IMG'			=> $this->user[$user_id]['rank_img'],
				'RANK_IMG_SRC'		=> $this->user[$user_id]['rank_img_src'],

				'STATUS_IMG'		=> (($this->user[$user_id]['status']) ? $user->img('icon_user_online', 'ONLINE') : $user->img('icon_user_offline', 'OFFLINE')),
				'S_ONLINE'			=> $this->user[$user_id]['status'],

				'POSTER_POSTS'		=> $this->user[$user_id]['user_posts'],
				'POSTER_JOINED'		=> $user->format_date($this->user[$user_id]['user_regdate']),
				'POSTER_FROM'		=> $this->user[$user_id]['user_from'],

				'U_PM'				=> $this->user[$user_id]['pm_url'],
				'U_EMAIL'			=> $this->user[$user_id]['email_url'],
				'U_WWW'				=> $this->user[$user_id]['user_website'],
				'U_MSN'				=> $this->user[$user_id]['msn_url'],
				'U_YIM'				=> $this->user[$user_id]['yim_url'],
				'U_AIM'				=> $this->user[$user_id]['aim_url'],
				'U_ICQ'				=> $this->user[$user_id]['icq_url'],
				'U_JABBER'			=> $this->user[$user_id]['jabber_url'],

				'U_DELETED_LINK'	=> ($auth->acl_get('m_blogdelete')) ? '<a href="' . append_sid("{$phpbb_root_path}blog.$phpEx", "page=view&amp;mode=deleted&amp;u=" . $this->user[$user_id]['user_id']) . '">' . $user->lang['VIEW_DELETED_BLOGS'] . '</a>' : '',

				'S_CUSTOM_FIELDS'	=> (isset($this->user[$user_id]['cp_row']['blockrow'])) ? true : false,
			);

			return ($output_data);
		}
		else if ($config['blog_custom_profile_enable'])
		{
			// add the blog links in the custom fields
			add_blog_links($user_id, $output_custom);
	
			// output the custom profile fields
			if (isset($this->user[$user_id]['cp_row']['blockrow']))
			{
				foreach ($this->user[$user_id]['cp_row']['blockrow'] as $row)
				{
					$template->assign_block_vars($output_custom, array(
						'PROFILE_FIELD_NAME'	=> $row['PROFILE_FIELD_NAME'],
						'PROFILE_FIELD_VALUE'	=> $row['PROFILE_FIELD_VALUE'],
					));
				}
			}
		}
	}

}
?>