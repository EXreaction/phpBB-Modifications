<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
// Common
	'BLOG'						=> 'Blog',
	'USER_BLOGS'				=> 'User Blogs',
	'MY_BLOGS'					=> 'My Blogs',

	'NO_BLOG'					=> 'The requested blog does not exist.',
	'NO_REPLY'					=> 'The requested reply does not exist.',
	'NO_BLOGS'					=> 'There are no blogs.',

	'VIEW_BLOG'					=> 'View Blog',
	'VIEW_BLOGS'				=> 'View Blogs',
	'RETURN_BLOG_MAIN_OWN'		=> '%sReturn to your main blog page%s',
	'RETURN_BLOG_MAIN'			=> '%sReturn to %s\'s main blog page%s',

	'BLOG_AUTHOR'				=> 'About the Author',
	'AUTHOR_CONTACT'			=> 'Contact & Info',
	'VIEW_DELETED_BLOGS'		=> 'View Deleted Blogs',
	'ARCHIVES'					=> 'Archives',	
	'ADD_BLOG'					=> 'Add a new blog',

	'CONTINUED'					=> 'Continued',

	'BLOG_CREDITS'				=> 'Blog System powered by <a href="http://www.lithiumstudios.org/">User Blog Mod</a> &copy; 2007 EXreaction',

	'RANDOM_BLOGS'				=> 'Random Blogs',
	'RECENT_BLOGS'				=> 'Recent Blogs',
	'POPULAR_BLOGS'				=> 'Popular Blogs',
	'REPORTED_BLOGS'			=> 'These blogs have been reported by users.',
	'DISAPPROVED_BLOGS'			=> 'These blogs need approval before they can be viewed by the public.',
	'REPORTED_REPLIES'			=> 'These replies have been reported by users.',
	'DISAPPROVED_REPLIES'		=> 'These replies need approval before they can be viewed by the public.',
	'NO_REPLIES'				=> 'There are no replies',

	'BLOG_MCP'					=> 'Blog Moderator CP',

// View Blogs
	'USERNAMES_BLOGS'			=> '%s\'s Blogs',  // Would end up like EXreaction's Blogs
	'BLOG_REPLIES'				=> 'There are <b>%1$s</b> %2$sreplies%3$s to this blog',
	'BLOG_REPLY'				=> 'There is <b>1</b> %sreply%s to this blog',
	'NO_BLOGS_USER'				=> 'No blogs have been posted by this user.',
	'BLOG_SUBJECT'				=> 'Blog Subject',
	'BLOG_UNAPPROVED'			=> 'Blog Needs Approval',
	'REPLY_UNAPPROVED'			=> 'Reply Needs Approval',
	'BLOG_INFO'					=> 'About the Blog',
	'BLOG_VIEWS'				=> 'This blog has been viewed <b>%s</b> times',
	'BLOG_VIEW'					=> 'This blog has been viewed <b>1</b> time',
	'BLOG_POST_IP'				=> 'IP Address used to post',
	'BLOG_IS_DELETED'			=> 'This blog was deleted by %1$s on %2$s.  Click <b>%3$shere%4$s</b> to un-delete this blog.',
	'REPLY_IS_DELETED'			=> 'This reply was deleted by %1$s on %2$s.  Click <b>%3$shere%4$s</b> to un-delete this reply.',
	'DELETED_REPLY_SHOW'		=> 'This reply has been soft deleted.  Click here to show the reply.',
	'DELETED_REPLY_SHOW_NO_JS'	=> 'You must enable Javascript to view this post.',
	'BLOG_REPORTED'				=> 'Blog has been reported, click to close the report',
	'REPLY_REPORTED'			=> 'Reply has been reported, click to close the report',

// View deleted blogs
	'USERNAMES_DELETED_BLOGS'	=> '%s\'s Deleted Blogs',  // Would end up like EXreaction's Deleted Blogs
	'NO_DELETED_BLOGS'			=> 'There are no deleted blogs by this user.',
	'DELETED_BLOGS'				=> 'Deleted Blogs',
	'DELETED_MESSAGE'			=> 'These blogs have all been deleted.',
	'DELETED_MESSAGE_EXPLAIN'	=> 'There is a link in every "This blog was deleted by..." section to un-delete the blog.',
	'DELETED_MESSAGE_SINGLE'	=> 'This blog has been deleted.',
	'DELETED_MESSAGE_EXPLAIN_SINGLE'	=> 'There is a link in the "This blog was deleted by..." section to un-delete the blog.',

// Add a blog
	'LOGIN_EXPLAIN_NEW_BLOG'	=> 'You must log in before creating a new blog.',
	'POST_A'					=> 'Post a new blog',
	'BLOG_NEED_APPROVE'			=> 'A moderator or administrator must approve your blogs before they are public.',

// Edit a blog
	'LOGIN_EXPLAIN_EDIT_BLOG'	=> 'You must log in before editing a blog.',
	'EDIT_BLOG'					=> 'Edit Blog',
	'BLOG_EDIT_LOCKED'			=> 'This blog is locked for editing.',

// Delete and Un-delete a blog
	'DELETE_BLOG'				=> 'Delete Blog',
	'UNDELETE_BLOG'				=> 'Un-Delete Blog',
	'DELETE_BLOG_CONFIRM'		=> 'Are you sure you want to delete this blog?',
	'BLOG_ALREADY_DELETED'		=> 'This blog has already been deleted.',
	'UNDELETE_BLOG_CONFIRM'		=> 'Are you sure you want to un-delete this blog?',
	'BLOG_NOT_DELETED'			=> 'This blog is not deleted.  Why are you trying to un-delete it?',
	'BLOG_DELETED'				=> 'Blog has been deleted.',
	'BLOG_UNDELETED'			=> 'The blog has been un-deleted.',
	'DELETE_BLOG_WARN'			=> 'Once deleted, only a moderator or administrator can un-delete this blog',

	'PERMANENTLY_DELETE_BLOG_CONFIRM'	=> 'Are you sure you want to permanently delete this blog?  This can not be un-done.',

// Report blog
	'REPORT_BLOG'				=> 'Report Blog',
	'BLOG_REPORT_CONFIRM'		=> 'Are you sure you want to report this blog?',

	'BLOG_REPORT_PM_SUBJECT'	=> 'Blog Reported!',
	'BLOG_REPORT_PM'			=> 'This is an automatically dispatched message from the User Blog Mod.<br/><br/>%1$s has just reported <a href="%2$s">this blog</a>.<br/>Please take the time to read over the blog and decide what needs to be done.',

// Approve Blog
	'APPROVE_BLOG'				=> 'Approve Blog',
	'APPROVE_BLOG_CONFIRM'		=> 'Are you sure you want to approve this blog?',
	'APPROVE_BLOG_SUCCESS'		=> 'You have successfully approved this blog for public viewing.',
	'BLOG_ALREADY_APPROVED'		=> 'This blog is already approved.',

	'BLOG_APPROVE_PM_SUBJECT'	=> 'Blog Approval Needed!',
	'BLOG_APPROVE_PM'			=> 'This is an automatically dispatched message from the User Blog Mod.<br/><br/>%1$s has just posted <a href="%2$s">this blog</a> and it needs approval before it is publically viewable.<br/>Please take the time to read over the reply and decide what needs to be done.',

// Reply ----------------------------------
	'REPLY'						=> 'Reply',
	'VIEW_REPLY'				=> 'View Reply',
	'REPLY_NEED_APPROVE'		=> 'A moderator or administrator must approve your replies before they are public.',
	'REPLY_SUBMITTED'			=> 'Your reply has been submitted!',

// Reply Edit
	'EDIT_REPLY'				=> 'Edit Reply',
	'REPLY_EDIT_LOCKED'			=> 'This reply is locked for editing.',

// Delete Reply
	'DELETE_REPLY'				=> 'Delete Reply',
	'DELETE_REPLY_WARN'			=> 'Once deleted, only a moderator or administrator can un-delete this reply',
	'DELETE_REPLY_CONFIRM'		=> 'Are you sure you want to delete this reply?',
	'REPLY_ALREADY_DELETED'		=> 'This reply has already been deleted.',
	'UNDELETE_REPLY'			=> 'Un-delete Reply',
	'UNDELETE_REPLY_CONFIRM'	=> 'Are you sure you want to un-delete this reply?',
	'REPLY_NOT_DELETED'			=> 'This reply is not deleted.  Why are you trying to un-delete it?',
	'REPLY_DELETED'				=> 'Reply has been deleted.',
	'REPLY_UNDELETED'			=> 'The reply has been un-deleted.',

	'PERMANENTLY_DELETE_REPLY_CONFIRM'	=> 'Are you sure you want to permanently delete this reply?  This can not be un-done.',

// Report reply
	'REPORT_REPLY'				=> 'Report Reply',
	'REPLY_REPORT_CONFIRM'		=> 'Are you sure you want to report this reply?',

	'REPLY_REPORT_PM_SUBJECT'	=> 'Blog Reply Reported!',
	'REPLY_REPORT_PM'			=> 'This is an automatically dispatched message from the User Blog Mod.<br/><br/>%1$s has just reported <a href="%2$s">this reply</a>.<br/>Please take the time to read over the reply and decide what needs to be done.',

// Approve Reply
	'APPROVE_REPLY'				=> 'Approve Reply',
	'APPROVE_REPLY_CONFIRM'		=> 'Are you sure you want to approve this reply?',
	'APPROVE_REPLY_SUCCESS'		=> 'You have successfully approved this reply for public viewing.',
	'REPLY_ALREADY_APPROVED'	=> 'This reply is already approved.',

	'REPLY_APPROVE_PM_SUBJECT'	=> 'Blog Reply Approval Needed!',
	'REPLY_APPROVE_PM'			=> 'This is an automatically dispatched message from the User Blog Mod.<br/><br/>%1$s has just posted <a href="%2$s">this reply</a> and it needs approval before it is publically viewable.<br/>Please take the time to read over the reply and decide what needs to be done.',
));

?>