<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// check permissions
if (!$auth->acl_get('u_blogpost'))
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}

// Add the language Variables for posting
$user->add_lang('posting');

$self_url = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=blog&amp;mode=add');
$view_user_url = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=user&amp;u=' . $user->data['user_id']);

// Setup the page header and sent the title of the page that will go into the browser header
page_header($user->lang['ADD_BLOG']);

// Generate the breadcrumbs
$breadcrumbs = array(
	sprintf($user->lang['USERNAMES_BLOGS'], $user->data['username']) => $view_user_url,
	$user->lang['ADD_BLOG'] => $self_url,
	);
generate_blog_breadcrumbs($breadcrumbs);

// Posting permissions
$post_options = new post_options;
$post_options->set_status(!isset($_POST['disable_bbcode']), !isset($_POST['disable_smilies']), !isset($_POST['disable_magic_url']));
$post_options->set_in_template();

// If they did submit or hit preview
if ($submit || $preview)
{
	// see if they tried submitting a message or suject(if they hit preview or submit) put it in an array for consistency with the edit mode
	$blog_subject = request_var('subject', '', true);
	$blog_text = request_var('message', '', true);

	// set up the message parser to parse BBCode, Smilies, etc
	$message_parser = new parse_message();
	$message_parser->message = $blog_text;
	$message_parser->parse($post_options->enable_bbcode, $post_options->enable_magic_url, $post_options->enable_smilies, $post_options->img_status, $post_options->flash_status, $post_options->bbcode_status, $post_options->url_status);

	// If they did not include a subject, give them the empty subject error
	if ($blog_subject == '')
	{
		$error[] = $user->lang['EMPTY_SUBJECT'];
	}

	// If any errors were reported by the message parser add those as well
	if (sizeof($message_parser->warn_msg))
	{
		$error[] = implode('<br />', $message_parser->warn_msg);
	}
}
else
{
	$blog_subject = '';
	$blog_text = '';
}

// if they did not submit or they have an error
if ( (!$submit) || (sizeof($error)) )
{
	// if they are trying to preview the message and do not have an error
	if ( ($preview) && (!sizeof($error)) )
	{
		// output some data to the template parser
		$template->assign_vars(array(
			'S_DISPLAY_PREVIEW'			=> true,
			'PREVIEW_SUBJECT'			=> censor_text($blog_subject),
			'PREVIEW_MESSAGE'			=> $message_parser->format_display($post_options->enable_bbcode, $post_options->enable_magic_url, $post_options->enable_smilies, false),
			'POST_DATE'					=> $user->format_date(time()),
		));
	}

	// Generate smiley listing
	generate_smilies('inline', false);

	// Assign some variables to the template parser
	$template->assign_vars(array(
		// If we have any limit on the number of chars a user can enter display that, otherwise don't
		'L_MESSAGE_BODY_EXPLAIN'	=> (intval($config['max_post_chars'])) ? sprintf($user->lang['MESSAGE_BODY_EXPLAIN'], intval($config['max_post_chars'])) : '',

		// If they hit preview or submit and got an error, or are editing their post make sure we carry their existing post info & options over
		'SUBJECT'					=> $blog_subject,
		'MESSAGE'					=> $blog_text,

		// if there are any errors report them
		'ERROR'						=> (sizeof($error)) ? implode('<br />', $error) : '',

		// The post action...
		'S_POST_ACTION'				=> $self_url,
	));

	// Tell the template parser what template file to use
	$template->set_filenames(array(
		'body' => 'posting_body.html'
	));
}
else // user submitted and there are no errors
{
	// insert array, not all of these really need to be inserted, since some are what the fields are as default, but I want it this way. :P
	$sql_data = array(
		'user_id' 			=> $user->data['user_id'],
		'user_ip'			=> $user->data['user_ip'],
		'blog_time'			=> time(),
		'blog_subject'		=> $blog_subject,
		'blog_text'			=> $message_parser->message,
		'blog_checksum'		=> md5($message_parser->message),
		'blog_approved' 	=> $auth->acl_get('u_blognoapprove'),
		'blog_reported'		=> 0,
		'enable_bbcode' 	=> $post_options->enable_bbcode,
		'enable_smilies'	=> $post_options->enable_smilies,
		'enable_magic_url'	=> $post_options->enable_magic_url,
		'bbcode_bitfield'	=> $message_parser->bbcode_bitfield,
		'bbcode_uid'		=> $message_parser->bbcode_uid,
		'blog_edit_time'	=> 0,
		'blog_edit_reason'	=> '',
		'blog_edit_user'	=> 0,
		'blog_edit_count'	=> 0,
		'blog_edit_locked'	=> 0,
		'blog_deleted'		=> 0,
		'blog_deleted_time'	=> 0,
		'blog_read_count'	=> 1,
		'blog_reply_count'	=> 0,
	);

	// insert query
	$sql = 'INSERT INTO ' . BLOGS_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);

	// run the query
	$db->sql_query($sql);

	// we no longer need the message parser
	unset($message_parser);

	$blog_id = $db->sql_nextid();
	$view_blog_url = append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $blog_id);

	if (!$auth->acl_get('u_blognoapprove'))
	{
		inform_approve_report('blog_approve', $blog_id);
	}

	$message = (!$auth->acl_get('u_blognoapprove')) ? $user->lang['BLOG_NEED_APPROVE'] . '<br /><br />' : ''; 
	$message .= '<a href="' . $view_blog_url . '">' . $user->lang['VIEW_BLOG'] . '</a><br/><br/>';

	$message .= sprintf($user->lang['RETURN_BLOG_MAIN_OWN'], '<a href="' . $view_user_url . '">', '</a>');

	// redirect
	meta_refresh(3, $view_blog_url);

	trigger_error($message);
}
?>