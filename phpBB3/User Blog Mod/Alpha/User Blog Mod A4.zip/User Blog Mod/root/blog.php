<?php
/*
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/*
* TODO List
*
* PRIORITY -------------------------------
*
* NEEDS TO BE STARTED/FINISHED -----------
* report to selected mods/admins when a blog needs approval or is reported
* Add option to subscribe to blogs/users
* Add RSS Output Feed
* ACP config options
*
* LOW PRIORITY/MAYBE --------------------
* Attachments
* SEO Url's
*
* OTHER ---------------------------------
* Comments(comment more of the code)
*/

// Stuff required to work with phpBB3, and include some function pages that we will use later on...
define('IN_PHPBB', true);
$phpbb_root_path = './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/bbcode.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);
include($phpbb_root_path . 'includes/functions_posting.' . $phpEx);
include($phpbb_root_path . 'includes/message_parser.' . $phpEx);
include($phpbb_root_path . 'includes/functions_profile_fields.' . $phpEx);

include($phpbb_root_path . 'includes/blog/functions.' . $phpEx);
include($phpbb_root_path . 'includes/blog/blog_data.' . $phpEx);
include($phpbb_root_path . 'includes/blog/post_options.' . $phpEx);

// Start Quick config settings ------------------------------------------------------------------------------------
// later move these to the ACP
$config['blog_custom_profile_enable'] = true;
$config['blog_text_limit'] = 500;
$config['blog_inform']	=	'2';
// End Quick config settings --------------------------------------------------------------------------------------

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('blog');

// get some initial data
$page = request_var('page', '');
$mode = request_var('mode', '');
$user_id = intval(request_var('u', 0));
$blog_id = intval(request_var('b', 0));
$reply_id = intval(request_var('r', 0));

$print = (request_var('view', '') == 'print') ? true : false;
$submit = (isset($_POST['post'])) ? true : false;
$preview = (isset($_POST['preview'])) ? true : false;
$cancel = (isset($_POST['cancel'])) ? true : false;

// set some initial variables that we will (almost) always use
$blog_data = array();
$user_data = array();
$breadcrumbs = array();
$error = array();

// setup our data classes
$blog_data = new blog_data();
$bbcode = new bbcode();
$cp = new custom_profile();

switch ($page)
{
	case 'view' :
		switch ($mode)
		{
			case 'deleted' :
			case 'blog' :
			case 'user' :
				include($phpbb_root_path . 'includes/blog/view.' . $phpEx);
				break;
			default :
				include($phpbb_root_path . 'includes/blog/main.' . $phpEx);
		}
		break;
	case 'blog' :
		switch ($mode)
		{
			case 'add' :
			case 'edit' :
			case 'delete' :
			case 'undelete' :
			case 'report' :
			case 'approve' :
				include($phpbb_root_path . "includes/blog/blog/{$mode}.$phpEx");
				break;
			default :
				include($phpbb_root_path . 'includes/blog/main.' . $phpEx);
		}
		break;
	case 'reply' :
		switch ($mode)
		{
			case 'add' :
			case 'edit' :
			case 'delete' :
			case 'undelete' :
			case 'report' :
			case 'approve' :
				include($phpbb_root_path . "includes/blog/reply/{$mode}.$phpEx");
				break;
			case 'quote' :
				include($phpbb_root_path . "includes/blog/reply/add.$phpEx");
				break;
			default :
				include($phpbb_root_path . 'includes/blog/main.' . $phpEx);
		}
		break;
	case 'mcp' :
		include($phpbb_root_path . 'includes/blog/mcp.' . $phpEx);
		break;
	default :
		include($phpbb_root_path . 'includes/blog/main.' . $phpEx);
}

// Add some data to the template
$template->assign_vars(array(
	'PAGE'				=> $page,
	'MODE'				=> $mode,

	'U_BLOG_MCP'		=> ($auth->acl_gets('m_blogapprove', 'acl_m_blogreport')) ? append_sid("{$phpbb_root_path}blog.$phpEx", 'page=mcp') : '',
));

// Lets add credits for the User Blog mod...this is not the best way to do it, but it makes it so the person installing it has 1 less edit to do per style
$user->lang['TRANSLATION_INFO'] = (!empty($user->lang['TRANSLATION_INFO'])) ? $user->lang['BLOG_CREDITS'] . '<br/>' . $user->lang['TRANSLATION_INFO'] : $user->lang['BLOG_CREDITS'];

// setup the page footer
page_footer();
?>