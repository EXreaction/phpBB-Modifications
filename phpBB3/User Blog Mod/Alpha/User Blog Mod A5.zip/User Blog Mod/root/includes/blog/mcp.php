<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// Check if they have the required permissions
if (!$auth->acl_gets('m_blogapprove', 'acl_m_blogreport'))
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}

// Add the language Variables for viewtopic
$user->add_lang('viewtopic');

generate_blog_breadcrumbs(array($user->lang['USER_BLOGS'] => append_sid("{$phpbb_root_path}blog.$phpEx")));
page_header($user->lang['USER_BLOGS']);

// Reported Blogs
$reported_blog_ids = $blog_data->get_blog_data(array('reported' => true));

// Non-Approved blogs
$disapproved_blog_ids = $blog_data->get_blog_data(array('disapproved' => true));

// Reported Replies
$reported_reply_ids = $blog_data->get_reply_data(array('reported' => true));

// Non-Approved Replies
$disapproved_reply_ids = $blog_data->get_reply_data(array('disapproved' => true));

$blog_data->get_user_data(false, true);

// Output the reported blogs
if ($reported_blog_ids !== false)
{
	foreach ($reported_blog_ids as $id)
	{
		$user_row = $blog_data->handle_user_data($blog_data->blog[$id]['user_id']);

		$blog_row = array(
			'U_VIEW'		=> append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $id),
			'SUBJECT'		=> $blog_data->blog[$id]['blog_subject'],
			'DATE'			=> $user->format_date($blog_data->blog[$id]['blog_time']),
	
			'TEXT'			=> $blog_data->trim_text_length($id, false, 50, true),
		);

		$template->assign_block_vars('blog_reportedrow', $user_row + $blog_row);
	}
}

// Output the non-approved blogs
if ($disapproved_blog_ids !== false)
{
	foreach ($disapproved_blog_ids as $id)
	{
		$user_row = $blog_data->handle_user_data($blog_data->blog[$id]['user_id']);

		$blog_row = array(
			'U_VIEW'		=> append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $id),
			'SUBJECT'		=> $blog_data->blog[$id]['blog_subject'],
			'DATE'			=> $user->format_date($blog_data->blog[$id]['blog_time']),
	
			'TEXT'			=> $blog_data->trim_text_length($id, false, 50, true),
		);

		$template->assign_block_vars('blog_disapprovedrow', $user_row + $blog_row);
	}
}

// Output the reported replies
if ($reported_reply_ids !== false)
{
	foreach ($reported_reply_ids as $id)
	{
		$user_row = $blog_data->handle_user_data($blog_data->reply[$id]['user_id']);

		$reply_row = array(
			'U_VIEW'		=> append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $blog_data->reply[$id]['blog_id'] . '#' . $id),
			'SUBJECT'		=> $blog_data->reply[$id]['reply_subject'],
			'DATE'			=> $user->format_date($blog_data->reply[$id]['reply_time']),
	
			'TEXT'			=> $blog_data->trim_text_length(false, $id, 50, true),
		);

		$template->assign_block_vars('reply_reportedrow', $user_row + $reply_row);
	}
}

// Output the non-approved replies
if ($disapproved_reply_ids !== false)
{
	foreach ($disapproved_reply_ids as $id)
	{
		$user_row = $blog_data->handle_user_data($blog_data->reply[$id]['user_id']);

		$reply_row = array(
			'U_VIEW'		=> append_sid("{$phpbb_root_path}blog.$phpEx", 'page=view&amp;mode=blog&amp;b=' . $blog_data->reply[$id]['blog_id'] . '#' . $id),
			'SUBJECT'		=> $blog_data->reply[$id]['reply_subject'],
			'DATE'			=> $user->format_date($blog_data->reply[$id]['reply_time']),
	
			'TEXT'			=> $blog_data->trim_text_length(false, $id, 50, true),
		);

		$template->assign_block_vars('reply_disapprovedrow', $user_row + $reply_row);
	}
}

// tell the template parser what template file to use
$template->set_filenames(array(
	'body' => 'mcp_blog.html'
));
?>