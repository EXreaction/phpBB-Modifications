<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// only founders are allowed here
if ($user->data['user_type'] != USER_FOUNDER)
{
	trigger_error('You must be a founder to access this page.');
}

// url to the main page
$main_blog_url = append_sid("{$phpbb_root_path}blog.$phpEx");

// Was Cancel pressed? If so then redirect to the appropriate page
if ($cancel)
{
	redirect($main_blog_url);
}

if ( isset($config['user_blog_version']) && ($user_blog_version == $config['user_blog_version']) )
{
	trigger_error('You have already updated the database.<br/><br/>Click <a href="' . $main_blog_url . '">here</a> to return to the main blog page.');
}
else
{
	if (confirm_box(true))
	{
		// if the version isn't set they must have a version earlier than Alpha 6, so lets update A5 -> A6 here
		if (!isset($config['user_blog_version']))
		{
			$sql = 'ALTER TABLE ' . USERS_TABLE . ' ADD blog_count MEDIUMINT( 8 ) NOT NULL DEFAULT \'0\'';
			$db->sql_query($sql);

			resync_blog('blog_count');

			$sql = 'INSERT INTO ' . CONFIG_TABLE . ' VALUES (\'user_blog_version\', \'' . $user_blog_version . '\', 0)';
			$db->sql_query($sql);
		}
		else
		{
			switch ($config['user_blog_version'])
			{
				case 'A6' : // Alpha 6
					break;
				default : // Alpha 5
			}
		}

		// update the version
		$sql = 'UPDATE ' . CONFIG_TABLE . ' SET config_value = \'' . $user_blog_version . '\' WHERE config_name = \'user_blog_version\'';
		$db->sql_query($sql);

		// clear the cache
		$cache->purge();

		$message = 'User blog mod has been updated to ' . $user_blog_version . '.<br/><br/>Click <a href="' . $main_blog_url . '">here</a> to return to the main blog page.';

		trigger_error($message);
	}
	else
	{
		confirm_box(false, 'If you have a version eariler than Alpha 5 you must follow the instructions in the MOD History section of the main mod install document first before you do this.<br/><br/>Are you ready to upgrade the database for the User Blog Mod?');
	}

	// they pressed No, so redirect them
	redirect($main_blog_url);
}
?>