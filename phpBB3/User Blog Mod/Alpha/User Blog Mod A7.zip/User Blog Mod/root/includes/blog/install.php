<?php
/** 
*
* @package phpBB3 User Blog
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// only founders are allowed here
if ($user->data['user_type'] !== USER_FOUNDER)
{
	trigger_error('You must be a founder to access this page.');
}

// I will make the install page later
trigger_error('The install page is not finished in this version.');

?>