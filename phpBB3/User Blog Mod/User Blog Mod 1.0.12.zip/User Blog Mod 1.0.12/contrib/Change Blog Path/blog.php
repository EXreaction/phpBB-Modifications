<?php

define('PHPBB_ROOT_PATH', './phpBB3/');
include(PHPBB_ROOT_PATH . 'blog.' . substr(strrchr(__FILE__, '.'), 1));

?>