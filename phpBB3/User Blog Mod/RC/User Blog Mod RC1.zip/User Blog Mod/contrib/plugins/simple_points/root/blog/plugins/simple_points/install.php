<?php
/**
*
* @package phpBB3 User Blog Simple Points
* @version $Id$
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

set_config('user_blog_sp_blog_points', 2);
set_config('user_blog_sp_reply_points', 1);

?>