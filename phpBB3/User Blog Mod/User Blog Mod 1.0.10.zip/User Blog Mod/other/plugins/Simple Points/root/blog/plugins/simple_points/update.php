<?php
/**
*
* @package phpBB3 User Blog Simple Points
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!isset($config['user_blog_cp_points']))
{
	set_config('user_blog_cp_points', 1);
}

?>