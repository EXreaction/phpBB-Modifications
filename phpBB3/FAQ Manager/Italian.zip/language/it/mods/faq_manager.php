<?php
/**
*
* @package phpBB3 FAQ Manager
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ACP_FAQ_MANAGER'			=> 'Amministrazione FAQ',

	'BACKUP_LOCATION_NO_WRITE'	=> 'Impossibile creare un file di backup.  Controllare i permessi per la cartella store/faq_backup/ ed ogni cartella o file contenuti in essa.',
	'BAD_FAQ_FILE'				=> 'Il file che si sta cercando di modificare non appartiene alle FAQ.',

	'CAT_ALREADY_EXISTS'		=> 'Esiste gi&agrave; una categoria con questo nome.',
	'CATEGORY_NOT_EXIST'		=> 'La categoria indicata non esiste.',
	'CREATE_CATEGORY'			=> 'Crea una categoria',
	'CREATE_FIELD'				=> 'Crea FAQ',

	'DELETE_CAT'				=> 'Cancella categoria',
	'DELETE_CAT_CONFIRM'		=> 'Sei sicuro di voler cancellare questa categoria?  Se si, tutte le FAQ al suo interno saranno cancellate!',
	'DELETE_VAR'				=> 'Cancella FAQ',
	'DELETE_VAR_CONFIRM'		=> 'Sei sicuro di voler cancellare questa FAQ?',

	'FAQ_CAT_LIST'				=> 'Da qui &egrave; possibile vedere e modificare le categorie.',
	'FAQ_EDIT_SUCCESS'			=> 'FAQ aggiornata con successo.',
	'FAQ_FILE_NOT_EXIST'		=> 'Il file che si sta cercando di modificare non esiste.',
	'FAQ_FILE_NO_WRITE'			=> 'Impossibile aggiornare il file.  Controllane i permessi CHMOD.',
	'FAQ_FILE_SELECT'			=> 'Seleziona il file da modificare.',

	'LANGUAGE'					=> 'Lingua',
	'LOAD_BACKUP'				=> 'Carica backup',

	'NAME'						=> 'Nome',
	'NOT_ALLOWED_OUT_OF_DIR'	=> 'Non hai i permessi per modificare i file esterni alla cartella delle lingue.',
	'NO_FAQ_FILES'				=> 'Nessun file di FAQ disponibile',
	'NO_FAQ_VARS'				=> 'Non ci sono variabili di FAQ nel file.',

	'VAR_ALREADY_EXISTS'		=> 'Una FAQ con questo nome esiste gi&agrave;.',
	'VAR_NOT_EXIST'				=> 'La variabile richiesta non esiste.',
));

?>