<?php
/**
*
* @package phpBB3 FAQ Manager
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
   exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
   $lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ACP_FAQ_MANAGER'			=> 'FAQ Manažér',

	'BACKUP_LOCATION_NO_WRITE'	=> 'Nie je možné zálohovať súbory.  Prosím skontrolujte či sa v priečinku store/faq_backup/ nachádzajú všetky potrebné súbory.',
	'BAD_FAQ_FILE'				=> 'Súbor ktorý sa pokúšate upraviť, nie je FAQ súbor.',

	'CATEGORY_NOT_EXIST'		=> 'Požadovaná kategória neexistuje.',
	'CAT_ALREADY_EXISTS'		=> 'Kategória s rovnakým pomenovaním už existuje.',
	'CREATE_CATEGORY'			=> 'Vytvoriť Kategóriu',
	'CREATE_FIELD'				=> 'Vytvoriť Pole',

	'DELETE_CAT'				=> 'Vymazať Kategóriu',
	'DELETE_CAT_CONFIRM'		=> 'Ste si istý, že chcete odstrániť túto kategóriu?  Polia v kategórii budú taktiež odstránené!',
	'DELETE_VAR'				=> 'Odstrániť Pole',
	'DELETE_VAR_CONFIRM'		=> 'Ste si istý, že chcete odstrániť toto pole?',

	'FAQ_CAT_LIST'				=> 'Tu môžete sledovať a upravovať existujúce Kategórie.',
	'FAQ_EDIT_SUCCESS'			=> 'FAQ bolo úspešne aktualizované.',
	'FAQ_FILE_NOT_EXIST'		=> 'Súbor, ktorý sa pokúšate upraviť neexistuje.',
	'FAQ_FILE_NO_WRITE'			=> 'Nie je možné aktualizovať súbor.  Prosím skontrolujte, či sa daný súbor nachádza na potrebnom mieste.',
	'FAQ_FILE_SELECT'			=> 'Vyberte súbor, ktorý chcete upraviť.',

	'LANGUAGE'					=> 'Jazyk',
	'LOAD_BACKUP'				=> 'Obnoviť zálohované súbory',

	'NAME'						=> 'Názov',
	'NOT_ALLOWED_OUT_OF_DIR'	=> 'Nie ste oprávnený na upravovanie súborov mimo jazykových oblastí.',
	'NO_FAQ_FILES'				=> 'FAQ súbory nie sú dostupné.',
	'NO_FAQ_VARS'				=> 'V súbore nie sú žiadne FAQ premenné.',

	'VAR_ALREADY_EXISTS'		=> 'Pole s rovnakým názvom už existuje.',
	'VAR_NOT_EXIST'				=> 'Požadovaná premenná neexistuje.',
));

?>