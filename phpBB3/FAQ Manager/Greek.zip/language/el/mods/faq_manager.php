<?php
/**
*
* @package phpBB3 FAQ Manager
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ACP_FAQ_MANAGER'			=> 'Διαχείριση FAQ',

	'BACKUP_LOCATION_NO_WRITE'		=> 'Μη δυνατή η δημιουργία του αντιγράφου ασφαλείας. Παρακαλώ ελέγξτε τα δικαιώματα του φακέλου store/faq_backup/.',
	'BAD_FAQ_FILE'				=> 'Το αρχείο που προσπαθείτε να επεξεργαστείτε δεν είναι αρχείο FAQ.',

	'CAT_ALREADY_EXISTS'			=> 'Μια κατηγορία με αυτό το όνομα υπάρχει ήδη.',
	'CATEGORY_NOT_EXIST'			=> 'Η κατηγορία που επιλέξατε δεν υπάρχει.',
	'CREATE_CATEGORY'			=> 'Δημιουργία Κατηγορίας',
	'CREATE_FIELD'				=> 'Δημιουργία Πεδίου',

	'DELETE_CAT'				=> 'Διαγραφή Κατηγορίας',
	'DELETE_CAT_CONFIRM'			=> 'Είστε σίγουρος ότι θέλετε να διαγράψετε αυτήν την κατηγορία; Όλα τα πεδία της θα διαγραφούν και αυτά αν εκτελέσετε αυτήν την ενέργεια!',
	'DELETE_VAR'				=> 'Διαγραφή Πεδίου',
	'DELETE_VAR_CONFIRM'			=> 'Είστε σίγουρος ότι θέλετε να διαγράψετε αυτό το πεδίο;',

	'FAQ_CAT_LIST'				=> 'Εδώ μπορείτε να δείτε και να επεξεργαστείτε ήδη υπάρχουσες κατηγορίες.',
	'FAQ_EDIT_SUCCESS'			=> 'Επιτυχής ενημέρωση FAQ.',
	'FAQ_FILE_NOT_EXIST'			=> 'Το αρχείο που προσπαθείτε να επεξεργαστείτε δεν υπάρχει.',
	'FAQ_FILE_NO_WRITE'			=> 'Δεν μπορεί να γίνει ανανέωση του αρχείου. Παρακαλώ ελέγξτε τα δικαιώματα για το αρχείο που προσπαθείτε να επεξεργαστείτε.',
	'FAQ_FILE_SELECT'			=> 'Επιλέξτε το αρχείο που θέλετε να επεξεργαστείτε.',

	'LANGUAGE'				=> 'Γλώσσα',
	'LOAD_BACKUP'				=> 'Φόρτωση Αντιγράφου Ασφαλείας',

	'NAME'					=> 'Όνομα',
	'NOT_ALLOWED_OUT_OF_DIR'		=> 'Δεν μπορείτε να επεξεργαστείτε αρχεία εκτός του καταλόγου γλώσσας.',
	'NO_FAQ_FILES'				=> 'Δεν υπάρχουν διαθέσιμα Αρχεία FAQ.',
	'NO_FAQ_VARS'				=> 'Δεν υπάρχουν μεταβλητές FAQ σε αυτό το αρχείο.',

	'VAR_ALREADY_EXISTS'			=> 'Ένα πεδίο με το όνομα που δώσατε υπάρχει ήδη.',
	'VAR_NOT_EXIST'				=> 'Η ζητούμενη μεταβλητή δεν υπάρχει.',
));

?>
