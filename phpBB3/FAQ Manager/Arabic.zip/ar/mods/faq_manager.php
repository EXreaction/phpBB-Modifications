<?php
/**
*
* @package phpBB3 FAQ Manager
* @copyright (c) 2007 EXreaction, Lithium Studios
* @author 2008-05-21 - phpBBu.com
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ACP_FAQ_MANAGER'			=> 'إدارة الأسئلة المترددة',

	'BACKUP_LOCATION_NO_WRITE'	=> 'غير قادر على إنشاء ملف نسخة الإحتياط.  الرجاء فحص صلاحيات المجلد من أجل store/faq_backup/ وكل مجلد أو ملف داخله.',
	'BAD_FAQ_FILE'				=> 'الملف الذي تطلبه من أجل التعديل ليس ملف أسئلة متكررة.',

	'CAT_ALREADY_EXISTS'		=> 'قسم بالإسم الذي أعطيته موجود سابقاً.',
	'CATEGORY_NOT_EXIST'		=> 'القسم المطلوب غير موجود.',
	'CREATE_CATEGORY'			=> 'أنشئ قسم',
	'CREATE_FIELD'				=> 'أنشئ خانة',

	'DELETE_CAT'				=> 'حذف القسم',
	'DELETE_CAT_CONFIRM'		=> 'هل أنت متأكد من أنك تريد حذف هذا القسم ؟  كل الخانات داخل هذل القسم سيتم حذفها إن أكملت العملية!',
	'DELETE_VAR'				=> 'حذف الخانة',
	'DELETE_VAR_CONFIRM'		=> 'هل أنت متأكد من أنك تريد حذف الخانة?',

	'FAQ_CAT_LIST'				=> 'هنا يمكنك تعديل أقسام موجودة.',
	'FAQ_EDIT_SUCCESS'			=> 'تم تحديث الأسئلة المتكررة بنجاح.',
	'FAQ_FILE_NOT_EXIST'		=> 'الملف الذي تطلبه من أجل التعديل ليس موجودا.',
	'FAQ_FILE_NO_WRITE'			=> 'غير قادر على تحديث الملف.  الرجاء فحص صلاحيات الملف من أجل الملف الذي تطلبه للتعديل.',
	'FAQ_FILE_SELECT'			=> 'حدد الملف الذي تريد تعديله.',

	'LANGUAGE'					=> 'اللغة',
	'LOAD_BACKUP'				=> 'رفع نسخة الإحتياط',

	'NAME'						=> 'الإسم',
	'NOT_ALLOWED_OUT_OF_DIR'	=> 'ليس مسموحاً لك بتعديل الملفات خارج مجلد اللغة.',
	'NO_FAQ_FILES'				=> 'لا توجد ملفات أسئلة متكررة متوفرة.',
	'NO_FAQ_VARS'				=> 'ليس هناك متغيرات أسئلة متكررة متوفرة في الملف.',

	'VAR_ALREADY_EXISTS'		=> 'الخانة بالإسم المعطى موجود مسبقاً.',
	'VAR_NOT_EXIST'				=> 'المتغيرات المطلوبة غير موجودة.',
));

?>