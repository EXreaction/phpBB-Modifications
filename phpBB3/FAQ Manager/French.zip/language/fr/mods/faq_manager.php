<?php
/**
*
* @package phpBB3 FAQ Manager
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
   exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
   $lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
   'ACP_FAQ_MANAGER'         => 'Gestionnaire de FAQ',

   'BACKUP_LOCATION_NO_WRITE'   => 'Impossible de cr�er un fichier de sauvegarde.  Veuillez v�rifier les permissions d`\'�criture du dossier store/faq_backup/.',
   'BAD_FAQ_FILE'            => 'Le fichier que vous tentez d\�diter n\'est pas un fichier de la FAQ.',

   'CAT_ALREADY_EXISTS'      => 'Une cat�gorie du m�me nom existe d�j�.',
   'CATEGORY_NOT_EXIST'      => 'La cat�gorie requise n\'existe pas.',
   'CREATE_CATEGORY'         => 'Cr�er une cat�gorie',
   'CREATE_FIELD'            => 'Cr�er un champ',

   'DELETE_CAT'            => 'Supprimer une cat�gorie',
   'DELETE_CAT_CONFIRM'      => 'Etes vous s�r de vouloir supprimer cette cat�gorie ?  Tous les champs de la cat�gorie seront supprim�s si vous faites �a !',
   'DELETE_VAR'            => 'Effacer un champ',
   'DELETE_VAR_CONFIRM'      => 'Etes vous s�r de vouloir effacer ce champ ?',

   'FAQ_CAT_LIST'            => 'Ici, vous pouvez lister et �diter les cat�gories existantes.',
   'FAQ_EDIT_SUCCESS'         => 'La FAQ a bien �t� mise � jour.',
   'FAQ_FILE_NOT_EXIST'      => 'Le fichier que vous tentez d\'�diter n\'existe pas.',
   'FAQ_FILE_NO_WRITE'         => 'Impossible de mettre � jour le fichier.  Veuillez v�rifier les permissions d\'�criture de ce fichier.',
   'FAQ_FILE_SELECT'         => 'S�lectionner le fichier � �diter.',

   'LANGUAGE'               => 'Langue',
   'LOAD_BACKUP'            => 'Restaurer � partir d\'une sauvegarde',

   'NAME'                  => 'Nom',
   'NOT_ALLOWED_OUT_OF_DIR'   => 'Vous n\'�tes pas autoris� � �diter les fichiers or du dossier de langue.',
   'NO_FAQ_FILES'            => 'Aucun fichier de FAQ disponnible.',
   'NO_FAQ_VARS'            => 'Il n\'y a pas de variable de FAQ disponnible dans ce fichier.',

   'VAR_ALREADY_EXISTS'      => 'Un champ du m�me nom existe d�j�.',
   'VAR_NOT_EXIST'            => 'La variable demand� n\'existe pas.',
));

?>