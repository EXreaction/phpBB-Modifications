<?php
/**
*
* @package phpBB3 FAQ Manager
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ACP_FAQ_MANAGER'			=> 'Administrar FAQs',

	'BACKUP_LOCATION_NO_WRITE'	=> 'Ha sido imposible crear una Copia de Seguridad.  Por favor revisa los permisos del directorio store/faq_backup/ y de los que hay dentro.',
	'BAD_FAQ_FILE'				=> 'El archivo que intenta editar no es un archivo FAQ.',

	'CAT_ALREADY_EXISTS'		=> 'Ya existe una categoría con el mismo nombre.',
	'CATEGORY_NOT_EXIST'		=> 'La categoría no existe.',
	'CREATE_CATEGORY'			=> 'Crear Categoría',
	'CREATE_FIELD'				=> 'Crear Campo',

	'DELETE_CAT'				=> 'Borrar Categoría',
	'DELETE_CAT_CONFIRM'		=> '¿Está seguro de borrar esta categoría?  Si lo haces, todos los campos incluidos en ella también serán borrados.',
	'DELETE_VAR'				=> 'Borrar Campo',
	'DELETE_VAR_CONFIRM'		=> '¿Está seguro de borrar este campo?',

	'FAQ_CAT_LIST'				=> 'Aquí puedes ver y editar las categorías existentes.',
	'FAQ_EDIT_SUCCESS'			=> 'El FAQ ha sido actualizado correctamente.',
	'FAQ_FILE_NOT_EXIST'		=> 'El archivo que intenta editar no existe.',
	'FAQ_FILE_NO_WRITE'			=> 'Ha sido imposible editar el archivo.  Por favor revise los permisos del archivo que intenta editar.',
	'FAQ_FILE_SELECT'			=> 'Selecciona el archivo que quiera editar.',

	'LANGUAGE'					=> 'Idioma',
	'LOAD_BACKUP'				=> 'Cargar Copia de Seguridad',

	'NAME'						=> 'Nombre',
	'NOT_ALLOWED_OUT_OF_DIR'	=> 'No tiene permitido editar archivos fuera del directorio Idioma.',
	'NO_FAQ_FILES'				=> 'Los archivos FAQ no están disponibles.',
	'NO_FAQ_VARS'				=> 'No hay variable FAQ en el archivo.',

	'VAR_ALREADY_EXISTS'		=> 'Ya existe un campo con el mismo nombre.',
	'VAR_NOT_EXIST'				=> 'La variable no existe.',
));

?>
