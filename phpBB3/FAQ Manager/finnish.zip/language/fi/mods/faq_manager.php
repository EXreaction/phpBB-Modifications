<?php
/**
*
* @package phpBB3 FAQ Manager
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
   exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
   $lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
   'ACP_FAQ_MANAGER'         => 'UKK-editori',

   'BACKUP_LOCATION_NO_WRITE'   => 'Varmuuskopio-tiedoston luonti epäonnistui. Tarkasta kansion store/faq_backup/ käyttöoikeudet.',
   'BAD_FAQ_FILE'            => 'Tiedosto, mitä yritätte muokata, ei ole UKK-tiedosto.',

   'CAT_ALREADY_EXISTS'      => 'Kategorian nimi on jo käytössä.',
   'CATEGORY_NOT_EXIST'      => 'Kategoriaa ei ole olemassa.',
   'CREATE_CATEGORY'         => 'Luo kategoria',
   'CREATE_FIELD'            => 'Luo kenttä',

   'DELETE_CAT'            => 'Poista kategoria',
   'DELETE_CAT_CONFIRM'      => 'Oletko varma, että haluat poistaa kategorian? Kaikki kategorian kentät poistetaan myös, jos poistat kategorian!',
   'DELETE_VAR'            => 'Poista kenttä',
   'DELETE_VAR_CONFIRM'      => 'Oletko varma, että haluat poistaa kentän?',

   'FAQ_CAT_LIST'            => 'Tässä voit nähdä olemassa olevat kategoriat, ja muokata niitä.',
   'FAQ_EDIT_SUCCESS'         => 'UKK:n päivitys onnistui.',
   'FAQ_FILE_NOT_EXIST'      => 'Tiedostoa, mitä yritätte muokata, ei ole olemassa.',
   'FAQ_FILE_NO_WRITE'         => 'Tiedoston päivitys epäonnistui. Tarkasta tiedoston käyttöoikeudet.',
   'FAQ_FILE_SELECT'         => 'Valitse tiedosto, mitä haluat muokata.',

   'LANGUAGE'               => 'Kieli',
   'LOAD_BACKUP'            => 'Palauta varmuuskopio',

   'NAME'                  => 'Nimi',
   'NOT_ALLOWED_OUT_OF_DIR'   => 'Et voi muokata tiedostoja, jotka ovat /language/ -kansion ulkopuolella.',
   'NO_FAQ_FILES'            => 'Ei UKK-tiedostoja',
   'NO_FAQ_VARS'            => 'Tiedostossa ei ole UKK-muuttujia',

   'VAR_ALREADY_EXISTS'      => 'Kentän nimi on jo käytössä',
   'VAR_NOT_EXIST'            => 'Muuttujaa, mitä yritätte muokata, ei ole olemassa.',
));

?>