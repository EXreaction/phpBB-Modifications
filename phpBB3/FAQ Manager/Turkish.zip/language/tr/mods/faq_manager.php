<?php
/**
*
* @package phpBB3 FAQ Manager
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'ACP_FAQ_MANAGER'			=> 'SSS Yöneticisi',

	'BACKUP_LOCATION_NO_WRITE'	=> 'Yedek dosyası yaratılamadı!  store/faq_backup/ klasörü ve içindeki tüm dosyaların yazma izinlerini kontrol edin.',
	'BAD_FAQ_FILE'				=> 'Düzenlemeye çalıştığınız dosya bir SSS dosyası değildir.',

	'CAT_ALREADY_EXISTS'		=> 'Bu isimde bir kategori zaten mevcut.',
	'CATEGORY_NOT_EXIST'		=> 'Kategori bulunamadı.',
	'CREATE_CATEGORY'			=> 'Yeni Kategori',
	'CREATE_FIELD'				=> 'Yeni Alan',

	'DELETE_CAT'				=> 'Kategoriyi Sil',
	'DELETE_CAT_CONFIRM'		=> 'Bu kategoriyi silmek istediğinizden emin misiniz?  Bu kategori altındaki tüm alanlar da beraberinde silinecektir!',
	'DELETE_VAR'				=> 'Alanı sil',
	'DELETE_VAR_CONFIRM'		=> 'Bu alanı silmek istediğinizden emin misiniz?',

	'FAQ_CAT_LIST'				=> 'Varolan kategorilerin listesi aşağıdadır.',
	'FAQ_EDIT_SUCCESS'			=> 'SSS başarıyla güncellendi.',
	'FAQ_FILE_NOT_EXIST'		=> 'Düzenlemeye çalıştığınız dosya bulunamadı.',
	'FAQ_FILE_NO_WRITE'			=> 'Dosya düzenlenemedi! Lütfen yazma izinlerini kontrol edin.',
	'FAQ_FILE_SELECT'			=> 'Düzenlemek istediğiniz dosyayı seçiniz.',

	'LANGUAGE'					=> 'Dil',
	'LOAD_BACKUP'				=> 'Yedeği Geri Yükle',

	'NAME'						=> 'İsim',
	'NOT_ALLOWED_OUT_OF_DIR'	=> 'Dil dosyalarının bulunduğu klasörün dışında birşeyler düzenleyemezsiniz.',
	'NO_FAQ_FILES'				=> 'SSS dosyası yok.',
	'NO_FAQ_VARS'				=> 'Dosyada bir SSS değişkeni bulunamadı.',

	'VAR_ALREADY_EXISTS'		=> 'Bu isimde bir alan zaten var.',
	'VAR_NOT_EXIST'				=> 'İstediğiniz alan bulunamadı.',
));

?>