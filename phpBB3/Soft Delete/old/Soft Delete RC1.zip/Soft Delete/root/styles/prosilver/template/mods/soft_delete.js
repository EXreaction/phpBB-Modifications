/*
* For the deleted posts; to open and close divs
*/
function toggleDiv(divName, toggle)
{
    thisDiv = document.getElementById(divName);
    if (thisDiv)
	{
        if (thisDiv.style.display == "none" || toggle == "show")
		{
            thisDiv.style.display = "block";
        }
        else
		{
            thisDiv.style.display = "none";
        }
    }
}