<?php
/**
* @package phpBB3 Soft Delete
* @copyright (c) 2007 EXreaction,
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

/**
* Updates the reply and real reply count for a topic to include the number of soft deleted posts if the user can view them.
*	It also handles the check to see if a post is soft deleted or not (if it is it gives the error to regular users)
*/
function soft_delete_update_reply_count(&$topic_data, $error_on_deleted = true)
{
	global $db, $auth, $user;
	

	if ((!isset($topic_data['topic_deleted_reply_count']) || !isset($topic_data['topic_deleted'])) && ($auth->acl_gets('a_delete', 'm_delete') || $auth->acl_get('f_delete', $topic_data['forum_id'])))
	{
		$sql = 'SELECT topic_deleted, topic_deleted_reply_count FROM ' . TOPICS_TABLE . ' WHERE topic_id = \'' . intval($topic_data['topic_id']) . '\' LIMIT 1';
		$result = $db->sql_query($sql);
		$count = $db->sql_fetchrow($result);
		$topic_data['topic_deleted_reply_count'] = $count['topic_deleted_reply_count'];
		$db->sql_freeresult($result);
		unset ($count);
	}

	if ($topic_data['topic_deleted'] != 0)
	{
		$topic_data['topic_replies']--;
		$topic_data['topic_replies_real']--;
	}

	if  ($topic_data['topic_deleted_reply_count'] == 0)
	{
		return;
	}

	if ($auth->acl_gets('a_delete', 'm_delete'))
	{
		$topic_data['topic_replies'] += $topic_data['topic_deleted_reply_count'];
		$topic_data['topic_replies_real'] += $topic_data['topic_deleted_reply_count'];
	}
	else if ($auth->acl_get('f_delete', $topic_data['forum_id']))
	{
		$sql = 'SELECT count(post_id) AS topic_deleted_reply_count FROM ' . POSTS_TABLE . '
			WHERE topic_id = \'' . $topic_data['topic_id'] . '\'
				AND (post_deleted = \'0\' OR post_deleted = \'' . $user->data['user_id'] . '\')';
		$result = $db->sql_query($sql);
		$total = $db->sql_fetchrow($result);
		$db->sql_freeresult($result);

		$topic_data['topic_replies'] += $total['topic_deleted_reply_count'];
		$topic_data['topic_replies_real'] += $total['topic_deleted_reply_count'];
	}

	if ($topic_data['topic_deleted'] != 0 && !$auth->acl_gets('a_delete', 'm_delete'))
	{

		if (isset($total))
		{
			if ($total['topic_deleted_reply_count'] > 0)
			{
				return;
			}
		}

		if ($error_on_deleted)
		{
			trigger_error('TOPIC_SOFT_DELETED');
		}
		else
		{
			$topic_data['soft_deleted_error'] = true;
		}
	}
}

/**
* Updates the reply and real reply count for a topic to include the number of soft deleted posts if the user can view them.
*/
function soft_delete_update_topic_count(&$forum_data)
{
	global $db, $auth, $user;

	if (!$auth->acl_gets('a_delete', 'm_delete') && !$auth->acl_get('f_delete', $forum_data['forum_id']))
	{
		return;
	}

	if (!isset($forum_data['topic_deleted_count']))
	{
		$sql = 'SELECT count(topic_id) AS topic_deleted_count FROM ' . TOPICS_TABLE . '
			WHERE forum_id = \'' . intval($forum_data['forum_id']) . '\'' . 
				(($auth->acl_gets('a_delete', 'm_delete')) ? '' : (($auth->acl_get('f_delete', $forum_data['forum_id'])) ? " AND (topic_deleted = '0' OR topic_deleted = '{$user->data['user_id']}')" : " AND topic_deleted = '0'"));
		$result = $db->sql_query($sql);
		$count = $db->sql_fetchrow($result);
		$forum_data['topic_deleted_count'] = $count['topic_deleted_count'];
		$db->sql_freeresult($result);
		unset ($count);
	}

	$forum_data['forum_topics'] += $forum_data['topic_deleted_count'];
	$forum_data['forum_topics_real'] += $forum_data['topic_deleted_count'];
}

/**
* Handles undeleting of posts/topics for posting.php
*/
function handle_undelete($post_id)
{
	global $user, $db, $auth, $phpbb_root_path, $phpEx;

	$user->setup('posting');

	// make sure we have an int here, for security
	$post_id = intval($post_id);

	if (!$post_id)
	{
		trigger_error('NO_POST');
	}

	// Grab some data on the post
	$sql = 'SELECT p.post_time, p.poster_id, p.post_subject, p.post_deleted, p.topic_id, t.forum_id, t.topic_title, t.topic_last_post_time, t.topic_deleted
		FROM ' . POSTS_TABLE . ' p, ' . TOPICS_TABLE . ' t
			WHERE post_id = \'' . $post_id . '\'
				AND t.topic_id = p.topic_id';
	$result = $db->sql_query($sql);
	$data = $db->sql_fetchrow($result);
	$db->sql_freeresult($result);

	if (!$data)
	{
		trigger_error('NO_POST');
	}

	$topic_id = $data['topic_id'];
	$forum_id = $data['forum_id'];

	if (!$topic_id)
	{
		trigger_error('NO_TOPIC');
	}

	if (!$forum_id)
	{
		trigger_error('NO_FORUM');
	}

	if ($data['post_deleted'] == 0)
	{
		trigger_error('POST_NOT_DELETED');
	}

	if (!$auth->acl_gets('a_delete', 'm_delete') && !($auth->acl_get('f_delete', $forum_id) && $data['post_deleted'] == $user->data['user_id']))
	{
		trigger_error('NO_AUTH_OPERATION');
	}

	if (confirm_box(true))
	{
		$sql = 'UPDATE ' . POSTS_TABLE . '
			SET post_deleted = \'0\',
				post_deleted_time = \'0\'
					WHERE post_id = \'' . $post_id . '\'';
		$db->sql_query($sql);

		if ($data['topic_deleted'] != 0)
		{
			$sql = 'SELECT count(post_id) AS total FROM ' . POSTS_TABLE . ' WHERE topic_id = \'' . $topic_id . '\' AND post_deleted = \'0\'';
			$result = $db->sql_query($sql);
			$total_real = $db->sql_fetchrow($result);
			$total_real['total']--;

			$sql = 'SELECT count(post_id) AS total FROM ' . POSTS_TABLE . ' WHERE topic_id = \'' . $topic_id . '\' AND post_deleted = \'0\' AND post_approved = \'1\'';
			$result = $db->sql_query($sql);
			$total = $db->sql_fetchrow($result);
			$total['total']--;

			$sql = 'UPDATE ' . TOPICS_TABLE . '
				SET topic_replies = \'' . $total['total'] . '\',
					topic_replies_real = \'' . $total_real['total'] . '\',
					topic_deleted = \'0\',
					topic_deleted_time = \'0\',
					topic_deleted_reply_count = topic_deleted_reply_count - 1
						WHERE topic_id = \'' . $topic_id . '\'';
			$db->sql_query($sql);

			add_log('mod', $forum_id, $topic_id, 'LOG_UNDELETE_TOPIC', $data['topic_title']);
		}
		else
		{
			$sql = 'UPDATE ' . TOPICS_TABLE . '
				SET topic_replies = topic_replies + 1,
					topic_replies_real = topic_replies_real + 1,
					topic_deleted_reply_count = topic_deleted_reply_count - 1
						WHERE topic_id = \'' . $topic_id . '\'';
			$db->sql_query($sql);

			add_log('mod', $forum_id, $topic_id, 'LOG_UNDELETE_POST', $data['post_subject']);
		}

		if ($data['topic_last_post_time'] < $data['post_time'])
		{
			$sql = 'SELECT p.post_id, p.poster_id, p.post_subject, p.post_time, u.username, u.user_colour FROM ' . POSTS_TABLE . ' p, ' . USERS_TABLE . ' u
				WHERE post_deleted = \'0\'
					AND topic_id = \'' . $topic_id . '\'
						AND u.user_id = p.poster_id
							ORDER BY post_time DESC
								LIMIT 1';
			$result = $db->sql_query($sql);
			$last_post_data = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);

			$sql = 'UPDATE ' . TOPICS_TABLE . '
				SET topic_last_post_id = \'' . $last_post_data['post_id'] . '\',
					topic_last_poster_id = \'' . $last_post_data['poster_id'] . '\',
					topic_last_poster_name = \'' . $last_post_data['username'] . '\',
					topic_last_poster_colour = \'' . $last_post_data['user_colour'] . '\',
					topic_last_post_subject = \'' . $last_post_data['post_subject'] . '\',
					topic_last_post_time = \'' . $last_post_data['post_time'] . '\'
						WHERE topic_id = \'' . $topic_id . '\'';
			$db->sql_query($sql);
		}

		$sql = 'SELECT forum_last_post_time FROM ' . FORUMS_TABLE . ' WHERE forum_id = \'' . $forum_id . '\'';
		$db->sql_query($sql);
		$forum_last_post_time = $db->sql_fetchfield('forum_last_post_id');

		if ($forum_last_post_time < $data['post_time'])
		{
			$sql = 'SELECT p.post_id, p.poster_id, p.post_subject, p.post_time, u.username, u.user_colour FROM ' . POSTS_TABLE . ' p, ' . USERS_TABLE . ' u
				WHERE post_deleted = \'0\'
						AND u.user_id = p.poster_id
							ORDER BY post_time DESC
								LIMIT 1';
			$result = $db->sql_query($sql);
			$last_post_data = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);

			$topic_count = ($data['topic_deleted'] != 0) ? 'forum_topics = forum_topics + 1, forum_topics_real = forum_topics_real + 1,' : '';
			$sql = 'UPDATE ' . FORUMS_TABLE . '
				SET ' . $topic_count . '
					forum_posts = forum_posts + 1,
					forum_last_post_id = \'' . $last_post_data['post_id'] . '\',
					forum_last_poster_id = \'' . $last_post_data['poster_id'] . '\',
					forum_last_post_subject = \'' . $last_post_data['post_subject'] . '\',
					forum_last_post_time = \'' . $last_post_data['post_time'] . '\',
					forum_last_poster_name = \'' . $last_post_data['username'] . '\',
					forum_last_poster_colour = \'' . $last_post_data['user_colour'] . '\'
						WHERE forum_id = \'' . $forum_id . '\'';
			$db->sql_query($sql);
		}
		else
		{
			$topic_count = ($data['topic_deleted'] != 0) ? 'forum_topics = forum_topics + 1, forum_topics_real = forum_topics_real + 1,' : '';
			$sql = 'UPDATE ' . FORUMS_TABLE . '
				SET ' . $topic_count . '
					forum_posts = forum_posts + 1
						WHERE forum_id = \'' . $forum_id . '\'';
			$db->sql_query($sql);
		}

		add_log('mod', $forum_id, $topic_id, 'LOG_UNDELETE_TOPIC', $data['topic_title']);

		$redirect = append_sid("{$phpbb_root_path}viewtopic.$phpEx", 'f=' . $forum_id . '&amp;t=' . $topic_id . '&amp;p=' . $post_id) . "#p$post_id";

		$message = $user->lang['POST_UNDELETED'] . '<br/><br/>';
		$message .= sprintf($user->lang['RETURN_TOPIC'], '<a href="' . $redirect . '">', '</a>') . '<br/>';
		$message .= sprintf($user->lang['RETURN_FORUM'], '<a href="' . append_sid("{$phpbb_root_path}viewforum.$phpEx", 'f=' . $forum_id) . '">', '</a>');

		meta_refresh(3, $redirect);
		trigger_error($message);
	}
	else
	{
		confirm_box(false, 'UNDELETE_POST');
	}

	redirect(append_sid("{$phpbb_root_path}viewtopic.$phpEx", 'f=' . $forum_id . '&amp;t=' . $topic_id . '&amp;p=' . $post_id) . "#p$post_id");
}

/**
* Soft delete Post
*/
function soft_delete_post($post_id)
{
	global $db, $user, $auth;
	global $config, $phpEx, $phpbb_root_path;

	// just to make sure they are ints, for security
	$post_id = intval($post_id);

	$sql = 'SELECT p.forum_id, p.topic_id, f.forum_last_post_id, f.forum_posts, f.forum_topics FROM ' . POSTS_TABLE . ' p, ' . FORUMS_TABLE . ' f
		WHERE p.post_id = \'' . $post_id . '\'
			AND f.forum_id = p.forum_id';
	$result = $db->sql_query($sql);
	$data = $db->sql_fetchrow($result);
	$db->sql_freeresult($result);
	$topic_id = $data['topic_id'];
	$forum_id = $data['forum_id'];

	$sql = 'SELECT post_id FROM ' . POSTS_TABLE . ' WHERE topic_id = \'' . $topic_id . '\' AND post_deleted = \'0\' ORDER BY post_time ASC LIMIT 1';
	$db->sql_query($sql);
	$first_post_id = $db->sql_fetchfield('post_id');

	if (!$topic_id)
	{
		trigger_error('NO_TOPIC');
	}

	if (!$forum_id)
	{
		trigger_error('NO_FORUM');
	}

	// Handle Posts
	$sql = 'UPDATE ' . POSTS_TABLE . '
		SET post_deleted = \'' . $user->data['user_id'] . '\',
			post_deleted_time = \'' . time() . '\'
				WHERE post_id = \'' . $post_id . '\'';
	$db->sql_query($sql);

	// Handle Topics.  I used to have this check with sent variables to see if it was the last/first post already and only do extra SQL queries/updates if needed, but the sent data isn't always usable, plus things get screwy with 0 replies counting as 1 post and 0 replies...everything can become screwed up, so we do this the hard way every time.
	$sql = 'SELECT count(post_id) AS total FROM ' . POSTS_TABLE . ' WHERE topic_id = \'' . $topic_id . '\' AND post_deleted = \'0\'';
	$result = $db->sql_query($sql);
	$total_real = $db->sql_fetchrow($result);
	$real_replies = ($total_real['total'] - 1);

	$sql = 'SELECT count(post_id) AS total FROM ' . POSTS_TABLE . ' WHERE topic_id = \'' . $topic_id . '\' AND post_deleted != \'0\'';
	$result = $db->sql_query($sql);
	$total_deleted = $db->sql_fetchrow($result);

	$sql = 'SELECT count(post_id) AS total FROM ' . POSTS_TABLE . ' WHERE topic_id = \'' . $topic_id . '\' AND post_deleted = \'0\' AND post_approved = \'1\'';
	$result = $db->sql_query($sql);
	$total = $db->sql_fetchrow($result);

	if ($total_real['total'] != 0 || $first_post_id != $post_id)
	{
		$total_real['total']--;
	}
	if ($total['total'] != 0 || $first_post_id != $post_id)
	{
		$total['total']--;
	}

	$sql = 'SELECT p.post_id, p.poster_id, u.username, u.user_colour FROM ' . POSTS_TABLE . ' p, ' . USERS_TABLE . ' u
		WHERE post_deleted = \'0\'
			AND topic_id = \'' . $topic_id . '\'
				AND u.user_id = p.poster_id
					ORDER BY post_time ASC
						LIMIT 1';
	$result = $db->sql_query($sql);
	$first_post_data = $db->sql_fetchrow($result);
	$db->sql_freeresult($result);

	$sql = 'SELECT p.post_id, p.poster_id, p.post_subject, p.post_time, t.topic_deleted, t.topic_deleted_reply_count, u.username, u.user_colour FROM ' . POSTS_TABLE . ' p, ' . TOPICS_TABLE . ' t, ' . USERS_TABLE . ' u
		WHERE p.post_deleted = \'0\'
			AND p.topic_id = \'' . $topic_id . '\'
				AND u.user_id = p.poster_id
					ORDER BY post_time DESC
						LIMIT 1';
	$result = $db->sql_query($sql);
	$last_post_data = $db->sql_fetchrow($result);
	$db->sql_freeresult($result);

	if ($real_replies == -1)
	{
		$deleted_sql = 'topic_deleted = \'' . $user->data['user_id'] . '\',
			topic_deleted_time = \'' . time() . '\',';
	}
	else
	{
		$deleted_sql = '';
	}

	if ($first_post_data)
	{
		$first_sql = 'topic_first_post_id = \'' . $first_post_data['post_id'] . '\',
			topic_first_poster_name = \'' . $first_post_data['username'] . '\',
			topic_first_poster_colour = \'' . $first_post_data['user_colour'] . '\',';
	}
	else
	{
		$first_sql = '';
	}

	if ($last_post_data)
	{
		$last_sql = 'topic_last_post_id = \'' . $last_post_data['post_id'] . '\',
			topic_last_poster_id = \'' . $last_post_data['poster_id'] . '\',
			topic_last_poster_name = \'' . $last_post_data['username'] . '\',
			topic_last_poster_colour = \'' . $last_post_data['user_colour'] . '\',
			topic_last_post_subject = \'' . $last_post_data['post_subject'] . '\',
			topic_last_post_time = \'' . $last_post_data['post_time'] . '\',';
	}
	else
	{
		$last_sql = '';
	}

	$sql = 'UPDATE ' . TOPICS_TABLE . '
		SET topic_replies = \'' . $total['total'] . '\',
			topic_replies_real = \'' . $total_real['total'] . '\',' .
			$deleted_sql .
			$first_sql .
			$last_sql . '
			topic_deleted_reply_count = \'' . $total_deleted['total'] . '\'
				WHERE topic_id = \'' . $topic_id . '\'';
	$db->sql_query($sql);

	// Handle Forums
	if ($post_id == $data['forum_last_post_id'])
	{
		$sql = 'SELECT p.post_id, p.poster_id, p.post_subject, p.post_time, u.username, u.user_colour FROM ' . POSTS_TABLE . ' p, ' . USERS_TABLE . ' u
			WHERE post_deleted = \'0\'
					AND u.user_id = p.poster_id
						ORDER BY post_time DESC
							LIMIT 1';
		$result = $db->sql_query($sql);
		$last_topic_data = $db->sql_fetchrow($result);
		$db->sql_freeresult($result);

		if (!$last_topic_data)
		{
			$last_topic_data['post_id'] = '0';
			$last_topic_data['poster_id'] = '0';
			$last_topic_data['post_time'] = '0';
			$forum_posts = "'0'";
		}
		else
		{
			$forum_posts = 'forum_posts - 1';
		}

		$topic_count = ($real_replies == -1 && $data['forum_topics'] != 0) ? 'forum_topics = forum_topics - 1, forum_topics_real = forum_topics_real - 1,' : '';
		$sql = 'UPDATE ' . FORUMS_TABLE . '
			SET ' . $topic_count . '
				forum_posts = ' . $forum_posts . ',
				forum_last_post_id = \'' . $last_topic_data['post_id'] . '\',
				forum_last_poster_id = \'' . $last_topic_data['poster_id'] . '\',
				forum_last_post_subject = \'' . $last_topic_data['post_subject'] . '\',
				forum_last_post_time = \'' . $last_topic_data['post_time'] . '\',
				forum_last_poster_name = \'' . $last_topic_data['username'] . '\',
				forum_last_poster_colour = \'' . $last_topic_data['user_colour'] . '\'
					WHERE forum_id = \'' . $forum_id . '\'';
		$db->sql_query($sql);
	}
	else
	{
		$topic_count = ($real_replies == -1 && $data['forum_topics'] != 0) ? 'forum_topics = forum_topics - 1, forum_topics_real = forum_topics_real - 1,' : '';
		$sql = 'UPDATE ' . FORUMS_TABLE . '
			SET ' . $topic_count . '
				forum_posts = forum_posts - 1
					WHERE forum_id = \'' . $forum_id . '\'';
		$db->sql_query($sql);
	}

	// handle board stats
	set_config('num_posts', ($config['num_posts'] - 1));
	if ($real_replies == -1)
	{
		set_config('num_topics', ($config['num_topics'] - 1));
	}
}

/**
* Handle soft deleting of topics (this also soft deletes the first post in the topic)
*/
function soft_delete_topics($topic_ids)
{
	global $auth, $user, $db;

	if (!is_array($topic_ids))
	{
		$topic_ids = array($topic_ids);
	}

	$posts_to_delete = array();

	$sql = 'SELECT topic_first_post_id FROM ' . TOPICS_TABLE . '
		WHERE ' . $db->sql_in_set('topic_id',  $topic_ids);
	$result = $db->sql_query($sql);
	while ($row = $db->sql_fetchrow($result))
	{
		soft_delete_post($row['topic_first_post_id']);
	}
	
	$sql = 'UPDATE ' . TOPICS_TABLE . ' SET topic_deleted = \'' . $user->data['user_id'] . '\', topic_deleted_time = \'' . time() . '\'
		WHERE ' . $db->sql_in_set('topic_id', $topic_ids);
	$db->sql_query($sql);
}

/**
* Get Deleted Users
*/
function get_soft_delete_users($rowset, $user_cache)
{
	global $auth, $user, $db, $phpEx, $phpbb_root_path;

	$delete_users_to_query = array();
	foreach ($rowset as $row)
	{
		if ($row['post_deleted'] != 0 && !array_key_exists($row['post_deleted'], $user_cache))
		{
			$delete_users_to_query[] = $row['post_deleted'];
		}
	}
	if (count($delete_users_to_query))
	{
		$sql = 'SELECT * FROM ' . USERS_TABLE . '
			WHERE ' . $db->sql_in_set($delete_users_to_query);
		$result = $db->sql_query($sql);
		while ($row = $db->sql_fetchrow($result))
		{
			$poster_id = $row['user_id'];

			if (!isset($user_cache[$poster_id]))
			{
				$user_sig = '';

				// We add the signature to every posters entry because enable_sig is post dependant
				if ($row['user_sig'] && $config['allow_sig'] && $user->optionget('viewsigs'))
				{
					$user_sig = $row['user_sig'];
				}

				$id_cache[] = $poster_id;

				$user_cache[$poster_id] = array(
					'joined'		=> $user->format_date($row['user_regdate']),
					'posts'			=> $row['user_posts'],
					'warnings'		=> (isset($row['user_warnings'])) ? $row['user_warnings'] : 0,
					'from'			=> (!empty($row['user_from'])) ? $row['user_from'] : '',

					'sig'					=> $user_sig,
					'sig_bbcode_uid'		=> (!empty($row['user_sig_bbcode_uid'])) ? $row['user_sig_bbcode_uid'] : '',
					'sig_bbcode_bitfield'	=> (!empty($row['user_sig_bbcode_bitfield'])) ? $row['user_sig_bbcode_bitfield'] : '',

					'viewonline'	=> $row['user_allow_viewonline'],
					'allow_pm'		=> $row['user_allow_pm'],

					'avatar'		=> ($user->optionget('viewavatars')) ? get_user_avatar($row['user_avatar'], $row['user_avatar_type'], $row['user_avatar_width'], $row['user_avatar_height']) : '',
					'age'			=> '',

					'rank_title'		=> '',
					'rank_image'		=> '',
					'rank_image_src'	=> '',

					'username'			=> $row['username'],
					'user_colour'		=> $row['user_colour'],

					'online'		=> false,
					'profile'		=> append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=viewprofile&amp;u=$poster_id"),
					'www'			=> $row['user_website'],
					'aim'			=> ($row['user_aim'] && $auth->acl_get('u_sendim')) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=aim&amp;u=$poster_id") : '',
					'msn'			=> ($row['user_msnm'] && $auth->acl_get('u_sendim')) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=msnm&amp;u=$poster_id") : '',
					'yim'			=> ($row['user_yim']) ? 'http://edit.yahoo.com/config/send_webmesg?.target=' . $row['user_yim'] . '&amp;.src=pg' : '',
					'jabber'		=> ($row['user_jabber'] && $auth->acl_get('u_sendim')) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=jabber&amp;u=$poster_id") : '',
					'search'		=> ($auth->acl_get('u_search')) ? append_sid("{$phpbb_root_path}search.$phpEx", 'search_author=' . urlencode($row['username']) .'&amp;showresults=posts') : '',
					'blog_count'	=> $row['blog_count'],
				);

				get_user_rank($row['user_rank'], $row['user_posts'], $user_cache[$poster_id]['rank_title'], $user_cache[$poster_id]['rank_image'], $user_cache[$poster_id]['rank_image_src']);

				if (!empty($row['user_allow_viewemail']) || $auth->acl_get('a_email'))
				{
					$user_cache[$poster_id]['email'] = ($config['board_email_form'] && $config['email_enable']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=email&amp;u=$poster_id") : (($config['board_hide_emails'] && !$auth->acl_get('a_email')) ? '' : 'mailto:' . $row['user_email']);
				}
				else
				{
					$user_cache[$poster_id]['email'] = '';
				}

				if (!empty($row['user_icq']))
				{
					$user_cache[$poster_id]['icq'] = 'http://www.icq.com/people/webmsg.php?to=' . $row['user_icq'];
					$user_cache[$poster_id]['icq_status_img'] = '<img src="http://web.icq.com/whitepages/online?icq=' . $row['user_icq'] . '&amp;img=5" width="18" height="18" alt="" />';
				}
				else
				{
					$user_cache[$poster_id]['icq_status_img'] = '';
					$user_cache[$poster_id]['icq'] = '';
				}

				if ($config['allow_birthdays'] && !empty($row['user_birthday']))
				{
					list($bday_day, $bday_month, $bday_year) = array_map('intval', explode('-', $row['user_birthday']));

					if ($bday_year)
					{
						$diff = $now['mon'] - $bday_month;
						if ($diff == 0)
						{
							$diff = ($now['mday'] - $bday_day < 0) ? 1 : 0;
						}
						else
						{
							$diff = ($diff < 0) ? 1 : 0;
						}

						$user_cache[$poster_id]['age'] = (int) ($now['year'] - $bday_year - $diff);
					}
				}
			}
		}
	}
}

/**
* MCP Delete Topics
*/
function mcp_delete_topics($topic_ids)
{
	global $auth, $user, $db, $phpEx, $phpbb_root_path;

	$redirect = request_var('redirect', build_url(array('_f_', 'action', 'quickmod')));
	$forum_id = request_var('f', 0);

	$s_hidden_fields = build_hidden_fields(array(
		'topic_id_list'	=> $topic_ids,
		'f'				=> $forum_id,
		'action'		=> 'delete_topic',
		'redirect'		=> $redirect)
	);
	$success_msg = '';

	$soft_delete = $hard_delete = $post_data = array();
	$sql = 'SELECT topic_id, topic_deleted FROM ' . TOPICS_TABLE . '
		WHERE ' . $db->sql_in_set('topic_id', $topic_ids);
	$result = $db->sql_query($sql);
	while ($row = $db->sql_fetchrow($result))
	{
		if ($row['topic_deleted'])
		{
			$hard_delete[] = $row['topic_id'];
		}
		else
		{
			$soft_delete[] = $row['topic_id'];
		}
	}
	$db->sql_freeresult($result);

	if (!$auth->acl_get('a_delete') && !count($soft_delete))
	{
		trigger_error($user->lang['NOT_ALLOWED_HARD_DELETE']);
	}

	if (confirm_box(true))
	{
		include_once($phpbb_root_path . 'includes/mods/soft_delete.' . $phpEx);

		$data = get_topic_data($topic_ids);

		if ($auth->acl_get('a_delete') && count($hard_delete))
		{
			foreach ($data as $topic_id => $row)
			{
				if (in_array($topic_id, $hard_delete))
				{
					add_log('mod', $row['forum_id'], 0, 'LOG_HARD_DELETE_TOPIC', $row['topic_title']);
				}
			}

			$return = delete_topics('topic_id', $hard_delete);
		}

		if (count($soft_delete))
		{
			soft_delete_topics($soft_delete);

			foreach ($data as $topic_id => $row)
			{
				if (in_array($topic_id, $soft_delete))
				{
					add_log('mod', $row['forum_id'], 0, 'LOG_SOFT_DELETE_TOPIC', $row['topic_title']);
				}
			}
		}

		$success_msg = (sizeof($topic_ids) == 1) ? 'TOPIC_SOFT_DELETED_SUCCESS' : 'TOPICS_SOFT_DELETED_SUCCESS';
	}
	else
	{
		confirm_box(false, (sizeof($topic_ids) == 1) ? 'DELETE_TOPIC' : 'DELETE_TOPICS', $s_hidden_fields);
	}

	$redirect = request_var('redirect', "index.$phpEx");
	$redirect = reapply_sid($redirect);

	if (!$success_msg)
	{
		redirect($redirect);
	}
	else
	{
		$redirect_url = append_sid("{$phpbb_root_path}viewforum.$phpEx", 'f=' . $forum_id);
		meta_refresh(3, $redirect_url);
		trigger_error($user->lang[$success_msg] . '<br /><br />' . sprintf($user->lang['RETURN_FORUM'], '<a href="' . $redirect_url . '">', '</a>'));
	}
}

/**
* MCP Delete Posts
*/
function mcp_delete_posts($post_ids)
{
	global $auth, $user, $db, $phpEx, $phpbb_root_path;

	$redirect = request_var('redirect', build_url(array('_f_', 'action', 'quickmod')));
	$forum_id = request_var('f', 0);

	$s_hidden_fields = build_hidden_fields(array(
		'post_id_list'	=> $post_ids,
		'f'				=> $forum_id,
		'action'		=> 'delete_post',
		'redirect'		=> $redirect)
	);
	$success_msg = '';

	$soft_delete = $hard_delete = $post_data = $topic_id_list = $return_link = array();
	$sql = 'SELECT p.post_id, p.post_subject, p.post_deleted, t.topic_id, t.forum_id, t.topic_first_post_id, t.topic_last_post_id FROM ' . POSTS_TABLE . ' p, ' . TOPICS_TABLE . ' t
		WHERE ' . $db->sql_in_set('p.post_id', $post_ids) . '
			AND p.topic_id = t.topic_id';
	$result = $db->sql_query($sql);
	while ($row = $db->sql_fetchrow($result))
	{
		if ($row['post_deleted'])
		{
			$hard_delete[] = $row['post_id'];
		}
		else
		{
			$soft_delete[] = $row['post_id'];
		}

		$post_data[$row['post_id']] = $row;

		if (!in_array($row['topic_id'], $topic_id_list))
		{
			$topic_id_list[] = $row['topic_id'];
		}
	}
	$db->sql_freeresult($result);

	if (!$auth->acl_get('a_delete') && !count($soft_delete))
	{
		trigger_error($user->lang['NOT_ALLOWED_HARD_DELETE']);
	}

	if (confirm_box(true))
	{
		include_once($phpbb_root_path . 'includes/mods/soft_delete.' . $phpEx);
		if (count($soft_delete))
		{
			foreach($soft_delete as $id)
			{
				soft_delete_post($id);
				add_log('mod', $post_data[$id]['forum_id'], $post_data[$id]['topic_id'], 'LOG_SOFT_DELETE_POST', $post_data[$id]['post_subject']);
			}
		}

		$topic_id = request_var('t', 0);

		if ($auth->acl_get('a_delete') && count($hard_delete))
		{
			$post_ids = $hard_delete;

			if (!function_exists('delete_posts'))
			{
				include($phpbb_root_path . 'includes/functions_admin.' . $phpEx);
			}

			$affected_topics = sizeof($topic_id_list);

			foreach ($post_data as $id => $row)
			{
				add_log('mod', $row['forum_id'], $row['topic_id'], 'LOG_HARD_DELETE_POST', $row['post_subject']);
			}

			// Now delete the posts, topics and forums are automatically resync'ed
			delete_posts('post_id', $post_ids);

			$sql = 'SELECT COUNT(topic_id) AS topics_left
				FROM ' . TOPICS_TABLE . '
				WHERE ' . $db->sql_in_set('topic_id', $topic_id_list);
			$result = $db->sql_query_limit($sql, 1);
			$deleted_topics = ($row = $db->sql_fetchrow($result)) ? ($affected_topics - $row['topics_left']) : $affected_topics;
			$db->sql_freeresult($result);

			// Return links
			if ($affected_topics == 1 && !$deleted_topics && $topic_id)
			{
				$return_link[] = sprintf($user->lang['RETURN_TOPIC'], '<a href="' . append_sid("{$phpbb_root_path}viewtopic.$phpEx", "f=$forum_id&amp;t=$topic_id") . '">', '</a>');
			}

			$return_link[] = sprintf($user->lang['RETURN_FORUM'], '<a href="' . append_sid("{$phpbb_root_path}viewforum.$phpEx", 'f=' . $forum_id) . '">', '</a>');

			if (sizeof($post_ids) == 1)
			{
				if ($deleted_topics)
				{
					// We deleted the only post of a topic, which in turn has
					// been removed from the database
					$success_msg = $user->lang['TOPIC_DELETED_SUCCESS'];
				}
				else
				{
					$success_msg = $user->lang['POST_DELETED_SUCCESS'];
				}
			}
			else
			{
				if ($deleted_topics)
				{
					// Some of topics disappeared
					$success_msg = $user->lang['POSTS_DELETED_SUCCESS'] . '<br /><br />' . $user->lang['EMPTY_TOPICS_REMOVED_WARNING'];
				}
				else
				{
					$success_msg = $user->lang['POSTS_DELETED_SUCCESS'];
				}
			}
			if (!($affected_topics == 1 && !$deleted_topics && $topic_id))
			{
				meta_refresh(3, append_sid("{$phpbb_root_path}viewforum.$phpEx", 'f=' . $forum_id));
				trigger_error($success_msg . '<br /><br />' . implode('<br /><br />', $return_link));
			}
		}
		else
		{
			if (sizeof($soft_delete) == 1)
			{
				$success_msg = $user->lang['POST_DELETED_SUCCESS'];
			}
			else
			{
				$success_msg = $user->lang['POSTS_DELETED_SUCCESS'];
			}

			$return_link[] = sprintf($user->lang['RETURN_TOPIC'], '<a href="' . append_sid("{$phpbb_root_path}viewtopic.$phpEx", "f=$forum_id&amp;t=$topic_id") . '">', '</a>');
			$return_link[] = sprintf($user->lang['RETURN_FORUM'], '<a href="' . append_sid("{$phpbb_root_path}viewforum.$phpEx", 'f=' . $forum_id) . '">', '</a>');
		}
	}
	else
	{
		confirm_box(false, (sizeof($post_ids) == 1) ? 'DELETE_POST' : 'DELETE_POSTS', $s_hidden_fields);
	}

	$redirect = request_var('redirect', "index.$phpEx");
	$redirect = reapply_sid($redirect);

	if (!$success_msg)
	{
		redirect($redirect);
	}
	else
	{
		meta_refresh(3, $redirect);
		trigger_error($success_msg . '<br /><br />' . sprintf($user->lang['RETURN_PAGE'], '<a href="' . $redirect . '">', '</a>') . '<br /><br />' . implode('<br /><br />', $return_link));
	}
}
?>