<?php
/**
* @package phpBB3 Soft Delete
* @copyright (c) 2007 EXreaction,
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (!defined('SOFT_DELETE_INCLUDED'))
{
	define('SOFT_DELETE_INCLUDED', true);

	/**
	* Updates the reply and real reply count for a topic to include the number of soft deleted posts if the user can view them.
	*	It also handles the check to see if a post is soft deleted or not (if it is it gives the error to regular users)
	*/
	function soft_delete_update_reply_count(&$topic_data, $error_on_deleted = true)
	{
		global $db, $auth, $user;
		

		if ((!isset($topic_data['topic_deleted_reply_count']) || !isset($topic_data['topic_deleted'])) && ($auth->acl_get('a_harddelete') || $auth->acl_get('m_harddelete') || $auth->acl_get('m_harddelete', $topic_data['forum_id']) || $auth->acl_get('m_delete', $topic_data['forum_id']) || $auth->acl_get('f_delete', $topic_data['forum_id'])))
		{
			$sql = 'SELECT topic_deleted, topic_deleted_reply_count FROM ' . TOPICS_TABLE . ' WHERE topic_id = \'' . intval($topic_data['topic_id']) . '\' LIMIT 1';
			$result = $db->sql_query($sql);
			$count = $db->sql_fetchrow($result);
			$topic_data['topic_deleted_reply_count'] = $count['topic_deleted_reply_count'];
			$db->sql_freeresult($result);
			unset ($count);
		}

		if  ($topic_data['topic_deleted_reply_count'] == 0 || $auth->acl_get('a_harddelete') || $auth->acl_get('m_harddelete') || $auth->acl_get('m_harddelete', $topic_data['forum_id']) || $auth->acl_get('m_delete', $topic_data['forum_id']))
		{
			return;
		}

		if ($auth->acl_get('f_delete', $topic_data['forum_id']))
		{
			$sql = 'SELECT count(post_id) AS topic_deleted_reply_count FROM ' . POSTS_TABLE . '
				WHERE topic_id = \'' . $topic_data['topic_id'] . '\'
					AND post_deleted != \'0\'
					AND post_deleted != \'' . $user->data['user_id'] . '\'';
			$result = $db->sql_query($sql);
			$total = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);

			$topic_data['topic_replies'] -= $total['topic_deleted_reply_count'];
			$topic_data['topic_replies_real'] -= $total['topic_deleted_reply_count'];
		}
		else
		{
			$topic_data['topic_replies'] -= $topic_data['topic_deleted_reply_count'];
			$topic_data['topic_replies_real'] -= $topic_data['topic_deleted_reply_count'];
		}

		if ($topic_data['topic_deleted'] != 0 &&  $topic_data['topic_deleted'] != $user->data['user_id'] && !($auth->acl_get('a_harddelete') || $auth->acl_get('m_harddelete') || $auth->acl_get('m_harddelete', $topic_data['forum_id']) || $auth->acl_get('m_delete', $topic_data['forum_id'])))
		{
			$topic_data['soft_deleted_error'] = true;

			if ($error_on_deleted)
			{
				trigger_error('TOPIC_SOFT_DELETED');
			}

			if (isset($total))
			{
				if ($total['topic_deleted_reply_count'] > 0)
				{
					return;
				}
			}
		}
	}

	/**
	* Updates the topic count for viewforum
	*/
	function soft_delete_update_topic_count(&$forum_data)
	{
		global $db, $auth, $user;

		if ($auth->acl_get('a_harddelete') || $auth->acl_get('m_harddelete') || $auth->acl_get('m_harddelete', $forum_data['forum_id']) || $auth->acl_get('m_delete', $forum_data['forum_id']))
		{
			return;
		}

		if (!isset($forum_data['forum_deleted_topic_count']) || $auth->acl_get('f_delete', $forum_data['forum_id']))
		{
			$sql = 'SELECT count(topic_id) AS forum_topic_count FROM ' . TOPICS_TABLE . '
				WHERE forum_id = \'' . intval($forum_data['forum_id']) . '\'' . 
					(($auth->acl_get('f_delete', $forum_data['forum_id'])) ? " AND topic_deleted = '0' OR topic_deleted = '{$user->data['user_id']}'" : " AND topic_deleted = '0'");
			$result = $db->sql_query($sql);
			$count = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);

			$forum_data['forum_topics'] = $count['forum_topic_count'];
			$forum_data['forum_topics_real'] = $count['forum_topic_count'];
		}
		else
		{
			$forum_data['forum_topics'] -= $forum_data['forum_deleted_topic_count'];
			$forum_data['forum_topics_real'] -= $forum_data['forum_deleted_topic_count'];
		}
	}

	/**
	* Updates the topic and reply count for the forum index & subforums
	*/
	function soft_delete_update_topic_post_count(&$forum_data)
	{
		global $auth;

		if ($auth->acl_get('a_harddelete') || $auth->acl_get('m_harddelete') || $auth->acl_get('m_harddelete', $forum_data['forum_id']) || $auth->acl_get('m_delete', $forum_data['forum_id']))
		{
			return;
		}

		if (isset($forum_data['forum_deleted_topic_count']))
		{
			// this time we just subtract the topic count instead of doing a bunch of SQL queries to find out exactly how many there is for other users
			$forum_data['forum_topics'] -= $forum_data['forum_deleted_topic_count'];
			$forum_data['forum_topics_real'] -= $forum_data['forum_deleted_topic_count'];
		}

		if (isset($forum_data['forum_deleted_reply_count']))
		{
			// this time we just subtract the reply count instead of doing a bunch of SQL queries to find out exactly how many there is for other users
			$forum_data['forum_posts'] -= $forum_data['forum_deleted_reply_count'];
			//$forum_data['forum_posts'] += $forum_data['forum_deleted_topic_count'];
		}
	}

	/**
	* Get Info on users who deleted the posts
	*/
	function get_soft_delete_users($rowset, &$user_cache)
	{
		global $auth, $user, $db, $phpEx, $phpbb_root_path;

		$delete_users_to_query = array();
		foreach ($rowset as $row)
		{
			if ($row['post_deleted'] != 0 && !array_key_exists($row['post_deleted'], $user_cache))
			{
				$delete_users_to_query[] = $row['post_deleted'];
			}
		}

		if (count($delete_users_to_query))
		{
			$sql = 'SELECT user_id, username, user_colour FROM ' . USERS_TABLE . '
				WHERE ' . $db->sql_in_set('user_id', $delete_users_to_query);
			$result = $db->sql_query($sql);
			while ($row = $db->sql_fetchrow($result))
			{
				if (!isset($user_cache[$row['user_id']]))
				{
					$user_cache[$row['user_id']] = array(
						'username'		=> $row['username'],
						'user_colour'	=> $row['user_colour'],
					);
				}
			}
		}
	}

	/**
	* Handles deleting of posts/topics for posting.php
	*/
	function handle_delete($post_id)
	{
		global $user, $db, $auth, $phpbb_root_path, $phpEx;

		$user->setup('common');

		if (!$post_id)
		{
			trigger_error('NO_POST');
		}

		include($phpbb_root_path . 'includes/mods/soft_delete_class.' . $phpEx);
		$delete = new delete();
		$delete->get_post_data(array($post_id));
		$delete->hard_or_soft_check(array($post_id), false);

		if (!count($delete->soft_delete['p']) && !count($delete->hard_delete['p']))
		{
			trigger_error('NO_AUTH_OPERATION');
		}

		if (confirm_box(true))
		{
			$delete->soft_delete_posts();
			$delete->hard_delete_posts();

			$redirect_post = append_sid("{$phpbb_root_path}viewtopic.$phpEx", "f={$delete->post_data[$post_id]['forum_id']}&amp;t={$delete->post_data[$post_id]['topic_id']}&amp;p={$post_id}#$post_id");
			$redirect_topic = append_sid("{$phpbb_root_path}viewtopic.$phpEx", "f={$delete->post_data[$post_id]['forum_id']}&amp;t={$delete->post_data[$post_id]['topic_id']}");
			$redirect_forum = append_sid("{$phpbb_root_path}viewforum.$phpEx", "f={$delete->post_data[$post_id]['forum_id']}");

			if (count($delete->hard_delete['t']))
			{
				$message = $user->lang['TOPIC_HARD_DELETE_SUCCESS'] . '<br/><br/>';

				$message .= sprintf($user->lang['CLICK_RETURN_FORUM'], "<a href=\"{$redirect_forum}\">", '</a><br/>');

				meta_refresh(3, $redirect_forum);
			}
			else
			{
				if (count($delete->soft_delete['p']))
				{
					if (count($delete->soft_delete['t']))
					{
						$message = $user->lang['TOPIC_SOFT_DELETE_SUCCESS'] . '<br/><br/>';
					}
					else
					{
						$message = $user->lang['POST_SOFT_DELETE_SUCCESS'] . '<br/><br/>';
					}

					$message .= sprintf($user->lang['CLICK_RETURN_POST'], "<a href=\"{$redirect_post}\">", '</a><br/>');
					$message .= sprintf($user->lang['CLICK_RETURN_TOPIC'], "<a href=\"{$redirect_topic}\">", '</a><br/>');
					$message .= sprintf($user->lang['CLICK_RETURN_FORUM'], "<a href=\"{$redirect_forum}\">", '</a><br/>');

					meta_refresh(3, $redirect_post);
				}
				else
				{
					if (count($delete->hard_delete['t']))
					{
						$message = $user->lang['TOPIC_HARD_DELETE_SUCCESS'] . '<br/><br/>';
						meta_refresh(3, $redirect_forum);
					}
					else
					{
						$message = $user->lang['POST_HARD_DELETE_SUCCESS'] . '<br/><br/>';
						$message .= sprintf($user->lang['CLICK_RETURN_TOPIC'], "<a href=\"{$redirect_topic}\">", '</a><br/>');

						meta_refresh(3, $redirect_topic);
					}

					$message .= sprintf($user->lang['CLICK_RETURN_FORUM'], "<a href=\"{$redirect_forum}\">", '</a><br/>');
				}
			}

			trigger_error($message);
		}
		else
		{
			$s_hidden_fields = build_hidden_fields(array(
				'p'		=> $post_id,
				'mode'	=> 'delete')
			);

			if (count($delete->soft_delete['p']))
			{
				confirm_box(false, 'SOFT_DELETE_MESSAGE', $s_hidden_fields);
			}
			else
			{
				confirm_box(false, 'HARD_DELETE_MESSAGE', $s_hidden_fields);
			}
		}

		redirect(append_sid("{$phpbb_root_path}viewtopic.$phpEx", "p=$post_id") . "#$post_id");
	}

	/**
	* Handles undeleting of posts/topics for posting.php
	*/
	function handle_undelete($post_id)
	{
		global $user, $db, $auth, $phpbb_root_path, $phpEx;

		$user->setup('common');

		if (!$post_id)
		{
			trigger_error('NO_POST');
		}

		include($phpbb_root_path . 'includes/mods/soft_delete_class.' . $phpEx);
		$delete = new delete();
		$delete->get_post_data(array($post_id));
		$delete->undelete_check(array($post_id), false);

		if (!count($delete->undelete['p']))
		{
			trigger_error('NO_AUTH_OPERATION');
		}

		if (confirm_box(true))
		{
			$delete->undelete_posts();

			$redirect_post = append_sid("{$phpbb_root_path}viewtopic.$phpEx", "f={$delete->post_data[$post_id]['forum_id']}&amp;t={$delete->post_data[$post_id]['topic_id']}&amp;p={$post_id}#$post_id");
			$redirect_topic = append_sid("{$phpbb_root_path}viewtopic.$phpEx", "f={$delete->post_data[$post_id]['forum_id']}&amp;t={$delete->post_data[$post_id]['topic_id']}");
			$redirect_forum = append_sid("{$phpbb_root_path}viewforum.$phpEx", "f={$delete->post_data[$post_id]['forum_id']}");

			if (count($delete->undelete['t']))
			{
				$message = $user->lang['TOPIC_UNDELETE_SUCCESS'] . '<br/><br/>';
			}
			else
			{
				$message = $user->lang['POST_UNDELETE_SUCCESS'] . '<br/><br/>';
			}

			$message .= sprintf($user->lang['CLICK_RETURN_POST'], "<a href=\"{$redirect_post}\">", '</a><br/>');
			$message .= sprintf($user->lang['CLICK_RETURN_TOPIC'], "<a href=\"{$redirect_topic}\">", '</a><br/>');
			$message .= sprintf($user->lang['CLICK_RETURN_FORUM'], "<a href=\"{$redirect_forum}\">", '</a><br/>');

			meta_refresh(3, $redirect_post);
			trigger_error($message);
		}
		else
		{
			$s_hidden_fields = build_hidden_fields(array(
				'p'		=> $post_id,
				'mode'	=> 'undelete')
			);

			confirm_box(false, 'UNDELETE_POST', $s_hidden_fields);
		}

		redirect(append_sid("{$phpbb_root_path}viewtopic.$phpEx", "p=$post_id") . "#$post_id");
	}

	/**
	* MCP Delete Topics
	*/
	function mcp_delete_topics($topic_ids)
	{
		global $auth, $user, $db, $phpEx, $phpbb_root_path;

		$redirect = request_var('redirect', build_url(array('_f_', 'action', 'quickmod')));
		$forum_id = request_var('f', 0);

		if (!is_array($topic_ids))
		{
			$topic_ids = array($topic_ids);
		}

		$s_hidden_fields = build_hidden_fields(array(
			'topic_id_list'	=> $topic_ids,
			'f'				=> $forum_id,
			'action'		=> 'delete_topic',
			'redirect'		=> $redirect)
		);

		include($phpbb_root_path . 'includes/mods/soft_delete_class.' . $phpEx);
		$delete = new delete();

		$redirect_forum = append_sid("{$phpbb_root_path}viewforum.$phpEx", "f={$forum_id}");

		if (confirm_box(true))
		{
			$post_ids = array();
			foreach ($topic_ids as $id)
			{
				$sql = 'SELECT post_id FROM ' . POSTS_TABLE . ' WHERE topic_id = \'' . $id . '\'';
				$result = $db->sql_query($sql);
				while ($row = $db->sql_fetchrow($result))
				{
					$post_ids[] = $row['post_id'];
				}
			}
			$delete->get_post_data($post_ids);

			$delete->hard_or_soft_check($post_ids, false, true);

			if (!count($delete->soft_delete['p']) && !count($delete->hard_delete['p']))
			{
				trigger_error('NO_AUTH_OPERATION');
			}

			$delete->soft_delete_posts();
			$delete->hard_delete_posts();

			$message = $user->lang['TOPICS_MCP_DELETE_SUCCESS'] . '<br/><br/>';
			$message .= sprintf($user->lang['CLICK_RETURN_FORUM'], "<a href=\"{$redirect_forum}\">", '</a><br/>');

			meta_refresh(3, $redirect_forum);
			trigger_error($message);
		}
		else
		{
			$delete->get_topic_data($topic_ids);
			$delete->hard_or_soft_check(false, $topic_ids);

			if (!count($delete->soft_delete['t']) && !count($delete->hard_delete['t']))
			{
				trigger_error('NO_AUTH_OPERATION');
			}

			confirm_box(false, (sizeof($topic_ids) == 1) ? 'DELETE_TOPIC' : 'DELETE_TOPICS', $s_hidden_fields);
		}

		meta_refresh(3, $redirect_forum);
	}

	/**
	* MCP Delete Posts
	*/
	function mcp_delete_posts($post_ids)
	{
		global $auth, $user, $db, $phpEx, $phpbb_root_path;

		$redirect = request_var('redirect', build_url(array('_f_', 'action', 'quickmod')));
		$forum_id = request_var('f', 0);

		if (!is_array($post_ids))
		{
			$post_ids = array($post_ids);
		}

		$s_hidden_fields = build_hidden_fields(array(
			'post_id_list'	=> $post_ids,
			'f'				=> $forum_id,
			'action'		=> 'delete_post',
			'redirect'		=> $redirect)
		);

		include($phpbb_root_path . 'includes/mods/soft_delete_class.' . $phpEx);
		$delete = new delete();
		$delete->get_post_data($post_ids);
		$delete->hard_or_soft_check($post_ids, false);

		if (!count($delete->soft_delete['p']) && !count($delete->hard_delete['p']))
		{
			trigger_error('NO_AUTH_OPERATION');
		}

		if (count($delete->topic_data) == 1)
		{
			$redirect_topic = append_sid("{$phpbb_root_path}viewtopic.$phpEx", "f={$forum_id}&amp;t={$delete->post_data[$post_id[0]]['topic_id']}");
		}
		else
		{
			$redirect_topic = false;
		}

		$redirect_forum = append_sid("{$phpbb_root_path}viewforum.$phpEx", "f={$forum_id}");

		if (confirm_box(true))
		{	
			$delete->soft_delete_posts();
			$delete->hard_delete_topics();

			$message = $user->lang['POSTS_MCP_DELETE_SUCCESS'] . '<br/><br/>';

			if ($redirect_topic)
			{
				$message .= sprintf($user->lang['CLICK_RETURN_TOPIC'], "<a href=\"{$redirect_topic}\">", '</a><br/>');
				meta_refresh(3, $redirect_topic);
			}
			else
			{
				meta_refresh(3, $redirect_forum);
			}
			$message .= sprintf($user->lang['CLICK_RETURN_FORUM'], "<a href=\"{$redirect_forum}\">", '</a><br/>');

			trigger_error($message);
		}
		else
		{
			confirm_box(false, (count($delete->topic_data) == 1) ? 'DELETE_POST' : 'DELETE_POSTS', $s_hidden_fields);
		}

		if ($redirect_topic)
		{
			meta_refresh(3, $redirect_topic);
		}
		else
		{
			meta_refresh(3, $redirect_forum);
		}
	}
}
?>