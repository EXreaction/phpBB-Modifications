<?php
/**
* @package phpBB3 Soft Delete
* @copyright (c) 2007 EXreaction,
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'LOG_HARD_DELETE_POST'			=> '<strong>مشاركة مجذوفة</strong><br />> %s',
	'LOG_HARD_DELETE_TOPIC'			=> '<strong>موضوع مذوف</strong><br />> %s',
	'LOG_SOFT_DELETE_POST'			=> '<strong>مشاركة محذوفة بسرعة</strong><br />> %s',
	'LOG_SOFT_DELETE_TOPIC'			=> '<strong>موضوع محذوف بسرعة</strong><br />> %s',
	'LOG_UNDELETE_POST'				=> '<strong>مشاركة غير محذوفة</strong><br />> %s',
	'LOG_UNDELETE_TOPIC'			=> '<strong>موضوع غير محذوف</strong><br />> %s',
));

?>