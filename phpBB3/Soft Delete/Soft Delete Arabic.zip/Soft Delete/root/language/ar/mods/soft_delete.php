<?php
/**
* @package phpBB3 Soft Delete
* @copyright (c) 2007 EXreaction,
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'CLICK_RETURN_POST'				=> '%sإضغط هنا للرجوع للمشاركة%s',
	'CLICK_RETURN_TOPIC'			=> '%sإضغط هنا للرجوع للموضوع%s',
	'CLICK_RETURN_FORUM'			=> '%sإضغط هنا للرجوع للمنتدى%s',

	'FOUNDER_ONLY'					=> ' يجب أن تكون مؤسس منتدى للولوج لهذه الصفحة.',

	'HARD_DELETE'					=> 'حذف قوي',
	'HARD_DELETE_MESSAGE'			=> 'حذف الرسالة',
	'HARD_DELETE_MESSAGE_CONFIRM'	=> 'هل أنت متأكد من أنك تريد حذف هذه المشاركة بشكل دائم?  هذا لا يمكن الرجوع عنه.',
	'HARD_DELETE_TOPIC'				=> 'خذف قوي للموضوع',
	'HARD_DELETE_TOPIC_CONFIRM'		=> 'هل أنت متأكد من أنك تريد حذف هذا الموضوع بشكل دائم?  هذا لا يمكن الرجوع عنه.',
	'HARD_DELETE_TOPICS'			=> 'خذف قوي للمواضيع',
	'HARD_DELETE_TOPICS_CONFIRM'	=> 'هل أنت متأكد من أنك تريد حذف هذه المواضيع بشكل دائم?  هذا لا يمكن الرجوع عنه.',

	'LOG_HARD_DELETE_POST'			=> '<strong>مشاركة مجذوفة</strong><br />» %s',
	'LOG_HARD_DELETE_TOPIC'			=> '<strong>موضوع مذوف</strong><br />» %s',
	'LOG_SOFT_DELETE_POST'			=> '<strong>مشاركة محذوفة بسرعة</strong><br />» %s',
	'LOG_SOFT_DELETE_TOPIC'			=> '<strong>موضوع محذوف بسرعة</strong><br />» %s',
	'LOG_UNDELETE_POST'				=> '<strong>مشاركة غير محذوفة</strong><br />» %s',
	'LOG_UNDELETE_TOPIC'			=> '<strong>موضوع غير محذوف</strong><br />» %s',

	'POST_HARD_DELETE_SUCCESS'		=> 'تم حذف المشاركة بقوة بنجاح.',
	'POST_SOFT_DELETE_SUCCESS'		=> 'تم حذف المشاركة بسرعة بنجاح.',
	'POST_UNDELETE_SUCCESS'			=> 'المشاركة لم تحذف بنجاح.',
	'POSTS_MCP_DELETE_SUCCESS'		=> 'تم حذف المشاركات بنجاح.',

	'SOFT_DELETE_INSTALL_COMPLETE'	=> 'تغيرات قاعدة البيانات تمت بنجاح!<br />الرجاء خذف هذا الملف.',
	'SOFT_DELETE_MESSAGE'			=> 'حذف الرسالة بسرعة',
	'SOFT_DELETE_MESSAGE_CONFIRM'	=> 'هل أنت متأكد من أنك تريد حذف بسرعة هذه الرسالة ?',

	'TOPIC_HARD_DELETE_SUCCESS'		=> 'تم حذف الموضوع بقوة بنجاح.',
	'TOPIC_SOFT_DELETED'			=> 'هذا الموضوع تم حذفه.',
	'TOPIC_SOFT_DELETE_SUCCESS'		=> 'تم حذف الموضوع بسرعة بنجاح.',
	'TOPIC_UNDELETE_SUCCESS'		=> 'الموضوع لم يحذف بنجاح.',
	'TOPICS_MCP_DELETE_SUCCESS'		=> 'تم حذف الموضوع بنجاح.',

	'UNDELETE_POST'					=> 'لا تحذف المشاركة',
	'UNDELETE_POST_CONFIRM'			=> 'هل أنت متأكد من أنك تريد عدم حذف هذه المشاركة?',
));

?>