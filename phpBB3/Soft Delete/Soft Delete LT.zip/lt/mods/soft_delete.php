﻿<?php
/**
* @package phpBB3 Soft Delete
* @copyright (c) 2007 EXreaction,
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'CLICK_RETURN_POST'				=> '%sSpausk &#269;ia kad sugry&#382;tum i post&#261;%s',
	'CLICK_RETURN_TOPIC'			=> '%sspausk &#269;ia kad sugry&#382;tum į tem&#261;%s',
	'CLICK_RETURN_FORUM'			=> '%sSpausk &#269;ia kad sugry&#382;tum i forum&#261;%s',

	'FOUNDER_ONLY'					=> 'Tik &#303;kur&#279;jai gali matyti &#353;&#303; puslap&#303;',

	'HARD_DELETE'					=> 'Sunkus trinimas',
	'HARD_DELETE_MESSAGE'			=> 'i&#353;trinti &#382;inut&#281;',
	'HARD_DELETE_MESSAGE_CONFIRM'	=> 'Ar j&#363;s patvirtinate kad norite visam laikui i&#353;trinti &#353;i&#261; &#382;inut&#281;? Negali buti nebaigta.',
	'HARD_DELETE_TOPIC'				=> 'Sunkiai i&#353;tirnti temą',
	'HARD_DELETE_TOPIC_CONFIRM'		=> 'Ar j&#363;s patvirtinate kad norite visam laikui i&#353;trinti &#353;i&#261; tem&#261;? Negali buti nebaigta.',
	'HARD_DELETE_TOPICS'			=> 'Sunkiai i&#353;trinti temas',
	'HARD_DELETE_TOPICS_CONFIRM'	=> 'Ar j&#363;s patvirtinate kad norite visam laikui i&#353;trinti &#353;ias temas? Negali buti nebaigta.',

	'LOG_HARD_DELETE_POST'			=> '<strong>Žinut&#279; i&#353;trinta</strong><br />» %s',
	'LOG_HARD_DELETE_TOPIC'			=> '<strong>Tema i&#353;trinta</strong><br />» %s',
	'LOG_SOFT_DELETE_POST'			=> '<strong>Lengvai i&#353;trinta &#382;inut&#279;</strong><br />» %s',
	'LOG_SOFT_DELETE_TOPIC'			=> '<strong>Lengvai i&#353;trinta tema</strong><br />» %s',
	'LOG_UNDELETE_POST'				=> '<strong>Nei&#353;trintos &#382;inut&#279;s</strong><br />» %s',
	'LOG_UNDELETE_TOPIC'			=> '<strong>Nei&#353;trintos temos</strong><br />» %s',

	'POST_HARD_DELETE_SUCCESS'		=> 'Žinut&#279; sunkiai bet s&#279;kmingai i&#353;trinta.',
	'POST_SOFT_DELETE_SUCCESS'		=> 'Žinut&#279; sunkiai ir s&#279;kmingai i&#353;trinta.',
	'POST_UNDELETE_SUCCESS'			=> 'Žinut&#279; s&#279;kmingai attrinta.',
	'POSTS_MCP_DELETE_SUCCESS'		=> 'Žinut&#279;s sunkiai bet s&#279;kmingai i&#353;trintos.',

	'SOFT_DELETE_INSTALL_COMPLETE'	=> 'Duomenų baz&#279;s pakeitimai atlikti s&#279;kmingaiĄ<br />Pra&#353;ome i&#353;trinti &#353;i&#261; byl&#261;',
	'SOFT_DELETE_MESSAGE'			=> 'Lengvai i&#353;trink &#382;inutes',
	'SOFT_DELETE_MESSAGE_CONFIRM'	=> 'Ar tu nori lengvai i&#353;trinti &#353;i&#261; &#382;inut&#281;',

	'TOPIC_HARD_DELETE_SUCCESS'		=> 'Tema sunkiai bet s&#279;kmingai i&#353;trinta.',
	'TOPIC_SOFT_DELETED'			=> 'Tema buvo i&#353;trinta.',
	'TOPIC_SOFT_DELETE_SUCCESS'		=> 'Tema s&#279;kmingai ir lengvai i&#353;trinta.',
	'TOPIC_UNDELETE_SUCCESS'		=> 'Temos attrintos s&#279;kmingai.',
	'TOPICS_MCP_DELETE_SUCCESS'		=> 'Temos Buvo i&#353;trintos s&#279;kmingai.',

	'UNDELETE_POST'					=> 'Attrinti &#382;inut&#281;',
	'UNDELETE_POST_CONFIRM'			=> 'Ar j&#363;s isitikin&#281; kad norite attrinti &#353;i&#261; &#382;inut&#281;',
));

?>