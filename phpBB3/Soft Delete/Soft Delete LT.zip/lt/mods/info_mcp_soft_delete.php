<?php
/**
* @package phpBB3 Soft Delete
* @copyright (c) 2007 EXreaction,
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'LOG_HARD_DELETE_POST'			=> '<strong>I&#353;trinta &#382;inut&#279;</strong><br />> %s',
	'LOG_HARD_DELETE_TOPIC'			=> '<strong>I&#353;trinta Tema</strong><br />> %s',
	'LOG_SOFT_DELETE_POST'			=> '<strong>Lengvai I&#353;trinta &#382;inut&#279;</strong><br />> %s',
	'LOG_SOFT_DELETE_TOPIC'			=> '<strong>Lengvai I&#353;trinta tema</strong><br />> %s',
	'LOG_UNDELETE_POST'				=> '<strong>nei&#353;trinta &#382;inut&#279;</strong><br />> %s',
	'LOG_UNDELETE_TOPIC'			=> '<strong>nei&#353;trinta tema</strong><br />> %s',
));

?>