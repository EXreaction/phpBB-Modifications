<?php
/*
* START CONFIG
*/

// Ban the username?
$ban_username = true;

/* Set to the group ID if you want to move a user to a certain group.  This will set that group as default and remove the user from any other groups */
$move_to_group = 9;

// Delete the user's posts?
$delete_posts = true;

// Delete the user's avatar?
$delete_avatar = true;

// Delete the user's signature?
$delete_signature = true;

// Delete profile fields (website, IM addresses, location, etc)
$delete_profile_fields = true;

/*
* END CONFIG
*/

define('IN_PHPBB', true);

// Include files
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
require($phpbb_root_path . 'common.' . $phpEx);
require($phpbb_root_path . 'includes/functions_admin.' . $phpEx);
require($phpbb_root_path . 'includes/functions_user.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup(array('acp/common', 'mods/ocban'));
// End session management

// Have they authenticated (again) as an admin for this session?
if (!isset($user->data['session_admin']) || !$user->data['session_admin'])
{
	login_box('', $user->lang['LOGIN_ADMIN_CONFIRM'], $user->lang['LOGIN_ADMIN_SUCCESS'], true, false);
}

// Is user any type of admin?
if (!$auth->acl_get('a_'))
{
	trigger_error('NO_ADMIN');
}

$user_id = request_var('u', 0);

if (!$user_id)
{
	trigger_error('NO_USER');
}

$sql = 'SELECT * FROM ' . USERS_TABLE . ' WHERE user_id = ' . $user_id;
$result = $db->sql_query($sql);
$row = $db->sql_fetchrow($result);
$db->sql_freeresult($result);

if (!$row)
{
	trigger_error('NO_USER');
}
$username = $row['username'];

if (confirm_box(true))
{
	if ($ban_username)
	{
		user_ban('user', $username, 0, '', 0, '');
	}

	if ($delete_posts)
	{
		delete_posts('poster_id', $user_id);
	}

	if ($delete_avatar)
	{
		avatar_delete('user', $row, true);
	}

	if ($delete_signature)
	{
		$db->sql_query('UPDATE ' . USERS_TABLE . ' SET ' .
			$db->sql_build_array('UPDATE', array('user_sig' => '', 'user_sig_bbcode_uid' => '', 'user_sig_bbcode_bitfield' => '')) . '
			WHERE user_id = ' . $user_id);
	}

	if ($delete_profile_fields)
	{
		$sql_ary = array(
			'user_birthday' 	=> '',
			'user_from'			=> '',
			'user_icq'			=> '',
			'user_aim'			=> '',
			'user_yim'			=> '',
			'user_msnm'			=> '',
			'user_jabber'		=> '',
			'user_website'		=> '',
			'user_occ'			=> '',
			'user_interests'	=> '',
		);
		$db->sql_query('UPDATE ' . USERS_TABLE . ' SET ' .
			$db->sql_build_array('UPDATE', $sql_ary) . '
			WHERE user_id = ' . $user_id);
	}

	if ($move_to_group)
	{
		$sql = 'SELECT group_id FROM ' . USER_GROUP_TABLE . ' WHERE user_id = ' . $user_id;
		$result = $db->sql_query($sql);
		while ($row = $db->sql_fetchrow($result))
		{
			group_user_del($row['group_id'], array($user_id), array($username));
		}
		$db->sql_freeresult($result);

		group_user_add($move_to_group, array($user_id), array($username), false, true);
	}

	trigger_error(sprintf($user->lang['OCBAN_COMPLETE'], append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=viewprofile&amp;u=$user_id")));
}
else
{
	confirm_box(false, sprintf($user->lang['OCBAN_CONFIRM'],
			$username,
			($ban_username) ? '' : $user->lang['NOT'],
			($move_to_group) ? $move_to_group : $user->lang['N/A'],
			($delete_posts) ? '' : $user->lang['NOT'],
			($delete_avatar) ? '' : $user->lang['NOT'],
			($delete_signature) ? '' : $user->lang['NOT'],
			($delete_profile_fields) ? '' : $user->lang['NOT']
	));
}

?>