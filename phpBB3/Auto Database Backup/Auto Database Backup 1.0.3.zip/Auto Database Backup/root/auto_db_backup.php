<?php
/**
*
* @package Auto Database Backup
* @copyright (c) 2008 EXreaction
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined('IN_PHPBB'))
{
	// Stuff required to work with phpBB3
	define('IN_PHPBB', true);
	$phpbb_root_path = './';
	$phpEx = substr(strrchr(__FILE__, '.'), 1);
	include($phpbb_root_path . 'common.' . $phpEx);

	// Start session management
	$user->session_begin();
	$auth->acl($user->data);
	$user->setup('acp/database');

	if (!backup_db())
	{
		trigger_error('The database has already been backed up today.');
	}

	trigger_error('BACKUP_SUCCESS');
}

function backup_db()
{
	global $db, $phpbb_root_path, $phpEx, $table_prefix;

	$name = 'auto_backup/db_backup_' . date('Y-m-d');

	//Make sure this script can only be ran once per day
	if (file_exists($phpbb_root_path . 'store/' . $name . '.sql.gz'))
	{
		return false;
	}

	include($phpbb_root_path . 'includes/functions_install.' . $phpEx);
	include($phpbb_root_path . 'includes/acp/acp_database.' . $phpEx);

	@set_time_limit(1200);
	@set_time_limit(0);

	switch ($db->sql_layer)
	{
		case 'mysqli':
		case 'mysql4':
		case 'mysql':
			$extractor = new mysql_extractor(false, true, 'gzip', $name, time());
		break;

		case 'sqlite':
			$extractor = new sqlite_extractor(false, true, 'gzip', $name, time());
		break;

		case 'postgres':
			$extractor = new postgres_extractor(false, true, 'gzip', $name, time());
		break;

		case 'oracle':
			$extractor = new oracle_extractor(false, true, 'gzip', $name, time());
		break;

		case 'mssql':
		case 'mssql_odbc':
			$extractor = new mssql_extractor(false, true, 'gzip', $name, time());
		break;

		case 'firebird':
			$extractor = new firebird_extractor(false, true, 'gzip', $name, time());
		break;
	}

	$extractor->write_start($table_prefix);

	foreach (get_tables($db) as $table_name)
	{
		// Get the table structure
		$extractor->write_table($table_name);

		// Data
		$extractor->write_data($table_name);
	}

	$extractor->write_end();

	add_log('admin', 'LOG_DB_BACKUP');

	set_config('backup_last_gc', time(), true);

	return true;
}

?>