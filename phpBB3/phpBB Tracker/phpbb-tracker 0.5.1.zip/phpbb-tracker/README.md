This originated from the phpBB Tracker mod by JRSweets:
https://www.phpbb.com/community/viewtopic.php?p=4582065