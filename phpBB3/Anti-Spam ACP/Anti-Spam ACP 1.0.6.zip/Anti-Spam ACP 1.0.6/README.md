This is the Git repository for the Anti-Spam ACP modification for phpBB3.

Please see the release topic for more information: http://lithiumstudios.org/forum/viewtopic.php?f=31&t=941