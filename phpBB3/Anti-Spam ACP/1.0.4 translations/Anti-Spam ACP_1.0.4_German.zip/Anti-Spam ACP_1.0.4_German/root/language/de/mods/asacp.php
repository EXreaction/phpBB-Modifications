<?php
/**
*
* @package Anti-Spam ACP
* @copyright (c) 2008 EXreaction
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @translation by femu (http://die-muellers.org)
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ASACP_BAN'									=> 'Ein-Klick-Bann',
	'ASACP_BAN_ACTIONS'							=> 'Nachfolgendende Aktionen werden durchgeführt: %s',
	'ASACP_BAN_COMPLETE'						=> 'Du hast den Benutzer erfolgreich gebannt.<br /><br /><a href="%s">Klicke hier, um zum Benutzer Profil zurückzukehren.</a>',
	'ASACP_BAN_CONFIRM'							=> 'Bist du sicher, daß du den Benutzer %s bannen willst? Alle Aktionen die in den Anti-Spam ACP Einstellungen vorgenommen wurden, werden während des Ein-Klick-Bannes auf diesen Benutzer angewandt.<br /><br /><strong>Dies kann nicht rückgängig gemacht werden!</strong>',
	'ASACP_CREDITS'								=> 'Geschützt durch <a href="http://www.lithiumstudios.org" target="_blank">Anti-Spam ACP</a>',

	'ASACP_BAN_REASON'							=> 'Grund für den Bann',
	'ASACP_BAN_REASON_EXPLAIN'					=> 'Gib hier bitte den Grund für den Bann an (Privat).',
	'ASACP_BAN_REASON_SHOWN_TO_USER'			=> 'Grund für den Bann, der dem Benutzer angezeigt wird',
	'ASACP_BAN_REASON_SHOWN_TO_USER_EXPLAIN'	=> 'Wenn hier eine Nachricht eigegeben wurde, wird diese dem Benutzer angezeigt, der gebannt wurde.',
	'ASACP_CREDITS'								=> 'Geschützt durch <a href="http://www.lithiumstudios.org" target="_blank">Anti-Spam ACP</a>',
	'ASACP_EVIDENCE_SFS'						=> 'Wenn du Informationen an Stop Forum Spam übertragen willst, mußt du hier eine Begründung angeben.<br />(max. 8000 Zeichen)',
	'FOUNDER_ONLY'								=> 'Du müsst den Board Gründer Status haben, um auf diese Seite zugreifen zu können.',

	'IP_SEARCH'									=> 'IP Suche',

	'MORE'										=> 'Mehr',

	'PROFILE_SPAM_DENIED'						=> 'Eines oder mehrere der eingegebenen Felder wurden als Spam markiert.',

	'REMOVE_ASACP'								=> 'Entferne das Anti-Spam ACP',
	'REMOVE_ASACP_CONFIRM'						=> 'Bist du sicher, daß du die durch die Anti-Spam ACP Modifikation vorgenommenen Datenbankänderungen entfernen möchtest?<br /><br />Bevor du das tust, stelle sicher, das du die von der Modifikation vorgenommenen Änderungen an den Dateien rückgängig machst. Ansonsten werden die Datenbankeinträge  automatisch wieder hinzugefügt.',

	'SFS_SUBMIT'								=> 'Teile die Profil-Informationen <a href="http://www.stopforumspam.com/">Stop Forum Spam</a> mit',
	'SIGNATURE_DISABLED'						=> 'Du kannst keine Signatur verwenden.',
	'SPAM_DENIED'								=> 'Diese Nachricht wurde als Spam markiert und wurde verweigert.',
	'STOP_FORUM_SPAM'							=> 'Stop Forum Spam',
	'USER_FLAG'									=> 'Markiert',
	'USER_FLAGGED'								=> 'Benutzer markiert',
	'USER_FLAG_CONFIRM'							=> 'Bist du sicher, daß du den Benutzer %s markieren willst?',
	'USER_FLAG_NEW'								=> 'Neue Markierungen wurden gelogged',
	'USER_FLAG_SUCCESS'							=> 'Der Benutzer wurde erfolgreich markiert.',
	'USER_UNFLAG'								=> 'Markierung entfernen',
	'USER_UNFLAG_CONFIRM'						=> 'Bst du sicher, daß du die Markierung des Benutzer %s entfernen willst?',
	'USER_UNFLAG_SUCCESS'						=> 'Die Markierung des Benutzers wurde erfolgfreich entfernt.',
));

?>