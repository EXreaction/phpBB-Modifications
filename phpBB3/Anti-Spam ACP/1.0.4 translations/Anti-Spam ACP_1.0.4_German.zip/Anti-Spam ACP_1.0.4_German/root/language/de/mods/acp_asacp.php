<?php
/**
*
* @package Anti-Spam ACP
* @copyright (c) 2008 EXreaction
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @translation by femu (http://die-muellers.org)
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ADD_WORD'									=> 'Wort hinzufügen',
	'ALLOW_FIELD'								=> 'Erlauben',
	'ASACP_BAN_CLEAR_OUTBOX'					=> 'Leere die PN Ausgangsbox des Benutzers',
	'ASACP_BAN_CLEAR_OUTBOX_EXPLAIN'			=> 'Entferne alle PNs aus der Ausgangsbox des Benutzers',
	'ASACP_BAN_DEACTIVATE_USER'					=> 'Konto deaktivieren',
	'ASACP_BAN_DEACTIVATE_USER_EXPLAIN'			=> 'Deaktiviere das Konto des Benutzers',
	'ASACP_BAN_DELETE_AVATAR'					=> 'Entferne Avatar',
	'ASACP_BAN_DELETE_AVATAR_EXPLAIN'			=> 'Entferne das Benutzer Avatar, wenn ein Ein-Klick-Bann-Vorgang durchgeführt wird',
	'ASACP_BAN_DELETE_POSTS'					=> 'Entferne Beiträge',
	'ASACP_BAN_DELETE_POSTS_EXPLAIN'			=> 'Entferne die Benutzer Beiträge, wenn ein Ein-Klick-Bann-Vorgang durchgeführt wird',
	'ASACP_BAN_DELETE_PROFILE_FIELDS'			=> 'Entferne Profil Felder',
	'ASACP_BAN_DELETE_PROFILE_FIELDS_EXPLAIN'	=> 'Entferne die Profil Informationen des Benutzers, wenn ein Ein-Klick-Bann-Vorgang durchgeführt wird',
	'ASACP_BAN_DELETE_SIGNATURE'				=> 'Entferne Signatur',
	'ASACP_BAN_DELETE_SIGNATURE_EXPLAIN'		=> 'Entferne die Signatur des Benutzers, wenn ein Ein-Klick-Bann-Vorgang durchgeführt wird',
	'ASACP_BAN_MOVE_TO_GROUP'					=> 'Gruppe ändern',
	'ASACP_BAN_MOVE_TO_GROUP_EXPLAIN'			=> 'Füge den Benutzer zur folgenden Gruppe hinzu, wenn ein Ein-Klick-Bann-Vorgang durchgeführt wird',
	'ASACP_BAN_SETTINGS'						=> 'Ein-Klick-Bann Einstellungen',
	'ASACP_BAN_USERNAME'						=> 'Banne Benutzername',
	'ASACP_BAN_USERNAME_EXPLAIN'				=> 'Banne den Benutzernamen, wenn ein Ein-Klick-Bann-Vorgang durchgeführt wird',
	'ASACP_ENABLE'								=> 'Anti-Spam ACP einschalten',
	'ASACP_ENABLE_EXPLAIN'						=> 'Auf <strong>Nein</strong> setzen, um das komplette Anti-Spam ACP-System auszuschalten (damit werden aber nicht Funtionalitäten, wie z.B. der Ein-Klick-Bann deaktiviert).',
	'ASACP_FLAG_LIST_EXPLAIN'					=> 'Eine Liste aller zur Zeit markierten Benutzer.',
	'ASACP_IP_SEARCH_BOT_CHECK'					=> 'Bot Prüfung',
	'ASACP_IP_SEARCH_EXPLAIN'					=> 'Durchsuchen des ganzen Forums nach Handlungen, die von einer bestimmten IP-Adresse gemachten wurden.',
	'ASACP_IP_SEARCH_FLAG_LOG'					=> 'Markierungs Log',
	'ASACP_IP_SEARCH_LOGS'						=> 'Log Aktionen',
	'ASACP_IP_SEARCH_POLL_VOTES'				=> 'Umfragen',
	'ASACP_IP_SEARCH_POSTS'						=> 'Beiträge',
	'ASACP_IP_SEARCH_PRIVMSGS'					=> 'Private Nachrichten',
	'ASACP_IP_SEARCH_SPAM_LOG'					=> 'Spam Log',
	'ASACP_IP_SEARCH_USERS'						=> 'Benutzer',
	'ASACP_LOG'									=> 'Spam Log einschalten',
	'ASACP_LOG_EXPLAIN'							=> 'Wenn ausgeschaltet, werden keine neuen Einträge zum Spam Log hinzugefügt.',
	'ASACP_NOTIFY_NEW_FLAG'						=> 'Bei neuem Markierungs Log Eintrag benachrichtigen',
	'ASACP_NOTIFY_NEW_FLAG_EXPLAIN'				=> 'Benachrichtigt authorisierte Benutzer, sobald dem Markierungs Log ein neuer Eintrag hinzugefügt wird.',
	'ASACP_PROFILE_DURING_REG'					=> 'Erlaubte Felder während der Registratierung zeigen',
	'ASACP_PROFILE_DURING_REG_EXPLAIN'			=> 'Wenn hier <strong>Ja</strong> gesetzt ist, wird jedes, als zugelassen markierte Feld, während der Registrierung angezeigt (außer das Signatur-Feld).',
	'ASACP_PROFILE_FIELDS'						=> 'Profil Felder',
	'ASACP_PROFILE_FIELDS_EXPLAIN'				=> 'Erlaubt dir, Beschränkungen einzusetzen, wenn Profil Felder von Benutzern ausgefüllt werden können. <br /><br /><strong>Nach dem Speichern werden alle Felder bei allen Benutzern zurückgesetzt, um diejenigen Felder zu leeren, die den Benutzern nach den neuen Regeln nicht erlaubt sind.',
	'ASACP_REGISTER_SETTINGS'					=> 'Registrierungs Einstellungen',
	'ASACP_REG_CAPTCHA'							=> 'Registrierungs Captcha',
	'ASACP_REG_CAPTCHA_EXPLAIN'					=> 'Dies kontrolliert die Anzeige des vor dem eigentlichen Registrierungs Prozesses gezeigten Captchas.<br />Wenn eingeschaltet, solltest du die Einstellung "Visuellen Bestätigungscode für Registrierungen aktivieren" im Abschnitt Allgemein->Board-Konfiguration->Registrierung auf Nein setzen. So braucht der Benutzer keine zwei Captchas auszufüllen, um sich zu registrieren.',
	'ASACP_SETTINGS_UPDATED'					=> 'Anti-Spam ACP Einstellungen erfolgreich aktualisiert.',
	'ASACP_SFS_ACTION'							=> 'Stop Forum Spam Aktion',
	'ASACP_SFS_ACTION_EXPLAIN'					=> 'Die Aktion durchführen, wenn ein Konto mit den gespeicherten Profil-Informationen von <a href="http://www.stopforumspam.com/">Stop Forum Spam</a> registriert wird',
	'ASACP_SFS_KEY'								=> 'Stop Forum Spam Schlüssel',
	'ASACP_SFS_KEY_EXPLAIN'						=> 'Wenn du die Möglichkeit haben willst, Informationen an <a href="http://www.stopforumspam.com/">Stop Forum Spam</a> weiter zu geben, melde dich für einen API Schlüssel <a href="http://www.stopforumspam.com/signup">hier</a> an und gib ihn in dieses Feld ein.',
	'ASACP_SFS_MIN_FREQ'						=> 'Minimale Frequenz',
	'ASACP_SFS_MIN_FREQ_EXPLAIN'				=> 'Minimale Frequenz (Häufigkeit, die dieser Account durch andere gemeldet wurde) bevor eine Aktion bei diesem Konto aufgrund der Informationen von <a href="http://www.stopforumspam.com/">Stop Forum Spam</a> durchgeführt wird',
	'ASACP_SFS_SETTINGS'						=> 'Stop Forum Spam Einstellungen',
	'ASACP_SPAM_WORDS_ENABLE'					=> 'Spam Wörter-Funktion einschalten',
	'ASACP_SPAM_WORDS_ENABLE_EXPLAIN'			=> 'Auf <strong>Nein</strong> setzen, um das komplette Anti-Spam-Wort System auszuschalten.',
	'ASACP_SPAM_WORDS_EXPLAIN'					=> 'Eingabe und Verwalten von Triggerwörtern für das Anti-Spam-Wort System.',
	'ASACP_SPAM_WORDS_FLAG_LIMIT'				=> 'Markierungszähler bevor jemand als Spam zu markieren ist',
	'ASACP_SPAM_WORDS_FLAG_LIMIT_EXPLAIN'		=> 'Wenn die Nachrichten so oft oder öfter als Spam markiert werden, wird die Veröffentlichung entweder verweigert oder eine Genehmigung erwartet.',
	'ASACP_SPAM_WORDS_GUEST_ALWAYS'				=> 'Immer nach Gästen prüfen',
	'ASACP_SPAM_WORDS_GUEST_ALWAYS_EXPLAIN'		=> 'Dies ignoriert die Beitragszähler Begrenzung für Gäste und wird die Spam-Wörter für sie überprüfen.',
	'ASACP_SPAM_WORDS_PM_ACTION'				=> 'Aktion für Private Nachrichten Spam',
	'ASACP_SPAM_WORDS_PM_ACTION_EXPLAIN'		=> 'Wähle die Aktion aus, die du durchführen möchtest, wenn eine private Nachricht als Spam markiert wurde.',
	'ASACP_SPAM_WORDS_POSTING_ACTION'			=> 'Aktion für Spam-Beiträge',
	'ASACP_SPAM_WORDS_POSTING_ACTION_EXPLAIN'	=> 'Wähle die Aktion aus, die du durchführen möchtest, wenn ein Beitrag als Spam markiert wurde.',
	'ASACP_SPAM_WORDS_POST_LIMIT'				=> 'Beitragszähler',
	'ASACP_SPAM_WORDS_POST_LIMIT_EXPLAIN'		=> 'Wenn der Beitragszähler eines Benutzers höher ist als hier angegebene, wird die Spam-Wort-Kontrolle auf diesen Benutzer nicht angewendet.<br /><strong>Wenn du hier 0 eingibst, ist die Spam-Wort-Kontrolle immer aktiv.</strong>',
	'ASACP_SPAM_WORDS_PROFILE_ACTION'			=> 'Aktion für Spam-Profil-Informationen',
	'ASACP_SPAM_WORDS_PROFILE_ACTION_EXPLAIN'	=> 'Wähle die Aktion aus, die du durchführen möchtest, wenn Informationen in ein als Spam markiertes Benutzerprofil eingegeben werden.',
	'ASACP_USER_FLAG_ENABLE'					=> 'Benutzer Markierungssystem einschalten',
	'ASACP_USER_FLAG_ENABLE_EXPLAIN'			=> 'Wenn du <strong>Nein</strong> ausgewählt hast, können keine Benutzer markiert werden. Und alle vorher markierten Benutzer werden nicht mehr länger im Markierungs-Log gespeichert.',
	'ASACP_VERSION'								=> 'Versionsinformation',

	'CLICK_CHECK_NEW_VERSION'					=> 'Klicke %shier%s, um auf eine neue Version zu überprüfen.',
	'CLICK_GET_NEW_VERSION'						=> 'Klicke %shier%s, um die aktuelle Version beizubehalten.',

	'DELETE_SPAM_WORD'							=> 'Spam Wort löschen',
	'DELETE_SPAM_WORD_CONFIRM'					=> 'Bist du sicher, daß du dieses Spam-Wort löschen willst?',
	'DENY_FIELD'								=> 'Verweigern',
	'DENY_SUBMISSION'							=> 'Übertragung verweigern',

	'FLAG_USER'									=> 'Benutzer markieren',

	'INSTALLED_VERSION'							=> 'Installierte Version',
	'INTERESTS_POST_COUNT'						=> 'Beitragszähler für Interessen',
	'INTERESTS_POST_COUNT_EXPLAIN'				=> 'Wenn der Beitragszähler für Interessen eingestellt ist, kann der Benutzer nach Erreichen dieser Zahl an Beiträgen, seine Interessen im entsprechenden Profil-Feld eintragen.',

	'LATEST_VERSION'							=> 'Aktuelle Version',
	'LOCATION_POST_COUNT'						=> 'Höhe des Beitragszähler',
	'LOCATION_POST_COUNT_EXPLAIN'				=> 'Wenn die Höhe des Beitragszählers angegeben ist, ist es dem Benutzer möglich, dieses Feld auszufüllen, wenn er die entsprechende Anzahl an Beiträgen erreicht hat.',
	'LOG_VIEW_POST'								=> '%sBeiträge sehen%s',
	'LOG_VIEW_PROFILE'							=> '%sProfile sehen%s',

	'NOTHING'									=> 'Nichts',
	'NOT_AVAILABLE'								=> 'Nicht möglich',
	'NO_ITEMS'									=> 'Keine Ergebnisse von der eingegebenen IP-Adresse.',
	'NO_SPAM_WORD'								=> 'Das gewählte Wort existiert nicht.',
	'NO_SPAM_WORDS'								=> 'Keine Spam-Wörter in der Datenbank.',

	'OCCUPATION_POST_COUNT'						=> 'Beitragszähler Aktivität',
	'OCCUPATION_POST_COUNT_EXPLAIN'				=> 'Wenn der Beitragszähler für Aktivität eingestellt ist, hat der Benutzer die Möglichkeit, dieses Feld auszufüllen, sobald er die vorgegebene Anzahl an Beiträgen erreicht hat.',

	'POST_COUNT'								=> 'Beitragszähler',

	'REGEX'										=> 'Regulärer Ausdruck',
	'REGEX_AUTO'								=> 'Automatisches Ersetzen',
	'REGEX_AUTO_EXPLAIN'						=> 'Wähle ja, damit das System automatisch ein dem Spam-Wort entsprechenden regulären Ausdruck ersetzt.',
	'REGEX_EXPLAIN'								=> 'Wähle ja, um ein - dem Spam Text entsprechenden - regulären Ausdruck zu benutzen.',
	'REQUIRE_ADMIN_ACTIVATION'					=> 'Erfordert Aktivität eines Administrators',
	'REQUIRE_APPROVAL'							=> 'Erfordert Zustimmung eines Moderators',
	'REQUIRE_FIELD'								=> 'Erfordert',
	'REQUIRE_USER_ACTIVATION'					=> 'Erfordert Aktivität des Benutzer',

	'SIGNATURE_POST_COUNT'						=> 'Beitragszähler für Signatur',
	'SIGNATURE_POST_COUNT_EXPLAIN'				=> 'Wenn der Beitragszähler für die Signature gesetzt ist, ist es dem Benutzer möglich, dieses Feld auszufüllen, sobald er die vorgegebenen Anzahl an Beiträgen erreicht hat.<br /><br />Erforderliche Einstellungen für die Signatur müssen nicht den anderen Einstellungen entsprechen. Die Signatur kann bei der Registrierung als nicht erforderlich eingestellt werden.',
	'SPAM_WORD_ADD_SUCCESS'						=> 'Spam Wort erfolgreich hinzugefügt.',
	'SPAM_WORD_DELETE_SUCCESS'					=> 'Spam Wort erfolgreich entfernt.',
	'SPAM_WORD_EDIT_SUCCESS'					=> 'Spam Wort erfolgreich bearbeitet.',
	'SPAM_WORD_TEXT'							=> 'Spam Wort Text',
	'SPAM_WORD_TEXT_EXPLAIN'					=> 'Wenn ein regulärer Ausdruck benutzt wird, stelle sicher, daß du es nach <a href="http://us2.php.net/manual/en/function.preg-match.php">preg_match</a> richtg formatierst (einschließlich der Musterbegrenzungszeichens)',

	'UCP_AIM_POST_COUNT'						=> 'Beitragszähler für AOL Instant Messenger',
	'UCP_AIM_POST_COUNT_EXPLAIN'				=> 'Wenn der Beitragszähler für den AOL Instant Messenger gesetzt ist, ist es den Benutzern möglich, das Feld auszufüllen, sobald die vorgegebene Anzahl an Beiträgen erreicht worden sind.',
	'UCP_ICQ_POST_COUNT'						=> 'Beitragszähler für die ICQ-Nummer',
	'UCP_ICQ_POST_COUNT_EXPLAIN'				=> 'Wenn der Beitragszähler für die ICQ-Nummer gesetzt ist, ist es den Benutzern möglich, das Feld auszufüllen, sobald sie die vorgegebene Anzahl an Beiträgen erreicht haben.',
	'UCP_JABBER_POST_COUNT'						=> 'Beitragszähler für die Jabber-Addresse',
	'UCP_JABBER_POST_COUNT_EXPLAIN'				=> 'Wenn der Beitragszähler für die Jabber-Addresse gesetzt ist, ist es den Benutzern möglich, das Feld auszufüllen, sobald sie die vorgegebene Anzahl an Beiträgen erreicht haben.',
	'UCP_MSNM_POST_COUNT'						=> 'Beitragszähler für den MSN Messenger',
	'UCP_MSNM_POST_COUNT_EXPLAIN'				=> 'Wenn der Beitragszähler für den MSN Messenger gesetzt ist, ist es den Benutzern möglich, das Feld auszufüllen, sobald sie die vorgegebene Anzahl an Beiträgen erreicht haben.',
	'UCP_YIM_POST_COUNT'						=> 'Beitragszähler für den Yahoo Messenger',
	'UCP_YIM_POST_COUNT_EXPLAIN'				=> 'Wenn der Beitragszähler für den Yahoo Messenger gesetzt ist, ist es den Benutzern möglich, das Feld auszufüllen, sobald sie die vorgegebene Anzahl an Beiträgen erreicht haben.',

	'VERSION'									=> 'Version',

	'WEBSITE_POST_COUNT'						=> 'Beitragszähler für Webseiten',
	'WEBSITE_POST_COUNT_EXPLAIN'				=> 'Wenn der Beitragszähler für die Webseite gesetzt ist, ist es den Benutzern möglich, das Feld auszufüllen, sobald sie die vorgegebene Anzahl an Beiträgen erreicht haben.',
));

?>