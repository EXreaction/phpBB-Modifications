<?php
/**
*
* @package Anti-Spam ACP
* @copyright (c) 2008 EXreaction
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @translation by femu (http://die-muellers.org)
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ANTISPAM'						=> 'Anti-Spam',
	'ASACP_FLAG_LIST'				=> 'Liste der markierten Benutzer',
	'ASACP_FLAG_LOG'				=> 'Flag Log',
	'ASACP_IP_SEARCH'				=> 'IP Suche',
	'ASACP_PROFILE_FIELDS'			=> 'Profil Felder',
	'ASACP_SETTINGS'				=> 'Anti-Spam ACP Einstellungen',
	'ASACP_SPAM_LOG'				=> 'Spam Log',
	'ASACP_SPAM_WORDS'				=> 'Spam Wörter',

	'LOG_ADDED_POST'				=> 'Hat ein Beitrag hinzugefügt',
	'LOG_ALTERED_PROFILE'			=> 'Hat die Profil informationen geändert',
	'LOG_ALTERED_SIGNATURE'			=> 'Hat die Signatur geändert',
	'LOG_ASACP_SETTINGS'			=> 'Hat die Anti-Spam ACP Einstellungen geändert',
	'LOG_CLEAR_FLAG_LOG'			=> 'Hat das Flag Log gelöscht',
	'LOG_CLEAR_SPAM_LOG'			=> 'Hat das Spam Log gelöscht',
	'LOG_EDITED_POST'				=> 'Hat einen Beitrag bearbeitet',
	'LOG_INCORRECT_CODE'			=> 'Hat einen falschen Bestätigungscode eingegeben.',
	'LOG_INCORRECT_CODE_DATA'		=> 'Angezeigter Code: "%s"<br />Eingegebener Code: "%s"',
	'LOG_USER_SFS_ACTIVATION'		=> '%s hat sich registriert, wurde aber von Stop Forum Spam als möglicher Spammer markiert.',
	'LOG_SENT_PM'					=> 'Hat ein PN gesendet<br />An folgende Benutzer: %s',
	'LOG_SPAM_PM_DENIED'			=> 'Eine private Nachricht wurde als Spam markiert und daher nicht gesendet.<br />Die Überschrift lautete:<br />%s<br /><br />Die Nachricht lautete:<br />%s',
	'LOG_SPAM_POST_DENIED'			=> 'Ein Beitrag wurde als Spam markiert und daher nicht gesendet.<br />Die Überschrift lautete:<br />%s<br /><br />Die Nachricht lautete:<br />%s',
	'LOG_SPAM_PROFILE_DENIED'		=> 'Ein oder mehrere Profilfelder wurden als Span markiert.<br />Die übertragenen Informationen lauteten:<br /><br />%s',
	'LOG_SPAM_SIGNATURE_DENIED'		=> 'Die Signatur wurde als Spam markiert.<br />Die Signatur lautete:<br />%s',
	'LOG_USER_FLAGGED'				=> '%s wurde markiert.',
	'LOG_USER_UNFLAGGED'			=> 'Die Markierung von %s wurde entfernt.',
));

?>