<?php
/**
*
* @package Anti-Spam ACP [Slovak] preložené s prekladačom Google + PC Translator, upravil J.P alias Brahma
* @copyright (c) 2008 EXreaction
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ANTISPAM'						=> 'Anti-Spam',
	'ASACP_FLAG_LIST'				=> 'Označený, Zoznam užívateľov',
	'ASACP_FLAG_LOG'				=> 'Zaznamenaný Identifikátory',
	'ASACP_IP_SEARCH'				=> 'Vyhľadanie IP',
	'ASACP_PROFILE_FIELDS'			=> 'Pole Profilu',
	'ASACP_SETTINGS'				=> 'Nastavenia ACP Anti-Spam',
	'ASACP_SPAM_LOG'				=> 'Zaznamenaný Spam',
	'ASACP_SPAM_WORDS'				=> 'Spamovanie slov',

	'LOG_ADDED_POST'				=> 'Pridaný príspevok',
	'LOG_ALTERED_PROFILE'			=> 'Zmenené informácie v profile',
	'LOG_ALTERED_SIGNATURE'			=> 'Zmenený podpis',
	'LOG_ASACP_SETTINGS'			=> 'Updated Anti-Spam ACP Settings',
	'LOG_CLEAR_SPAM_LOG'			=> 'Prečistil Protokol Spamov',
	'LOG_EDITED_POST'				=> 'Upravil príspevok',
	'LOG_INCORRECT_CODE'			=> 'Zadaný bol nesprávny potvrdzovací kód.',
	'LOG_INCORRECT_CODE_DATA'		=> 'Zobrazený Kód: "%s"<br />Zadaný Kód: "%s"',
	'LOG_USER_SFS_ACTIVATION'		=> '%s registrovaný bol označený ako možný spam účet bol Stopnutý Spam Fórom.',
	'LOG_SENT_PM'					=> 'Poslal PM<br />Do zoznamu: %s',
	'LOG_SPAM_PM_DENIED'			=> 'Súkromná správa bola označená ako spam a teda bola zakázaná, nebude odslaná.<br />Predmet správy bol:<br />%s<br /><br />Správa bola:<br />%s',
	'LOG_SPAM_POST_DENIED'			=> 'Príspevok bol označený ako spam a teda bol zakázaný, nebude odslaný.<br />Predmet správy bol:<br />%s<br /><br />Správa bola:<br />%s',
	'LOG_SPAM_PROFILE_DENIED'		=> 'Viac ako jedno zadanie v poli profilu bolo označené ako spam.<br />Informácia bola podaná:<br /><br />%s',
	'LOG_SPAM_SIGNATURE_DENIED'		=> 'Podpis bol označený ako spam.<br />Podpis bol:<br />%s',
	'LOG_USER_FLAGGED'				=> '%s bol označený.',
	'LOG_USER_UNFLAGGED'			=> 'Označený %s bol odstránený.',

	'acl_a_asacp'					=> array(
		'lang'						=> 'Môže riadiť Anti-Spam ACP',
		'cat'						=> 'nastavenie',
	),

	'acl_a_asacp_ban'				=> array(
		'lang'						=> 'Can One Click Ban users',
		'cat'						=> 'nastavenie',
	),

	'acl_a_asacp_ip_search'			=> array(
		'lang'						=> 'Môže použiť Vyhľadanie IP',
		'cat'						=> 'nastavenie',
	),

	'acl_a_asacp_profile_fields'	=> array(
		'lang'						=> 'Môže meniť nastavenie Polí Profilu',
		'cat'						=> 'nastavenie',
	),

	'acl_a_asacp_spam_log'			=> array(
		'lang'						=> 'Môže zobraziť Peotokol Spamu',
		'cat'						=> 'nastavenie',
	),

	'acl_a_asacp_spam_words'		=> array(
		'lang'						=> 'Môže spravovať Spam Slov',
		'cat'						=> 'nastavenie',
	),

	'acl_a_asacp_user_flag'			=> array(
		'lang'						=> 'Môže Identifikovať Uživateľov, zobraziť si protokol identifikovaných, a zobraziť si Zoznam Označených Userov',
		'cat'						=> 'nastavenie',
	),

));

?>