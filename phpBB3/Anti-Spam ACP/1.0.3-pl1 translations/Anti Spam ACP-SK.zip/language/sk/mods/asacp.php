<?php
/**
*
* @package Anti-Spam ACP [Slovak] preložené s prekladačom Google + PC Translator, upravil J.P alias Brahma
* @copyright (c) 2008 EXreaction
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ASACP_BAN'				=> 'Po kliknutí Ban',
	'ASACP_BAN_COMPLETE'	=> 'Užívateľ bol úspešne zakázaný.<br /><br /><a href="%s">Sem kliknite a prejdem do profilu uživateľa.</a>',
	'ASACP_BAN_CONFIRM'		=> 'Ste si istí, mám zabanovať užívateľa? Všetky výkony, ako je uvedené v nastaveniach Anti-Spam ACP sa uskutočnia v priebehu Prvého Kliknutia tohto užívateľa keď bude na fóre.<br /><br /><strong>Tento výkon za už nedá potom vrátiť späť!</strong>',
	'ASACP_CREDITS'			=> 'Protected by <a href="http://www.lithiumstudios.org" target="_blank">Anti-Spam ACP</a>',

	'FOUNDER_ONLY'			=> 'Musíte byť zakladateľ fóra aby ste mal prístup k tejto stránke.',

	'IP_SEARCH'				=> 'Vyhladanie IP',

	'MORE'					=> 'Viac',

	'PROFILE_SPAM_DENIED'	=> 'V zadaní niekoľko polí bolo označených ako spam.',

	'REMOVE_ASACP'			=> 'Odstrániť Anti-Spam ACP',
	'REMOVE_ASACP_CONFIRM'	=> 'Ste si istí, mám odstrániť databázu a zmeny vykonané módom Anti-Spam ACP?<br /><br />Predtým než tak urobíte overte si, či ste odstránili editáciu módu zo súborov.',

	'SFS_SUBMIT'			=> 'Predložte informáciu o profile do <a href="http://www.stopforumspam.com/">Stop Forum Spam</a>',
	'SIGNATURE_DISABLED'	=> 'Nemáte povolené použiť podpis.',
	'SPAM_DENIED'			=> 'Táto správa bola označená ako spam a bola zamietnutá.',

	'USER_FLAG'				=> 'Označenie',
	'USER_FLAGGED'			=> 'Označenie Uživateľa',
	'USER_FLAG_CONFIRM'		=> 'Ste si istí, že chcete označiť užívateľa %s?',
	'USER_FLAG_NEW'			=> 'Nový Identit Prihlásenia',
	'USER_FLAG_SUCCESS'		=> 'Užívateľ bol označený úspešne.',
	'USER_UNFLAG'			=> 'Odstrániť Identifikovanie',
	'USER_UNFLAG_CONFIRM'	=> 'Ste si istí, mám odstrániť označenie užívateľa %s?',
	'USER_UNFLAG_SUCCESS'	=> 'Označenie užívateľa bolo odstránené úspešne.',
));

?>