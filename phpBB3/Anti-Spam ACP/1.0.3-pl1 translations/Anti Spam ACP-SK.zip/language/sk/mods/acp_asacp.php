<?php
/**
*
* @package Anti-Spam ACP [Slovak] preložené s prekladačom Google + PC Translator, upravil J.P alias Brahma
* @copyright (c) 2008 EXreaction
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ADD_WORD'									=> 'Pridať slovo',
	'ALLOW_FIELD'								=> 'Povoliť',
	'ASACP_BAN_CLEAR_OUTBOX'					=> 'Odstránim uživateľove PM, Pošta na odoslanie',
	'ASACP_BAN_CLEAR_OUTBOX_EXPLAIN'			=> 'Odstránim všetky Súkromné Správy, Pošta na odoslanie',
	'ASACP_BAN_DELETE_AVATAR'					=> 'Odstránim Avatar',
	'ASACP_BAN_DELETE_AVATAR_EXPLAIN'			=> 'Odstránim uživatelov Avatar po Prvom Kliknutí, ak je vo výkone (vyhostenia) Ban.',
	'ASACP_BAN_DELETE_POSTS'					=> 'Odstránim príspevky',
	'ASACP_BAN_DELETE_POSTS_EXPLAIN'			=> 'Odstránim uživatelove príspevky po Prvom Kliknutí, ak je vo výkone (vyhostenia) Ban.',
	'ASACP_BAN_DELETE_PROFILE_FIELDS'			=> 'Vymažem pole profilu',
	'ASACP_BAN_DELETE_PROFILE_FIELDS_EXPLAIN'	=> 'Odstránim užívateľský Profil po Prvom Kliknutí, ak je vo výkone (vyhostenia) Ban.',
	'ASACP_BAN_DELETE_SIGNATURE'				=> 'Odstránim Podpis',
	'ASACP_BAN_DELETE_SIGNATURE_EXPLAIN'		=> 'Odstránim uživatelov Podpis po Prvom Kliknutí, ak je vo výkone (vyhostenia) Ban.',
	'ASACP_BAN_MOVE_TO_GROUP'					=> 'Presuniem do skupiny',
	'ASACP_BAN_MOVE_TO_GROUP_EXPLAIN'			=> 'Presuniem uživateľa do nasledujúcej skupiny po Prvom Kliknutí, ak je vo výkone (vyhostenia) Ban.',
	'ASACP_BAN_SETTINGS'						=> 'Nastavenie Prvé Kliknutie, Ban',
	'ASACP_BAN_USERNAME'						=> 'Ban Uživateľovho názvu',
	'ASACP_BAN_USERNAME_EXPLAIN'				=> 'Ban uživateľovho názvu po Prvom Kliknutí, ak je vo výkone (vyhostenia) Ban',
	'ASACP_ENABLE'								=> 'Povoliť ACP Anti-Spam',
	'ASACP_ENABLE_EXPLAIN'						=> 'Ak je nastavené na Nie bude celý systém v ACP Anti-Spam vypnutý.',
	'ASACP_FLAG_LIST_EXPLAIN'					=> 'Zoznam všetkých aktuálne označených užívateľov.',
	'ASACP_IP_SEARCH_BOT_CHECK'					=> 'Preverenie Botov',
	'ASACP_IP_SEARCH_EXPLAIN'					=> 'Prehľadanie celého fóra ohľadom výkonov, vytvorené z určitej IP Adresy.',
	'ASACP_IP_SEARCH_FLAG_LOG'					=> 'Protokol Identifikovania',
	'ASACP_IP_SEARCH_LOGS'						=> 'Protokol Výkonov',
	'ASACP_IP_SEARCH_POLL_VOTES'				=> 'Anketa hlasovanie',
	'ASACP_IP_SEARCH_POSTS'						=> 'Príspevky',
	'ASACP_IP_SEARCH_PRIVMSGS'					=> 'Súkromné Správy',
	'ASACP_IP_SEARCH_SPAM_LOG'					=> 'Protokol Spamu',
	'ASACP_IP_SEARCH_USERS'						=> 'Uživatelia',
	'ASACP_LOG'									=> 'Povoliť Protokolovanie Spamu',
	'ASACP_LOG_EXPLAIN'							=> 'Ak je nastavené na Nie nové položky nebudú pridané do záznamenania spamu.',
	'ASACP_NOTIFY_NEW_FLAG'						=> 'Upozorniť na nový identit protokol vstupu',
	'ASACP_NOTIFY_NEW_FLAG_EXPLAIN'				=> 'Upozorním oprávnených uživateľov, keď je nová položka pridaná do protokolu identifikátora.',
	'ASACP_PROFILE_DURING_REG'					=> 'Povolím zobraziť polia profilu počas registrácie',
	'ASACP_PROFILE_DURING_REG_EXPLAIN'			=> 'Ak je nastavené na Áno, všetky polia povolím v nastavení profilu (okrem časti pre podpis).',
	'ASACP_PROFILE_FIELDS'						=> 'Pole Profilu',
	'ASACP_PROFILE_FIELDS_EXPLAIN'				=> 'Umožňuje nastaviť obmedzenia, vyplnenie pola v profile uživateľov.<br /><br /><strong>Po zadaní budú, všetkým uživateľom všetky polia resynchronizované podľa nových pravidiel, prečistia sa poľia ktoré boli už vyplnené.</strong>',
	'ASACP_REGISTER_SETTINGS'					=> 'Nastavenie Registrácie',
	'ASACP_REG_CAPTCHA'							=> 'Pre-Registrácia Captcha',
	'ASACP_REG_CAPTCHA_EXPLAIN'					=> 'Toto riadi zobrazenie pôvodného captcha zobrazeného pred procesom registrácii.<br />Ak je zadanie povolené, mali by ste zvážiť jeho vypnutie a "Povoliť vizuálne potvrdenie o registrácii" v Všeobecné-> Konfigurácia fóra->Nastavenie registrácie užívateľov kde nemusíte vyplňovať Dve captcha pri registrácii.',
	'ASACP_SETTINGS_UPDATED'					=> 'Nastavenia Anti-Spam ACP boli úspešne aktualizované.',
	'ASACP_SFS_ACTION'							=> 'Zastavenie Výkonu Spamov na Fóre',
	'ASACP_SFS_ACTION_EXPLAIN'					=> 'Výkon keď je účet zaregistrovaný a informácia o profile sa zhoduje z uloženov informáciov. Info: <a href="http://www.stopforumspam.com/">Fórum o Zastavení Spamov</a>',
	'ASACP_SFS_KEY'								=> 'Klúč Zastavenie Spamu na Fóre',
	'ASACP_SFS_KEY_EXPLAIN'						=> 'Ak chcete predložiť informáciu na toto -> <a href="http://www.stopforumspam.com/">Fórum o Zastavení Spamov</a>. <a href="http://www.stopforumspam.com/signup">Tu</a> sa prihláste API Key a zadajte informáciu do pola.',
	'ASACP_SFS_MIN_FREQ'						=> 'Minimálna frekvencia',
	'ASACP_SFS_MIN_FREQ_EXPLAIN'				=> 'Minimálna frekvencia (počet oznámení ostatnými)  pred vykonaním akehokoľvek výkonu vrátneho popisu informácie. Info: <a href="http://www.stopforumspam.com/">Fórum o Zastavení Spamov</a>',
	'ASACP_SFS_SETTINGS'						=> 'Nastavenia Spamu na Fóre',
	'ASACP_SPAM_WORDS_ENABLE'					=> 'Povolím Spamovanie slov',
	'ASACP_SPAM_WORDS_ENABLE_EXPLAIN'			=> 'Ak je nastavené na Nie bude vypnuté v systéme Spam slov.',
	'ASACP_SPAM_WORDS_EXPLAIN'					=> 'Zadajte pre kontrolu spúšťacie slová ako slová považujúce sa ako spam. Info: Spam je nevyžiadaná a hromadne rozosielaná správa prakticky rovnakého obsahu. Ide o zneužívanie elektronickej komunikácie, najmä e-mailu.',
	'ASACP_SPAM_WORDS_FLAG_LIMIT'				=> 'Počet identifikácii pred označením ako spam',
	'ASACP_SPAM_WORDS_FLAG_LIMIT_EXPLAIN'		=> 'Ak sú správy označené ako spam viackrát, príspevok bude buď odmietnutý alebo bude vyžadovať schválenie.',
	'ASACP_SPAM_WORDS_GUEST_ALWAYS'				=> 'Vždy skontrolujem hostí',
	'ASACP_SPAM_WORDS_GUEST_ALWAYS_EXPLAIN'		=> 'Ak je zadané Áno, budem ignorovať návšteve, limit počtu príspevkov a vždy skontrolujem spamovanie slov.',
	'ASACP_SPAM_WORDS_PM_ACTION'				=> 'Výkony, Spam Súkromné správy',
	'ASACP_SPAM_WORDS_PM_ACTION_EXPLAIN'		=> 'Vyberte výkon, ktorý vykonám, keď súkromná správa je označená ako spam.',
	'ASACP_SPAM_WORDS_POSTING_ACTION'			=> 'Výkon, Spam Príspevky',
	'ASACP_SPAM_WORDS_POSTING_ACTION_EXPLAIN'	=> 'Vyberte výkon, ktorý mám vykonať, kde je príspevok označený ako spam.',
	'ASACP_SPAM_WORDS_POST_LIMIT'				=> 'Počet príspevkov',
	'ASACP_SPAM_WORDS_POST_LIMIT_EXPLAIN'		=> 'Ak má užívateľ vyšší počet príspevkov ako je tu zadané, tak kontrola spamovania slov nebude použitá u toho užívateľa.<br /><strong>Ak je zadaná 0 kontrola spamovania slov bude vždy spustená.</strong>',
	'ASACP_SPAM_WORDS_PROFILE_ACTION'			=> 'Výkon, Spam Informácie profilu',
	'ASACP_SPAM_WORDS_PROFILE_ACTION_EXPLAIN'	=> 'Vyberte výkon, ktorý mám vykonať, ak údaje profilu užívateľa je označený ako spam.',
	'ASACP_USER_FLAG_ENABLE'					=> 'Povolím systém identifikovanie Uživateľa',
	'ASACP_USER_FLAG_ENABLE_EXPLAIN'			=> 'Ak je zadané Nie, uživatelia nebudú identifikovaný ani v predchádzajúcich identifikovaniach užívateľov a tak položky nebudú zaznamenané v identifikačnom protokole.',
	'ASACP_VERSION'								=> 'Informácia o Verzii',

	'CLICK_CHECK_NEW_VERSION'					=> '%sSem%s kliknite a preverím či existuje nová verzia.',
	'CLICK_GET_NEW_VERSION'						=> '%sSem%s kliknite pre získanie novej verzie.',

	'DELETE_SPAM_WORD'							=> 'Vymazat Spam. Slovo',
	'DELETE_SPAM_WORD_CONFIRM'					=> 'Are you sure you want to delete this spam word?',
	'DENY_FIELD'								=> 'Zakázať',
	'DENY_SUBMISSION'							=> 'Zakázať zadanie',

	'FLAG_USER'									=> 'Identit Uživateľa',

	'INSTALLED_VERSION'							=> 'Nainštalovaná Verzia',
	'INTERESTS_POST_COUNT'						=> 'Záujmy, Počet príspevkov',
	'INTERESTS_POST_COUNT_EXPLAIN'				=> 'Ak Záujmy sa nastavia na hodnotu Počet Príspevkov, uživateľ bude môcť vyplniť túto časť potom, čo dosiahol tento počet príspevkov.',

	'LATEST_VERSION'							=> 'Posledná Verzia',
	'LOCATION_POST_COUNT'						=> 'Pole Bydlisko, Počet príspevkov',
	'LOCATION_POST_COUNT_EXPLAIN'				=> 'Ak Bydlisko sa nastaví na hodnotu Počet Príspevkov, uživateľ bude môcť vyplniť túto časť potom, čo dosiahol tento počet príspevkov.',
	'LOG_VIEW_POST'								=> '%sZobraziť príspevok%s',
	'LOG_VIEW_PROFILE'							=> '%sZobraziť profil%s',

	'NOTHING'									=> 'Nevykonať nič',
	'NOT_AVAILABLE'								=> 'Nie je k dispozícii',
	'NO_ITEMS'									=> 'Nenašiel som žiadne výsledky z danej IP adresy.',
	'NO_SPAM_WORD'								=> 'Vybrané slovo neexistuje.',
	'NO_SPAM_WORDS'								=> 'Nie je žiadny Spam Slov v databáze.',

	'OCCUPATION_POST_COUNT'						=> 'Pole Povolanie, Počet príspevkov',
	'OCCUPATION_POST_COUNT_EXPLAIN'				=> 'Ak Povolanie sa nastaví na hodnotu Počet Príspevkov, uživateľ bude môcť vyplniť túto časť potom, čo dosiahol tento počet príspevkov.',

	'POST_COUNT'								=> 'Počet príspevkov',

	'REGEX'										=> 'Bežný výraz',
	'REGEX_AUTO'								=> 'Auto Regex',
	'REGEX_AUTO_EXPLAIN'						=> 'Ak zadáte Áno, systém automaticky vytvorí regulárny výraz z daného textu spamovaných slov.',
	'REGEX_EXPLAIN'								=> 'Ak zadáte Áno, použie sa regulárny výraz z daného textu spamovaných slov.',
	'REQUIRE_ADMIN_ACTIVATION'					=> 'Vyžadovať Aktiváciu Admin.',
	'REQUIRE_APPROVAL'							=> 'Vyžadovať schválenie moderátorom',
	'REQUIRE_FIELD'								=> 'Vyžadovať',
	'REQUIRE_USER_ACTIVATION'					=> 'Vyžadovať aktiváciu uživateľa',

	'SIGNATURE_POST_COUNT'						=> 'Pole Podpis, Počet príspevkov',
	'SIGNATURE_POST_COUNT_EXPLAIN'				=> 'Ak Podpis sa nastaví na hodnotu Počet Príspevkov, uživateľ bude môcť vyplniť túto časť potom, čo dosiahol tento počet príspevkov.<br /><br />Vyžadované nastavenia na podpis nie sú také isté ako ostatné nastavenia.  Podpis nebude požadovaný počas registrácie.',
	'SPAM_WORD_ADD_SUCCESS'						=> 'Slovo spamu bolo úspešne pridané.',
	'SPAM_WORD_DELETE_SUCCESS'					=> 'Slovo spamu bolo úspešne zmazané.',
	'SPAM_WORD_EDIT_SUCCESS'					=> 'Slovo spamu bolo úspešne upravené.',
	'SPAM_WORD_TEXT'							=> 'Spam Slov v Texte',
	'SPAM_WORD_TEXT_EXPLAIN'					=> 'Ak použiete bežný výraz, uistite sa, že formát je v poriadku <a href="http://us2.php.net/manual/en/function.preg-match.php">preg_match</a> (vrátane štruktúry oddeľovača informácií)',

	'UCP_AIM_POST_COUNT'						=> 'Pole AOL Instant Messenger, Počet príspevkov',
	'UCP_AIM_POST_COUNT_EXPLAIN'				=> 'Ak AOL Instant Messenger sa nastaví na hodnotu Počet Príspevkov, uživateľ bude môcť vyplniť túto časť potom, čo dosiahol tento počet príspevkov.',
	'UCP_ICQ_POST_COUNT'						=> 'Pole ICQ číslo, Počet príspevkov',
	'UCP_ICQ_POST_COUNT_EXPLAIN'				=> 'Ak ICQ číslo sa nastaví na hodnotu Počet Príspevkov, uživateľ bude môcť vyplniť túto časť potom, čo dosiahol tento počet príspevkov.',
	'UCP_JABBER_POST_COUNT'						=> 'Pole Adresa Jabbera, Počet príspevkov',
	'UCP_JABBER_POST_COUNT_EXPLAIN'				=> 'Ak Adresa Jabbera sa nastaví na hodnotu Počet Príspevkov, uživateľ bude môcť vyplniť túto časť potom, čo dosiahol tento počet príspevkov.',
	'UCP_MSNM_POST_COUNT'						=> 'Pole MSN Messenger, Počet príspevkov',
	'UCP_MSNM_POST_COUNT_EXPLAIN'				=> 'Ak MSN Messenger sa nastaví na hodnotu Počet Príspevkov, uživateľ bude môcť vyplniť túto časť potom, čo dosiahol tento počet príspevkov.',
	'UCP_YIM_POST_COUNT'						=> 'Pole Yahoo Messenger, Počet príspevkov',
	'UCP_YIM_POST_COUNT_EXPLAIN'				=> 'Ak Yahoo Messenger sa nastaví na hodnotu Počet Príspevkov, uživateľ bude môcť vyplniť túto časť potom, čo dosiahol tento počet príspevkov.',

	'VERSION'									=> 'Verzia',

	'WEBSITE_POST_COUNT'						=> 'Pole Internetová stránka, Počet príspevkov',
	'WEBSITE_POST_COUNT_EXPLAIN'				=> 'Ak Internetová stránka sa nastaví na hodnotu Počet Príspevkov, uživateľ bude môcť vyplniť túto časť potom, čo dosiahol tento počet príspevkov.',
));

?>