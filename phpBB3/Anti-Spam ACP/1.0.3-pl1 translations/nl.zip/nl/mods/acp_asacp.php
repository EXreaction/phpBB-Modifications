<?php
/**
*
* @package Anti-Spam ACP
* @copyright (c) 2008 EXreaction
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ADD_WORD'									=> 'Toevoegen woord',
	'ALLOW_FIELD'								=> 'Toestaan',
	'ASACP_BAN_CLEAR_OUTBOX'					=> 'Wis gebruikers PM postvak uit',
	'ASACP_BAN_CLEAR_OUTBOX_EXPLAIN'			=> 'Verwijder alle PMs van de gebruikers postvak uit',
	'ASACP_BAN_DELETE_AVATAR'					=> 'Verwijder Avatar',
	'ASACP_BAN_DELETE_AVATAR_EXPLAIN'			=> 'Verwijder de gebruikers Avatar als er de Een Klik Verbanning-actie wordt uitgevoerd',
	'ASACP_BAN_DELETE_POSTS'					=> 'Verwijder Berichten',
	'ASACP_BAN_DELETE_POSTS_EXPLAIN'			=> 'Verwijder de gebruikers berichten als er de Een Klik Verbannings-actie wordt uitgevoerd',
	'ASACP_BAN_DELETE_PROFILE_FIELDS'			=> 'Verwijder Profiel informatie',
	'ASACP_BAN_DELETE_PROFILE_FIELDS_EXPLAIN'	=> 'Verwijder de gebruikers Profiel informatie als er de Een Klik Verbannings-actie wordt uitgevoerd',
	'ASACP_BAN_DELETE_SIGNATURE'				=> 'Verwijder Handtekening',
	'ASACP_BAN_DELETE_SIGNATURE_EXPLAIN'		=> 'Verwijder gebruikers Handtekening als er de Een Klik Verbannings-actie wordt uitgevoerd',
	'ASACP_BAN_MOVE_TO_GROUP'					=> 'Verplaats naar groep',
	'ASACP_BAN_MOVE_TO_GROUP_EXPLAIN'			=> 'Verplaats de gebruik naar de volgende groep als er de Een Klik Verbannings-actie wordt uitgevoerd',
	'ASACP_BAN_SETTINGS'						=> 'Een Klik Verban instellingen',
	'ASACP_BAN_USERNAME'						=> 'Verban Gebruiker',
	'ASACP_BAN_USERNAME_EXPLAIN'				=> 'Verban de gebruiker als de Een Klik Verbanningsactie wordt uitgevoerd',
	'ASACP_ENABLE'								=> 'Activeer de Anti-Spam ACP',
	'ASACP_ENABLE_EXPLAIN'						=> 'Sel op nee om de gehele Anti-Spam ACP systeem te deactiveren.',
	'ASACP_FLAG_LIST_EXPLAIN'					=> 'Een lijst van alle huidige gevlagde gebruikers.',
    'ASACP_IP_SEARCH_BOT_CHECK'               	=> 'Bot Controle',
    'ASACP_IP_SEARCH_EXPLAIN'               	=> 'Zoek in het gehele forum voor acties gemaakt vanaf een bepaald IP adres.',
    'ASACP_IP_SEARCH_FLAG_LOG'              	=> 'Markeer Logboek',
    'ASACP_IP_SEARCH_LOGS'                  	=> 'Log Acties',
    'ASACP_IP_SEARCH_POLL_VOTES'            	=> 'Poll Stemmen',
    'ASACP_IP_SEARCH_POSTS'                  	=> 'Berichen',
    'ASACP_IP_SEARCH_PRIVMSGS'               	=> 'Prive Berichten',
    'ASACP_IP_SEARCH_SPAM_LOG'               	=> 'Spam Logboek',
    'ASACP_IP_SEARCH_USERS'                  	=> 'Gebruikers',
    'ASACP_LOG'                           		=> 'Activeer Spam Logboek',
	'ASACP_LOG_EXPLAIN'                     	=> 'Gedeactiveerde nieuwe items worden niet toevegoed aan het spam logboek.',
    'ASACP_NOTIFY_NEW_FLAG'                  	=> 'Waarschuw bij een nieuw markeer logboekvermelding',
	'ASACP_NOTIFY_NEW_FLAG_EXPLAIN'            	=> 'Waarschuw geautoriseerde gebruikers wanneer er een nieuw item is toegevoegd aan het markeer logboek.',
	'ASACP_PROFILE_DURING_REG'               	=> 'Laat de toegestane profiel velden zien tijdens de registratie.',
	'ASACP_PROFILE_DURING_REG_EXPLAIN'         	=> 'Indien ingesteld op ja, alle velden gemarkeerd als toegestaan, bij de instellingen van profiel velden, worden weergegeven tijdens de registratie. (met uitzondering van het onderschrift)',
	'ASACP_PROFILE_FIELDS'                  	=> 'Profiel velden',
	'ASACP_PROFILE_FIELDS_EXPLAIN'            	=> 'Geeft de mogelijkheid om limieten in te stellen voor de profiel velden, die kunnen worden ingevuld door de gebruikers.<br /><br /><strong>Na activering, alle velden worden opnieuw gesynchroniseerd voor alle gebruikers, alle velden waarvan zij niet de permissies hebben zullen worden geleegd, afhankelijk van de nieuw ingestelde regels.',
	'ASACP_REGISTER_SETTINGS'               	=> 'Registratie instellingen',
	'ASACP_REG_CAPTCHA'                     	=> 'Pre-Registratie Captcha',
	'ASACP_REG_CAPTCHA_EXPLAIN'               	=> 'Dit bepaalt de weergave van de eerste captcha die getoond word voordat het registratie proces begint.<br />Indien geactiveerd, zou je moeten overwegen om de optie "Schakel visuele bevestiging voor registraties in" uit te schakelen in Algemeen->Forum configuratie->Instellingen visuele bevestiging zodat de gebuikers geen 2 captcha hoeven in de vullen.',
	'ASACP_SETTINGS_UPDATED'               		=> 'Anti-Spam ACP instellingen zijn succesvol gewijzigd.',
	'ASACP_SFS_ACTION'                     		=> 'Stop Forum Spam Actie',
	'ASACP_SFS_ACTION_EXPLAIN'               	=> 'De actie uit te voeren wanneer een account is geregistreerd en het profiel overeenkomt met de gegevens van de informatie die is opgeslagen op <a href="http://www.stopforumspam.com/">Stop Forum Spam</a>',
	'ASACP_SFS_KEY'                        		=> 'Stop Forum Spam Sleutel',
	'ASACP_SFS_KEY_EXPLAIN'                  	=> 'Als u graag de mogelijkheid zou willen hebben informatie te verstrekken aan <a href="http://www.stopforumspam.com/">Stop Forum Spam</a>, om je aan te melden voor een API sleutel <a href="http://www.stopforumspam.com/signup">hier</a> en voer hem hier in.',
	'ASACP_SFS_MIN_FREQ'                  		=> 'Minimumfrequentie',
	'ASACP_SFS_MIN_FREQ_EXPLAIN'          		=> 'Minimumfrequentie (aantal keren dat een account is gerapporteerd door anderen) voor het uitvoeren van een actie voor het account, van de informatie, die is geretourneerd door <a href="http://www.stopforumspam.com/">Stop Forum Spam</a>',
	'ASACP_SFS_SETTINGS'                  		=> 'Stop Forum Spam Instellingen',
	'ASACP_SPAM_WORDS_ENABLE'               	=> 'Activeer Spam woorden',
	'ASACP_SPAM_WORDS_ENABLE_EXPLAIN'         	=> 'Voorkom het uitschakelen van het hele Spam Woorden systeem.',
	'ASACP_SPAM_WORDS_EXPLAIN'              	=> 'Invoeren en beheren woorden voor het spam woorden systeem.',
	'ASACP_SPAM_WORDS_FLAG_LIMIT'            	=> 'Markeer teller voor het markeren als spam',
	'ASACP_SPAM_WORDS_FLAG_LIMIT_EXPLAIN'    	=> 'Als je berichten zijn gemarkeerd als spam, meer dan dit, veel of meer keer, het bericht zal ofwel geweigerd, of goedkeuring nodig hebben.',
	'ASACP_SPAM_WORDS_GUEST_ALWAYS'           	=> 'Controleer altijd voor de gasten',
	'ASACP_SPAM_WORDS_GUEST_ALWAYS_EXPLAIN'     => 'Dit negeert het aantal berichten voor gasten, en controleert altijd op spam woorden.',
	'ASACP_SPAM_WORDS_PM_ACTION'            	=> 'Actie voor spam prive berichten',
	'ASACP_SPAM_WORDS_PM_ACTION_EXPLAIN'      	=> 'Selecteer een gewenste actie, die zal worden uitgevoerd, wanneer een prive bericht word gemarkeerd als spam.',
	'ASACP_SPAM_WORDS_POSTING_ACTION'         	=> 'Actie voor Spam berichten',
	'ASACP_SPAM_WORDS_POSTING_ACTION_EXPLAIN'   => 'Selecteer een gewenste actie, die zal worden uitgevoerd, wanneer een bericht word gemarkeerd als spam.',
	'ASACP_SPAM_WORDS_POST_LIMIT'            	=> 'Berichtenteller',
	'ASACP_SPAM_WORDS_POST_LIMIT_EXPLAIN'      	=> 'Als het aantal berichten van een gebruiker hoger is dan ingediend, dan zal de spam woorden check niet worden uitgevoerd op deze gebruiker.<br /><strong>Als het getal 0 is ingevoerd, dan zal de spam woorden check altijd worden uitgevoerd.</strong>',
	'ASACP_SPAM_WORDS_PROFILE_ACTION'         	=> 'Actie voor Spam profiel informatie',
	'ASACP_SPAM_WORDS_PROFILE_ACTION_EXPLAIN'   => 'Selecteer een gewenste actie, die zal worden uitgevoerd, wanneer informatie in een gebruikers profiel word gemarkeerd als spam.',
	'ASACP_USER_FLAG_ENABLE'               		=> 'Activeer het gebuiker markeer systeem.',
	'ASACP_USER_FLAG_ENABLE_EXPLAIN'        	=> 'Als er nee is geselecteerd, de gebruikers kunnen dan niet gemarkeerd worden, en alle vorige gebruikers die gemarkeerd zijn, zullen geen items hebben, opgenomen in het markeer logboek, als ze iets doen.',
	'ASACP_VERSION'                        		=> 'Versie informatie',
 
	'CLICK_CHECK_NEW_VERSION'               => 'Klik %shier%s om te controleren voor een nieuwe versie.',
	'CLICK_GET_NEW_VERSION'                  => 'Klik %shier%s om de nieuwe versie te verkrijgen.',

	'DELETE_SPAM_WORD'                     => 'Verwijder Spam Woord',
	'DELETE_SPAM_WORD_CONFIRM'               => 'Ben je er zeker van om dit woord te verwijderen?',
	'DENY_FIELD'                        => 'Weigeren',
	'DENY_SUBMISSION'                     => 'Weiger aanmelding',

	'FLAG_USER'                           => 'Markeer gebruiker',
	
	'INSTALLED_VERSION'                     => 'Geinstalleerde versie',
	'INTERESTS_POST_COUNT'                  => 'Interesses berichtenteller',
	'INTERESTS_POST_COUNT_EXPLAIN'            => 'Als de interesses zijn ingesteld op de berichtenteller, dan is het voor de gebruiker mogelijk om dat veld in te vullen zodra het aantal berichten is bereikt.',

	'LATEST_VERSION'                     => 'Laatste versie',
	'LOCATION_POST_COUNT'                  => 'Woonplaats berichtenteller',
	'LOCATION_POST_COUNT_EXPLAIN'            => 'Als de woonplaats is ingesteld op de berichtenteller, dan is het voor de gebruiker mogelijk om dat veld in te vullen zodra het aantal berichten is bereikt.',
	'LOG_VIEW_POST'                        => '%sToon berichten%s',
	'LOG_VIEW_PROFILE'                     => '%sToon profiel%s',

	'NOTHING'                           => 'Niks',
	'NOT_AVAILABLE'                        => 'Niet beschikbaar',
	'NO_ITEMS'                           => 'Geen resultaten van het opgegeven IP adres.',
	'NO_SPAM_WORD'                        => 'Het geselecteerde woord bestaat niet.',
	'NO_SPAM_WORDS'                        => 'Geen spam woorden in de database.',

	'OCCUPATION_POST_COUNT'                  => 'Beroep berichtenteller',
	'OCCUPATION_POST_COUNT_EXPLAIN'            => 'Als het beroep is ingesteld op de berichtenteller, dan is het voor de gebruiker mogelijk om dat veld in te vullen zodra het aantal berichten is bereikt.',

	'POST_COUNT'                        => 'Berichtenteller',
    'REGEX'                              => 'Geregelde meningsuiting',
       'REGEX_AUTO'                        => 'Automatische Regex',
       'REGEX_AUTO_EXPLAIN'                  => 'Selecteer Ja om het systeem automatisch een geregelde meningsuiting match van de gegeven spam woorden tekst.',
       'REGEX_EXPLAIN'                        => 'Selecteer Ja om het systeem een geregelde meningsuiting match van de gegeven spam woorden tekst.',
       'REQUIRE_ADMIN_ACTIVATION'               => 'Administator activatie vereist',
       'REQUIRE_APPROVAL'                     => 'Vereist moderator goedkeuring',
       'REQUIRE_FIELD'                        => 'Vereist',
       'REQUIRE_USER_ACTIVATION'               => 'Gebruiker activatie vereist',
  
       'SIGNATURE_POST_COUNT'                  => 'Onderschrift berichtenteller',
       'SIGNATURE_POST_COUNT_EXPLAIN'            => 'Als het onderschrift is ingesteld op de berichtenteller, dan is het voor de gebruiker mogelijk om dat veld in te vullen zodra het aantal berichten is bereikt.<br /><br />Vereiste instellingen voor het onderschrift zijn niet dezelfde als anderen.  Onderschriften kunnen niet verplicht worden tijdens de registratie.',
       'SPAM_WORD_ADD_SUCCESS'                  => 'Spam woord succesvol toegevoegd.',
       'SPAM_WORD_DELETE_SUCCESS'               => 'Spam woord succesvol verwijderd.',
       'SPAM_WORD_EDIT_SUCCESS'               => 'Spam woord succesvol gewijzigd.',
       'SPAM_WORD_TEXT'                     => 'Spam woord tekst',
	'SPAM_WORD_TEXT_EXPLAIN'					=> 'Als er gebruik gemaakt wordt van een regular expressie, zorg er dan voor dat deze van het juiste formaat is <a href="http://us2.php.net/manual/en/function.preg-match.php">preg_match</a> (inclusief de pattern delimiter)',

	    'UCP_AIM_POST_COUNT'                  => 'AOL Instant Messenger berichtenteller',
       'UCP_AIM_POST_COUNT_EXPLAIN'            => 'Als AOL Instant Messenger is ingesteld op de berichtenteller, dan is het voor de gebruiker mogelijk om dat veld in te vullen zodra het aantal berichten is bereikt.',
       'UCP_ICQ_POST_COUNT'                  => 'ICQ number berichtenteller',
       'UCP_ICQ_POST_COUNT_EXPLAIN'            => 'Als het ICQ number is ingesteld op de berichtenteller, dan is het voor de gebruiker mogelijk om dat veld in te vullen zodra het aantal berichten is bereikt.',
       'UCP_JABBER_POST_COUNT'                  => 'Jabber address berichtenteller',
       'UCP_JABBER_POST_COUNT_EXPLAIN'            => 'Als het Jabber address is ingesteld op de berichtenteller, dan is het voor de gebruiker mogelijk om dat veld in te vullen zodra het aantal berichten is bereikt.',
       'UCP_MSNM_POST_COUNT'                  => 'MSN Messenger berichtenteller',
	'UCP_MSNM_POST_COUNT_EXPLAIN'            => 'Als MSN Messenger is ingesteld op de berichtenteller, dan is het voor de gebruiker mogelijk om dat veld in te vullen zodra het aantal berichten is bereikt.',
	'UCP_YIM_POST_COUNT'                  => 'Yahoo Messenger berichtenteller',
	'UCP_YIM_POST_COUNT_EXPLAIN'            => 'Als Yahoo Messenger is ingesteld op de berichtenteller, dan is het voor de gebruiker mogelijk om dat veld in te vullen zodra het aantal berichten is bereikt.',

	'VERSION'                           => 'Versie',

	'WEBSITE_POST_COUNT'                  => 'Website berichtenteller',
	'WEBSITE_POST_COUNT_EXPLAIN'            => 'Als de website is ingesteld op de berichtenteller, dan is het voor de gebruiker mogelijk om dat veld in te vullen zodra het aantal berichten is bereikt.',

));
   

?>