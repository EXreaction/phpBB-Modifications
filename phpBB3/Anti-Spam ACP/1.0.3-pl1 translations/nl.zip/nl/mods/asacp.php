<?php
/**
*
* @package Anti-Spam ACP
* @copyright (c) 2008 EXreaction
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array( 
	'ASACP_BAN'            	=> 'Een Klik Ban',
	'ASACP_BAN_COMPLETE'   	=> 'De gebruiker is succesvol gebanned.<br /><br /><a href="%s">Klik hier om terug te keren naar het gebruikers profiel.</a>',
	'ASACP_BAN_CONFIRM'     => 'Weet je zeker dat je %s wilt bannen?  Alle instellingen die in het Anti-Spam beheer zijn ingesteld voor een 1 klik ban zullen worden uitgevoerd.<br /><br /><strong>Dit kan niet ongedaan gemaakt worden!</strong>',
	'ASACP_CREDITS'         => 'Beveiligd door <a href="http://www.lithiumstudios.org" target="_blank">Anti-Spam ACP</a>',

	'FOUNDER_ONLY'         	=> 'Je hebt administrator rechten nodig om deze pagina te bekijken.',

	'IP_SEARCH'            	=> 'IP Zoeken',

	'MORE'               	=> 'Meer',

	'PROFILE_SPAM_DENIED'   => '1 of meer van de ingevoerde velden is gemarkeerd als spam.',

	'REMOVE_ASACP'         	=> 'Verwijder Anti-Spam ACP',
	'REMOVE_ASACP_CONFIRM'  => 'Ben je er zeker van om alle wijzigingen in de database die door de Anti-Spam ACP Mod zijn gemaakt te verwijderen?<br /><br />Alvorens deze stap uit te voeren moet je er zeker van zijn dat alle gemaakte wijzigingen voor de Anti-Spam ACP, in de bestanden zijn verwijderd, anders word de database automatisch weer hersteld.',

	'SFS_SUBMIT'         	=> 'Verstuur profiel informatie aan <a href="http://www.stopforumspam.com/">Stop Forum Spam</a>',
	'SIGNATURE_DISABLED'   	=> 'Je hebt de permissies niet om een onderschrift te gebruiken.',
	'SPAM_DENIED'         	=> 'Dit bericht is gemarkeerd als spam en is geweigerd.',

	'USER_FLAG'            	=> 'Markeer',
	'USER_FLAGGED'         	=> 'Gebruiker Gemarkeerd',
	'USER_FLAG_CONFIRM'     => 'Ben je er zeker van om %s te markeren?',
	'USER_FLAG_NEW'         => 'Nieuwe markeringen gelogd',
	'USER_FLAG_SUCCESS'     => 'De gebruiker is succesvol gemarkeerd.',
	'USER_UNFLAG'         	=> 'Verwijder markering',
	'USER_UNFLAG_CONFIRM'   => 'Ben je er zeker van om de markering van %s te verwijderen?',
	'USER_UNFLAG_SUCCESS'   => 'De markering van deze gebruiker is succesvol verwijderd.',
	
	));

?>
