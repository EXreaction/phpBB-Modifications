<?php
    /**
    *
    * @package Anti-Spam ACP
    * @copyright (c) 2008 EXreaction
    * @license http://opensource.org/licenses/gpl-license.php GNU Public License
    *
    */

    if (!defined('IN_PHPBB'))
    {
       exit;
    }

    if (empty($lang) || !is_array($lang))
    {
       $lang = array();
    }

    // DEVELOPERS PLEASE NOTE
    //
    // All language files should use UTF-8 as their encoding and the files must not contain a BOM.
    //
    // Placeholders can now contain order information, e.g. instead of
    // 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
    // translators to re-order the output of data while ensuring it remains correct
    //
    // You do not need this where single placeholders are used, e.g. 'Message %d' is fine
    // equally where a string contains only two placeholders which are used to wrap text
    // in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

    $lang = array_merge($lang, array(
       'ANTISPAM'                  => 'Anti-Spam',
       'ASACP_FLAG_LIST'            => 'Markeer gebruikerslijst',
       'ASACP_FLAG_LOG'            => 'Markeer logboek',
       'ASACP_IP_SEARCH'            => 'IP zoeken',
       'ASACP_PROFILE_FIELDS'         => 'Profiel velden',
       'ASACP_SETTINGS'            => 'Anti-Spam Instellingen',
       'ASACP_SPAM_LOG'            => 'Spam Logboek',
       'ASACP_SPAM_WORDS'            => 'Spam Woorden',

       'LOG_ADDED_POST'            => 'Bericht toegevoegd',
       'LOG_ALTERED_PROFILE'         => 'Veranderde profiel informatie',
       'LOG_ALTERED_SIGNATURE'         => 'Veranderde onderschrift',
       'LOG_ASACP_SETTINGS'         => 'Update Anti-Spam instellingen',
       'LOG_CLEAR_SPAM_LOG'         => 'Leeg Spam Logboek',
       'LOG_EDITED_POST'            => 'Bericht bewerkt',
       'LOG_INCORRECT_CODE'         => 'Verkeerde bevestigingscode ingevoerd.',
       'LOG_INCORRECT_CODE_DATA'      => 'Code gezien: "%s"<br />Code ingevoerd: "%s"',
		'LOG_USER_SFS_ACTIVATION'		=> '%s geregistreerd en was gevlagd als mogelijke spamaccount door het Stop Forum Spam.',
       'LOG_SENT_PM'               => 'Stuur een PB<br />Naar lijst: %s',
       'LOG_SPAM_PM_DENIED'         => 'Een prive bericht is gemarkeerd als spam en is tegengehouden bij de verzending.<br />Het onderwerp van het bericht was:<br />%s<br /><br />Het bericht was:<br />%s',
       'LOG_SPAM_POST_DENIED'         => 'Een bericht is gemarkeerd als spam en is tegengehouden bij de verzending.<br />Het onderwerp van het bericht was:<br />%s<br /><br />Het bericht was:<br />%s',
       'LOG_SPAM_PROFILE_DENIED'      => '1 of meer ingevulde profiel velden zijn gemarkeerd als spam.<br />Informatie ingevuld in het profiel veld:<br /><br />%s',
       'LOG_SPAM_SIGNATURE_DENIED'      => 'Onderschift gemarkeerd als spam.<br />Het onderschrift was:<br />%s',
       'LOG_USER_FLAGGED'            => '%s is gemarkeerd.',
       'LOG_USER_UNFLAGGED'         => 'De markering %s is verwijderd.',

       'acl_a_asacp'               => array(
          'lang'                  => 'Kan Anti-Spam ACP beheren',
          'cat'                  => 'instellingen',
       ),

       'acl_a_asacp_ban'            => array(
          'lang'                  => 'Kan de optie Een Klik Ban gebruiken',
          'cat'                  => 'instellingen',
       ),

       'acl_a_asacp_ip_search'         => array(
          'lang'                  => 'Kan IP zoeken gebruiken',
          'cat'                  => 'instellingen',
       ),

       'acl_a_asacp_profile_fields'   => array(
          'lang'                  => 'Kan profiel veld instellingen wijzigen',
          'cat'                  => 'instellingen',
       ),

       'acl_a_asacp_spam_log'         => array(
          'lang'                  => 'Kan het spam logboek bekijken',
          'cat'                  => 'instellingen',
       ),

       'acl_a_asacp_spam[code][/code]_words'      => array(
          'lang'                  => 'Kan de spam woorden beheren',
          'cat'                  => 'instellingen',
       ),

       'acl_a_asacp_user_flag'         => array(
          'lang'                  => 'Kan gebruikers markeren, kan het markeer logboek bekijken en kan de lijst met gemarkeerde gebruikers bekijken',
          'cat'                  => 'instellingen',
       ),

    ));

    ?>
