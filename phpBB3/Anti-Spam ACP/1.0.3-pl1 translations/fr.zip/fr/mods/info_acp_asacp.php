<?php
/**
*
* @package Anti-Spam ACP
* @copyright (c) 2008 EXreaction
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ANTISPAM'						=> 'Anti-Spam',
	'ASACP_FLAG_LIST'				=> 'Liste des utilisateurs marqués',
	'ASACP_FLAG_LOG'				=> 'Log des marquages',
	'ASACP_IP_SEARCH'				=> 'Recherche d\'adresse IP',
	'ASACP_PROFILE_FIELDS'			=> 'Champs de Profil',
	'ASACP_SETTINGS'				=> 'Paramètrage de Anti-Spam ACP',
	'ASACP_SPAM_LOG'				=> 'Log des spams',
	'ASACP_SPAM_WORDS'				=> 'Mots de Spam',

	'LOG_ADDED_POST'				=> 'Ajout d\'un message',
	'LOG_ALTERED_PROFILE'			=> 'Information de profil modifié',
	'LOG_ALTERED_SIGNATURE'			=> 'Signature modifié',
	'LOG_ASACP_SETTINGS'			=> 'Paramètrage de Anti-Spam ACP modifié',
	'LOG_CLEAR_SPAM_LOG'			=> 'Log des Spams nettoyée',
	'LOG_EDITED_POST'				=> 'Message édité',
	'LOG_INCORRECT_CODE'			=> 'Code de confirmation érroné.',
	'LOG_INCORRECT_CODE_DATA'		=> 'Code affiché: "%s"<br />Code saisie: "%s"',
	'LOG_USER_SFS_ACTIVATION'		=> '%s enregistré et marqué comme un possible compte de spam par Stop Forum Spam.',
	'LOG_SENT_PM'					=> 'Envoyer un message privé<br />à la liste: %s',
	'LOG_SPAM_PM_DENIED'			=> 'Un message privé a été marqué comme spam et interdit d\'envoi.<br />Le sujet du message était:<br />%s<br /><br />Le message était:<br />%s',
	'LOG_SPAM_POST_DENIED'			=> 'Un message a été marqué comme spam et interdit d\'envoi.<br />Le sujet du message était:<br />%s<br /><br />Le message était:<br />%s',
	'LOG_SPAM_PROFILE_DENIED'		=> 'Un ou plusieurs champs du profil étaient marqué(s) comme Spam.<br />Les informations soumises:<br /><br />%s',
	'LOG_SPAM_SIGNATURE_DENIED'		=> 'La signature a été marquée comme spam.<br />La signature était:<br />%s',
	'LOG_USER_FLAGGED'				=> '%s a été marqué.',
	'LOG_USER_UNFLAGGED'			=> 'Le marquage de %s a été retiré.',

	'acl_a_asacp'					=> array(
		'lang'						=> 'Peut gérer Anti-Spam ACP',
		'cat'						=> 'settings',
	),

	'acl_a_asacp_ban'				=> array(
		'lang'						=> 'Peut utiliser Bannir en un Clic',
		'cat'						=> 'settings',
	),

	'acl_a_asacp_ip_search'			=> array(
		'lang'						=> 'Peut utiliser la recherche d\'adresse IP',
		'cat'						=> 'settings',
	),

	'acl_a_asacp_profile_fields'	=> array(
		'lang'						=> 'Peut modifier le paramètrage de profil',
		'cat'						=> 'settings',
	),

	'acl_a_asacp_spam_log'			=> array(
		'lang'						=> 'Peut voir la log des Spams',
		'cat'						=> 'settings',
	),

	'acl_a_asacp_spam_words'		=> array(
		'lang'						=> 'Peut gérer la liste des Mots de Spam',
		'cat'						=> 'settings',
	),

	'acl_a_asacp_user_flag'			=> array(
		'lang'						=> 'Peut marquer les utilisateur, voir la log des marquages et la liste des utilisateurs marqués',
		'cat'						=> 'settings',
	),

));

?>