<?php
/**
*
* @package Anti-Spam ACP
* @copyright (c) 2008 EXreaction
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined('IN_PHPBB'))
{
    exit;
}

if (empty($lang) || !is_array($lang))
{
    $lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
    'ASACP_BAN'             => 'Bannir en un Clic',
    'ASACP_BAN_COMPLETE'    => 'Vous avez banni avec succès l\'utilisateur.<br /><br /><a href="%s">Cliquer ici pour retourner au profil de l\'utilisateur.</a>',
    'ASACP_BAN_CONFIRM'     => 'Etes vous sur de vouloir bannir l\'utilisateur %s?  Toutes les actions définies dans les paramètres de Bannir en un Clic de Anti-Spam ACP seront exécutées pour cet utilisateur.<br /><br /><strong>Pas de marche arrière possible!</strong>',
    'ASACP_CREDITS'         => 'Protégé par <a href="http://www.lithiumstudios.org" target="_blank">Anti-Spam ACP</a>',

    'FOUNDER_ONLY'          => 'Vous devez êtes Fondateur du forum pour accéder à cette fonctionnalité.',

    'IP_SEARCH'             => 'Trouver l\'adresse IP',

    'MORE'                  => 'Plus',

    'PROFILE_SPAM_DENIED'   => 'Un ou plusieurs des champs saisis sont considérés comme du spam.',

    'REMOVE_ASACP'          => 'Supprimer Anti-Spam ACP',
    'REMOVE_ASACP_CONFIRM'  => 'Etes vous sur de vouloir supprimer les modifications faites par le mod Anti-Spam ACP?<br /><br />Auparavent, assurez-vous que les modifications des sources aient été supprimés ou les modifications de la bases de données seront automatiquement refaites.',

    'SFS_SUBMIT'            => 'Soumettre les informations de profil à <a href="http://www.stopforumspam.com/">Stop Forum Spam</a>',
    'SIGNATURE_DISABLED'    => 'Vous n\'êtes pas autorisé à utiliser une signature.',
    'SPAM_DENIED'           => 'Ce message a été marqué comme Spam et donc refusé.',

    'USER_FLAG'             => 'Marquage',
    'USER_FLAGGED'          => 'Utilisateur marqué',
    'USER_FLAG_CONFIRM'     => 'Etes vous sur de vouloir marquer l\'utilisateur %s?',
    'USER_FLAG_NEW'         => 'Nouveau marquage inscrit dans la log',
    'USER_FLAG_SUCCESS'     => 'L\'utilisateur a été marqué avec succès.',
    'USER_UNFLAG'           => 'Retirer le marquage',
    'USER_UNFLAG_CONFIRM'   => 'Etes vous sur de vouloir retirer le marquage pour l\'utilisateur %s?',
    'USER_UNFLAG_SUCCESS'   => 'Le marquage a été retiré avec succès pour cet utilisateur.',
));

?>