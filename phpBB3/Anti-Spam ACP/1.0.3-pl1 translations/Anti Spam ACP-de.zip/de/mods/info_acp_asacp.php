<?php
/**
*
* @package Anti-Spam ACP
* @copyright (c) 2008 EXreaction
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ANTISPAM'						=> 'Anti-Spam',
	'ASACP_FLAG_LIST'				=> 'Liste der markierten Benutzer',
	'ASACP_FLAG_LOG'				=> 'Markierungs-Log',
	'ASACP_IP_SEARCH'				=> 'IP Suche',
	'ASACP_PROFILE_FIELDS'			=> 'Profil-Felder',
	'ASACP_SETTINGS'				=> 'Anti-Spam ACP Einstellungen',
	'ASACP_SPAM_LOG'				=> 'Spam Log',
	'ASACP_SPAM_WORDS'				=> 'Spam Wörter',

	'LOG_ADDED_POST'				=> 'Einen Post hinzufügen',
	'LOG_ALTERED_PROFILE'			=> 'Veränderte Profil-Information',
	'LOG_ALTERED_SIGNATURE'			=> 'Veränderte Signatur',
	'LOG_ASACP_SETTINGS'			=> 'Anti-Spam ACP Einstellungen aktualisiert',
	'LOG_CLEAR_SPAM_LOG'			=> 'Spam Log geleert',
	'LOG_EDITED_POST'				=> 'Post editieren',
	'LOG_INCORRECT_CODE'			=> 'Eingegangen als falsch bestätigter Code.',
	'LOG_INCORRECT_CODE_DATA'		=> 'Code zeigen: "%s"<br />Code eingegeben: "%s"',
	'LOG_USER_SFS_ACTIVATION'		=> '%s registriert und wurde als möglicher Spam-Account von Stop Forum Spam markiert.',
	'LOG_SENT_PM'					=> 'Sende eine PM<br />Zur Liste: %s',
	'LOG_SPAM_PM_DENIED'			=> 'Eine private Nachricht wurde als Spam markiert und das Senden verweigert.<br />Der Titel der Nachricht war:<br />%s<br /><br />Die Nachricht war:<br />%s',
	'LOG_SPAM_POST_DENIED'			=> 'Ein Beitrag wurde als Spam markiert und das posten verweigert.<br />Der Titel war:<br />%s<br /><br />Die Nachricht war:<br />%s',
	'LOG_SPAM_PROFILE_DENIED'		=> 'Eines oder mehrere der eingegebenen Profil-Felder wurde als Spam markiert.<br />Die mitgeteilte Information:<br /><br />%s',
	'LOG_SPAM_SIGNATURE_DENIED'		=> 'Signatur wurde als Spam markiert.<br />Die Signatur war:<br />%s',
	'LOG_USER_FLAGGED'				=> '%s urde markiert.',
	'LOG_USER_UNFLAGGED'			=> 'Die Markierung von %s wurde entfernt.',

	'acl_a_asacp'					=> array(
		'lang'						=> 'Kann Anti-Spam ACP bearbeiten',
		'cat'						=> 'Einstellungen',
	),

	'acl_a_asacp_ban'				=> array(
		'lang'						=> 'Kann Benutzer Bannen',
		'cat'						=> 'Einstellungen',
	),

	'acl_a_asacp_ip_search'			=> array(
		'lang'						=> 'Kan die IP-Suche benutzen',
		'cat'						=> 'Einstellungen',
	),

	'acl_a_asacp_profile_fields'	=> array(
		'lang'						=> 'Kann Profil-Feld-Einstellungen ändern',
		'cat'						=> 'Einstellungen',
	),

	'acl_a_asacp_spam_log'			=> array(
		'lang'						=> 'Kann das Spam Log sehen',
		'cat'						=> 'Einstellungen',
	),

	'acl_a_asacp_spam_words'		=> array(
		'lang'						=> 'Kann Spam Wörter bearbeiten',
		'cat'						=> 'Einstellungen',
	),

	'acl_a_asacp_user_flag'			=> array(
		'lang'						=> 'Kann Benutzer markieren, das Markierungs-Log sehen und die Liste der markierten Benutzer sehen',
		'cat'						=> 'Einstellungen',
	),

));

?>