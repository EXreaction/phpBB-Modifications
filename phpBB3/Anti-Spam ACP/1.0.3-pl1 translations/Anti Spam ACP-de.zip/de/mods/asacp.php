<?php
/**
*
* @package Anti-Spam ACP
* @copyright (c) 2008 EXreaction
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ASACP_BAN'				=> 'Ein-Klick-Bann',
	'ASACP_BAN_COMPLETE'	=> 'Sie haben den Benutzer erfolgreich gebannt.<br /><br /><a href="%s">Klicken Sie hier, um zum Benutzer-Profil zurückzukehren.</a>',
	'ASACP_BAN_CONFIRM'		=> 'Sind Sie sicher, den Benutzer %s bannen zu wollen? Alle Aktionen die in den Anti-Spam ACP Einstellungen vorgenommen wurden, werden während des Ein-Klick-Bannes auf diesen Benutzer angewandt.<br /><br /><strong>Dies kann nicht rückgängig gemacht werden!</strong>',
	'ASACP_CREDITS'			=> 'Geschützt durch <a href="http://www.lithiumstudios.org" target="_blank">Anti-Spam ACP</a>',

	'FOUNDER_ONLY'			=> 'Sie müssen ein Board-Gründer sein, um auf diese Seite zugreifen zu können.',

	'IP_SEARCH'				=> 'IP Suche',

	'MORE'					=> 'Mehr',

	'PROFILE_SPAM_DENIED'	=> 'Eines oder mehrere der eingegebenen Felder wurden als SPam markiert.',

	'REMOVE_ASACP'			=> 'Entferne Anti-Spam ACP',
	'REMOVE_ASACP_CONFIRM'	=> 'Sind Sie sicher, das Sie die durch den Anti-Spam ACP-Mod vorgenommenen Datenbank-Änderungen entfernen möchten?<br /><br />Bevor Sie das tun, stellen Sie sicher, das Sie die vom Mod vorgenommenen Änderungen an den Dateien rückgängig machen. Ansonsten wird die Datenbank-Sektion automatisch wieder hinzugefügt.',

	'SFS_SUBMIT'			=> 'Teilen Sie die Profil-Informationen <a href="http://www.stopforumspam.com/">Stop Forum Spam</a> mit',
	'SIGNATURE_DISABLED'	=> 'Sie können keine Signature benutzen.',
	'SPAM_DENIED'			=> 'Diese Nachricht wurde als Spam markiert und wurde verweigert.',

	'USER_FLAG'				=> 'Markiert',
	'USER_FLAGGED'			=> 'Benutzer markier',
	'USER_FLAG_CONFIRM'		=> 'Sie Sie sicher, den Benutzer %s? zu markieren',
	'USER_FLAG_NEW'			=> 'Neue Markierungen gelogged',
	'USER_FLAG_SUCCESS'		=> 'Der Benutzer wurde erfolgreich markiert.',
	'USER_UNFLAG'			=> 'Markierung entfernen',
	'USER_UNFLAG_CONFIRM'	=> 'Sind Sie sicher, die Markierung des Benutzer %s entfernen zu wollen?',
	'USER_UNFLAG_SUCCESS'	=> 'Die Markierung des Benutzers wurde erfolgfreich entfernt.',
));

?>