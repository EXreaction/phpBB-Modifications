<?php
/**
*
* @author EXreaction (Nathan Guse) exreaction@lithiumstudios.org
* @package Advanced Subscriptions
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

function advanced_subscriptions($notify_rows, $data)
{
	global $config, $db, $phpbb_root_path, $phpEx, $user;

	if (!isset($config['advsub_version']))
	{
		return;
	}

	$msg_users = $pm_users = array();
	foreach ($notify_rows as $user_id => $row)
	{
		if (!$row['allowed'])
		{
			continue;
		}

		switch ($row['subscription_type'])
		{
			// Non-notification Subscription
			case 0 :
			break;

			// Email Subscription (handled back in functions_posting.php)
			case 1 :
				if (trim($row['user_email']))
				{
					$msg_users[] = $row;
				}
			break;

			// PM Subscription
			case 2 :
				$pm_users[] = $user_id;
			break;
		}
	}

	if (sizeof($pm_users))
	{
		if (!function_exists('submit_pm'))
		{
			include("{$phpbb_root_path}includes/functions_privmsgs.$phpEx");
		}

		if (!class_exists('parse_message'))
		{
			include("{$phpbb_root_path}includes/message_parser.$phpEx");
		}

		$user->add_lang('mods/advanced_subscriptions');

		$u_new_post = generate_board_url() . "/viewtopic.$phpEx?f={$data['forum_id']}&t={$data['topic_id']}&p={$data['post_id']}#{$data['post_id']}";
		$u_topic = generate_board_url() . "/viewtopic.$phpEx?f={$data['forum_id']}&t={$data['topic_id']}";
		$u_forum = generate_board_url() . "/viewforum.$phpEx?f={$data['forum_id']}";
		$u_stop_watching_topic = generate_board_url() . "/viewtopic.$phpEx?uid={USER_ID}&f={$data['forum_id']}&t={$data['topic_id']}&unwatch=topic";
		$u_stop_watching_forum = generate_board_url() . "/viewforum.$phpEx?uid={USER_ID}&f={$data['forum_id']}&unwatch=forum";

		$subject = $user->lang['ADVSUB_PM_SUBJECT'];
		$subject = sprintf($subject, $data['topic_title']);

		if ($data['mode'] == 'post')
		{
			$message = $user->lang['ADVSUB_PM_FORUM_MESSAGE'];
			$message = sprintf($message, '{USERNAME}', $data['forum_name'], $u_topic, $u_forum, $u_stop_watching_forum);
		}
		else
		{
			$message = $user->lang['ADVSUB_PM_TOPIC_MESSAGE'];
			$message = sprintf($message, '{USERNAME}', $data['topic_title'], $u_new_post, $u_topic, $u_forum, $u_stop_watching_topic);
		}

		foreach ($pm_users as $id)
		{
			$message_parser = new parse_message();

			$message_parser->message = str_replace(array('{USER_ID}', '{USERNAME}'), array($id, $notify_rows[$id]['username']), $message);
			$message_parser->parse(true, true, true);

			$pm_data = array(
				'from_user_id'		=> 2,
				'from_username'		=> 'Administrator', // Should not be shown...
				'address_list'		=> array('u' => array($id => 'to')),
				'icon_id'			=> 10,
				'from_user_ip'		=> '0.0.0.0',
				'enable_bbcode'		=> true,
				'enable_smilies'	=> true,
				'enable_urls'		=> true,
				'enable_sig'		=> true,
				'message'			=> $message_parser->message,
				'bbcode_bitfield'	=> $message_parser->bbcode_bitfield,
				'bbcode_uid'		=> $message_parser->bbcode_uid,
			);

			submit_pm('post', $subject, $pm_data, false);
		}
	}

	return $msg_users;
}

function advanced_subscriptions_subscribe($mode, $user_id, $topic_id, $forum_id, $start)
{
	global $config, $db, $phpbb_root_path, $phpEx, $user;

	if (!isset($config['advsub_version']))
	{
		return;
	}

	if ($mode == 'topic')
	{
		$redirect_url = append_sid("{$phpbb_root_path}viewtopic.$phpEx", "t=$topic_id&amp;start=$start");
	}
	else
	{
		$redirect_url = append_sid("{$phpbb_root_path}viewforum.$phpEx", "f=$forum_id&amp;start=$start");
	}

	if (confirm_box(true))
	{
		$is_watching = true;
		$subscription_type = request_var('subscription_type', 1);

		if ($mode == 'topic')
		{
			$sql_ary = array(
				'user_id'			=> $user_id,
				'topic_id'			=> $topic_id,
				'notify_status'		=> 0,
				'subscription_type'	=> $subscription_type,
			);
			$sql = 'INSERT INTO ' . TOPICS_WATCH_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_ary);
		}
		else
		{
			$sql_ary = array(
				'user_id'			=> $user_id,
				'forum_id'			=> $forum_id,
				'notify_status'		=> 0,
				'subscription_type'	=> $subscription_type,
			);
			$sql = 'INSERT INTO ' . FORUMS_WATCH_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_ary);
		}
		$db->sql_query($sql);

		$message = $user->lang['ARE_WATCHING_' . strtoupper($mode)] . '<br /><br />' . sprintf($user->lang['RETURN_' . strtoupper($mode)], '<a href="' . $redirect_url . '">', '</a>');

		meta_refresh(3, $redirect_url);
		trigger_error($message);
	}
	else
	{
		if ($user_id != $user->data['user_id'])
		{
			$auth = new auth;
			$sql = 'SELECT * FROM ' . USERS_TABLE . ' WHERE user_id = ' . (int) $user_id;
			$result = $db->sql_fetchrow($result);
			$row = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);

			if (!$row)
			{
				// Should not get here
				redirect($redirect_url);
			}

			$auth->acl($row);
		}
		else
		{
			global $auth;
		}

		$user->add_lang('mods/advanced_subscriptions');

		$confirm = '<br /><br /><select name="subscription_type">';
		$confirm .= '<option value="0"' . (($user->data['advsub_default_type'] == 0) ? ' selected="selected"' : '') . '>' . $user->lang['NO_NOTIFICATION'] . '</option>';
		$confirm .= ($config['email_enable'] || $config['jab_enable']) ? '<option value="1"' . (($user->data['advsub_default_type'] == 1) ? ' selected="selected"' : '') . '>' . $user->lang['EMAIL_NOTIFICATION'] . '</option>' : '';
		$confirm .= ($auth->acl_get('u_readpm')) ? '<option value="2"' . (($user->data['advsub_default_type'] == 2) ? ' selected="selected"' : '') . '>' . $user->lang['PM_NOTIFICATION'] . '</option>' : '';
		$confirm .= '</select>';

		if ($mode == 'topic')
		{
			$user->lang['ADVSUB_TOPIC_SUBSCRIBE_CONFIRM'] .= $confirm;
			confirm_box(false, 'ADVSUB_TOPIC_SUBSCRIBE');
		}
		else
		{
			$user->lang['ADVSUB_FORUM_SUBSCRIBE_CONFIRM'] .= $confirm;
			confirm_box(false, 'ADVSUB_FORUM_SUBSCRIBE');
		}
	}

	// Should not get here
	redirect($redirect_url);
}
?>