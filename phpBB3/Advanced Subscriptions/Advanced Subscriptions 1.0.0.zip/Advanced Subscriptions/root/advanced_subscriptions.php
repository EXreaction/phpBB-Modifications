<?php
/**
*
* @author EXreaction (Nathan Guse) exreaction@lithiumstudios.org
* @package Advanced Subscriptions
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/**
* @ignore
*/
define('UMIL_AUTO', true);
define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
$user->session_begin();
$auth->acl($user->data);
$user->setup();

if (!file_exists($phpbb_root_path . 'umil/umil_auto.' . $phpEx))
{
	trigger_error('Please download the latest UMIL (Unified MOD Install Library) from: <a href="http://www.phpbb.com/mods/umil/">phpBB.com/mods/umil</a>', E_USER_ERROR);
}

$mod_name = 'ADVSUB';
$version_config_name = 'advsub_version';
$language_file = 'mods/advanced_subscriptions';

$versions = array(
	'1.0.0-b1'	=> array(
		'table_column_add' => array(
			array(TOPICS_WATCH_TABLE, 'subscription_type', array('INT:11', 1)),
			array(FORUMS_WATCH_TABLE, 'subscription_type', array('INT:11', 1)),
			array(USERS_TABLE, 'advsub_default_type', array('INT:11', 1)),
		),
	),
	'1.0.0'	=> array(),
);

include($phpbb_root_path . 'umil/umil_auto.' . $phpEx);

?>