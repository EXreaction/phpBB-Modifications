<?php
/**
*
* @author EXreaction (Nathan Guse) exreaction@lithiumstudios.org
* @package Advanced Subscriptions
* @copyright (c) 2008 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/**
* @ignore
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'ADVSUB'							=> 'Advanced Subscriptions',
	'ADVSUB_EXPLAIN'					=> 'The Advanced Subscriptions modification by <a href="http://www.lithiumstudios.org">EXreaction</a>.',
	'ADVSUB_FORUM_SUBSCRIBE'			=> 'Advanced Subscription',
	'ADVSUB_FORUM_SUBSCRIBE_CONFIRM'	=> 'To subscribe to this forum select a subscription method below and hit Yes',
	'ADVSUB_PM_FORUM_MESSAGE'			=> 'Hello %1$s,

You are receiving this notification because you are watching the forum "%2$s".  A new topic has been posted since your last visit.  No more notifications will be sent until you visit the forum.

If you want to view the new topic, click the following link:
%3$s

If you want to view the forum, click the following link:
%4$s

If you no longer wish to watch this topic you can either click the "Unsubscribe topic" link found at the bottom of the forum, or by clicking the following link:

%5$s',
	'ADVSUB_PM_TOPIC_MESSAGE'			=> 'Hello %1$s,

You are receiving this notification because you are watching the topic "%2$s". This topic has received a reply since your last visit. No more notifications will be sent until you visit the topic.

If you want to view the newest post made since your last visit, click the following link:
%3$s

If you want to view the topic, click the following link:
%4$s

If you want to view the forum, click the following link:
%5$s

If you no longer wish to watch this topic you can either click the "Unsubscribe topic" link found at the bottom of the topic above, or by clicking the following link:

%6$s',
	'ADVSUB_PM_SUBJECT'			=> 'Subscription notification - "%s"',
	'ADVSUB_TOPIC_SUBSCRIBE'			=> 'Advanced Subscription',
	'ADVSUB_TOPIC_SUBSCRIBE_CONFIRM'	=> 'To subscribe to this topic select a subscription method below and hit Yes',

	'EMAIL_NOTIFICATION'		=> 'Email Notification',

	'INSTALL_ADVSUB'			=> 'Install Advanced Subscriptions',
	'INSTALL_ADVSUB_CONFIRM'	=> 'Are you ready to install the Advanced Subscriptions Mod?',

	'NO_NOTIFICATION'			=> 'No Notification',

	'PM_NOTIFICATION'			=> 'Private Message Notification',

	'UNINSTALL_ADVSUB'			=> 'Uninstall Advanced Subscriptions',
	'UNINSTALL_ADVSUB_CONFIRM'	=> 'Are you ready to uninstall the Advanced Subscriptions Mod?  All settings and data saved by this mod will be removed!',
	'UPDATE_ADVSUB'				=> 'Update Advanced Subscriptions',
	'UPDATE_ADVSUB_CONFIRM'		=> 'Are you ready to update the Advanced Subscriptions Mod?',
));

?>