<?php
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'CATEGORY'				=> 'Categorie',
	'CAT_ADDED'				=> 'De categorie is succesvol toegevoegd.',
	'CAT_DELETED'			=> 'De categorie is succesvol verwijderd.',
	'CAT_DETAILS'			=> 'Categorie details',
	'CAT_ICON'				=> 'Categorie icoon',
	'CAT_ICON_EXPLAIN'		=> 'Typ de volledige url van het icoon dat je voor deze categorie wilt tonen. Je kunt "{SMILIES_PATH}" gebruiken om de url naar het smilies pad te specificeren.',
	'CAT_NAME'				=> 'Categorie naam',
	'CAT_NAME_EXPLAIN'		=> '',
	'CAT_UPDATED'			=> 'De categorie is succesvol geupdate.',
	'CREATE_CAT'			=> 'Maak nieuwe categorie aan',

	'DELETE_CAT'			=> 'Verwijder categorie',
	'DELETE_CAT_CONFIRM'	=> 'Weet je zeker dat je deze categorie wilt verwijderen?',

	'ICON'					=> 'Icoon',

	'NO_CATS'				=> 'Geen categorieën',
));

?>