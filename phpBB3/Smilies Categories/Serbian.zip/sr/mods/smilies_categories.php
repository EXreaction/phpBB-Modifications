<?php
/* By cedomirovic  */

if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'CATEGORY'				=> 'Kategorija',
	'CAT_ADDED'				=> 'Kategorija je dodata uspešno.',
	'CAT_DELETED'			=> 'Kategorija je izbrisana uspešno.',
	'CAT_DETAILS'			=> 'Detalji kategorije',
	'CAT_ICON'				=> 'Ikonica kategorije',
	'CAT_ICON_EXPLAIN'		=> 'Tip punog URL-a ikone koju želis da se prikazuje ispred kategorije.  Možeš da orišeš "{SMILIES_PATH}" da specifiraš url put do smajlije.',
	'CAT_NAME'				=> 'Ime kategorije',
	'CAT_NAME_EXPLAIN'		=> '',
	'CAT_UPDATED'			=> 'Kategorija je ažurirana uspešno.',
	'CREATE_CAT'			=> 'Napravi kategoriju',

	'DELETE_CAT'			=> 'Izbriši kategoriju',
	'DELETE_CAT_CONFIRM'	=> 'Jeste li sigurni da želite da izbrišete ovu kategoriju?',

	'ICON'					=> 'Ikonica',

	'NO_CATS'				=> 'Nema kategorije',
));

?>