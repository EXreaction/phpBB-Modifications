<?php
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'CATEGORY'				=> 'Categoria',
	'CAT_ADDED'				=> 'Categoria aggiunta correttamente.',
	'CAT_DELETED'			=> 'Categoria cancellata correttamente.',
	'CAT_DETAILS'			=> 'Dettagli Categoria',
	'CAT_ICON'				=> 'Icona Categoria',
	'CAT_ICON_EXPLAIN'		=> 'Inserisci URL completo dell\'icona che vuoi utilizzare per questa categoria. Puoi anche utilizzare "{SMILIES_PATH}" per indicare l\'url del percorso degli smile.',
	'CAT_NAME'				=> 'Nome Categoria',
	'CAT_NAME_EXPLAIN'		=> '',
	'CAT_UPDATED'			=> 'Categoria aggiornata correttamente.',
	'CREATE_CAT'			=> 'Crea Categoria',

	'DELETE_CAT'			=> 'Elimina Categoria',
	'DELETE_CAT_CONFIRM'	=> 'Sei sicuro di voler eliminare questa categoria ?',

	'ICON'					=> 'Icona',

	'NO_CATS'				=> 'Nessuna Categoria',
));

?>
