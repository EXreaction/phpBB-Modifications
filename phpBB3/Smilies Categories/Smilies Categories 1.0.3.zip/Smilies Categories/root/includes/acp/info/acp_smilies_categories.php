<?php

/**
* @package module_install
*/
class acp_smilies_categories_info
{
	function module()
	{
		return array(
			'filename'	=> 'acp_smilies_categories',
			'title'		=> 'ACP_SMILIES_CATEGORIES',
			'version'	=> '1.0.0',
			'modes'		=> array(
				'default'	=> array('title' => 'ACP_SMILIES_CATEGORIES', 'auth' => 'acl_a_icons', 'cat' => array('ACP_MESSAGES')),
			),
		);
	}

	function install()
	{
	}

	function uninstall()
	{
	}
}

?>