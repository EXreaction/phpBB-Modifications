<?php

define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : '../';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup();

include($phpbb_root_path . 'smilies_install/eami.' . $phpEx);
include($phpbb_root_path . 'includes/functions_admin.' . $phpEx);
include($phpbb_root_path . 'includes/functions_install.' . $phpEx);
$dbmd = get_available_dbms($dbms);
$eami = new eami();

if ($dbms == 'mysql' || $dbms == 'mysqli')
{
	if ($dbms == 'mysqli' || version_compare($db->mysql_version, '4.1.3', '>='))
	{
		$dbms_schema = 'mysql_41_schema.sql';
	}
	else
	{
		$dbms_schema = 'mysql_40_schema.sql';
	}
}
else
{
	$dbms_schema = $dbms . '_schema.sql';
}

if (!file_exists($phpbb_root_path . 'smilies_install/schemas/' . $dbms_schema))
{
	trigger_error('The schema for your DB (' . $dbms . ') does not exist.');
}

$remove_remarks = $dbmd[$dbms]['COMMENTS'];
$delimiter = $dbmd[$dbms]['DELIM'];

$sql_query = @file_get_contents($phpbb_root_path . 'smilies_install/schemas/' . $dbms_schema);

$sql_query = preg_replace('#phpbb_#i', $table_prefix, $sql_query);

$remove_remarks($sql_query);

$sql_query = split_sql_file($sql_query, $delimiter);

foreach ($sql_query as $sql)
{
	if (!$db->sql_query($sql))
	{
		$error[] = $db->sql_error();
	}
}
unset($sql_query);

$sql_ary = array(
	'module_basename'	=> 'smilies_categories',
	'module_langname'	=> 'ACP_SMILIES_CATEGORIES',
	'module_mode'		=> 'default',
	'module_auth'		=> 'acl_a_icons',
);
$eami->add_module('acp', 'ACP_MESSAGES', $sql_ary);

trigger_error('Done installing, now delete the smilies_install/ folder!');
?>