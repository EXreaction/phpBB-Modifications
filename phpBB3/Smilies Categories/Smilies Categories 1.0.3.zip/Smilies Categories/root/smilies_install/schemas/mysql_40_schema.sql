#
# $Id: $
#

# Table: 'phpbb_smilies_categories'
CREATE TABLE phpbb_smilies_categories (
	cat_id mediumint(8) UNSIGNED NOT NULL auto_increment,
	cat_name blob NOT NULL,
	cat_count mediumint(8) UNSIGNED DEFAULT '0' NOT NULL,
	cat_icon blob NOT NULL,
	PRIMARY KEY (cat_id),
	KEY cat_count (cat_count)
);


# Table: 'phpbb_smilies_in_cats'
CREATE TABLE phpbb_smilies_in_cats (
	smiley_id mediumint(8) UNSIGNED DEFAULT '0' NOT NULL,
	cat_id mediumint(8) UNSIGNED DEFAULT '0' NOT NULL,
	PRIMARY KEY (smiley_id, cat_id)
);


