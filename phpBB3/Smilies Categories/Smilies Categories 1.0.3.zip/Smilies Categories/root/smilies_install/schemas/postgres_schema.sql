/*

 $Id: $

*/

BEGIN;


/*
	Table: 'phpbb_smilies_categories'
*/
CREATE SEQUENCE phpbb_smilies_categories_seq;

CREATE TABLE phpbb_smilies_categories (
	cat_id INT4 DEFAULT nextval('phpbb_smilies_categories_seq'),
	cat_name varchar(255) DEFAULT '' NOT NULL,
	cat_count INT4 DEFAULT '0' NOT NULL CHECK (cat_count >= 0),
	cat_icon varchar(255) DEFAULT '' NOT NULL,
	PRIMARY KEY (cat_id)
);

CREATE INDEX phpbb_smilies_categories_cat_count ON phpbb_smilies_categories (cat_count);

/*
	Table: 'phpbb_smilies_in_cats'
*/
CREATE TABLE phpbb_smilies_in_cats (
	smiley_id INT4 DEFAULT '0' NOT NULL CHECK (smiley_id >= 0),
	cat_id INT4 DEFAULT '0' NOT NULL CHECK (cat_id >= 0),
	PRIMARY KEY (smiley_id, cat_id)
);



COMMIT;