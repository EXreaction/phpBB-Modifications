#
# $Id: $
#

BEGIN TRANSACTION;

# Table: 'phpbb_smilies_categories'
CREATE TABLE phpbb_smilies_categories (
	cat_id INTEGER PRIMARY KEY NOT NULL ,
	cat_name text(65535) NOT NULL DEFAULT '',
	cat_count INTEGER UNSIGNED NOT NULL DEFAULT '0',
	cat_icon text(65535) NOT NULL DEFAULT ''
);

CREATE INDEX phpbb_smilies_categories_cat_count ON phpbb_smilies_categories (cat_count);

# Table: 'phpbb_smilies_in_cats'
CREATE TABLE phpbb_smilies_in_cats (
	smiley_id INTEGER UNSIGNED NOT NULL DEFAULT '0',
	cat_id INTEGER UNSIGNED NOT NULL DEFAULT '0',
	PRIMARY KEY (smiley_id, cat_id)
);



COMMIT;