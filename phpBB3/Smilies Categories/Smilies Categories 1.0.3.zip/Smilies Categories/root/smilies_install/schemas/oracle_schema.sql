/*

 $Id: $

*/


/*
	Table: 'phpbb_smilies_categories'
*/
CREATE TABLE phpbb_smilies_categories (
	cat_id number(8) NOT NULL,
	cat_name varchar2(765) DEFAULT '' ,
	cat_count number(8) DEFAULT '0' NOT NULL,
	cat_icon varchar2(765) DEFAULT '' ,
	CONSTRAINT pk_phpbb_smilies_categories PRIMARY KEY (cat_id)
)
/

CREATE INDEX phpbb_smilies_categories_cat_count ON phpbb_smilies_categories (cat_count)
/

CREATE SEQUENCE phpbb_smilies_categories_seq
/

CREATE OR REPLACE TRIGGER t_phpbb_smilies_categories
BEFORE INSERT ON phpbb_smilies_categories
FOR EACH ROW WHEN (
	new.cat_id IS NULL OR new.cat_id = 0
)
BEGIN
	SELECT phpbb_smilies_categories_seq.nextval
	INTO :new.cat_id
	FROM dual;
END;
/


/*
	Table: 'phpbb_smilies_in_cats'
*/
CREATE TABLE phpbb_smilies_in_cats (
	smiley_id number(8) DEFAULT '0' NOT NULL,
	cat_id number(8) DEFAULT '0' NOT NULL,
	CONSTRAINT pk_phpbb_smilies_in_cats PRIMARY KEY (smiley_id, cat_id)
)
/


