#
# $Id: $
#


# Table: 'phpbb_smilies_categories'
CREATE TABLE phpbb_smilies_categories (
	cat_id INTEGER NOT NULL,
	cat_name VARCHAR(255) CHARACTER SET UTF8 DEFAULT '' NOT NULL COLLATE UNICODE,
	cat_count INTEGER DEFAULT 0 NOT NULL,
	cat_icon VARCHAR(255) CHARACTER SET UTF8 DEFAULT '' NOT NULL COLLATE UNICODE
);;

ALTER TABLE phpbb_smilies_categories ADD PRIMARY KEY (cat_id);;

CREATE INDEX phpbb_smilies_categories_cat_count ON phpbb_smilies_categories(cat_count);;

CREATE GENERATOR phpbb_smilies_categories_gen;;
SET GENERATOR phpbb_smilies_categories_gen TO 0;;

CREATE TRIGGER t_phpbb_smilies_categories FOR phpbb_smilies_categories
BEFORE INSERT
AS
BEGIN
	NEW.cat_id = GEN_ID(phpbb_smilies_categories_gen, 1);
END;;


# Table: 'phpbb_smilies_in_cats'
CREATE TABLE phpbb_smilies_in_cats (
	smiley_id INTEGER DEFAULT 0 NOT NULL,
	cat_id INTEGER DEFAULT 0 NOT NULL
);;

ALTER TABLE phpbb_smilies_in_cats ADD PRIMARY KEY (smiley_id, cat_id);;


