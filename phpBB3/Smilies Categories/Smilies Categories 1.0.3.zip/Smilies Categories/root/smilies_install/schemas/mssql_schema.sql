/*

 $Id: $

*/

BEGIN TRANSACTION
GO

/*
	Table: 'phpbb_smilies_categories'
*/
CREATE TABLE [phpbb_smilies_categories] (
	[cat_id] [int] IDENTITY (1, 1) NOT NULL ,
	[cat_name] [varchar] (255) DEFAULT ('') NOT NULL ,
	[cat_count] [int] DEFAULT (0) NOT NULL ,
	[cat_icon] [varchar] (255) DEFAULT ('') NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [phpbb_smilies_categories] WITH NOCHECK ADD 
	CONSTRAINT [PK_phpbb_smilies_categories] PRIMARY KEY  CLUSTERED 
	(
		[cat_id]
	)  ON [PRIMARY] 
GO

CREATE  INDEX [cat_count] ON [phpbb_smilies_categories]([cat_count]) ON [PRIMARY]
GO


/*
	Table: 'phpbb_smilies_in_cats'
*/
CREATE TABLE [phpbb_smilies_in_cats] (
	[smiley_id] [int] DEFAULT (0) NOT NULL ,
	[cat_id] [int] DEFAULT (0) NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [phpbb_smilies_in_cats] WITH NOCHECK ADD 
	CONSTRAINT [PK_phpbb_smilies_in_cats] PRIMARY KEY  CLUSTERED 
	(
		[smiley_id],
		[cat_id]
	)  ON [PRIMARY] 
GO



COMMIT
GO

