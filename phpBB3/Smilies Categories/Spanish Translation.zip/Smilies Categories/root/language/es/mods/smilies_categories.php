﻿<?php
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'CATEGORY'				=> 'Categoría',
	'CAT_ADDED'				=> 'La categoría ha sido añadida correctamente.',
	'CAT_DELETED'			=> 'La categoría ha sido borrada correctamente.',
	'CAT_DETAILS'			=> 'Detalles de la categoría',
	'CAT_ICON'				=> 'Icono de la categoría',
	'CAT_ICON_EXPLAIN'		=> 'Escriba la URL entera del icono que deseas mostrar para esta categoría.  Puede usar "{SMILIES_PATH}" para especificar la ruta URL de los iconos.',
	'CAT_NAME'				=> 'Nombre de la categoría',
	'CAT_NAME_EXPLAIN'		=> '',
	'CAT_UPDATED'			=> 'La categoría ha sido actualizada correctamente.',
	'CREATE_CAT'			=> 'Crear categoría',

	'DELETE_CAT'			=> 'Borrar categoría',
	'DELETE_CAT_CONFIRM'	=> '¿Esta usted seguro de querer borrar esta categoría?',

	'ICON'					=> 'Icono',

	'NO_CATS'				=> 'No hay categorías',
));

?>