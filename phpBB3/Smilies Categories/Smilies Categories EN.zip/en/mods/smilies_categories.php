<?php
if (!defined('IN_PHPBB'))
{
	exit;
}

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'CATEGORY'				=> 'Category',
	'CAT_ADDED'				=> 'The category has been added successfully.',
	'CAT_DELETED'			=> 'The category has been deleted successfully.',
	'CAT_DETAILS'			=> 'Category Details',
	'CAT_ICON'				=> 'Category Icon',
	'CAT_ICON_EXPLAIN'		=> 'Type the full URL of the icon you want displayed for this category.  You may use "{SMILIES_PATH}" to specify the url to the smilies path.',
	'CAT_NAME'				=> 'Category Name',
	'CAT_NAME_EXPLAIN'		=> '',
	'CAT_UPDATED'			=> 'The category has been updated successfully.',
	'CREATE_CAT'			=> 'Create Category',

	'DELETE_CAT'			=> 'Delete Category',
	'DELETE_CAT_CONFIRM'	=> 'Are you sure you want to delete this category?',

	'ICON'					=> 'Icon',

	'NO_CATS'				=> 'No Categories',
));

?>