<?php
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'CP_GROUPS'					=> 'Custom Profile Groups',
	'CP_GROUPS_EXPLAIN'			=> 'Custom Profile Groups modification by EXreaction',
	'CP_GROUPS_EXPLAIN_ACP'		=> 'Select which group(s) you would like this profile field to be shown for.<br />Select none/dashes to show it for all groups.<br />Hold CTRL while selecting to select multiple groups.',
));

?>
