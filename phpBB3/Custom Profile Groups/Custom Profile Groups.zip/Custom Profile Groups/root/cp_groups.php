<?php
define('UMIL_AUTO', true);
define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
$user->session_begin();
$auth->acl($user->data);
$user->setup();

if (!file_exists($phpbb_root_path . 'umil/umil_auto.' . $phpEx))
{
	trigger_error('Please download the latest UMIL (Unified MOD Install Library) from: <a href="http://www.phpbb.com/mods/umil/">phpBB.com/mods/umil</a>', E_USER_ERROR);
}

$mod_name = 'CP_GROUPS';
$version_config_name = 'cp_groups_version';
$language_file = 'mods/cp_groups';

$versions = array(
	'1.0.0' => array(
		'table_column_add' => array(
			array(PROFILE_FIELDS_TABLE, 'field_group', array('VCHAR:30', '')),
		),
	),
);

include($phpbb_root_path . 'umil/umil_auto.' . $phpEx);

?>