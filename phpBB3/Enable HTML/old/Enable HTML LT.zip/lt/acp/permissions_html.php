<?php
// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'acl_u_html'		=> array('lang' => 'Gali Ra&#353;yti HTML &#303; &#382;inutes.<br /><em>Tai leid&#382;ia visus HTML, skriptus, bet tai visi&#353;kai pa&#382;eid&#382;ia saugumo priemonnes. &#352;is nustatymas <strong>niekada</strong> buti duotas jokiam vartotojui.</em>', 'cat' => 'post'),
	'acl_f_html'		=> array('lang' => 'Gali Ra&#353;yti HTML &#303; &#382;inutes.<br /><em>Tai leid&#382;ia visus HTML, skriptus, bet tai visi&#353;kai pa&#382;eid&#382;ia saugumo priemonnes. &#352;is nustatymas <strong>niekada</strong> buti duotas jokiam vartotojui.</em>', 'cat' => 'content'),
));
?>