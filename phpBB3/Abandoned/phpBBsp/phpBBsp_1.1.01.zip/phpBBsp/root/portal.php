<?php
/*
*
* @name portal.php
* @version 1.1.01
* @package phpBBsp
* @copyright (c) 2006 EXreaction, Lithium Studios 
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// START configuration
//

// Style ------------------------------------------------------------------------------------

// true if you want the original "Block" style, false if you want the "newspaper" style
$CFG['block_style'] = true;

// Announcments -------------------------------------------------------------------------

// Show announcments?
$CFG['announcements'] = true;

// Number of announcments on Portal
$CFG['number_of_announcments'] = '3';

// Number of days(0 means infinite) to display the announcment
$CFG['announcment_length'] = '5';

// Global Announcments forum(since it is in all forums, declare here one forum id that will be used for the reply button when it is a global announcment)
// If you don't understand what I mean, just pick any forum ID in your forums and put it here (if left blank it will have to run an extra SQL query to find one automatically).
$CFG['global_announcment_forum'] = '';

// News -------------------------------------------------------------------------------------

// Show news?
$CFG['news'] = true;

// Number of news articles on Portal(0 means infinite)
$CFG['number_of_news'] = '10';

// Max length(0 means infinite) of news article. 
//  Note:  If the post exceeds the length limit the BBCodes and Smileys will be removed.  Also, the length limit does not seem to accuratly count the chars, so you might need to set this higher
//                    than you think if you want it on.
$CFG['news_length'] = '0';

// News Forum ID(forum we pull the articles from, leave blank to pull from all forums) separate by comma for multiple forums, ex: '1,2,5'
$CFG['news_forum'] = '';

// Show all of the articles in this forum, including Stickies, Announcments, and Global Announcments?
$CFG['show_all_news'] = false;

//
// END configuration
// DONT CHANGE ANYTHING BELOW UNLESS YOU KNOW WHAT YOU ARE DOING!
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Note: If you would like to have the portal in a different location than in the main phpBB3 directory
// You must change the following variable, and change the 'U_PORTAL' template variable in functions.php
$phpbb_root_path = './';


define('IN_PHPBB', true);
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/message_parser.'.$phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('viewforum');

/*
 * Strip all BBCodes and Smileys from the post
 */
function strip_post($text, $uid, &$text_length)
{
	// for BBCode
	$text = preg_replace("#\[\/?[a-z0-9\*\+\-]+(?:=.*?)?(?::[a-z])?(\:?$uid)\]#", '', $text);
	
	// for smileys
	$text = preg_replace('#<!\-\- s(.*?) \-\-><img src="\{SMILIES_PATH\}\/.*? \/><!\-\- s(.*?) \-\->#', '', $text, -1, $replacements);

	if ($text_length != 0)
	{
		$text_length += $replacements;
	}

	return $text;	
}

function phpbb_fetch_posts($forum_sql, $number_of_posts, $text_length, $time, $type)
{
	global $db, $user, $phpbb_root_path, $phpEx, $auth;
	
	$from_forum = ($forum_sql != '') ? 't.forum_id IN (' . $forum_sql . ') AND' : '';
	$post_time = ($time == 0) ? '' : 't.topic_time > ' . (time() - $time * 86400) . ' AND';

	if ($type == 'announcments')
	{
		$topic_type = '( t.topic_type = 2 OR t.topic_type = 3 ) AND';
	}
	else if ($type == 'news_all')
	{
		$topic_type = '';
	}
	else
	{
		$topic_type = 't.topic_type = 0 AND';
	}

	$sql = 'SELECT
			t.forum_id,
			t.topic_id,
			t.topic_time,
			t.topic_title,
			p.post_text,
			u.username,
			t.topic_replies,
			p.bbcode_uid,
			t.forum_id,
			t.topic_poster,
			p.post_id,
			p.enable_smilies,
			p.enable_bbcode,
			p.enable_magic_url,
			p.bbcode_bitfield,
			p.bbcode_uid,
			t.topic_attachment,
			t.poll_title
		FROM
			' . TOPICS_TABLE . ' AS t,
			' . USERS_TABLE . ' AS u,
			' . POSTS_TABLE . ' AS p
		WHERE
			' . $topic_type . '
			' . $from_forum . '
			' . $post_time . '
			t.topic_poster = u.user_id AND
			t.topic_first_post_id = p.post_id AND
			t.topic_first_post_id = p.post_id AND
			t.topic_status <> 2 AND
			t.topic_approved = 1
		ORDER BY
			t.topic_time DESC';

	if(!($result = $db->sql_query($sql)))
	{
		die('Could not query topic information');
	}

	$posts = array();
	$i = 0;
	while ( ($row = $db->sql_fetchrow($result)) && ( ($i < $number_of_posts) || ($number_of_posts == '0') ) )
	{
		if ( ($auth->acl_get('f_read', $row['forum_id'])) || ($row['forum_id'] == '0') )
		{
			$posts[$i]['post_text'] = censor_text($row['post_text']);
			$posts[$i]['topic_id'] = $row['topic_id'];
			$posts[$i]['forum_id'] = $row['forum_id'];
			$posts[$i]['topic_replies'] = $row['topic_replies'];
			$posts[$i]['topic_time'] = $user->format_date($row['topic_time']);
			$posts[$i]['topic_title'] = $row['topic_title'];
			$posts[$i]['username'] = $row['username'];
			$posts[$i]['poll'] = ($row['poll_title'] != '') ? true : false;
			$posts[$i]['attachment'] = ($row['topic_attachment']) ? true : false;

			$len_check = $posts[$i]['post_text'];

			$len_check = strip_post($len_check, $row['bbcode_uid'], $text_length);

			if (($text_length != 0) && (strlen($len_check) > $text_length))
			{
				$posts[$i]['post_text'] = substr($len_check, 0, $text_length);
				$posts[$i]['post_text'] .= '...';
				$posts[$i]['striped'] = true;
			}

			include_once($phpbb_root_path . 'includes/bbcode.' . $phpEx);
			$bbcode = new bbcode($row['bbcode_bitfield']);
			$posts[$i]['post_text'] = censor_text($posts[$i]['post_text']);

			$bbcode->bbcode_second_pass($posts[$i]['post_text'], $row['bbcode_uid'], $row['bbcode_bitfield']);
			$posts[$i]['post_text'] = smiley_text($posts[$i]['post_text']);
			$posts[$i]['post_text'] = str_replace("\n", '<br />', $posts[$i]['post_text']);
			$i++;
		}
	}

	return $posts;
}

//
// Fetch Posts for announcments
//
if($CFG['announcements'] == true)
{	
	$fetch_announcments = phpbb_fetch_posts('', $CFG['number_of_announcments'], 0, $CFG['announcment_length'], 'announcments');

	if ( (!intval($CFG['global_announcment_forum'])) && (count($fetch_announcments) > 0) )
	{
		$sql = 'SELECT forum_id FROM ' . FORUMS_TABLE . ' WHERE forum_type = 1';
		if(!($result = $db->sql_query_limit($sql, '1')))
		{
			die('Could not query forum information');
		}
		$row = $db->sql_fetchrow($result);		
		$CFG['global_announcment_forum'] =  $row['forum_id'];
	}

	for ($i = 0; $i < count($fetch_announcments); $i++)
	{
		$a_fid = (intval($fetch_announcments[$i]['forum_id'])) ? $fetch_announcments[$i]['forum_id'] : $CFG['global_announcment_forum'];
		$template->assign_block_vars('announcments_row', array(
			'ATTACH_ICON_IMG'	=> ($fetch_announcments[$i]['attachment']) ? $user->img('icon_attach', $user->lang['TOTAL_ATTACHMENTS']) : '',
            'TITLE'				=> $fetch_announcments[$i]['topic_title'],
            'POSTER'			=> $fetch_announcments[$i]['username'],
      		'TIME'				=> $fetch_announcments[$i]['topic_time'],
            'TEXT'				=> $fetch_announcments[$i]['post_text'],
            'REPLIES'			=> $fetch_announcments[$i]['topic_replies'],
            'U_VIEW_COMMENTS'	=> append_sid($phpbb_root_path . 'viewtopic.' . $phpEx . '?t=' . $fetch_announcments[$i]['topic_id'] . '&f=' . $a_fid),
            'U_POST_COMMENT'	=> append_sid($phpbb_root_path . 'posting.' . $phpEx . '?mode=reply&amp;t=' . $fetch_announcments[$i]['topic_id'] . '&f=' . $a_fid),
            'S_NOT_LAST'		=> ($i < count($fetch_announcments) - 1) ? true : false,
			'S_POLL'			=> $fetch_announcments[$i]['poll']
		));
	}

	$template->assign_vars(array(
		'S_DISPLAY_ANNOUNCMENT_LIST'	=> (count($fetch_announcments) == 0 || isset($HTTP_GET_VARS['article'])) ? false : true
	));
}
//
// End fetch Posts for announcments
//

//
// Fetch Posts for news
//
if( (!isset($HTTP_GET_VARS['article'])) && ($CFG['news'] == true) )
{
	$fetch_news = phpbb_fetch_posts($CFG['news_forum'], $CFG['number_of_news'], $CFG['news_length'], 0, ($CFG['show_all_news']) ? 'news_all' : 'news');
	
	if (count($fetch_news) == 0)
	{
		$template->assign_block_vars('news_row', array(
			'S_NO_TOPICS'	=> true,
			'S_NOT_LAST'	=> false
		));
	}
	else
	{
		for ($i = 0; $i < count($fetch_news); $i++)
		{
	      	if( isset($fetch_news[$i]['striped']) && $fetch_news[$i]['striped'] == true )
	      	{
				$open_bracket = '[ ';
				$close_bracket = ' ]';
				$read_full = $user->lang['READ_FULL'];
			}
			else
			{
	      	      $open_bracket = '';
	      	      $close_bracket = '';
	      	      $read_full = '';
			}
			
			$template->assign_block_vars('news_row', array(
				'ATTACH_ICON_IMG'	=> ($fetch_news[$i]['attachment']) ? $user->img('icon_attach', $user->lang['TOTAL_ATTACHMENTS']) : '',
				'TITLE'				=> $fetch_news[$i]['topic_title'],
				'POSTER'			=> $fetch_news[$i]['username'],
				'TIME'				=> $fetch_news[$i]['topic_time'],
				'TEXT'				=> $fetch_news[$i]['post_text'],
				'REPLIES'			=> $fetch_news[$i]['topic_replies'],
				'U_VIEW_COMMENTS'	=> append_sid($phpbb_root_path . 'viewtopic.' . $phpEx . '?t=' . $fetch_news[$i]['topic_id'] . '&f=' . $fetch_news[$i]['forum_id']),
				'U_POST_COMMENT'	=> append_sid($phpbb_root_path . 'posting.' . $phpEx . '?mode=reply&amp;t=' . $fetch_news[$i]['topic_id'] . '&f=' . $fetch_news[$i]['forum_id']),
				'U_READ_FULL'		=> append_sid($_SERVER['PHP_SELF'] . '?article=' . $i),
				'L_READ_FULL'		=> $read_full,
				'OPEN'				=> $open_bracket,
				'CLOSE'				=> $close_bracket,
				'S_NOT_LAST'		=> ($i < count($fetch_news) - 1) ? true : false,
				'S_POLL'			=> $fetch_news[$i]['poll']
			));
		}
	}

	$template->assign_vars(array(
		'S_DISPLAY_NEWS_LIST'	=> true
	));

}
else if ($CFG['news'] == true)
{
	$fetch_news = phpbb_fetch_posts($CFG['news_forum'], $CFG['number_of_news'], 0, 0, ($CFG['show_all_news']) ? 'news_all' : 'news');

	$i = intval($HTTP_GET_VARS['article']);

	$template->assign_block_vars('news_row', array(
		'ATTACH_ICON_IMG'	=> ($fetch_news[$i]['attachment']) ? $user->img('icon_attach', $user->lang['TOTAL_ATTACHMENTS']) : '',
		'TITLE'				=> $fetch_news[$i]['topic_title'],
		'POSTER'			=> $fetch_news[$i]['username'],
		'TIME'				=> $fetch_news[$i]['topic_time'],
		'TEXT'				=> $fetch_news[$i]['post_text'],
		'REPLIES'			=> $fetch_news[$i]['topic_replies'],
		'U_VIEW_COMMENTS'	=> append_sid($phpbb_root_path . 'viewtopic.' . $phpEx . '?t=' . $fetch_news[$i]['topic_id']),
		'U_POST_COMMENT'	=> append_sid($phpbb_root_path . 'posting.' . $phpEx . '?mode=reply&amp;t=' . $fetch_news[$i]['topic_id'] . '&f=' . $fetch_news[$i]['forum_id']),
		'S_POLL'			=> $fetch_news[$i]['poll']
	));

	$template->assign_vars(array(
		'S_DISPLAY_NEWS_LIST'	=> true
	));
}
//
// End fetch Posts for news 
//

//
// Fetch Who is Online, B-Days, and Stats(borrowed from index.php(v3.0 DEV B3) if this gets changed(in index.php) and I don't notice it, please tell me)
//

// Set some stats, get posts count from forums data if we... hum... retrieve all forums data
$total_posts	= $config['num_posts'];
$total_topics	= $config['num_topics'];
$total_users	= $config['num_users'];
$newest_user	= $config['newest_username'];
$newest_uid		= $config['newest_user_id'];

$l_total_user_s = ($total_users == 0) ? 'TOTAL_USERS_ZERO' : 'TOTAL_USERS_OTHER';
$l_total_post_s = ($total_posts == 0) ? 'TOTAL_POSTS_ZERO' : 'TOTAL_POSTS_OTHER';
$l_total_topic_s = ($total_topics == 0) ? 'TOTAL_TOPICS_ZERO' : 'TOTAL_TOPICS_OTHER';

// Grab group details for legend display
$sql = 'SELECT group_id, group_name, group_colour, group_type
	FROM ' . GROUPS_TABLE . '
	WHERE group_legend = 1
		AND group_type <> ' . GROUP_HIDDEN . '
	ORDER BY group_name ASC';
$result = $db->sql_query($sql);

$legend = '';
while ($row = $db->sql_fetchrow($result))
{
	if ($row['group_name'] == 'BOTS')
	{
		$legend .= (($legend != '') ? ', ' : '') . '<span style="color:#' . $row['group_colour'] . '">' . $user->lang['G_BOTS'] . '</span>';
	}
	else
	{
		$legend .= (($legend != '') ? ', ' : '') . '<a style="color:#' . $row['group_colour'] . '" href="' . append_sid("{$phpbb_root_path}memberlist.$phpEx", 'mode=group&amp;g=' . $row['group_id']) . '">' . (($row['group_type'] == GROUP_SPECIAL) ? $user->lang['G_' . $row['group_name']] : $row['group_name']) . '</a>';
	}
}
$db->sql_freeresult($result);

// Generate birthday list if required ...
$birthday_list = '';
if ($config['load_birthdays'])
{
	$now = getdate(time() + $user->timezone + $user->dst - (date('H', time()) - gmdate('H', time())) * 3600);
	$sql = 'SELECT user_id, username, user_colour, user_birthday
		FROM ' . USERS_TABLE . "
		WHERE user_birthday LIKE '" . $db->sql_escape(sprintf('%2d-%2d-', $now['mday'], $now['mon'])) . "%'
			AND user_type IN (" . USER_NORMAL . ', ' . USER_FOUNDER . ')';
	$result = $db->sql_query($sql);

	while ($row = $db->sql_fetchrow($result))
	{
		$user_colour = ($row['user_colour']) ? ' style="color:#' . $row['user_colour'] .'"' : '';
		$birthday_list .= (($birthday_list != '') ? ', ' : '') . '<a' . $user_colour . ' href="' . append_sid("{$phpbb_root_path}memberlist.$phpEx", 'mode=viewprofile&amp;u=' . $row['user_id']) . '">' . $row['username'] . '</a>';

		if ($age = (int) substr($row['user_birthday'], -4))
		{
			$birthday_list .= ' (' . ($now['year'] - $age) . ')';
		}
	}
	$db->sql_freeresult($result);
}

// Assign index specific vars

$template->assign_vars(array(
	'TOTAL_POSTS'			=> sprintf($user->lang[$l_total_post_s], $total_posts),
	'TOTAL_TOPICS'			=> sprintf($user->lang[$l_total_topic_s], $total_topics),
	'TOTAL_USERS'			=> sprintf($user->lang[$l_total_user_s], $total_users),
	'NEWEST_USER'			=> sprintf($user->lang['NEWEST_USER'], '<a href="' . append_sid("{$phpbb_root_path}memberlist.$phpEx", 'mode=viewprofile&amp;u=' . $newest_uid) . '">', $newest_user, '</a>'),
	'LEGEND'				=> $legend,
	'BIRTHDAY_LIST'			=> $birthday_list,

	'S_LOGIN_ACTION'			=> append_sid("{$phpbb_root_path}ucp.$phpEx", 'mode=login'),
	'S_DISPLAY_BIRTHDAY_LIST'	=> ($config['load_birthdays']) ? true : false,
	'S_BLOCK_STYLE'				=> $CFG['block_style'],

	'U_MCP'					=> ($auth->acl_get('m_') || $auth->acl_getf_global('m_')) ? append_sid("{$phpbb_root_path}mcp.$phpEx", 'i=main&amp;mode=front', true, $user->session_id) : '',
	'L_ANNOUNCMENTS'		=> $user->lang['ANNOUNCMENTS'],
	'L_NEWS'				=> $user->lang['NEWS'],
	'L_NO_NEWS'				=> $user->lang['NO_NEWS'],
	'L_POSTED_BY'			=> $user->lang['POSTED_BY'],
	'L_AT'					=> $user->lang['AT'],
	'L_COMMENTS'			=> $user->lang['COMMENTS'],
	'L_VIEW_COMMENTS'		=> $user->lang['VIEW_COMMENTS'],
	'L_POST_REPLY'			=> $user->lang['POST_REPLY']
	)
);

// Output page
page_header($user->lang['PORTAL']);

$template->set_filenames(array(
    'body' => 'portal_body.html')
);

page_footer();

?>