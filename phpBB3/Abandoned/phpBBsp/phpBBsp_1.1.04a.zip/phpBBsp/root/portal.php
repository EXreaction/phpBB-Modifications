<?php
/*
*
* @name portal.php
* @version 1.1.04a
* @package phpBBsp
* @copyright (c) 2007 EXreaction, Lithium Studios 
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// START configuration
//

// Style ------------------------------------------------------------------------------------

// true if you want the original "Block" style, false if you want the "newspaper" style
$CFG['block_style'] = true;

// announcements -------------------------------------------------------------------------

// Show announcements?
$CFG['announcements'] = true;

// Number of announcements on Portal
$CFG['number_of_announcements'] = '3';

// Number of days(0 means infinite) to display the announcement
$CFG['announcement_length'] = '5';

// Global announcements forum(since it is in all forums, declare here one forum id that will be used for the reply button when it is a global announcement)
// If you don't understand what I mean, just pick any forum ID in your forums and put it here (if left blank it will have to run an extra SQL query to find one automatically).
$CFG['global_announcement_forum'] = '';

// News -------------------------------------------------------------------------------------

// Show news?
$CFG['news'] = true;

// Number of news articles on Portal(0 means infinite)
$CFG['number_of_news'] = '10';

// Max length(0 means infinite) of news article. 
//  Note:  If the post exceeds the length limit the BBCodes and Smileys will be removed.  Also, the length limit does not seem to accuratly count the chars, so you might need to set this higher
//                    than you think if you want it on.
$CFG['news_length'] = '0';

// News Forum ID(forum we pull the articles from, leave blank to pull from all forums) separate by comma for multiple forums, ex: '1,2,5'
$CFG['news_forum'] = '';

// Show all of the articles in this forum, including Stickies, announcements, and Global announcements?
$CFG['show_all_news'] = false;

//
// END configuration
// DONT CHANGE ANYTHING BELOW UNLESS YOU KNOW WHAT YOU ARE DOING!
// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Note: If you would like to have the portal in a different location than in the main phpBB3 directory
// You must change the following variable, and change the 'U_PORTAL' template variable in functions.php
$phpbb_root_path = './';


define('IN_PHPBB', true);
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/message_parser.'.$phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('portal');

/*
 * Strip all BBCodes and Smileys from the post
 */
function strip_post($text, $uid, &$text_length)
{
	// for BBCode
	$text = preg_replace("#\[\/?[a-z0-9\*\+\-]+(?:=.*?)?(?::[a-z])?(\:?$uid)\]#", '', $text);

	// for smileys
	$text = preg_replace('#<!\-\- s(.*?) \-\-><img src="\{SMILIES_PATH\}\/.*? \/><!\-\- s(.*?) \-\->#', '', $text, -1);

	return $text;	
}

function phpbb_fetch_posts($from_forum, $number_of_posts, $text_length, $post_time, $type)
{
	global $db, $user, $phpbb_root_path, $phpEx, $auth;

	// To select from only certain forums(using forum_id)
	$from_forum = ($from_forum != '') ? 't.forum_id IN (' . $from_forum . ') AND' : '';

	// To limit the time displayed on the portal
	$post_time = ($post_time == 0) ? '' : 't.topic_time > ' . (time() - $post_time * 86400) . ' AND';

	// To limit the types picked, if only announcements, all, or only regular
	if ($type == 'announcements')
	{
		$topic_type = '( t.topic_type = 2 OR t.topic_type = 3 ) AND';
	}
	else if ($type == 'news_all')
	{
		$topic_type = '';
	}
	else
	{
		$topic_type = 't.topic_type = 0 AND';
	}

	$sql = 'SELECT
			t.forum_id,
			t.topic_id,
			t.topic_time,
			t.topic_title,
			p.post_text,
			u.username,
			t.topic_replies,
			p.bbcode_uid,
			t.forum_id,
			t.topic_poster,
			p.post_id,
			p.enable_smilies,
			p.enable_bbcode,
			p.enable_magic_url,
			p.bbcode_bitfield,
			p.bbcode_uid,
			t.topic_attachment,
			t.poll_title
		FROM
			' . TOPICS_TABLE . ' AS t,
			' . USERS_TABLE . ' AS u,
			' . POSTS_TABLE . ' AS p
		WHERE
			' . $topic_type . '
			' . $from_forum . '
			' . $post_time . '
			t.topic_poster = u.user_id AND
			t.topic_first_post_id = p.post_id AND
			t.topic_first_post_id = p.post_id AND
			t.topic_status <> 2 AND
			t.topic_approved = 1
		ORDER BY
			t.topic_time DESC';

	if(!($result = $db->sql_query($sql)))
	{
		die('Could not query topic information');
	}

	$posts = array();
	$i = 0;
	while ( ($row = $db->sql_fetchrow($result)) && ( ($i < $number_of_posts) || ($number_of_posts == '0') ) )
	{
		if ( ($auth->acl_get('f_read', $row['forum_id'])) || ($row['forum_id'] == '0') )
		{
			$posts[$i]['post_text']		= censor_text($row['post_text']);
			$posts[$i]['topic_id']		= $row['topic_id'];
			$posts[$i]['forum_id']		= $row['forum_id'];
			$posts[$i]['topic_replies']	= $row['topic_replies'];
			$posts[$i]['topic_time']	= $user->format_date($row['topic_time']);
			$posts[$i]['topic_title']	= $row['topic_title'];
			$posts[$i]['username']		= $row['username'];
			$posts[$i]['poll']			= ($row['poll_title'] != '') ? true : false;
			$posts[$i]['attachment']	= ($row['topic_attachment']) ? true : false;

			// Make another copy of it to check the length, then strip the BBCode and smilies
			$len_check = $posts[$i]['post_text'];
			$len_check = strip_post($len_check, $row['bbcode_uid'], $text_length);

			// 0 means there is no limit, so if it has a limit and the stripped text is longer than the limit use the stripped version, remove the extra chars, and add a ... to the end of it
			if (($text_length != 0) && (strlen($len_check) > $text_length))
			{
				$posts[$i]['post_text'] = substr($len_check, 0, $text_length);
				$posts[$i]['post_text'] .= '...';
				$posts[$i]['striped'] = true;
			}
			else
			{
				// else parse the BBCode
				include_once($phpbb_root_path . 'includes/bbcode.' . $phpEx);
				$bbcode = new bbcode($row['bbcode_bitfield']);

				$bbcode->bbcode_second_pass($posts[$i]['post_text'], $row['bbcode_uid'], $row['bbcode_bitfield']);
				$posts[$i]['post_text'] = smiley_text($posts[$i]['post_text']);
			}

			// Replace any \n so that the end lines are counted and all the text is not put onto one line.
			$posts[$i]['post_text'] = str_replace("\n", '<br />', $posts[$i]['post_text']);
			$i++;
		}
	}

	return $posts;
}

//
// Fetch Posts for announcements
//
if ( ($CFG['announcements'] == true) && (!isset($_GET['article'])) )
{
	// Get the wanted announcements
	$fetch_announcements = phpbb_fetch_posts('', $CFG['number_of_announcements'], 0, $CFG['announcement_length'], 'announcements');

	// Count the number of announcements now so we do not need to keep doing it
	$count = count($fetch_announcements);

	// Here we get a forum_id to use in the link if one was not supplied earlier
	if ( (!intval($CFG['global_announcement_forum'])) && ($count > 0) )
	{
		$sql = 'SELECT forum_id FROM ' . FORUMS_TABLE . ' WHERE forum_type = 1';
		if(!($result = $db->sql_query_limit($sql, '1')))
		{
			die('Could not query forum information');
		}
		$row = $db->sql_fetchrow($result);		
		$CFG['global_announcement_forum'] =  $row['forum_id'];
	}

	// Display the announcements
	for ($i = 0; $i < $count; $i++)
	{
		$a_fid = (intval($fetch_announcements[$i]['forum_id'])) ? $fetch_announcements[$i]['forum_id'] : $CFG['global_announcement_forum'];
		$template->assign_block_vars('announcements_row', array(
			'ATTACH_ICON_IMG'	=> ($fetch_announcements[$i]['attachment']) ? $user->img('icon_attach', $user->lang['TOTAL_ATTACHMENTS']) : '',
            'TITLE'				=> $fetch_announcements[$i]['topic_title'],
            'POSTER'			=> $fetch_announcements[$i]['username'],
      		'TIME'				=> $fetch_announcements[$i]['topic_time'],
            'TEXT'				=> $fetch_announcements[$i]['post_text'],
            'REPLIES'			=> $fetch_announcements[$i]['topic_replies'],
            'U_VIEW_COMMENTS'	=> append_sid($phpbb_root_path . 'viewtopic.' . $phpEx . '?t=' . $fetch_announcements[$i]['topic_id'] . '&f=' . $a_fid),
            'U_POST_COMMENT'	=> append_sid($phpbb_root_path . 'posting.' . $phpEx . '?mode=reply&amp;t=' . $fetch_announcements[$i]['topic_id'] . '&f=' . $a_fid),
            'S_NOT_LAST'		=> ($i < count($fetch_announcements) - 1) ? true : false,
			'S_POLL'			=> $fetch_announcements[$i]['poll']
		));
	}

	// Turn on the switch over the announcements if there is at least 1 article
	$template->assign_vars(array(
		'S_DISPLAY_ANNOUNCEMENT_LIST'	=> ($count == 0) ? false : true
	));
}
//
// End fetch Posts for announcements
//

//
// Fetch Posts for news
//
// If the news is on and the user is not trying to view an entire article
if( (!isset($_GET['article'])) && ($CFG['news'] == true) )
{
	// Get the wanted news
	$fetch_news = phpbb_fetch_posts($CFG['news_forum'], $CFG['number_of_news'], $CFG['news_length'], 0, ($CFG['show_all_news']) ? 'news_all' : 'news');

	// Count the number of news articles now so we do not need to keep doing it
	$count = count($fetch_news);

	if ($count == 0)
	{
		$template->assign_block_vars('news_row', array(
			'S_NO_TOPICS'	=> true,
			'S_NOT_LAST'	=> false
		));
	}
	else
	{
		for ($i = 0; $i < $count; $i++)
		{
	      	if( isset($fetch_news[$i]['striped']) && $fetch_news[$i]['striped'] == true )
	      	{
				$url = append_sid($_SERVER['PHP_SELF'] . '?article=' . $i);
				$read_full = '[ <a href="' . $url . '">' . $user->lang['READ_FULL'] . '</a> ]';
			}
			else
			{
	      	      $read_full = '';
			}
			
			$template->assign_block_vars('news_row', array(
				'ATTACH_ICON_IMG'	=> ($fetch_news[$i]['attachment']) ? $user->img('icon_attach', $user->lang['TOTAL_ATTACHMENTS']) : '',
				'TITLE'				=> $fetch_news[$i]['topic_title'],
				'POSTER'			=> $fetch_news[$i]['username'],
				'TIME'				=> $fetch_news[$i]['topic_time'],
				'TEXT'				=> $fetch_news[$i]['post_text'],
				'REPLIES'			=> $fetch_news[$i]['topic_replies'],
				'U_VIEW_COMMENTS'	=> append_sid($phpbb_root_path . 'viewtopic.' . $phpEx . '?t=' . $fetch_news[$i]['topic_id'] . '&f=' . $fetch_news[$i]['forum_id']),
				'U_POST_COMMENT'	=> append_sid($phpbb_root_path . 'posting.' . $phpEx . '?mode=reply&amp;t=' . $fetch_news[$i]['topic_id'] . '&f=' . $fetch_news[$i]['forum_id']),
				'L_READ_FULL'		=> $read_full,
				'S_NOT_LAST'		=> ($i < count($fetch_news) - 1) ? true : false,
				'S_POLL'			=> $fetch_news[$i]['poll']
			));
		}
	}

	$template->assign_vars(array(
		'S_DISPLAY_NEWS_LIST'	=> true
	));

}
else if ($CFG['news'] == true) // If the user is trying to view an article and news is on
{
	// Get the wanted news
	$fetch_news = phpbb_fetch_posts($CFG['news_forum'], $CFG['number_of_news'], 0, 0, ($CFG['show_all_news']) ? 'news_all' : 'news');

	// The article number they want to view
	$i = intval($_GET['article']);

	if ($i > (count($fetch_news) - 1)) // if someone is messing with the $_GET and it goes above what it can
	{
		$template->assign_block_vars('news_row', array(
			'S_NO_TOPICS'	=> true,
			'S_NOT_LAST'	=> false
		));
	}
	else
	{
		$template->assign_block_vars('news_row', array(
			'ATTACH_ICON_IMG'	=> ($fetch_news[$i]['attachment']) ? $user->img('icon_attach', $user->lang['TOTAL_ATTACHMENTS']) : '',
			'TITLE'				=> $fetch_news[$i]['topic_title'],
			'POSTER'			=> $fetch_news[$i]['username'],
			'TIME'				=> $fetch_news[$i]['topic_time'],
			'TEXT'				=> $fetch_news[$i]['post_text'],
			'REPLIES'			=> $fetch_news[$i]['topic_replies'],
			'U_VIEW_COMMENTS'	=> append_sid($phpbb_root_path . 'viewtopic.' . $phpEx . '?t=' . $fetch_news[$i]['topic_id']),
			'U_POST_COMMENT'	=> append_sid($phpbb_root_path . 'posting.' . $phpEx . '?mode=reply&amp;t=' . $fetch_news[$i]['topic_id'] . '&f=' . $fetch_news[$i]['forum_id']),
			'S_POLL'			=> $fetch_news[$i]['poll']
		));
	}

	$template->assign_vars(array(
		'S_DISPLAY_NEWS_LIST'	=> true
	));
}
//
// End fetch Posts for news 
//

//
// Fetch Who is Online, B-Days, and Stats(borrowed from index.php(v3.0 B5) if this gets changed(in index.php) and I don't notice it, please tell me)
//

// Set some stats, get posts count from forums data if we... hum... retrieve all forums data
$total_posts	= $config['num_posts'];
$total_topics	= $config['num_topics'];
$total_users	= $config['num_users'];
$newest_user	= $config['newest_username'];
$newest_uid		= $config['newest_user_id'];

$l_total_user_s = ($total_users == 0) ? 'TOTAL_USERS_ZERO' : 'TOTAL_USERS_OTHER';
$l_total_post_s = ($total_posts == 0) ? 'TOTAL_POSTS_ZERO' : 'TOTAL_POSTS_OTHER';
$l_total_topic_s = ($total_topics == 0) ? 'TOTAL_TOPICS_ZERO' : 'TOTAL_TOPICS_OTHER';

// Grab group details for legend display
$sql = 'SELECT group_id, group_name, group_colour, group_type
	FROM ' . GROUPS_TABLE . '
	WHERE group_legend = 1
		AND group_type <> ' . GROUP_HIDDEN . '
	ORDER BY group_name ASC';
$result = $db->sql_query($sql);

$legend = '';
while ($row = $db->sql_fetchrow($result))
{
	if ($row['group_name'] == 'BOTS')
	{
		$legend .= (($legend != '') ? ', ' : '') . '<span style="color:#' . $row['group_colour'] . '">' . $user->lang['G_BOTS'] . '</span>';
	}
	else
	{
		$legend .= (($legend != '') ? ', ' : '') . '<a style="color:#' . $row['group_colour'] . '" href="' . append_sid("{$phpbb_root_path}memberlist.$phpEx", 'mode=group&amp;g=' . $row['group_id']) . '">' . (($row['group_type'] == GROUP_SPECIAL) ? $user->lang['G_' . $row['group_name']] : $row['group_name']) . '</a>';
	}
}
$db->sql_freeresult($result);

// Generate birthday list if required ...
$birthday_list = '';
if ($config['load_birthdays'])
{
	$now = getdate(time() + $user->timezone + $user->dst - date('Z'));
	$sql = 'SELECT user_id, username, user_colour, user_birthday
		FROM ' . USERS_TABLE . "
		WHERE user_birthday LIKE '" . $db->sql_escape(sprintf('%2d-%2d-', $now['mday'], $now['mon'])) . "%'
			AND user_type IN (" . USER_NORMAL . ', ' . USER_FOUNDER . ')';
	$result = $db->sql_query($sql);

	while ($row = $db->sql_fetchrow($result))
	{
		$user_colour = ($row['user_colour']) ? ' style="color:#' . $row['user_colour'] .'"' : '';
		$birthday_list .= (($birthday_list != '') ? ', ' : '') . '<a' . $user_colour . ' href="' . append_sid("{$phpbb_root_path}memberlist.$phpEx", 'mode=viewprofile&amp;u=' . $row['user_id']) . '">' . $row['username'] . '</a>';

		if ($age = (int) substr($row['user_birthday'], -4))
		{
			$birthday_list .= ' (' . ($now['year'] - $age) . ')';
		}
	}
	$db->sql_freeresult($result);
}

// Assign index specific vars

$template->assign_vars(array(
	'TOTAL_POSTS'				=> sprintf($user->lang[$l_total_post_s], $total_posts),
	'TOTAL_TOPICS'				=> sprintf($user->lang[$l_total_topic_s], $total_topics),
	'TOTAL_USERS'				=> sprintf($user->lang[$l_total_user_s], $total_users),
	'NEWEST_USER'				=> sprintf($user->lang['NEWEST_USER'], '<a href="' . append_sid("{$phpbb_root_path}memberlist.$phpEx", 'mode=viewprofile&amp;u=' . $newest_uid) . '" style="color:#' . $config['newest_user_colour'] . '">', $newest_user, '</a>'),
	'LEGEND'					=> $legend,
	'BIRTHDAY_LIST'				=> $birthday_list,

	'S_LOGIN_ACTION'			=> append_sid("{$phpbb_root_path}ucp.$phpEx", 'mode=login'),
	'S_DISPLAY_BIRTHDAY_LIST'	=> ($config['load_birthdays']) ? true : false,
	'S_BLOCK_STYLE'				=> $CFG['block_style'],

	'U_MCP'						=> ($auth->acl_get('m_') || $auth->acl_getf_global('m_')) ? append_sid("{$phpbb_root_path}mcp.$phpEx", 'i=main&amp;mode=front', true, $user->session_id) : '',
	'L_ANNOUNCEMENTS'			=> $user->lang['announcements'],
	'L_NEWS'					=> $user->lang['NEWS'],
	'L_NO_NEWS'					=> $user->lang['NO_NEWS'],
	'L_POSTED_BY'				=> $user->lang['POSTED_BY'],
	'L_AT'						=> $user->lang['AT'],
	'L_COMMENTS'				=> $user->lang['COMMENTS'],
	'L_VIEW_COMMENTS'			=> $user->lang['VIEW_COMMENTS'],
	'L_POST_REPLY'				=> $user->lang['POST_REPLY']
	));

// Output page
page_header($user->lang['PORTAL']);

$template->set_filenames(array(
    'body' => 'portal_body.html')
);

page_footer();

?>