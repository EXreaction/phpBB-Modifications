<?php
/**
* @package module_install
*/
class mcp_giveaway_info
{
	function module()
	{
		return array(
			'filename'	=> 'mcp_giveaway',
			'title'		=> 'Giveaway',
			'version'	=> '1.0.0',
			'modes'		=> array(
				'main'		=> array('title' => 'Main', 'auth' => 'acl_m_giveaway', 'cat' => array('MCP_GIVEAWAY')),
				'repick'	=> array('title' => 'Repick Winner', 'auth' => 'acl_m_giveaway', 'cat' => array('MCP_GIVEAWAY')),
			),
		);
	}

	function install()
	{
	}

	function uninstall()
	{
	}
}

?>