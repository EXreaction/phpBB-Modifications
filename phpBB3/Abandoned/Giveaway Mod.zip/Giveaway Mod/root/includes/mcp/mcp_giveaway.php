<?php
class mcp_giveaway
{
	var $u_action;

	function main($id, $mode)
	{
		global $config, $db, $user, $auth, $template, $cache;
		global $phpbb_root_path, $phpEx;

		// ------------------------------------------------------------- START CONFIG SECTION ---------------------------------------------------------------------
		
		// the forum id you would like to use to insert the posts into
		$forum_id = 2;

		// default minimum post limit
		$default_minimum_post = 50;

		// Groups to ignore (that can't be picked from).  Seperate with a comma, like '5,6,7,8'
		// 5 and 6 are administrators and global moderators by default
		$ignore_groups = '5,6';


		// The post and title text -------

		/* REPLACEMENTS
		*
		* %date% later gets replaced with the current date
		* %item% later gets replaced with the item
		* %value% later gets replaced with the value
		* %count% later gets replaced with the total number of eligible users that were picked from for the prize
		* %post_limit% later gets replaced with the minimum post limit required for users to be eligible
		* %winner% later gets replaced with the winner's name, and a link to their view profile page
		* %giveaway_id% later gets replaced with the giveaway id (to easily repick a user for the giveaway if needed)
		*/
		$topic_title = "Daily Giveaway %date% %value%";

		$post_text = "    Daily Giveaway %date%; #%giveaway_id%

    Todays giveaway is [b]%item%[/b] worth approximatly [b]%value%[/b]  NP.

    There were [b]%count%[/b] people entered for this giveaway, each with over [b]%post_limit%[/b] posts.

    The winner is [b]%winner%[/b]!

    Please contact me within 48 hours to claim your prize.";

		// ------------------------------------------------------------- END CONFIG SECTION ---------------------------------------------------------------------


		// Start the main code...
		if (!$auth->acl_get('m_giveaway'))
		{
			trigger_error('You are not allowed to access this page.');
		}

		$submit = (isset($_POST['submit'])) ? true : false;
		$main = ($mode == 'main') ? true : false;

		if (!$submit)
		{
			$this->tpl_name = 'mcp_giveaway';

			$template->assign_vars(array(
				'L_TITLE'				=> ($main) ? 'Giveaway' : 'Repick Winner',
				'L_EXPLAIN'				=> ($main) ? 'Giveaway' : 'Enter the Giveaway ID to Repick a winner for an existing Giveaway.  The Giveaway ID is after the # symbol by default in the post text',

				'DEFAULT_POST_LIMIT'	=> $default_minimum_post,

				'DEFAULT_TEXT'			=> nl2br($post_text),

				'S_MAIN'				=> $main,
			));
		}
		else
		{
			include($phpbb_root_path . 'includes/message_parser.' . $phpEx);
			include($phpbb_root_path . 'includes/functions_posting.' . $phpEx);

			$date = date('m/d/Y');
			$item = request_var('item', '');
			$value = request_var('value', '');
			$time = time();
			$post_limit = intval(request_var('post_limit', '50'));
			$post_limit = ($post_limit < 0) ? $default_minimum_post : $post_limit;

			if (!$main)
			{
				$id = intval(request_var('id', ''));

				$sql = 'SELECT * FROM ' . GIVEAWAY_TABLE . ' WHERE giveaway_id = \'' . $db->sql_escape($id) . '\'';
				$result = $db->sql_query($sql);
				if (!$giveaway_data = $db->sql_fetchrow($result))
				{
					trigger_error('That giveaway does not exist.');
				}

				$sql_user = ' AND user_id != \'' . $giveaway_data['winner_user_id'] . '\'';

				$date = date('m/d/Y', $giveaway_data['time']);
				$item = $giveaway_data['item'];
				$value = $giveaway_data['value'];
				$time = $giveaway_data['time'];
				$post_limit = $giveaway_data['minimum_posts'];
				$giveaway_id = $giveaway_data['giveaway_id'];
				$post_id = $giveaway_data['post_id'];
			}
			else
			{
				$sql_user = '';
			}

			if ( ( ($item == '') || ($value == '') ) && ($main) )
			{
				trigger_error('You need to enter both an item and value.');
			}

			$i = 0;
			$users = array();

			if ($ignore_groups != '')
			{
				$ignore_ary = explode(',', $ignore_groups);

				$ignore_sql = '';
				foreach ($ignore_ary as $ignore)
				{
					$ignore_sql .= ' AND group_id != \'' . $ignore . '\'';
				}
			}
			else
			{
				$ignore_sql = '';
			}

			// select users
			$sql = 'SELECT user_id FROM ' . USERS_TABLE . ' 
				WHERE user_posts >= \'' . $post_limit . '\' 
					AND user_type != \'2\'' . 
						$ignore_sql . 
						$sql_user;
			$result = $db->sql_query($sql);

			while($row = $db->sql_fetchrow($result))
			{
				$users[$i] = $row['user_id'];

				$i++;
			}

			$db->sql_freeresult($result);

			$count = count($users);

			if ($count == 0)
			{
				trigger_error('There are no users who can win with the selected post limit.');
			}

			$winner_id = $users[rand(0, ($count - 1))];

			$sql = 'SELECT username FROM ' . USERS_TABLE . ' WHERE user_id = \'' . $winner_id . '\'';
			$result = $db->sql_query($sql);
			$winner = $db->sql_fetchrow($result);

			// insert into giveaway table
			$sql_data = array(
				'winner_user_id'	=> $winner_id,
				'item'				=> $item,
				'value'				=> $value,
				'time'				=> $time,
				'picker_user_id'	=> $user->data['user_id'],
				'minimum_posts'		=> $post_limit,
				'users_count'		=> $count,
				'post_id'			=> (isset($post_id)) ? $post_id : 0,
			);

			if ($main)
			{
				$sql = 'INSERT INTO ' . GIVEAWAY_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);
			}
			else
			{
				$sql = 'UPDATE ' . GIVEAWAY_TABLE . '
					SET ' . $db->sql_build_array('UPDATE', $sql_data) . "
						WHERE giveaway_id = $giveaway_id";
			}

			$db->sql_query($sql);

			if ($main)
			{
				$giveaway_id = $db->sql_nextid();
			}

			$topic_title = str_replace('%date%', $date, $topic_title);
			$topic_title = str_replace('%value%', $value, $topic_title);

			$post_text = str_replace('%date%', $date, $post_text);
			$post_text = str_replace('%giveaway_id%', $giveaway_id, $post_text);
			$post_text = str_replace('%item%', $item, $post_text);
			$post_text = str_replace('%value%', $value, $post_text);
			$post_text = str_replace('%count%', $count, $post_text);
			$post_text = str_replace('%post_limit%', $post_limit, $post_text);
			$post_text = str_replace('%winner%', $winner['username'], $post_text);

			// parse_bbcode
			$message_parser = new parse_message();
			$message_parser->message = utf8_normalize_nfc($post_text);
			$message_parser->parse(true, true, true);

			// UTF8 the topic title
			$topic_title = utf8_normalize_nfc($topic_title);

			if ($main)
			{
				// insert into topics table
				$sql_data = array(
					'forum_id'					=> $forum_id,
					'topic_title'				=> $topic_title,
					'topic_poster'				=> $user->data['user_id'],
					'topic_time'				=> time(),
					'topic_first_poster_name'	=> $user->data['username'],
					'topic_first_poster_colour'	=> $user->data['user_colour'],
					'topic_last_poster_id'		=> $user->data['user_id'],
					'topic_last_poster_name'	=> $user->data['username'],
					'topic_last_poster_colour'	=> $user->data['user_colour'],
					'topic_last_post_subject'	=> $topic_title,
					'topic_last_post_time'		=> time(),
					'topic_last_view_time'		=> time(),
				);
				
				$sql = 'INSERT INTO ' . TOPICS_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);
				$db->sql_query($sql);

				$topic_id = $db->sql_nextid();

				// insert into topics posted table
				$sql_data = array(
					'user_id'				=> $user->data['user_id'],
					'topic_id'				=> $topic_id,
					'topic_posted'			=> 1,
				);
				
				$sql = 'INSERT INTO ' . TOPICS_POSTED_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);
				$db->sql_query($sql);

				// insert into topics track table
				$sql_data = array(
					'user_id'				=> $user->data['user_id'],
					'topic_id'				=> $topic_id,
					'forum_id'				=> $forum_id,
					'mark_time'				=> time(),
				);

				$sql = 'INSERT INTO ' . TOPICS_TRACK_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);

				// insert into posts table
				$sql_data = array(
					'topic_id'			=> $topic_id,
					'forum_id'			=> $forum_id,
					'poster_id'			=> $user->data['user_id'],
					'poster_ip'			=> $user->data['user_ip'],
					'post_time'			=> time(),
					'post_subject'		=> $topic_title,
					'post_text'			=> $message_parser->message,
					'post_checksum'		=> md5($message_parser->message),
					'bbcode_bitfield'	=> $message_parser->bbcode_bitfield,
					'bbcode_uid'		=> $message_parser->bbcode_uid,
				);
				
				$sql = 'INSERT INTO ' . POSTS_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);
				$db->sql_query($sql);

				$post_id = $db->sql_nextid();

				// update topic_first_post_id & topic_last_post_id
				$sql = 'UPDATE ' . TOPICS_TABLE . ' SET topic_first_post_id = \'' . $post_id . '\', topic_last_post_id = \'' . $post_id . '\' WHERE topic_id = \'' . $topic_id . '\'';
				$db->sql_query($sql);

				// update giveaway table with the posts id
				$sql = 'UPDATE ' . GIVEAWAY_TABLE . ' SET post_id = \'' . $post_id . '\' WHERE giveaway_id = \'' . $giveaway_id . '\'';
				$db->sql_query($sql);

				// Index message contents
				if ($config['load_search'])
				{
					// Select the search method and do some additional checks to ensure it can actually be utilised
					$search_type = basename($config['search_type']);

					if (!file_exists($phpbb_root_path . 'includes/search/' . $search_type . '.' . $phpEx))
					{
						trigger_error('NO_SUCH_SEARCH_MODULE');
					}

					require_once("{$phpbb_root_path}includes/search/$search_type.$phpEx");

					$error = false;
					$search = new $search_type($error);

					if ($error)
					{
						trigger_error($error);
					}

					$search->index('post', $post_id, $post_text, $topic_title, $user->data['user_id'], $forum_id);
				}

				add_log('mod', $forum_id, $topic_id, 'Giveaway', $topic_title);

				$url = append_sid("{$phpbb_root_path}viewtopic.$phpEx", 'f=' . $forum_id . '&amp;t=' . $topic_id);
				trigger_error('Giveaway submitted!<br/>Click <a href="' . $url . '">here</a> to view the post.');
				redirect($url);
			}
			else
			{
				// update the posts table
				$sql_data = array(
					'post_text'			=> $message_parser->message,
					'post_checksum'		=> md5($message_parser->message),
					'bbcode_bitfield'	=> $message_parser->bbcode_bitfield,
					'bbcode_uid'		=> $message_parser->bbcode_uid,
				);

				$sql = 'UPDATE ' . POSTS_TABLE . '
					SET ' . $db->sql_build_array('UPDATE', $sql_data) . "
						WHERE post_id = $post_id";
				$db->sql_query($sql);

				// Re-index message contents
				if ($config['load_search'])
				{
					// Select the search method and do some additional checks to ensure it can actually be utilised
					$search_type = basename($config['search_type']);

					if (!file_exists($phpbb_root_path . 'includes/search/' . $search_type . '.' . $phpEx))
					{
						trigger_error('NO_SUCH_SEARCH_MODULE');
					}

					require_once("{$phpbb_root_path}includes/search/$search_type.$phpEx");

					$error = false;
					$search = new $search_type($error);

					if ($error)
					{
						trigger_error($error);
					}

					$search->index('edit', $post_id, $post_text, $topic_title, $user->data['user_id'], $forum_id);
				}

				$sql = 'SELECT topic_id FROM ' . POSTS_TABLE . ' WHERE post_id = \'' . $post_id . '\'';
				$result = $db->sql_query($sql);
				$topic_id = $db->sql_fetchrow($result);

				add_log('mod', $forum_id, $topic_id['topic_id'], 'Giveaway Winner Re-Picked', $topic_title);

				$url = append_sid("{$phpbb_root_path}viewtopic.$phpEx", 'f=' . $forum_id . '&amp;t=' . $topic_id['topic_id']);
				trigger_error('Winner re-picked!<br/>Click <a href="' . $url . '">here</a> to view the post.');
				redirect($url);
			}
		}
	}
}

?>