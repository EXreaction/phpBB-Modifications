<?php
/** 
* @package language(permissions)
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*/

// Create the lang array if it does not already exist
if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// Create a new category named Download
$lang['permission_cat']['download'] = 'Download';

// User Permissions
$lang = array_merge($lang, array(
	'acl_u_downloadview'			=> array('lang' => 'Can view downloads', 'cat' => 'download'),
	'acl_u_downloadpost'			=> array('lang' => 'Can post downloads', 'cat' => 'download'),
	'acl_u_downloadedit'			=> array('lang' => 'Can edit own downloads', 'cat' => 'download'),
	'acl_u_downloaddelete'			=> array('lang' => 'Can delete own downloads', 'cat' => 'download'),
	'acl_u_downloadnoapprove'		=> array('lang' => 'Downloads do not need approval before public viewing', 'cat' => 'download'),
	'acl_u_downloadreport'			=> array('lang' => 'Can report downloads and replies', 'cat' => 'download'),
	'acl_u_downloadreply'			=> array('lang' => 'Can reply to downloads', 'cat' => 'download'),
	'acl_u_downloadreplyedit'		=> array('lang' => 'Can edit own replies', 'cat' => 'download'),
	'acl_u_downloadreplydelete'		=> array('lang' => 'Can delete own replies', 'cat' => 'download'),
	'acl_u_downloadreplynoapprove'	=> array('lang' => 'Replies do not need approval before public viewing', 'cat' => 'download'),
	'acl_u_downloadbbcode'			=> array('lang' => 'Can use BBCode in downloads and replies', 'cat' => 'download'),
	'acl_u_downloadsmilies'			=> array('lang' => 'Can use smilies in downloads and replies', 'cat' => 'download'),
	'acl_u_downloadimg'				=> array('lang' => 'Can post images in downloads and replies', 'cat' => 'download'),
	'acl_u_downloadurl'				=> array('lang' => 'Can post URL\'s in downloads and replies', 'cat' => 'download'),
	'acl_u_downloadflash'			=> array('lang' => 'Can post flash in downloads and replies', 'cat' => 'download'),
));

// Moderator Permissions
$lang = array_merge($lang, array(
	'acl_m_downloadapprove'			=> array('lang' => 'Can view unapproved downloads and replies and approve downloads or replies for public viewing', 'cat' => 'download'),
	'acl_m_downloadedit'			=> array('lang' => 'Can edit downloads and replies', 'cat' => 'download'),
	'acl_m_downloadlockedit'		=> array('lang' => 'Can lock editing of downloads and replies', 'cat' => 'download'),
	'acl_m_downloaddelete'			=> array('lang' => 'Can delete and un-delete downloads and replies', 'cat' => 'download'),
	'acl_m_downloadreport'			=> array('lang' => 'Can close and delete reports.', 'cat' => 'download'),
	'acl_m_addpurchasedownload'		=> array('lang' => 'Can add/remove programs to users\' purchased list.', 'cat' => 'download'),
));

// Administrator Permissions
$lang = array_merge($lang, array(
	'acl_a_downloadmanage'			=> array('lang' => 'Can change download settings', 'cat' => 'download'),
	'acl_a_downloaddelete'			=> array('lang' => 'Can permanently delete downloads', 'cat' => 'download'),
	'acl_a_downloadreplydelete'		=> array('lang' => 'Can permanently delete replies to downloads', 'cat' => 'download'),
));
?>