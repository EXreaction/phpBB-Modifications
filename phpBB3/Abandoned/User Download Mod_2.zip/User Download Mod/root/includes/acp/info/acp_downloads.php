<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* @package module_install
*/
class acp_downloads_info
{
	function module()
	{
		global $user;

		return array(
			'filename'	=> 'acp_downloads',
			'title'		=> 'ACP_DOWNLOADS',
			'version'	=> '1.0.0',
			'modes'		=> array(
				'default'	=> array('title' => 'ACP_DOWNLOADS', 'auth' => 'acl_a_downloadmanage', 'cat' => array('ACP_DOT_MODS')),
			),
		);
	}

	function install()
	{
	}

	function uninstall()
	{
	}
}

?>