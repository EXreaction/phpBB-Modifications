<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

/*
* generates the code selection box for programs (for what language it was written in)
* if $output is false we just return the language options array and don't output the data
* Selected is the ID that should be selected
* $return_colors is if we want to just return the language color array
*/
function generate_code_lang($output = false, $selected = 0, $return_colors = false)
{
	global $template;

	// make sure you edit the language options and language color array at the same time!  They both must have the same amount of values and Keys (the numbers in front).
	$language_options = array(
		0		=> 'VB.NET',
		1		=> 'VB6',
		2		=> 'Perl',
		3		=> 'SCAR',
		4		=> 'Other',
	);

	$language_color = array(
	   0		=> '#CDDBE2',
	   1		=> '#B7DEFF',
	   2		=> '#D8BEFF',
	   3		=> '#FFCCCC',
	   4		=> '#C2D7E2',
	);

	if ($return_colors)
	{
		return $language_color;
	}

	if ($output)
	{
		foreach ($language_options as $id => $option)
		{
			$template->assign_block_vars('language_options', array(
				'LANGUAGE_ID'		=> $id,
				'SELECTED'			=> ($id == $selected) ? ' selected="selected"' : '',
				'LANGUAGE_NAME'		=> $option,
			));
		}
	}
	else
	{
		return $language_options;
	}
}

/*
* gets and outputs the download stats
*/
function display_download_stats()
{
	global $user, $db, $template, $phpbb_root_path, $phpEx;

	if (!array_key_exists('DOWNLOAD_STATS', $user->lang))
	{
		$user->add_lang('download');
	}

	// get the totals
	$sql = 'SELECT count(download_id) AS download_count, count(DISTINCT user_id) AS author_count FROM ' . DOWNLOADS_TABLE . ' WHERE deleted = \'0\' AND approved = \'1\'';
	$result = $db->sql_query($sql);
	$total = $db->sql_fetchrow($result);

	// get the latest program
	$sql = 'SELECT download_id, name FROM ' . DOWNLOADS_TABLE . ' WHERE deleted = \'0\' AND approved = \'1\' ORDER BY time DESC LIMIT 1';
	$result = $db->sql_query($sql);
	$download = $db->sql_fetchrow($result);

	$template->assign_vars(array(
		'DOWNLOAD_STATS'	=> true,
		'LAST_PROGRAM'		=> '<a href="' . append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $download['download_id']) . '">' . $download['name'] . '</a>',
		'DOWNLOAD_TOTALS'	=> sprintf($user->lang['TOTAL_STATS'], $total['download_count'], $total['author_count']),
	));

	$sql = 'SELECT user_id, username, user_colour, download_count FROM ' . USERS_TABLE . ' WHERE user_type != \'2\' ORDER BY download_count DESC LIMIT 10';
	$result = $db->sql_query($sql);
	while ($row = $db->sql_fetchrow($result))
	{
		if ($row['download_count'] != 0)
		{
			$template->assign_block_vars('top_submitters', array(
				'USERNAME_FULL'		=> get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
				'UPLOAD_COUNT'		=> $row['download_count'],
			));
		}
	}
}

/*
* gets the star rating of the file from the int rating
* $average is if you want to force it to get the average score without the links to submit the rating
* $prefix is an extra prefix added on (for when it is possible that the same download is listed more than once)
*/
function get_star_rating($int_rating, $download_id, $average = false, $prefix = '')
{
	global $phpbb_root_path, $phpEx, $auth, $user, $download_data;

	$final_code = '';

	$star_grey = $phpbb_root_path . 'styles/' . $user->theme['imageset_path'] . '/imageset/download_mod/star.gif';
	$star_green = $phpbb_root_path . 'styles/' . $user->theme['imageset_path'] . '/imageset/download_mod/star_p.gif';
	$star_red = $phpbb_root_path . 'styles/' . $user->theme['imageset_path'] . '/imageset/download_mod/star_r.gif';
	$star_orange = $phpbb_root_path . 'styles/' . $user->theme['imageset_path'] . '/imageset/download_mod/star_yes.gif';

	if ($user->data['user_id'] != 1 && !$user->data['is_bot'])
	{
		$download_data->get_user_rating_data($user->data['user_id']);
	}

	if ($download_data->download[$download_id]['rating'] == 0 && $download_data->download[$download_id]['num_ratings'] == 0)
	{
		$int_rating = 3;
	}

	if ($user->data['user_id'] != 1 && !$user->data['is_bot'] && $average)
	{
		if (!isset($download_data->user_rating[$user->data['user_id']][$download_id]))
		{
			for ($i = 1; $i <= 5; $i++)
			{
				if ($i <= $int_rating)
				{
					$star = $star_orange;
				}
				else
				{
					$star = $star_grey;
				}

				$final_code .= '<a href="' . append_sid("{$phpbb_root_path}downloads.$phpEx", "page=rate&amp;d={$download_id}&rating=$i") . '">';
				$final_code .= '<img id="d' . $download_id . $prefix . 's' . $i . '" src="' . $star . '" onmouseover="ratingHover(';
				for ($j = 1; $j<= $i; $j++)
				{
					$final_code .= '\'d' . $download_id . $prefix . 's' . $j . '\',';
				}
				$final_code = substr($final_code, 0, -1);
				$final_code .= ')" onmouseout="ratingUnHover(';
				for ($j = 1; $j<= 5; $j++)
				{
					if ($j <= $int_rating)
					{
						$final_code .= '\'d' . $download_id . $prefix . 's' . $j . '\',\'' . $star_orange . '\',';
					}
					else
					{
						$final_code .= '\'d' . $download_id . $prefix . 's' . $j . '\',\'' . $star_grey . '\',';
					}
				}
				$final_code = substr($final_code, 0, -1);
				$final_code .= ')" onmousedown="ratingDown(';
				for ($j = 1; $j<= 5; $j++)
				{
					if ($j <= $i)
					{
						$final_code .= '\'d' . $download_id . $prefix . 's' . $j . '\',\'' . $star_green . '\',';
					}
					else
					{
						if ($j <= $int_rating)
						{
							$final_code .= '\'d' . $download_id . $prefix . 's' . $j . '\',\'' . $star_orange . '\',';
						}
						else
						{
							$final_code .= '\'d' . $download_id . $prefix . 's' . $j . '\',\'' . $star_grey . '\',';
						}
					}
				}
				$final_code = substr($final_code, 0, -1);
				$final_code .= ')" alt="' . $user->lang['RATE_ME'] . '" title="' . $user->lang['RATE_ME'] . '" /></a>';
			}
		}
		else
		{
			for ($i = 1; $i <= 5; $i++)
			{
				if ($i <= $int_rating)
				{
					$star = $star_orange;
				}
				else
				{
					$star = $star_grey;
				}

				$final_code .= '<img id="d' . $download_id . $prefix . 's' . $i . '" src="' . $star . '" />';
			}
		}
	}
	else
	{
		if (!isset($download_data->user_rating[$user->data['user_id']][$download_id]))
		{
			for ($i = 1; $i <= 5; $i++)
			{
				if ($i <= $int_rating)
				{
					$star = $star_orange;
				}
				else
				{
					$star = $star_grey;
				}

				$final_code .= '<img id="d' . $download_id . $prefix . 's' . $i . '" src="' . $star . '" />';
			}
		}
		else
		{
			for ($i = 1; $i <= $download_data->user_rating[$user->data['user_id']][$download_id]['score']; $i++)
			{
				$final_code .= '<img id="d' . $download_id . $prefix . 's' . $i . '" src="' . $star_green . '" />';
			}

			for ($i = $download_data->user_rating[$user->data['user_id']][$download_id]['score']; $i < 5; $i++)
			{
				$final_code .= '<img id="d' . $download_id . $prefix . 's' . $i . '" src="' . $star_grey . '" />';
			}
		}
	}

	return $final_code;
}

/*
* Gets all of the categories
*/
function get_dl_cats()
{
	global $auth, $db, $user;

	$dl_cats = array();

	if ( ($auth->acl_get('m_downloaddelete')) || ($auth->acl_get('a_downloaddelete')) )
	{
		$sql = 'SELECT count(download_id) AS total FROM ' . DOWNLOADS_TABLE . ' WHERE deleted != 0';
		$result = $db->sql_query($sql);
		$deleted_count = $db->sql_fetchrow($result);

		$dl_cats[-1] = array(
			'category_name'		=> $user->lang['DELETED_CATEGORY'],
			'downloads'			=> $deleted_count['total'],
		);
	}

	$sql = 'SELECT * FROM ' . DOWNLOADS_CATEGORIES_TABLE . ' ORDER BY order_id ASC';
	$result = $db->sql_query($sql);

	while($row = $db->sql_fetchrow($result))
	{
		$dl_cats[$row['category_id']] = array(
			'category_name'		=> $row['category_name'],
			'downloads'			=> $row['downloads'],
		);
	}

	$db->sql_freeresult($result);

	if (!count($dl_cats))
	{
		return false;
	}

	return $dl_cats;
}

/*
* Generates the categories menu
* if selectbox is true then it generates it as a selection box
* selected is the category that should be selected by default (if selectbox is true)
*/
function generate_categories_menu($selectbox = false, $selected = 0)
{
	global $db, $dl_cats, $template, $category_id, $phpbb_root_path, $phpEx;

	if ($dl_cats !== false)
	{
		if (!$selectbox)
		{
			foreach($dl_cats as $id => $data)
			{
				$template->assign_block_vars('categories', array(
					'SELECTED'		=> ($id == $category_id) ? true : false,
					'U_VIEW_CAT'	=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'c=' . $id),
					'NAME'			=> $data['category_name'],
					'DOWNLOADS'		=> $data['downloads'],
				));
			}
		}
		else
		{
			foreach($dl_cats as $id => $data)
			{
				if ($id != -1)
				{
					$template->assign_block_vars('category_options', array(
						'CATEGORY_ID'		=> $id,
						'SELECTED'			=> ($id == $selected) ? ' selected="selected"' : '',
						'CATEGORY_NAME'		=> $data['category_name'],
					));
				}
			}
		}
	}
}

/*
* builds the language code box showing the colors and options.  It is used on the left menu.
*/
function build_code_lang_info_box()
{
	global $template;

	$language_options = generate_code_lang(false);
	$language_colors = generate_code_lang(false, 0, true);

	if (count($language_options))
	{
		$at_least_one = false;

		foreach ($language_options as $id => $name)
		{
			if ($language_colors[$id] != '')
			{
				$template->assign_block_vars('lang_options', array(
					'NAME'	=> $name,
					'COLOR'	=> $language_colors[$id],
				));

				$at_least_one = true;
			}
		}

		if ($at_least_one)
		{
			$template->assign_vars(array(
				'LANGUAGE_CODE_BOX'	=> true,
			));
		}
	}
}

/*
* Informs users when a download or reply was reported or needs approval
*/
function inform_approve_report($mode, $id)
{
	global $phpbb_root_path, $phpEx, $config, $user;

	// include the private messages functions page
	include_once("{$phpbb_root_path}includes/functions_privmsgs.$phpEx");

	// this will hold the address list
	$address_list = array();

	$download_inform = explode(",", $config['download_inform']);

	// setup out to address list
	foreach ($download_inform as $id)
	{
		$address_list[$id] = 'to';
	}

	switch ($mode)
	{
		case 'download_report' :
			$message = sprintf($user->lang['DOWNLOAD_REPORT_PM'], $user->data['username'], append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=view&amp;mode=download&amp;d=' . $id));
			$subject = $user->lang['DOWNLOAD_REPORT_PM_SUBJECT'];
			break;
		case 'reply_report' :
			$message = sprintf($user->lang['REPLY_REPORT_PM'], $user->data['username'], append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=view&amp;mode=download&amp;r=' . $id));
			$subject = $user->lang['REPLY_REPORT_PM_SUBJECT'];
			break;
		case 'download_approve' :
			$message = sprintf($user->lang['DOWNLOAD_APPROVE_PM'], $user->data['username'], append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=view&amp;mode=download&amp;d=' . $id));
			$subject = $user->lang['DOWNLOAD_APPROVE_PM_SUBJECT'];
			break;
		case 'reply_approve' :
			$message = sprintf($user->lang['REPLY_APPROVE_PM'], $user->data['username'], append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=view&amp;mode=download&amp;r=' . $id));
			$subject = $user->lang['REPLY_APPROVE_PM_SUBJECT'];
	}

	$message_parser = new parse_message();
	$message_parser->message = $message;
	$message_parser->parse(true, true, true, true, true, true, true);

	$pm_data = array(
		'from_user_id'		=> $user->data['user_id'],
		'from_username'		=> $user->data['username'],
		'address_list'		=> array('u' => $address_list),
		'icon_id'			=> 10,
		'from_user_ip'		=> $user->data['user_ip'],
		'enable_bbcode'		=> true,
		'enable_smilies'	=> true,
		'enable_urls'		=> true,
		'enable_sig'		=> false,
		'message'			=> $message_parser->message,
		'bbcode_bitfield'	=> $message_parser->bbcode_bitfield,
		'bbcode_uid'		=> $message_parser->bbcode_uid,
	);

	submit_pm('post', $subject, $pm_data, false);
}

/*
* Create the breadcrumbs
*/
function generate_download_breadcrumbs($crumbs)
{
	global $template;

	foreach ($crumbs as $text => $link)
	{
		$template->assign_block_vars('navlinks', array(
			'FORUM_NAME'	=> $text,
			'U_VIEW_FORUM'	=> $link,
		));
	}
}

/*
* using this to keep some permission sections shorter and easier to manage, because some options can be extremely lengthy
*/
function check_download_permissions($page, $mode, $id)
{
	global $user, $auth, $download_data;

	switch ($page)
	{
		case 'reply' :
			switch ($mode)
			{
				case 'edit' :
					if ( ($user->data['user_id'] != ANONYMOUS) && ( ( ($auth->acl_get('u_downloadreplyedit')) && ($user->data['user_id'] == $download_data->reply[$id]['user_id']) ) || ($auth->acl_get('m_downloadedit')) ) )
					{
						return true;
					}
				break;
				case 'delete' :
					if ($download_data->reply[$id]['deleted'] != 0 && !$auth->acl_get('a_downloadreplydelete'))
					{
						return false;
					}

					if ($user->data['user_id'] != ANONYMOUS && ($auth->acl_get('a_downloadreplydelete') || $auth->acl_get('m_downloaddelete') || ($auth->acl_get('u_downloadreplydelete') && $user->data['user_id'] == $download_data->reply[$id]['user_id']) ) )
					{
						return true;
					}
				break;
			}
		break;
	}

	return false;
}
?>