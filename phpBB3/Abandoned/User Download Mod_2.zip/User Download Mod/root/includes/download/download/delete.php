<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// If they did not include the $download_id give them an error...
if ($download_id == 0)
{
	trigger_error('NO_DOWNLOAD');
}

// Was Cancel pressed? If so then redirect to the appropriate page
if ($cancel)
{
	$redirect = append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $download_id);
	redirect($redirect);
}

// Get the download's data, and check if there is no download...
if ($download_data->get_download_data(array('download_id' => $download_id, 'simple' => true)) === false)
{
	trigger_error('NO_DOWNLOAD');
}

// Get the author data, settings $user_id to keep things shorter later
$user_id = $download_data->download[$download_id]['user_id'];

// check to see if editing this message is locked, or if the one editing it has mod powers
if ( $download_data->download[$download_id]['edit_locked'] && !($auth->acl_get('m_downloadedit')) && !($auth->acl_get('a_downloaddelete')) )
{
	trigger_error('DOWNLOAD_EDIT_LOCKED');
}
	
// check permissions
if ( !($auth->acl_get('u_downloaddelete') && $user->data['user_id'] == $user_id) && !($auth->acl_get('m_downloaddelete')) && !($auth->acl_get('a_downloaddelete')) )
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}

$self_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=delete&amp;d=' . $download_id);
$view_download_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $download_id);

// Setup the page header and sent the title of the page that will go into the browser header
page_header($user->lang['DELETE_DOWNLOAD']);

// Generate the breadcrumbs
$breadcrumbs = array(
	$user->lang['USER_DOWNLOADS']					=> $view_download_main,
	$download_data->download[$download_id]['name']	=> $view_download_url,
	$user->lang['DELETE_DOWNLOAD']					=> $self_url,
	);
generate_download_breadcrumbs($breadcrumbs);


if ( ($download_data->download[$download_id]['deleted'] != 0) && (!$auth->acl_get('a_downloaddelete')) )
{
	trigger_error('DOWNLOAD_ALREADY_DELETED');
}

if (confirm_box(true))
{
	if ( ($download_data->download[$download_id]['deleted'] != 0) && ($auth->acl_get('a_downloaddelete')) ) // if it has already been soft deleted, and we want to hard delete it
	{
		// delete the download
		$sql = 'DELETE FROM ' . DOWNLOADS_TABLE . ' WHERE download_id = \'' . $download_id . '\'';
		$db->sql_query($sql);

		// delete the replies
		$sql = 'DELETE FROM ' . DOWNLOADS_REPLY_TABLE . ' WHERE download_id = \'' . $download_id . '\'';
		$db->sql_query($sql);

		// delete the ratings
		$sql = 'DELETE FROM ' . DOWNLOADS_RATINGS_TABLE . ' WHERE download_id = \'' . $download_id . '\'';
		$db->sql_query($sql);

		// delete the purchased data
		$sql = 'DELETE FROM ' . DOWNLOADS_PURCHASES_TABLE . ' WHERE download_id = \'' . $download_id . '\'';
		$db->sql_query($sql);
	}
	else
	{
		if (!$download_data->download[$download_id]['approved'])
		{
			include_once("{$phpbb_root_path}includes/functions_privmsgs.$phpEx");

			$message = sprintf($user->lang['DOWNLOAD_DISAPPROVED_PM'], $download_data->download[$download_id]['name']);

			$message_parser = new parse_message();
			$message_parser->message = $message;
			$message_parser->parse(true, true, true, true, true, true, true);

			$pm_data = array(
				'from_user_id'		=> $user->data['user_id'],
				'from_username'		=> $user->data['username'],
				'address_list'		=> array('u' => array($user_id => 'to')),
				'icon_id'			=> 10,
				'from_user_ip'		=> $user->data['user_ip'],
				'enable_bbcode'		=> true,
				'enable_smilies'	=> true,
				'enable_urls'		=> true,
				'enable_sig'		=> false,
				'message'			=> $message_parser->message,
				'bbcode_bitfield'	=> $message_parser->bbcode_bitfield,
				'bbcode_uid'		=> $message_parser->bbcode_uid,
			);

			submit_pm('post', $user->lang['DOWNLOAD_DISAPPROVED_SUBJECT_PM'], $pm_data, false);
		}

		// *delete* the download
		$sql = 'UPDATE ' . DOWNLOADS_TABLE . ' SET deleted = \'' . $user->data['user_id'] . ' \', deleted_time = \'' . time() . '\' WHERE download_id = \'' . $download_id . '\'';
		$db->sql_query($sql);

		// update the downloads count for the categories
		$sql = 'UPDATE ' . DOWNLOADS_CATEGORIES_TABLE . ' SET downloads = downloads - 1 WHERE category_id = \'' . $download_data->download[$download_id]['category_id'] . '\'';
		$db->sql_query($sql);

		// update the downloads count for the users
		$sql = 'UPDATE ' . USERS_TABLE . ' SET download_count = download_count - 1 WHERE user_id = \'' . $download_data->download[$download_id]['user_id'] . '\'';
		$db->sql_query($sql);
	}

	meta_refresh(3, $view_download_main);

	$message = $user->lang['DOWNLOAD_DELETED'];

	$message .= '<br/><br/>' . sprintf($user->lang['RETURN_DOWNLOAD_MAIN'], '<a href="' . $view_download_main . '">', '</a>');

	trigger_error($message);
}
else
{
	if ( ($download_data->download[$download_id]['deleted'] != 0)) // if it has already been soft deleted and we are not trying to undelete
	{
		confirm_box(false, 'PERMANENTLY_DELETE_DOWNLOAD');
	}
	else
	{
		confirm_box(false, 'DELETE_DOWNLOAD');
	}
}

// they pressed No, so redirect them
redirect($view_download_url);
?>