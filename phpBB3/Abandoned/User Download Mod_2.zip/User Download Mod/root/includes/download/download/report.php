<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// If they did not include the $download_id give them an error...
if ($download_id == 0)
{
	trigger_error('NO_DOWNLOAD');
}

// Get the download's data, and check if there is no download...
if ($download_data->get_download_data(array('download_id' => $download_id, 'simple' => true)) === false)
{
	trigger_error('NO_DOWNLOAD');
}

// Get the author data, settings $user_id to keep things shorter later
$user_id = $download_data->download[$download_id]['user_id'];
	
// check permissions
if ( !$auth->acl_get('u_downloadreport') )
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}

$self_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=report&amp;d=' . $download_id);
$view_download_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $download_id);

// Setup the page header and sent the title of the page that will go into the browser header
page_header($user->lang['REPORT_DOWNLOAD']);

// Generate the breadcrumbs
$breadcrumbs = array(
	$user->lang['USER_DOWNLOADS']					=> $view_download_main,
	$download_data->download[$download_id]['name']	=> $view_download_url,
	$user->lang['REPORT_DOWNLOAD']					=> $self_url,
	);
generate_download_breadcrumbs($breadcrumbs);

$user->add_lang('mcp');

// To close the reports
if ($download_data->download[$download_id]['reported'] && $auth->acl_get('m_downloadreport'))
{
	if (confirm_box(true))
	{
		$sql = 'UPDATE ' . DOWNLOADS_TABLE . '
			SET reported = \'0\'
			WHERE download_id = ' . $download_id;
		$db->sql_query($sql);

		meta_refresh(3, $view_download_url);

		$message = $user->lang['REPORT_CLOSED_SUCCESS'];
		$message .= '<br /><br /><a href="' . $view_download_url . '">' . $user->lang['VIEW_DOWNLOAD'] . '</a>';
		trigger_error($message);
	}
	else
	{
		confirm_box(false, 'CLOSE_REPORT');
	}
}
else
{
	if (confirm_box(true))
	{
		// we are making it look like the user can report the download even if it has already been reported...but if it already has reported we can skip the extra SQL query
		if (!$download_data->download[$download_id]['reported'])
		{
			$sql = 'UPDATE ' . DOWNLOADS_TABLE . '
				SET reported = \'1\'
				WHERE download_id = ' . $download_id;
			$db->sql_query($sql);
		}

		inform_approve_report('download_report', $download_id);

		meta_refresh(3, $view_download_url);
	
		$message = $user->lang['POST_REPORTED_SUCCESS'] . '<br /><br /><a href="' . $view_download_url . '">' . $user->lang['VIEW_DOWNLOAD'] . '</a>';
		trigger_error($message);
	}
	else
	{
		confirm_box(false, 'DOWNLOAD_REPORT');
	}
}
?>