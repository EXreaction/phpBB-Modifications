<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// If they did not include the $download_id give them an error...
if ($download_id == 0)
{
	trigger_error('NO_DOWNLOAD');
}

// Was Cancel pressed? If so then redirect to the appropriate page
if ($cancel)
{
	$redirect = append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $download_id);
	redirect($redirect);
}

// Get the download's data, and check if there is no download...
if ($download_data->get_download_data(array('download_id' => $download_id, 'simple' => true)) === false)
{
	trigger_error('NO_DOWNLOAD');
}

// Get the author data, settings $user_id to keep things shorter later
$user_id = $download_data->download[$download_id]['user_id'];
	
// check permissions
if ( !($auth->acl_get('m_downloaddelete')) && !($auth->acl_get('a_downloaddelete')) )
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}

$self_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=undelete&amp;d=' . $download_id);
$view_download_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $download_id);

// Setup the page header and sent the title of the page that will go into the browser header
page_header($user->lang['UNDELETE_DOWNLOAD']);

// Generate the breadcrumbs
$breadcrumbs = array(
	$user->lang['USER_DOWNLOADS']					=> $view_download_main,
	$download_data->download[$download_id]['name']	=> $view_download_url,
	$user->lang['UNDELETE_DOWNLOAD']				=> $self_url,
	);
generate_download_breadcrumbs($breadcrumbs);

if ($download_data->download[$download_id]['deleted'] == 0) // if someone is trying to un-delete a download and the download is not deleted
{
	trigger_error('DOWNLOAD_NOT_DELETED');
}

if (confirm_box(true))
{
	// magically un-delete the download ;-)
	$sql = 'UPDATE ' . DOWNLOADS_TABLE . ' SET deleted = \'0\', deleted_time = \'0\' WHERE download_id = \'' . $download_id . '\'';
	$db->sql_query($sql);

	// update the downloads count for the categories
	$sql = 'UPDATE ' . DOWNLOADS_CATEGORIES_TABLE . ' SET downloads = downloads + 1 WHERE category_id = \'' . $download_data->download[$download_id]['category_id'] . '\'';
	$db->sql_query($sql);

	meta_refresh(3, $view_download_url);

	$message = $user->lang['DOWNLOAD_UNDELETED'];
	$message .= '<br/><br/><a href="' . $view_download_url. '">' . $user->lang['VIEW_DOWNLOAD'] . '</a>';

	$message .= '<br/><br/>' . sprintf($user->lang['RETURN_DOWNLOAD_MAIN'], '<a href="' . $view_download_main . '">', '</a>');

	trigger_error($message);
}
else
{
	confirm_box(false, 'UNDELETE_DOWNLOAD');
}

// they pressed No, so redirect them
redirect($view_user_url);
?>