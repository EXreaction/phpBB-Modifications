<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// check permissions
if (!$auth->acl_get('u_downloadpost'))
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}

// Add the language Variables for posting
$user->add_lang('posting');
$user->add_lang('viewtopic');

$file_delete = (isset($_POST['file_delete'])) ? true : false;
$screenshot_delete = (isset($_POST['screenshot_delete'])) ? true : false;
$existing_file = intval(request_var('existing_file', 0));
$existing_screenshot = intval(request_var('existing_screenshot', 0));
$category = intval(request_var('category', $category_id));
$language_id = intval(request_var('language_id', 0));
$submit = ($submit || $file_delete || $screenshot_delete) ? true : false;

$self_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=add');
$hidden_fields = '';

// Setup the page header and sent the title of the page that will go into the browser header
page_header($user->lang['ADD_DOWNLOAD']);

// Generate the breadcrumbs
$breadcrumbs = array(
	$user->lang['DOWNLOADS'] => $view_download_main,
	$user->lang['ADD_DOWNLOAD'] => $self_url,
	);
generate_download_breadcrumbs($breadcrumbs);

// Posting permissions
$post_options = new post_options;
$post_options->set_status(!isset($_POST['disable_bbcode']), !isset($_POST['disable_smilies']), !isset($_POST['disable_magic_url']));
$post_options->set_in_template();

// setup the message parser
$message_parser = new parse_message();

// If they did submit or hit preview
if ($submit)
{
	$download_author = utf8_normalize_nfc(request_var('author', '', true));
	$download_name = utf8_normalize_nfc(request_var('name', '', true));
	$download_description = utf8_normalize_nfc(request_var('message', '', true));
	$download_cost = intval(request_var('cost', 0, true));

	// set up the message parser to parse BBCode, Smilies, etc
	$message_parser->message = $download_description;
	$message_parser->parse($post_options->enable_bbcode, $post_options->enable_magic_url, $post_options->enable_smilies, $post_options->img_status, $post_options->flash_status, $post_options->bbcode_status, $post_options->url_status);

	// Check the post and make sure they submitted everything correctly
	if ($download_name == '')
	{
		$error[] = $user->lang['EMPTY_PROGRAM_NAME'];
	}
	if ($download_author == '')
	{
		$error[] = $user->lang['EMPTY_AUTHOR_NAME'];
	}

	// now lets upload and parse the file
	if ($existing_file == 0)
	{
		$file_data = upload_attachment('file', 0, false, '', true, false);
	}
	else
	{
		$sql = 'SELECT * FROM ' . DOWNLOADS_ATTACHMENTS_TABLE . ' WHERE attach_id = \'' . $existing_file . '\'';
		$result = $db->sql_query($sql);
		$file_data = $db->sql_fetchrow($result);
		$db->sql_freeresult($result);

		if ( ($file_data == '') || (!file_exists($phpbb_root_path . $config['upload_path'] . '/' . $file_data['physical_filename'])) )
		{
			$file_data['error'][] = $user->lang['ERROR_NO_ATTACHMENT'];
			$file_id = '';
			$existing_file = '';
		}
	}

	if ( ($file_delete) && ($existing_file != 0) )
	{
		@unlink($phpbb_root_path . $config['upload_path'] . '/' . $file_data['physical_filename']);

		$sql = 'DELETE FROM ' . DOWNLOADS_ATTACHMENTS_TABLE . ' WHERE attach_id = \'' . $existing_file . '\'';
		$db->sql_query($sql);

		$file_id = '';
		$existing_file = '';

		$file_data = array('error' => array($user->lang['FILE_DELETED']));
	}

	if (count($file_data['error']))
	{
		foreach ($file_data['error'] as $file_error)
		{
			$error[] = $file_error;
		}

		$file_id = '';
	}
	else
	{
		if ($existing_file == 0)
		{
			$sql_data = array(
				'poster_id'				=> $user->data['user_id'],
				'physical_filename'		=> $file_data['physical_filename'],
				'real_filename'			=> $file_data['real_filename'],
				'extension'				=> $file_data['extension'],
				'mimetype'				=> $file_data['mimetype'],
				'filesize'				=> $file_data['filesize'],
				'filetime'				=> $file_data['filetime'],
			);

			$sql = 'INSERT INTO ' . DOWNLOADS_ATTACHMENTS_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);
			$db->sql_query($sql);

			$file_id = $db->sql_nextid();
		}
		else
		{
			$file_id = $existing_file;
		}
	}

	

	// If any errors were reported by the message parser add those as well
	if (sizeof($message_parser->warn_msg))
	{
		$error[] = implode('<br />', $message_parser->warn_msg);
	}
}
else
{
	$download_author = '';
	$download_name = '';
	$download_description = '';
	$download_cost = '';
	$file_id = '';
	$screenshot_id = '';
}

// if they did not submit or they have an error
if (!$submit || sizeof($error))
{
	// put the download data into the hidden fields
	$hidden_fields .= '<input type="hidden" name="existing_file" value="' . $file_id . "\" />\n";
	$hidden_fields .= '<input type="hidden" name="existing_screenshot" value="' . $screenshot_id . "\" />\n";

	// Generate smiley listing
	generate_smilies('inline', false);

	// Build custom bbcodes array
	display_custom_bbcodes();

	// generate the language options
	generate_code_lang(true, $language_id);

	// generate the category selection box
	generate_categories_menu(true, $category);

	// Assign some variables to the template parser
	$template->assign_vars(array(
		// If we have any limit on the number of chars a user can enter display that, otherwise don't
		'L_MESSAGE_BODY_EXPLAIN'	=> (intval($config['max_post_chars'])) ? sprintf($user->lang['MESSAGE_BODY_EXPLAIN'], intval($config['max_post_chars'])) : '',

		// If they hit preview or submit and got an error, or are editing their post make sure we carry their existing post info & options over
		'NAME'						=> $download_name,
		'AUTHOR'					=> $download_author,
		'DESCRIPTION'				=> $download_description,
		'COST'						=> $download_cost,

		// if there are any errors report them
		'ERROR'						=> (sizeof($error)) ? implode('<br />', $error) : '',

		// hidden
		'S_HIDDEN_FIELDS'			=> $hidden_fields,

		// files that were uploaded already
		'S_EXISTING_FILE'			=> ($submit && !count($file_data['error'])) ? true : false,
		'S_EXISTING_SCREENSHOT'		=> ($submit && !count($screenshot_data['error'])) ? true : false,
		'FILE_NAME'					=> ($submit && !count($file_data['error'])) ? $file_data['real_filename'] : '',
		'U_DOWNLOAD_FILE'			=> ($submit && !count($file_data['error'])) ? append_sid("{$phpbb_root_path}download.$phpEx", 'id=' . $file_id) : '',
		'SCREENSHOT_NAME'			=> ($submit && !count($screenshot_data['error'])) ? $screenshot_data['real_filename'] : '',
		'U_DOWNLOAD_SCREENSHOT'		=> ($submit && !count($screenshot_data['error'])) ? append_sid("{$phpbb_root_path}download.$phpEx", 'id=' . $screenshot_id) : '',

		// The post action...
		'U_ACTION'					=> $self_url,
	));

	// Tell the template parser what template file to use
	$template->set_filenames(array(
		'body' => 'download_add_body.html'
	));
}
else
{
	// insert array, not all of these really need to be inserted, since some are what the fields are as default, but I want it this way. :P
	$sql_data = array(
		'user_id'				=> $user->data['user_id'],
		'category_id'			=> $category,
		'user_ip'				=> $user->data['user_id'],
		'name'					=> $download_name,
		'cost'					=> $download_cost,
		'author'				=> $download_author,
		'description'			=> $message_parser->message,
		'checksum'				=> md5($message_parser->message),
		'time'					=> time(),
		'file_id'				=> $file_id,
		'language_id'			=> $language_id,
		'screenshot_id'			=> 0,//$screenshot_id,
		'approved'				=> $auth->acl_get('u_downloadnoapprove'),
		'enable_bbcode' 		=> $post_options->enable_bbcode,
		'enable_smilies'		=> $post_options->enable_smilies,
		'enable_magic_url'		=> $post_options->enable_magic_url,
		'bbcode_bitfield'		=> $message_parser->bbcode_bitfield,
		'bbcode_uid'			=> $message_parser->bbcode_uid,
		'edit_reason'			=> '',
	);

	// insert query
	$sql = 'INSERT INTO ' . DOWNLOADS_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);

	// run the query
	$db->sql_query($sql);

	// we no longer need the message parser
	unset($message_parser);

	$download_id = $db->sql_nextid();

	if ($auth->acl_get('u_downloadnoapprove'))
	{
		// update the downloads count for the categories
		$sql = 'UPDATE ' . DOWNLOADS_CATEGORIES_TABLE . ' SET downloads = downloads + 1 WHERE category_id = \'' . $category . '\'';
		$db->sql_query($sql);

		// update the downloads count for the users
		$sql = 'UPDATE ' . USERS_TABLE . ' SET download_count = download_count + 1 WHERE user_id = \'' . $user->data['user_id'] . '\'';
		$db->sql_query($sql);
	}

	// make sure to set it so the files are not orphans
	$sql = 'UPDATE ' . DOWNLOADS_ATTACHMENTS_TABLE . ' SET is_orphan = \'0\', download_id = \'' . $download_id . '\' WHERE attach_id = \'' . $file_id . '\'';// OR attach_id =\'' . $screenshot_id . '\'';
	$db->sql_query($sql);

	// insert into the purchases table
	$sql_data = array(
		'download_id'	=> $download_id,
		'user_id'		=> $user->data['user_id'],
	);
	$sql = 'INSERT INTO ' . DOWNLOADS_PURCHASES_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);
	$db->sql_query($sql);

	$view_download_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $download_id);

	if (!$auth->acl_get('u_downloadnoapprove'))
	{
		// inform those wanted that the download needs approval
		inform_approve_report('download_approve', $download_id);
	}

	$message = (!$auth->acl_get('u_downloadnoapprove')) ? $user->lang['DOWNLOAD_NEED_APPROVE'] : $user->lang['DOWNLOAD_SUBMITTED'];

	$message .= '<br /><br /><a href="' . $view_download_url . '">' . $user->lang['VIEW_DOWNLOAD'] . '</a><br/><br/>';

	// redirect
	meta_refresh(2, $view_download_url);

	trigger_error($message);
}
?>