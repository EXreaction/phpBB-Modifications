<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// If they did not include the $reply_id give them an error...
if ($reply_id == 0)
{
	trigger_error('NO_REPLY');
}

// Was Cancel pressed? If so then redirect to the appropriate page
if ($cancel)
{
	$redirect = append_sid("{$phpbb_root_path}downloads.$phpEx", '&amp;r=' . $reply_id);
	redirect($redirect);
}

// Get the reply's data, and check if there is no reply...
if ($download_data->get_reply_data(array('reply_id' => $reply_id, 'simple' => true)) === false)
{
	trigger_error('NO_REPLY');
}

// Add the language Variables for posting
$user->add_lang('posting');

// Get the author data, setting $user_id to keep things shorter later
$download_id = $download_data->reply[$reply_id]['download_id'];
$download_data->get_download_data(array('download_id' => $download_id));
$user_id = $download_data->download[$download_id]['user_id'];
	
// check permissions
if ( !$auth->acl_get('m_downloadapprove') )
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}

$self_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=reply&amp;mode=approve&amp;d=' . $reply_id);
$view_download_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $download_id);
$view_reply_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $download_id . '#r' . $reply_id);

// Setup the page header and sent the title of the page that will go into the browser header
page_header($user->lang['APPROVE_REPLY']);

// Generate the breadcrumbs
$breadcrumbs = array(
	$user->lang['DOWNLOADS'] 						=> append_sid("{$phpbb_root_path}downloads.$phpEx"),
	$download_data->download[$download_id]['name']	=> $view_download_url,
	$user->lang['APPROVE_REPLY']					=> $self_url,
	);
generate_download_breadcrumbs($breadcrumbs);

if ($download_data->reply[$reply_id]['approved'] == 0)
{
	if (confirm_box(true))
	{
		$sql = 'UPDATE ' . DOWNLOADS_REPLY_TABLE . '
			SET approved = \'1\'
			WHERE reply_id = ' . $reply_id;
		$db->sql_query($sql);

		// update the reply count for the download
		$sql = 'UPDATE ' . DOWNLOADS_TABLE . ' SET reply_count = reply_count + 1 WHERE download_id = \'' . $download_id . '\'';
		$db->sql_query($sql);

		meta_refresh(3, $view_reply_url);

		$message = $user->lang['APPROVE_REPLY_SUCCESS'];
		$message .= '<br /><br /><a href="' . $view_reply_url . '">' . $user->lang['VIEW_REPLY'] . '</a>';
		$message .= '<br/>' . sprintf($user->lang['RETURN_DOWNLOAD'], '<a href="' . $view_download_url . '">', '</a>');
		$message .= '<br/>' . sprintf($user->lang['RETURN_DOWNLOAD_MAIN'], '<a href="' . $view_download_main . '">', '</a>');
		trigger_error($message);
	}
	else
	{
		confirm_box(false, 'APPROVE_REPLY');
	}
}
else
{
	meta_refresh(3, $view_reply_url);

	$message = $user->lang['REPLY_ALREADY_APPROVED'];
	$message .= '<br /><br /><a href="' . $view_reply_url . '">' . $user->lang['VIEW_REPLY'] . '</a>';
	$message .= '<br/>' . sprintf($user->lang['RETURN_DOWNLOAD'], '<a href="' . $view_download_url . '">', '</a>');
	$message .= '<br/>' . sprintf($user->lang['RETURN_DOWNLOAD_MAIN'], '<a href="' . $view_download_main . '">', '</a>');

	trigger_error($message);
}
redirect($view_reply_url);
?>