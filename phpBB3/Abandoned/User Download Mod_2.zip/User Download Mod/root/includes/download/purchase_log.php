<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// check permissions
if ($user->data['user_type'] != 3)
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}

// Add the language Variables for viewtopic
$user->add_lang('viewtopic');

$breadcrumbs = array(
	$user->lang['USER_DOWNLOADS']	=> $view_download_main,
	$user->lang['ALL_PURCHASES']	=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=log'),
);
generate_download_breadcrumbs($breadcrumbs);
page_header($user->lang['USER_DOWNLOADS']);
generate_categories_menu();

$self = $_SERVER['REQUEST_URI'];
$self_minus_start_url = (strpos($self, 'start=')) ? reapply_sid(substr($self, 0, (strpos($self, 'start=')) - 1) . substr($self, (strpos($self, 'start=')) + 6 + strlen($start))) : reapply_sid($self);

$sql = 'SELECT count(DISTINCT download_id, user_id) AS total FROM ' . DOWNLOADS_PURCHASES_TABLE;
$result = $db->sql_query($sql);
$total = $db->sql_fetchrow($result);
$pagination = generate_pagination($self_minus_start_url, $total['total'], $limit, $start, false);

// output some data
$template->assign_vars(array(
	'PAGINATION'		=> $pagination,
	'PAGE_NUMBER' 		=> on_page($total['total'], $limit, $start),

	'SECTION_WIDTH'		=> '84',
	'U_VIEW'			=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=log'),
	'TITLE'				=> $user->lang['ALL_PURCHASES'],
));

$ids = array();
$sql = 'SELECT DISTINCT dp.download_id, dp.user_id, d.name, u.username, u.user_colour
	FROM ' . DOWNLOADS_PURCHASES_TABLE . ' dp, ' . DOWNLOADS_TABLE . ' d, ' . USERS_TABLE . ' u
		WHERE d.download_id = dp.download_id
			AND u.user_id = dp.user_id
				ORDER BY dp.purchase_id DESC
					LIMIT ' . $start . ', ' . $limit;
$result = $db->sql_query($sql);
while ($row = $db->sql_fetchrow($result))
{
	$template->assign_block_vars('row', array(
		'U_VIEW_APP'	=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $row['download_id']),
		'APP_TITLE'		=> $row['name'],
		'U_VIEW_USER'	=> append_sid("{$phpbb_root_path}memberlist.$phpEx", 'mode=viewprofile&amp;u=' . $row['user_id']),
		'USERNAME_FULL'	=> get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),
	));
}
$db->sql_freeresult($result);

$template->set_filenames(array(
	'body' => 'view_download_purchase_log.html'
));
?>