<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

$delete_id = intval(request_var('delete', 0));
$did_something = false;

if ($auth->acl_get('u_downloadview') && $user->data['user_id'] != 1 && !$user->data['is_bot'] && $delete_id < 1)
{
	$rating = intval(request_var('rating', -1));

	if ($rating >= 0 && $rating <= 5)
	{
		$download_data->get_user_rating_data($user->data['user_id']);

		if (!isset($download_data->user_rating[$user->data['user_id']][$download_id]))
		{
			$sql_data = array(
				'download_id'	=> $download_id,
				'user_id'		=> $user->data['user_id'],
				'score'			=> $rating,
			);

			$sql = 'INSERT INTO ' . DOWNLOADS_RATINGS_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);
			$db->sql_query($sql);

			$did_something = true;
		}
	}
}

if ($delete_id > 0)
{
	$download_data->get_user_rating_data($user->data['user_id']);

	if (isset($download_data->user_rating[$user->data['user_id']][$download_id]))
	{
		$sql = 'DELETE FROM ' . DOWNLOADS_RATINGS_TABLE . ' WHERE download_id = \'' . $delete_id . '\' AND user_id = \'' . $user->data['user_id'] . '\'';
		$db->sql_query($sql);

		$did_something = true;
	}
}

if ($did_something)
{
	unset($download_data->user_rating[$user->data['user_id']]);

	$sql = 'SELECT * FROM ' . DOWNLOADS_RATINGS_TABLE . ' WHERE download_id = \'' . $download_id . '\'';
	$result = $db->sql_query($sql);

	$total_rating = 0;
	$total_count = 0;

	while ($row = $db->sql_fetchrow($result))
	{
		$total_rating += $row['score'];
		$total_count++;
	}

	if ($total_count != 0)
	{
		$average_rating = (int) $total_rating / $total_count;
	}
	else
	{
		$average_rating = 0;
	}

	$sql = 'UPDATE ' . DOWNLOADS_TABLE . ' SET rating = \'' . $average_rating . '\', num_ratings = \'' . $total_count . '\' WHERE download_id = \'' . $download_id . '\'';
	$db->sql_query($sql);

	$db->sql_freeresult($result);
}

?>