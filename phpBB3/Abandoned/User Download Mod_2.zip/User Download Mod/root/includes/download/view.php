<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// check permissions
if (!$auth->acl_get('u_downloadview'))
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}
	
// Add the language Variables for viewtopic
$user->add_lang('viewtopic');

// Get the Download Data
if ($download_id != 0)
{
	// Try getting the download, if it doesn't exist the function should return false, so we can check for that right away as well
	if (!$download_data->get_download_data(array('download_id' => $download_id)))
	{
		trigger_error('NO_DOWNLOAD');
	}
}
else if ($reply_id != 0)
{
	// Try getting the download_id if they only give us the reply_id
	if (!$download_data->get_reply_data(array('reply_id' => $reply_id)))
	{
		trigger_error('NO_DOWNLOAD');
	}

	$download_id = $download_data->reply[$reply_id]['download_id'];

	// Try getting the download, if it doesn't exist the function should return false, so we can check for that right away as well
	if (!$download_data->get_download_data(array('download_id' => $download_id)))
	{
		trigger_error('NO_DOWNLOAD');
	}
}
else
{
	trigger_error('NO_DOWNLOAD');
}

// if the download was deleted and the person trying to view the download is not a moderator that can view deleted downloads, give them a nice error. :P
if ( ($download_data->download[$download_id]['deleted'] != 0) && (!$auth->acl_get('m_downloaddelete')) )
{
	trigger_error('DOWNLOAD_DELETED');
}

// for shortening things up later
$dl_data = $download_data->download[$download_id];
if ($dl_data['file_id'] == '')
{
	$file_data = array('formatted_filesize' => 0);
}
else
{
	$file_data = $download_data->file[$dl_data['file_id']];
}
//$screenshot_data = ($dl_data['screenshot_id'] != '') ? $download_data->file[$dl_data['screenshot_id']] : '';
$user_id = $dl_data['user_id'];
$category_id = $dl_data['category_id'];
$self_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $download_id);

// Get the reply data if we need to
if ( (($dl_data['reply_count'] > 0) ) || (($auth->acl_get('m_downloadapprove')) && ($dl_data['real_reply_count'] > 0)) )
{
	// Get the data on all of the replies
	$reply_ids = $download_data->get_reply_data(array('download_id' => $download_id, 'start' => $start, 'limit' => $limit));
}
else
{
	$reply_ids = false;
}

// Generate the breadcrumbs, setup the page header, and setup some variables we will use...
$breadcrumbs = array(
	$user->lang['USER_DOWNLOADS']				=> $view_download_main,
	$dl_cats[$category_id]['category_name']		=> append_sid("{$phpbb_root_path}downloads.$phpEx", "c=" . $category_id),
	$dl_data['name']							=> $self_url,
);
generate_download_breadcrumbs($breadcrumbs);
page_header($dl_data['name']);
generate_categories_menu();

$template->assign_vars($download_data->handle_download_data($download_id));

$template->assign_vars(array(
	'DOWNLOAD_IMG'		=> $phpbb_root_path . 'styles/' . $user->theme['theme_path'] . '/theme/images/download.gif',
	'U_ADD_REPLY'		=> ($auth->acl_get('u_downloadreply')) ? append_sid("{$phpbb_root_path}downloads.$phpEx", "page=reply&amp;mode=add&amp;d=$download_id") : '',

	'QUOTE_IMG'			=> $user->img('icon_post_quote', 'QUOTE'),
	'EDIT_IMG'			=> $user->img('icon_post_edit', 'EDIT_POST'),
	'DELETE_IMG'		=> $user->img('icon_post_delete', 'DELETE_POST'),
	'REPORT_IMG'		=> $user->img('icon_post_report', 'REPORT_POST'),
	'WARN_IMG'			=> $user->img('icon_user_warn', 'WARN_USER'),
	'UNAPPROVED_IMG'	=> $user->img('icon_topic_unapproved', 'POST_UNAPPROVED'),
	'REPORTED_IMG'		=> $user->img('icon_topic_reported', 'POST_REPORTED'),
	'MINI_POST_IMG'		=> $user->img('icon_post_target', 'POST'),

	'PROFILE_IMG'		=> $user->img('icon_user_profile', 'READ_PROFILE'),
	'PM_IMG'			=> $user->img('icon_contact_pm', 'SEND_PRIVATE_MESSAGE'),
	'EMAIL_IMG'			=> $user->img('icon_contact_email', 'SEND_EMAIL'),
	'WWW_IMG'			=> $user->img('icon_contact_www', 'VISIT_WEBSITE'),
	'MSN_IMG'			=> $user->img('icon_contact_msnm', 'MSNM'),
	'YIM_IMG'			=> $user->img('icon_contact_yahoo', 'YIM'),
	'AIM_IMG'			=> $user->img('icon_contact_aim', 'AIM'),
	'ICQ_IMG'			=> $user->img('icon_contact_icq', 'ICQ'),
	'JABBER_IMG'		=> $user->img('icon_contact_jabber', 'JABBER'),
));

// For the replies
if ($reply_ids !== false)
{
	if ($auth->acl_get('m_downloadapprove') && $auth->acl_gets('m_downloaddelete', 'a_downloadreplydelete'))
	{
		$total_replies = $download_data->download[$download_id]['real_reply_count'];
	}
	else if ($auth->acl_get('m_downloadapprove'))
	{
		$sql = 'SELECT count(download_id) AS total FROM ' . DOWNLOADS_REPLY_TABLE . ' WHERE deleted = \'0\' AND download_id = \'' . $download_id . '\'';
		$result = $db->sql_query($sql);
		$total = $db->sql_fetchrow($result);
		$total_replies = $total['total'];
	}
	else if ($auth->acl_gets('m_downloaddelete', 'a_downloadreplydelete'))
	{
		$sql = 'SELECT count(download_id) AS total FROM ' . DOWNLOADS_REPLY_TABLE . ' WHERE approved = \'1\' AND download_id = \'' . $download_id . '\'';
		$result = $db->sql_query($sql);
		$total = $db->sql_fetchrow($result);
		$total_replies = $total['total'];
	}
	else
	{
		$total_replies = $download_data->download[$download_id]['reply_count'];
	}
	
	$pagination = generate_pagination(append_sid("{$phpbb_root_path}downloads.$phpEx", "d={$download_id}&amp;limit=$limit"), $total_replies, $limit, $start, false);

	// tell the template we do have replies
	$template->assign_vars(array(
		'PAGINATION'			=> $pagination,
		'PAGE_NUMBER' 			=> on_page($total_replies, $limit, $start),
		'TOTAL_POSTS'			=> ($total_replies == 1) ? $user->lang['DOWNLOAD_COUNT'] : sprintf($user->lang['DOWNLOADS_COUNT'], $total_replies),

		'S_REPLIES'				=> true,
	));

	// Counter
	$i = 0;

	// use a foreach to easily output the data
	foreach($reply_ids as $id)
	{
		if ( ($download_data->reply[$id]['deleted_message'] == '') || $auth->acl_get('m_downloaddelete') || ($auth->acl_get('a_downloadreplydelete')) )
		{
			// increment the counter
			$i++;

			// shorten the vars up
			$r_data = $download_data->reply[$id];

			// output the user data to the replyrow block
			$user_replyrow = $download_data->handle_user_data($r_data['user_id']);

			$replyrow = array(
				'TITLE'				=> censor_text($r_data['subject']),
				'DATE'				=> $user->format_date($r_data['time']),

				'REPLY_MESSAGE'		=> $r_data['text'],

				'EDITED_MESSAGE'	=> $r_data['edited_message'],
				'EDIT_REASON'		=> $r_data['edit_reason'],
				'DELETED_MESSAGE'	=> $r_data['deleted_message'],

				'U_VIEW'			=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $download_id . '#r' . $id),

				'U_QUOTE'			=> ($auth->acl_get('u_downloadreply') && ($r_data['deleted_message'] == '')) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=reply&amp;mode=quote&amp;d=' . $download_id . '&amp;r=' . $id) : '',
				'U_EDIT'			=> (check_download_permissions('reply', 'edit', $id)) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=reply&amp;mode=edit&amp;r=' . $id) : '',
				'U_DELETE'			=> (check_download_permissions('reply', 'delete', $id)) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=reply&amp;mode=delete&amp;r=' . $id) : '',
				'U_REPORT'			=> ($auth->acl_get('u_downloadreport')) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=reply&amp;mode=report&amp;r=' . $id) : '',
				'U_WARN'			=> ($auth->acl_get('m_warn') && $r_data['user_id'] != $user->data['user_id'] && $r_data['user_id'] != ANONYMOUS) ? append_sid("{$phpbb_root_path}mcp.$phpEx", 'i=warn&amp;mode=warn_user&amp;u=' . $r_data['user_id'], true, $user->session_id) : '',
				'U_APPROVE'			=> ($auth->acl_get('m_downloadapprove') && $r_data['approved'] == 0) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=reply&amp;mode=approve&amp;r=' . $id) : '',

				'S_UNAPPROVED'		=> ($auth->acl_get('m_downloadapprove') && $r_data['approved'] == 0) ? true : false,
				'S_REPORTED'		=> ($r_data['reported'] && $auth->acl_get('m_downloadreport')) ? true : false,

				// For the anchors
				'ID'				=> $id,
			);

			// send the data to the template
			$template->assign_block_vars('replyrow', $user_replyrow + $replyrow);

			// output the custom fields
			$download_data->handle_user_data($r_data['user_id'], 'replyrow.custom_fields');
		}
	}
}

// tell the template parser what template file to use
$template->set_filenames(array(
	'body' => 'view_download.html'
));
?>