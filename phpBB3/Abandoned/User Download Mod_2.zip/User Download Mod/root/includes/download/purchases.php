<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// Hard Codded Limit and Start.  Doing this to forcefully not do any pagination. :P
$start = 0;
$limit = 9999999;

$sort_key	= request_var('sk', 'n');
$sort_dir	= request_var('sd', 'd');

// Add the language Variables for viewtopic
$user->add_lang('viewtopic');

if ($user_id > 1 && $user_id != $user->data['user_id'])
{
	$download_data->get_user_data($user_id);
	$purchase_text = sprintf($user->lang['USERS_PURCHASES'], $download_data->user[$user_id]['username']);
}
else
{
	$purchase_text = $user->lang['MY_PURCHASES'];
	$user_id = $user->data['user_id'];
}

$breadcrumbs = array(
	$user->lang['USER_DOWNLOADS']	=> $view_download_main,
	$purchase_text					=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=purchases&amp;u=' . $user_id),
);
generate_download_breadcrumbs($breadcrumbs);
page_header($user->lang['USER_DOWNLOADS']);
generate_categories_menu();

$url_data = '&amp;page=purchases&limit=' . $limit . (($user_id != 0) ? '&amp;u=' . $user_id : '');

// for sorting and pagination
$limit_days = array();
$sort_by_text = array('t' => $user->lang['POST_TIME'], 'n' => $user->lang['DOWNLOAD_NAME'], 'a' => $user->lang['AUTHOR'], 'r' => $user->lang['DOWNLOAD_RATING'], 'c' => $user->lang['PROGRAM_COST']);
$sort_by_sql = array('t' => 'time', 'n' => 'name', 'a' => 'author', 'r' => 'rating', 'c' => 'cost');

$sort_days = $s_sort_key = $s_sort_dir = $u_sort_param = '';
gen_sort_selects($limit_days, $sort_by_text, $sort_days, $sort_key, $sort_dir, $s_limit_days, $s_sort_key, $s_sort_dir, $u_sort_param);

$order_dir = ($sort_dir == 'a') ? 'ASC' : 'DESC';

if ($user_id != 0 && $user_id != $user->data['user_id'])
{
	$sql = 'SELECT count(DISTINCT download_id) AS total FROM ' . DOWNLOADS_PURCHASES_TABLE . ' WHERE user_id = \'' . $user_id . '\'';
	$result = $db->sql_query($sql);
	$total = $db->sql_fetchrow($result);
	$total_posts = $total['total'];
	$db->sql_freeresult($result);
	unset($total);
}
else
{
	$total_posts = ((count($purchased_data) !== false) ? count($purchased_data) : 0);
}

$pagination = generate_pagination(append_sid("{$phpbb_root_path}downloads.$phpEx", $url_data), $total_posts, $limit, $start, false);

// output some data
$template->assign_vars(array(
	'S_TOPIC_ACTION'	=> append_sid("{$phpbb_root_path}downloads.$phpEx", $url_data),
	'DOWNLOAD_IMG'		=> $phpbb_root_path . 'styles/' . $user->theme['theme_path'] . '/theme/images/download.gif',

	'U_ADD_PURCHASE'	=> ($auth->acl_get('m_addpurchasedownload')) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=purchase&amp;mod_add=true&amp;u=' . $user_id ) : '',
	'U_DELETE_PURCHASE'	=> ($auth->acl_get('m_addpurchasedownload')) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=purchase&amp;mod_remove=true&amp;u=' . $user_id ) : '',

	'QUOTE_IMG'			=> $user->img('icon_post_quote', 'QUOTE'),
	'EDIT_IMG'			=> $user->img('icon_post_edit', 'EDIT_POST'),
	'DELETE_IMG'		=> $user->img('icon_post_delete', 'DELETE_POST'),
	'REPORT_IMG'		=> $user->img('icon_post_report', 'REPORT_POST'),
	'WARN_IMG'			=> $user->img('icon_user_warn', 'WARN_USER'),
	'UNAPPROVED_IMG'	=> $user->img('icon_topic_unapproved', 'POST_UNAPPROVED'),
	'REPORTED_IMG'		=> $user->img('icon_topic_reported', 'POST_REPORTED'),
	'MINI_POST_IMG'		=> $user->img('icon_post_target', 'POST'),

	'PROFILE_IMG'		=> $user->img('icon_user_profile', 'READ_PROFILE'),
	'PM_IMG'			=> $user->img('icon_contact_pm', 'SEND_PRIVATE_MESSAGE'),
	'EMAIL_IMG'			=> $user->img('icon_contact_email', 'SEND_EMAIL'),
	'WWW_IMG'			=> $user->img('icon_contact_www', 'VISIT_WEBSITE'),
	'MSN_IMG'			=> $user->img('icon_contact_msnm', 'MSNM'),
	'YIM_IMG'			=> $user->img('icon_contact_yahoo', 'YIM'),
	'AIM_IMG'			=> $user->img('icon_contact_aim', 'AIM'),
	'ICQ_IMG'			=> $user->img('icon_contact_icq', 'ICQ'),
	'JABBER_IMG'		=> $user->img('icon_contact_jabber', 'JABBER'),

	'PAGINATION'			=> $pagination,
	'PAGE_NUMBER' 			=> on_page($total_posts, $limit, $start),
	'TOTAL_POSTS'			=> ($total_posts == 1) ? $user->lang['DOWNLOAD_COUNT'] : sprintf($user->lang['DOWNLOADS_COUNT'], $total_posts),
	'S_SORT'				=> true,
	'S_SELECT_SORT_DIR' 	=> $s_sort_dir,
	'S_SELECT_SORT_KEY' 	=> $s_sort_key,
));

$template->assign_vars(array(
	'SECTION_WIDTH'		=> '84',
	'U_VIEW'			=> append_sid("{$phpbb_root_path}downloads.$phpEx", $url_data),
	'TITLE'				=> $user->lang['PURCHASES'],
	'S_NORMAL'			=> true,
));

$purchased_ids = $download_data->get_download_data(array('purchased' => true, 'user_id' => $user_id, 'start' => $start, 'limit' => $limit, 'order_by' => $sort_by_sql[$sort_key], 'order_dir' => $order_dir));

if ($purchased_ids !== false)
{
	$i = 0;
	foreach ($purchased_ids as $id)
	{
		if ($i >= ($start + $limit) || $i < $start)
		{
			$i++;
			continue;
		}

		$user_row = $download_data->handle_user_data($download_data->download[$id]['user_id']);

		$category_row = $download_data->handle_download_data($id);

		$template->assign_block_vars('row', $user_row + $category_row);

		$i++;
	}
}

$template->set_filenames(array(
	'body' => 'view_download_purchase_log.html'
));
?>