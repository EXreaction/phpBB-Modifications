<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// Add some language variables
$user->add_lang('download');

// Add the Download's Link if they can view download's
if ($auth->acl_get('u_downloadview'))
{
	$template->assign_block_vars('download_links', array(
		'URL'		=> append_sid("{$phpbb_root_path}downloads.$phpEx"),
		'CLASS'		=> 'icon-members',
		'IMG'		=> '<img src="' . $phpbb_root_path . 'styles/' . $user->theme['theme_path'] . '/theme/images/icon_mini_members.gif" />',
		'TEXT'		=> $user->lang['DOWNLOADS'],
	));
}

/*
// Add the My Download's Link if they can view downloads and are registered
if ( ($auth->acl_get('u_downloadview')) && ($user->data['is_registered']) )
{
	$template->assign_block_vars('download_links', array(
		'URL'		=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=view&amp;mode=user&amp;u=' . $user->data['user_id']),
		'CLASS'		=> 'icon-ucp',
		'IMG'		=> '<img src="' . $phpbb_root_path . 'styles/' . $user->theme['theme_path'] . '/theme/images/icon_mini_message.gif" alt="' . $user->lang['MY_DOWNLOADS'] . '" />',
		'TEXT'		=> $user->lang['MY_DOWNLOADS'],
	));
}
*/
?>