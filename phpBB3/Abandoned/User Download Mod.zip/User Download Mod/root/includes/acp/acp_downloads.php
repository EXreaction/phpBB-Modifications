<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* @package acp
*/
class acp_downloads
{
	var $u_action;

	function main($id, $mode)
	{
		global $config, $db, $user, $auth, $template, $cache;
		global $phpbb_root_path, $phpbb_admin_path, $phpEx, $table_prefix;
		
		$submit = isset($_POST['submit']) ? true : false;
		$action = request_var('action', '');
		$category_id = intval(request_var('id', 0 ));
		$order_id = intval(request_var('order_id', 0 ));
		$edit_cat_name = request_var('edit_cat_name', '');

		$this->tpl_name = ($action != 'edit') ? 'acp_downloads' : 'acp_categories_edit';
		$this->page_title = $user->lang['ACP_DOWNLOADS'];

		if ($order_id != 0 && $category_id != 0)
		{
			if ($action == 'move_up')
			{
				$sql = 'UPDATE ' . DOWNLOADS_CATEGORIES_TABLE . ' SET order_id = order_id + 1  WHERE order_id = \'' . ($order_id - 1) . '\'';
				$db->sql_query($sql);

				$sql = 'UPDATE ' . DOWNLOADS_CATEGORIES_TABLE . ' SET order_id = order_id - 1  WHERE category_id = \'' . $category_id . '\'';
				$db->sql_query($sql);
			}
			else if ($action == 'move_down')
			{
				$sql = 'UPDATE ' . DOWNLOADS_CATEGORIES_TABLE . ' SET order_id = order_id - 1  WHERE order_id = \'' . ($order_id + 1) . '\'';
				$db->sql_query($sql);

				$sql = 'UPDATE ' . DOWNLOADS_CATEGORIES_TABLE . ' SET order_id = order_id + 1  WHERE category_id = \'' . $category_id . '\'';
				$db->sql_query($sql);
			}
			else if ($action == 'edit')
			{
				$sql = 'SELECT category_name FROM ' . DOWNLOADS_CATEGORIES_TABLE . ' WHERE category_id = \'' . $category_id . '\'';
				$result = $db->sql_query($sql);
				$cat_row = $db->sql_fetchrow($result);

				$template->assign_vars(array(
					'U_EDIT_ACTION'		=> $this->u_action . '&amp;id=' . $category_id,
					'L_EDIT_CAT'		=> $user->lang['EDIT_CAT'],
					'CAT_NAME'			=> $cat_row['category_name'],
					'L_CATEGORY_NAME'	=> $user->lang['CATEGORY_NAME'],
				));
			}
			else if ($action == 'delete')
			{
				if (confirm_box(true))
				{
					$sql = 'DELETE FROM ' . DOWNLOADS_CATEGORIES_TABLE . ' WHERE order_id = \'' . $order_id . '\'';
					$db->sql_query($sql);

					$sql = 'UPDATE ' . DOWNLOADS_CATEGORIES_TABLE . ' SET order_id = order_id - 1  WHERE order_id > \'' . $order_id . '\'';
					$db->sql_query($sql);
				}
				else
				{
					confirm_box(false, 'DELETE_CATEGORY');
				}
			}
		}

		if ($edit_cat_name != '' && $category_id != 0)
		{
			$sql = 'UPDATE ' . DOWNLOADS_CATEGORIES_TABLE . ' SET category_name = \'' . utf8_normalize_nfc($edit_cat_name) . '\'  WHERE category_id = \'' . $category_id . '\'';
			$db->sql_query($sql);
		}

		if (!$submit)
		{
			$template->assign_vars(array(
				'L_ACP_DOWNLOADS'							=> $user->lang['ACP_DOWNLOADS'],
				'L_DOWNLOAD_SETTINGS'						=> $user->lang['DOWNLOAD_SETTINGS'],
				'L_ENABLE_DOWNLOAD_CUSTOM_PROFILES'			=> $user->lang['ENABLE_DOWNLOAD_CUSTOM_PROFILES'],
				'1_DOWNLOAD_CUSTOM_PROFILE_ENABLE'			=> ($config['download_custom_profile_enable']) ? 'checked="checked"' : '',
				'0_DOWNLOAD_CUSTOM_PROFILE_ENABLE'			=> ($config['download_custom_profile_enable']) ? '' : 'checked="checked"',
				'L_DOWNLOAD_INFORM'							=> $user->lang['DOWNLOAD_INFORM'],
				'L_DOWNLOAD_INFORM_EXPLAIN'					=> $user->lang['DOWNLOAD_INFORM_EXPLAIN'],
				'DOWNLOAD_INFORM'							=> $config['download_inform'],
				'L_PERCENT_COST_GIVEN_SUBMITTER'			=> $user->lang['PERCENT_COST_GIVEN_SUBMITTER'],
				'L_PERCENT_COST_GIVEN_SUBMITTER_EXPLAIN'	=> $user->lang['PERCENT_COST_GIVEN_SUBMITTER_EXPLAIN'],
				'PERCENT_COST_GIVEN_SUBMITTER'				=> $config['percent_cost_given_submitter'],
				'L_NEW_CATEGORY'							=> $user->lang['NEW_CATEGORY'],
				'L_ADD_CAT'									=> $user->lang['ADD_CAT'],
			));

			$sql = 'SELECT * FROM ' . DOWNLOADS_CATEGORIES_TABLE . ' ORDER BY order_id ASC';
			$result = $db->sql_query($sql);

			while($row = $db->sql_fetchrow($result))
			{
				$url = $this->u_action . '&amp;id=' . $row['category_id'] . '&amp;order_id=' . $row['order_id'];

				$template->assign_block_vars('categories', array(
					'NAME'			=> $row['category_name'],

					'U_MOVE_UP'		=> $url . '&amp;action=move_up',
					'U_MOVE_DOWN'	=> $url . '&amp;action=move_down',
					'U_EDIT'		=> $url . '&amp;action=edit',
					'U_DELETE'		=> $url . '&amp;action=delete',
				));
			}

			$db->sql_freeresult($result);
		}
		else
		{
			$download_custom_profile_enable = request_var('download_custom_profile_enable', false);
			$download_inform = request_var('download_inform', '2');
			$percent_cost_given_submitter = request_var('percent_cost_given_submitter', 0);
			$new_cat_name = request_var('new_cat_name', '');

			if ($download_custom_profile_enable != $config['download_custom_profile_enable'])
			{
				set_config('download_custom_profile_enable', $download_custom_profile_enable);
			}
			if ($download_inform != $config['download_inform'])
			{
				set_config('download_inform', $download_inform);
			}
			if ($percent_cost_given_submitter != $config['percent_cost_given_submitter'])
			{
				set_config('percent_cost_given_submitter', $percent_cost_given_submitter);
			}

			if ($new_cat_name != '')
			{
				$sql = 'INSERT INTO ' . DOWNLOADS_CATEGORIES_TABLE . ' (category_name) VALUES (\'' . $new_cat_name . '\')';
				$db->sql_query($sql);

				$category_id = $db->sql_nextid();

				$sql = 'UPDATE ' . DOWNLOADS_CATEGORIES_TABLE . ' SET order_id = \'' . $category_id . '\' WHERE category_id = \'' . $category_id . '\'';
				$db->sql_query($sql);
			}

			trigger_error($user->lang['DOWNLOADS_UPDATED'] . adm_back_link($this->u_action));
		}
	}
}

?>