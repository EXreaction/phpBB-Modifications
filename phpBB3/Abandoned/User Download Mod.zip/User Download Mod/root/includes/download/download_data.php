<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

/*
* Download data class
*
* Mainly for holding and grabbing all of the data for the downloads, replies, and users requested at any time for this single page view/session
*/
class download_data
{
	// this is our large arrays holding all the user ratings, file, download, reply, and user data
	var $user_rating = array();
	var $file = array();
	var $download = array();
	var $reply = array();
	var $user = array();

	// this holds a queue of the user's data when requesting replies so we can cut down on queries
	var $queue = array();

	/*
	* -------------------------- RATING DATA SECTION -----------------------------
	*/
	function get_user_rating_data($user_id, $refresh = false)
	{
		global $db;

		if (isset($this->user_rating[$user_id]) && $refresh)
		{
			return;
		}

		$sql = 'SELECT * FROM ' . DOWNLOADS_RATINGS_TABLE . ' WHERE user_id = \'' . intval($user_id) . '\'';

		$result = $db->sql_query($sql);

		while ($row = $db->sql_fetchrow($result))
		{
			$this->user_rating[$row['user_id']][$row['download_id']] = $row['score'];
		}
	}

	/*
	* -------------------------- FILE DATA SECTION -----------------------------
	*/
	function get_file_data($file_id)
	{
		global $db;

		$file_ids = array();
		$files_to_query = array();

		if (!is_array($file_id))
		{
			$file_id = array($file_id);
		}

		// check if the download already exists
		foreach ($file_id as $id)
		{
			if ( (!array_key_exists($id, $this->file)) && (!in_array($id, $files_to_query)) )
			{
				array_push($files_to_query, $id);
			}
			else
			{
				// since the download was already queried once lets put it on the list of download_ids that we grabbed that we will return later
				array_push($file_ids, $id);
			}
		}

		if (count($files_to_query) == 0)
		{
			return false;
		}

		$sql = 'SELECT * FROM ' . DOWNLOADS_ATTACHMENTS_TABLE . '
			WHERE ' . $db->sql_in_set('attach_id', $files_to_query);
		$result = $db->sql_query($sql);

		while ($row = $db->sql_fetchrow($result))
		{
			$id = $row['attach_id'];

			$this->file[$id] = $row;

			// format the filesize
			if ($row['filesize'] / 1000000 > 1)
			{
				$this->file[$id]['formatted_filesize'] = number_format($row['filesize'] / 1000000, 2) . ' MB';
			}
			else if ($row['filesize'] / 1000 > 1)
			{
				$this->file[$id]['formatted_filesize'] = number_format($row['filesize'] / 1000, 2) . ' KB';
			}
			else
			{
				$this->file[$id]['formatted_filesize'] = $row['filesize'] . ' B';
			}
		}

		return $file_ids;
	}

	/*
	* -------------------------- DOWNLOAD DATA SECTION -----------------------------
	*/

	/*
	* get downloads
	* Input options are listed a few lines down.
	*/
	function get_download_data($selection_data)
	{
		global $db, $user, $phpbb_root_path, $phpEx, $auth;

		// input options
		$download_id =	(isset($selection_data['download_id'])) ? $selection_data['download_id'] :	false; // Select a single or if array, multiple download(s)
		$category_id =	(isset($selection_data['category_id']) && ($selection_data['category_id'] > 0)) ? $selection_data['category_id'] :	false; // Select downloads by a user ID
		$recent =		(isset($selection_data['recent'])) ? $selection_data['recent'] :			false; // Select the recent downloads
		$random =		(isset($selection_data['random'])) ? $selection_data['random'] :			false; // Select random downloads
		$popular = 		(isset($selection_data['popular'])) ? $selection_data['popular'] :			false; // Select popular downloads
		$reported = 	(isset($selection_data['reported'])) ? $selection_data['reported'] :		false; // Select reported downloads
		$disapproved = 	(isset($selection_data['disapproved'])) ? $selection_data['disapproved'] :	false; // Select disapproved downloads
		$deleted = 		(isset($selection_data['deleted'])) ? $selection_data['deleted'] : 			false; // view deleted downloads
		$purchased =	(isset($selection_data['purchased'])) ? $selection_data['purchased'] :		false; // view purchased downloads

		$user_id = 		(isset($selection_data['user_id'])) ? $selection_data['user_id'] :			$user->data['user_id']; // for viewing other users' purchased downloads
		$start =		(isset($selection_data['start'])) ? $selection_data['start'] :				0; // the start (for pagination)
		$limit =		(isset($selection_data['limit'])) ? $selection_data['limit'] :				10;	   // the limit on how many downloads we will select
		$simple =		(isset($selection_data['simple'])) ? $selection_data['simple'] :			false; // if we want to parse the text or just grab it from the db
		$force_all = 	(isset($selection_data['force_all'])) ? $selection_data['force_all'] :		false; // just in case we want to forcefully grab all the data and not take any from out little cache...
		$custom_sql = 	(isset($selection_data['custom_sql'])) ? $selection_data['custom_sql'] :	''; // for added custom SQL queries
		$order_by = 	(isset($selection_data['order_by'])) ? $selection_data['order_by'] :		''; // for added custom SQL queries
		$order_dir = 	(isset($selection_data['order_dir'])) ? $selection_data['order_dir'] :		''; // for added custom SQL queries

		// Setup some variables...
		$download_ids = array();
		$file_ids = array();
		$category_sql = ($category_id !== false) ? ' AND category_id = \'' . $category_id . '\'' : '';
		$view_unapproved_sql = ($auth->acl_get('m_downloadapprove')) ? '' : ' AND approved = \'1\'';
		if (strpos($custom_sql, 'ORDER BY'))
		{
			$order_by_sql = '';
		}
		else
		{
			$order_by_sql = ' ORDER BY ';
			$order_by_sql .= ($order_by != '') ? $order_by : 'download_id';
			$order_by_sql .= ($order_dir != '') ? ' ' . $order_dir : ' DESC';
		}
		$limit_sql = ($limit >= 1) ? ($start > 0) ? ' LIMIT ' . $start . ', ' . $limit : ' LIMIT ' . $limit : '';

		// Get the data on the download
		if ($download_id != false) // select download(s) by their download_id
		{
			if (!is_array($download_id))
			{
				$download_id = array($download_id);
			}

			$downloads_to_query = array();

			// check if the download already exists
			foreach ($download_id as $id)
			{
				if ( $force_all || ( (!array_key_exists($id, $this->download)) || ( (isset($this->download[$id]['simple'])) && ( ( ($this->download[$id]['simple'] == false) && ($simple == true) ) || ( ($this->download[$id]['simple'] == true) && ($simple == false) ) ) ) ) && (!in_array($id, $downloads_to_query)) )
				{
					array_push($downloads_to_query, $id);
				}
				else
				{
					// since the download was already queried once lets put it on the list of download_ids that we grabbed that we will return later
					array_push($download_ids, $id);
				}
			}

			if (count($downloads_to_query) == 0)
			{
				return $download_id;
			}

			$sql = 'SELECT * FROM ' . DOWNLOADS_TABLE . '
					WHERE ' . $db->sql_in_set('download_id', $downloads_to_query) .
						$view_unapproved_sql;
		}
		else if ($recent) // select recent downloads
		{
			$sql = 'SELECT * FROM ' . DOWNLOADS_TABLE .
				' WHERE deleted = \'0\'' .
					$custom_sql .
						$view_unapproved_sql .
							$category_sql .
								$order_by_sql .
									$limit_sql;
		}
		else if ($random) // select random downloads
		{
			$all_download_ids = array();
			$random_ids = array();
			$i = 0;

			$sql = 'SELECT download_id FROM ' . DOWNLOADS_TABLE .
				' WHERE deleted = \'0\'' .
					$custom_sql .
						$view_unapproved_sql .
							$category_sql;

			$result = $db->sql_query($sql);
			while ($row = $db->sql_fetchrow($result))
			{
				$i++;
				$all_download_ids[$i] = $row['download_id'];
			}

			// return false if there are no downloads
			if (count($all_download_ids) == 0)
			{
				return false;
			}

			// if the limit is higher than the total number of downloads, just give them what we have (and shuffle it so it looks random)
			if ($limit > count($all_download_ids))
			{
				shuffle($all_download_ids);
				$this->get_download_data(array('download_id' => $all_download_ids));
				return $all_download_ids;
			}
			else
			{
				// this is not the most efficient way to do it...but as long as the limit doesn't get too close to the total number of downloads it's fine
				// If the limit is near the total number of downloads we just hope it doesn't take too long (the user should not be requesting many random downloads anyways)
				for ($j = 0; $j < $limit; $j++)
				{
					$random_id = rand(1, $i);

					// make sure the random_id can only be picked once...
					if (!in_array($all_download_ids[$random_id], $random_ids))
					{
						array_push($random_ids, $all_download_ids[$random_id]);
					}
					else
					{
						$j--;
					}
				}
			}

			// to query them, we set download_id as the random_ids, then recall this function again.  I am doing it this way for a few reasons...
			$selection_data['download_id'] = $random_ids;
			$selection_data['random'] = false; // this really shouldn't need to be set the way the code is now, but it might prevent errors in the future if something gets changed
			$this->get_download_data($selection_data);

			return $random_ids;
		}
		else if ($popular) // select popular downloads
		{
			$order_dir = ($order_dir == '') ? 'DESC' : $order_dir;
			$sql = 'SELECT * FROM ' . DOWNLOADS_TABLE . '
				WHERE deleted = \'0\'' .
					$view_unapproved_sql .
						$category_sql .
							' ORDER BY download_count ' . $order_dir .
								$limit_sql;
		}
		else if ($reported) // select reported downloads
		{
			$sql = 'SELECT * FROM ' . DOWNLOADS_TABLE . '
				WHERE reported = \'1\'' .
					$custom_sql;
		}
		else if ($disapproved) // select non-aproved downloads
		{
			$sql = 'SELECT * FROM ' . DOWNLOADS_TABLE . '
				WHERE approved = \'0\'' .
					$custom_sql;
		}
		else if ($deleted)
		{
			$sql = 'SELECT * FROM ' . DOWNLOADS_TABLE . '
						WHERE deleted != \'0\'' .
							$custom_sql .
								$limit_sql;
		}
		else if ($purchased)
		{
			$purchased_data = array();

			$sql = 'SELECT * FROM ' . DOWNLOADS_PURCHASES_TABLE . '
				WHERE user_id = \'' . $user_id . '\'';
			$result = $db->sql_query($sql);

			while ($row = $db->sql_fetchrow($result))
			{
				array_push($purchased_data, $row['download_id']);
			}
			$db->sql_freeresult($result);

			if (count($purchased_data) == 0)
			{
				return false;
			}

			$sql = 'SELECT * FROM ' . DOWNLOADS_TABLE . '
				WHERE  ' . $db->sql_in_set('download_id', $purchased_data) .
					$custom_sql;
		}
		else if ($category_id != false) // select all downloads by a category_id
		{
			$sql = 'SELECT * FROM ' . DOWNLOADS_TABLE . '
						WHERE category_id = \'' . $category_id . '\'' .
								$view_unapproved_sql .
								$custom_sql .
									$order_by_sql .
										$limit_sql;
		}

		// check to make sure they included a mode to choose, if they didn't $sql would not have been set
		if (!isset($sql))
		{
			return false;
		}

		$result = $db->sql_query($sql);

		if ($simple) // if we just want to grab the data and not parse any of it...
		{
			while ($row = $db->sql_fetchrow($result))
			{
				$this->download[$row['download_id']] = $row;
				$this->download[$row['download_id']]['simple'] = true;

				array_push($download_ids, $row['download_id']);
			}
		}
		else
		{
			while ($row = $db->sql_fetchrow($result))
			{
				// this will set a lot of the data to start with...
				$this->download[$row['download_id']] = $row;

				// censor the text of the subject
				$this->download[$row['download_id']]['name'] = censor_text($this->download[$row['download_id']]['name']);

				// Parse BBCode and prepare the message for viewing
				$bbcode_options = (($row['enable_bbcode']) ? OPTION_FLAG_BBCODE : 0) + (($row['enable_smilies']) ? OPTION_FLAG_SMILIES : 0) + (($row['enable_magic_url']) ? OPTION_FLAG_LINKS : 0);
				$this->download[$row['download_id']]['description'] = generate_text_for_display($row['description'], $row['bbcode_uid'], $row['bbcode_bitfield'], $bbcode_options);
		
				// For Highlighting
				$hilit_words = request_var('hilit', '', true);
				if ($hilit_words)
				{
					$highlight_match = $highlight = '';
					foreach (explode(' ', trim($hilit_words)) as $word)
					{
						if (trim($word))
						{
							$highlight_match .= (($highlight_match != '') ? '|' : '') . str_replace('*', '\w*?', preg_quote($word, '#'));
						}
					}
					$highlight = urlencode($hilit_words);
					if ($highlight_match)
					{
						$this->download[$row['download_id']]['description'] = preg_replace('#(?!<.*)(?<!\w)(' . $highlight_match . ')(?!\w|[^<>]*(?:</s(?:cript|tyle))?>)#is', '<span class="posthilit">\1</span>', $this->download[$row['download_id']]['description']);
					}
				}

				// add the download owners' user_ids to the queue
				array_push($this->queue, $row['user_id']);

				// Add the edit user to the queue, if there is one
				if ($row['edit_count'] != 0)
				{
					array_push($this->queue, $row['edit_user']);
				}

				// Add the deleter user to the queue, if there is one
				if ($row['deleted'] != 0)
				{
					array_push($this->queue, $row['deleted']);
				}

				array_push($file_ids, $row['file_id'], $row['screenshot_id']);

				// make sure we set it so that it knows we are not doing the simple request if this download is requested again
				$this->download[$row['download_id']]['simple'] = false;

				// make sure we don't record the same download id in the list that we return more than once
				if (!in_array($row['download_id'], $download_ids))
				{
					array_push($download_ids, $row['download_id']);
				}
			}
			$db->sql_freeresult($result);
		}

		// if there are no downloads, return false
		if (count($download_ids) == 0)
		{
			return false;
		}

		if (!$simple)
		{
			// Get the data on the users
			$this->get_user_data(false, true);
			
			// Update the edit and delete info
			$this->update_edit_delete('download');

			$this->get_file_data($file_ids);
		}

		return $download_ids;
	}

	function handle_download_data($id, $prefix = '', $star_prefix = '')
	{
		global $user, $phpbb_root_path, $phpEx, $auth, $code_lang, $purchased_data;

		$dl_data = $this->download[$id];
		if ($dl_data['file_id'] == '')
		{
			$file_data = array('formatted_filesize' => 0);
		}
		else
		{
			$file_data = $this->file[$dl_data['file_id']];
		}
		$user_id = $dl_data['user_id'];
		$lang_colors = generate_code_lang(false, 0, true);

		$can_delete_download = ( !($auth->acl_get('u_downloaddelete') && $user->data['user_id'] == $user_id) && !($auth->acl_get('m_downloaddelete')) && !($auth->acl_get('a_downloaddelete')) ) ? false : true;
		$staff_dl = $auth->acl_gets('m_downloadapprove', 'm_downloadedit', 'm_downloadlockedit', 'm_downloaddelete', 'm_downloadreport', 'm_addpurchasedownload', 'a_downloadmanage', 'a_downloaddelete', 'a_downloadreplydelete');


		$category_row = array(
			$prefix . 'TITLE'			=> $dl_data['name'],
			$prefix . 'APP_TITLE'		=> $dl_data['name'],
			$prefix . 'USER_FULL'		=> $this->user[$dl_data['user_id']]['username_full'],
			$prefix . 'DATE'			=> $user->format_date($dl_data['time']),
			$prefix . 'FILESIZE'		=> $file_data['formatted_filesize'],
			$prefix . 'AUTHOR'			=> $dl_data['author'],
			$prefix . 'AVERAGE_RATING'	=> get_star_rating($dl_data['rating'], $id, true, $star_prefix),
			$prefix . 'RATING'			=> (isset($this->user_rating[$user->data['user_id']][$id])) ? get_star_rating($dl_data['rating'], $id) : false,
			$prefix . 'VOTES'			=> sprintf($user->lang['OUT_OF_VOTES'], $dl_data['num_ratings']),
			$prefix . 'COST'			=> $dl_data['cost'],
			$prefix . 'DOWNLOAD_COUNT'	=> $dl_data['download_count'],
			$prefix . 'DATE_ADDED'		=> date('F d, Y', $dl_data['time']),
			$prefix . 'CODE_LANGUAGE'	=> $code_lang[$dl_data['language_id']],
			$prefix . 'DESCRIPTION_OF'	=> sprintf($user->lang['DESCRIPTION_OF'], $dl_data['name']),
			$prefix . 'DESCRIPTION'		=> $dl_data['description'],
			$prefix . 'SCREENSHOT'		=> ($dl_data['screenshot_id'] != 0) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=download&amp;id=' . $dl_data['screenshot_id']) : $phpbb_root_path . 'styles/' . $user->theme['imageset_path'] . '/imageset/download_mod/no_image.gif',
			$prefix . 'POST_COLOR'		=> $lang_colors[$dl_data['language_id']],

			$prefix . 'EDITED_MESSAGE'	=> $dl_data['edited_message'],
			$prefix . 'EDIT_REASON'		=> $dl_data['edit_reason'],
			$prefix . 'DELETED_MESSAGE'	=> $dl_data['deleted_message'],

			$prefix . 'U_APPROVE'		=> ($auth->acl_get('m_downloadapprove') && $dl_data['approved'] == 0) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=approve&amp;d=' . $id) : '',
			$prefix . 'U_DELETE'		=> ($can_delete_download && ($dl_data['deleted_message'] == '' || $auth->acl_get('a_downloaddelete'))) ? append_sid("{$phpbb_root_path}downloads.$phpEx", "page=download&amp;mode=delete&amp;d=" . $id) : '',
			$prefix . 'U_DELETE_RATING'	=> (isset($this->user_rating[$user->data['user_id']][$id])) ? append_sid("{$phpbb_root_path}downloads.$phpEx", "page=rate&amp;delete={$id}&amp;d=$id") : '',
			$prefix . 'U_DIGG'			=> 'http://digg.com/submit?phase=2&amp;url=' . urlencode(generate_board_url() . '/downloads.' . $phpEx . '?d=' . $id),
			$prefix . 'U_DOWNLOAD'		=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=download&amp;id=' . $dl_data['file_id']),
			$prefix . 'U_EDIT'			=> ($auth->acl_get('m_downloadedit') || ($auth->acl_get('u_downloadedit') && ($dl_data['user_id'] == $user->data['user_id']) && !$dl_data['edit_locked'])) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=edit&amp;d=' . $id) : '',
			$prefix . 'U_PURCHASE'		=> (!$staff_dl && $dl_data['cost'] > 0 && !in_array($id, $purchased_data) && $user->data['user_id'] != $dl_data['user_id']) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=purchase&amp;d=' . $id) : '',
			$prefix . 'U_REPORT'		=> ($auth->acl_get('u_downloadreport')) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=report&amp;d=' . $id) : '',
			$prefix . 'U_VIEW'			=> append_sid("{$phpbb_root_path}downloads.$phpEx", "d=$id"),
			$prefix . 'U_VIEW_APP'		=> append_sid("{$phpbb_root_path}downloads.$phpEx", "d=$id"),
			$prefix . 'U_WARN'			=> ($auth->acl_get('m_warn') && $dl_data['user_id'] != $user->data['user_id'] && $dl_data['user_id'] != ANONYMOUS) ? append_sid("{$phpbb_root_path}mcp.$phpEx", 'i=warn&amp;mode=warn_user&amp;u=' . $dl_data['user_id'], true, $user->session_id) : '',

			$prefix . 'S_UNAPPROVED'	=> ($auth->acl_get('m_downloadapprove') && $dl_data['approved'] == 0) ? true : false,
			$prefix . 'S_REPORTED'		=> ($dl_data['reported'] && $auth->acl_get('m_downloadreport')) ? true : false,
			$prefix . 'S_DELETED'		=> ($dl_data['deleted'] != 0) ? true : false,
			$prefix . 'S_IMAGE'			=> ($dl_data['screenshot_id'] != 0) ? true : false,
		);

		return $category_row;
	}

	/*
	* -------------------------- REPLY DATA SECTION -----------------------------
	*/

	/*
	* get reply data
	*/
	function get_reply_data($selection_data)
	{
		global $db, $user, $phpbb_root_path, $phpEx, $auth;

		// input options
		$download_id =	(isset($selection_data['download_id'])) ? $selection_data['download_id'] :	false; // select reply data on a  single download
		$reply_id =		(isset($selection_data['reply_id'])) ? $selection_data['reply_id'] :		false; // select a single or if array, multiple reply(s)
		$reported = 	(isset($selection_data['reported'])) ? $selection_data['reported'] :		false; // Select reported downloads
		$disapproved = 	(isset($selection_data['disapproved'])) ? $selection_data['disapproved'] :	false; // Select disapproved downloads

		$simple =		(isset($selection_data['simple'])) ? $selection_data['simple'] :			false; // if we want to parse the text or just grab it from the db
		$limit =		(isset($selection_data['limit'])) ? $selection_data['limit'] :				10; // the limit for the sql
		$start = 		(isset($selection_data['start'])) ? $selection_data['start'] :				0; // the start for the sql

		// Setup some variables...
		$reply_ids = array();
		$view_unapproved_sql = ($auth->acl_get('m_downloadapprove')) ? '' : ' AND approved = \'1\'';
		$limit_sql = ($limit >= 1) ? ($start > 0) ? ' LIMIT ' . $start . ', ' . $limit : ' LIMIT ' . $limit : '';

		if ($download_id != false)
		{
			$sql = 'SELECT * FROM ' . DOWNLOADS_REPLY_TABLE . '
				WHERE download_id = \'' . $download_id . '\'' . 
					$view_unapproved_sql . '
						ORDER BY time DESC ' .
							$limit_sql;
		}
		else if ($reply_id != false)
		{
			if (!is_array($reply_id))
			{
				// check if the reply already exists
				if ( ( (!array_key_exists($reply_id, $this->reply)) || ( (isset($this->reply[$reply_id]['simple'])) && ( ( ($this->reply[$reply_id]['simple'] == false) && ($simple == true) ) || ( ($this->reply[$reply_id]['simple'] == true) && ($simple == false) ) ) ) ) )
				{
					$sql = 'SELECT * FROM ' . DOWNLOADS_REPLY_TABLE . '
								WHERE reply_id = \'' . $reply_id . '\'
									LIMIT 1';
				}
				else
				{
					return array($reply_id);
				}
			}
			else
			{
				$replys_to_query = array();

				// check if the reply already exists
				foreach ($reply_id as $id)
				{
					if ( (!array_key_exists($id, $this->reply)) || ( (isset($this->reply[$id]['simple'])) && ( ( ($this->reply[$id]['simple'] == false) && ($simple == true) ) || ( ($this->reply[$id]['simple'] == true) && ($simple == false) ) ) ) )
					{
						array_push($replys_to_query, $id);
					}
				}

				if (count($replys_to_query) == 0)
				{
					return $reply_id;
				}

				$sql = 'SELECT * FROM ' . DOWNLOADS_REPLY_TABLE . '
					WHERE ' . $db->sql_in_set('reply_id', $replies_to_query);
			}
		}
		else if ($reported)
		{
			$sql = 'SELECT * FROM ' . DOWNLOADS_REPLY_TABLE . '
					WHERE reported = \'1\'' .
						$limit_sql;
		}
		else if ($disapproved)
		{
			$sql = 'SELECT * FROM ' . DOWNLOADS_REPLY_TABLE . '
					WHERE approved = \'0\'' .
						$limit_sql;
		}

		$result = $db->sql_query($sql);

		if ($simple) // if we just want to grab the data and not parse any of it...
		{
			while ($row = $db->sql_fetchrow($result))
			{
				$this->reply[$row['reply_id']] = $row;
				$this->reply[$row['reply_id']]['simple'] = true;

				array_push($reply_ids, $row['reply_id']);
			}
		}
		else
		{
			while ($row = $db->sql_fetchrow($result))
			{
				// this will set a lot of the data to start with...
				$this->reply[$row['reply_id']] = $row;
		
				$this->reply[$row['reply_id']]['subject'] = censor_text($this->reply[$row['reply_id']]['subject']); // censor the text of the subject
		
				// Parse BBCode and prepare the message for viewing
				$bbcode_options = (($row['enable_bbcode']) ? OPTION_FLAG_BBCODE : 0) +
					(($row['enable_smilies']) ? OPTION_FLAG_SMILIES : 0) + 
					(($row['enable_magic_url']) ? OPTION_FLAG_LINKS : 0);
				$this->reply[$row['reply_id']]['text'] = generate_text_for_display($row['text'], $row['bbcode_uid'], $row['bbcode_bitfield'], $bbcode_options);
		
				// For Highlighting
				$hilit_words = request_var('hilit', '', true);
				$highlight_match = $highlight = '';
				if ($hilit_words)
				{
					foreach (explode(' ', trim($hilit_words)) as $word)
					{
						if (trim($word))
						{
							$highlight_match .= (($highlight_match != '') ? '|' : '') . str_replace('*', '\w*?', preg_quote($word, '#'));
						}
					}
		
					$highlight = urlencode($hilit_words);
				}
				if ($highlight_match)
				{
					$this->reply[$row['reply_id']]['text'] = preg_replace('#(?!<.*)(?<!\w)(' . $highlight_match . ')(?!\w|[^<>]*(?:</s(?:cript|tyle))?>)#is', '<span class="posthilit">\1</span>', $this->reply[$row['reply_id']]['text']);
				}
		
				// has the reply been edited?
				if ($row['edit_count'] != 0)
				{
					array_push($this->queue, $row['edit_user']);
				}
		
				// has the reply been deleted?
				if ($row['deleted'] != 0)
				{
					array_push($this->queue, $row['deleted']);
				}

				// Add this user's ID to the queue, so we can cut DB queries by selecting all the user's data at once.
				array_push($this->queue, $row['user_id']);

				$this->reply[$row['reply_id']]['simple'] = false;

				// make sure we don't record the same ID more than once
				if (!in_array($row['reply_id'], $reply_ids))
				{
					array_push($reply_ids, $row['reply_id']);
				}
			}
			$db->sql_freeresult($result);
		}

		// if there are no replys, return false
		if (count($reply_ids) == 0)
		{
			return false;
		}
		else
		{
			// Get the data on the users
			$this->get_user_data(false, true);
			
			// Update the edit and delete info
			$this->update_edit_delete('reply');

			return $reply_ids;
		}
	}

	/*
	* -------------------------- USER DATA SECTION -----------------------------
	*/

	// grabs the data on the user and places it in the $this->user array
	// if queue is true then we just grab the user_ids from the queue, otherwise we select data from just 1 user at a time.
	function get_user_data($user_id, $queue = false)
	{
		global $user, $db, $phpbb_root_path, $phpEx, $config, $auth, $cp, $bbcode;

		// if the $user_id isn't an array, make it one for consistency
		if ( ($user_id !== false) && (!is_array($user_id)) )
		{
			$user_id = array($user_id);
		}

		// if we are using the queue, set $user_id as that for consistency
		if ($queue)
		{
			$user_id = $this->queue;
		}

		// this holds the user_id's we will query
		$users_to_query = array();

		foreach ($user_id as $id)
		{
			if ( (!array_key_exists($id, $this->user)) && (!in_array($id, $users_to_query)) )
			{
				array_push($users_to_query, $id);
			}
		}

		if (count($users_to_query) == 0)
		{
			return;
		}

		// Grab all profile fields from users in id cache for later use - similar to the poster cache
		if ($config['download_custom_profile_enable'])
		{
			$profile_fields_cache = $cp->generate_profile_fields_template('grab', $users_to_query);
		}

		// Grab user status information
		$status_data = array();
		$sql = 'SELECT session_user_id, MAX(session_time) AS online_time, MIN(session_viewonline) AS viewonline
			FROM ' . SESSIONS_TABLE . '
				WHERE ' . $db->sql_in_set('session_user_id', $users_to_query) . '
					GROUP BY session_user_id';
		$result = $db->sql_query($sql);
		while($row = $db->sql_fetchrow($result))
		{
			$status_data[$row['session_user_id']] = $row;
		}
		$db->sql_freeresult($result);
		$update_time = $config['load_online_time'] * 60;

		// Get the rest of th data on the users and parse everything we need
		$sql = 'SELECT * FROM ' . USERS_TABLE . ' WHERE ' . $db->sql_in_set('user_id', $users_to_query);
		$result = $db->sql_query($sql);

		while ($row = $db->sql_fetchrow($result))
		{
			$this->user[$row['user_id']] = $row;

			// view profile link
			$this->user[$row['user_id']]['view_profile'] = append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=viewprofile&amp;u=" . $row['user_id']);
	
			// Full username, with colour
			$this->user[$row['user_id']]['username_full'] = get_username_string('full', $row['user_id'], $this->user[$row['user_id']]['username'], $this->user[$row['user_id']]['user_colour']);
	
			// format the color correctly
			$this->user[$row['user_id']]['user_colour'] = get_username_string('colour', $row['user_id'], $this->user[$row['user_id']]['username'], $this->user[$row['user_id']]['user_colour']);

			// Status
			$this->user[$row['user_id']]['status'] = (isset($status_data[$row['user_id']]) && time() - $update_time < $status_data[$row['user_id']]['online_time'] && (($status_data[$row['user_id']]['viewonline'] && $this->user[$row['user_id']]['user_allow_viewonline']) || $auth->acl_get('u_viewonline'))) ? true : false;
	
			// Avatar
			if ($this->user[$row['user_id']]['user_avatar_type'] == 3)
			{
				$this->user[$row['user_id']]['avatar'] = ($this->user[$row['user_id']]['user_avatar'] && $user->optionget('viewavatars')) ? '<img src="' . $phpbb_root_path . $config['avatar_gallery_path'] . '/' . $this->user[$row['user_id']]['user_avatar'] . '" width="' . $this->user[$row['user_id']]['user_avatar_width'] . '" height="' . $this->user[$row['user_id']]['user_avatar_height'] . '" alt="" />' : '';
			}
			else if ($this->user[$row['user_id']]['user_avatar_type'] == 2)
			{
				$this->user[$row['user_id']]['avatar'] = ($this->user[$row['user_id']]['user_avatar'] && $user->optionget('viewavatars')) ? '<img src="' . $this->user[$row['user_id']]['user_avatar'] . '" width="' . $this->user[$row['user_id']]['user_avatar_width'] . '" height="' . $this->user[$row['user_id']]['user_avatar_height'] . '" alt="" />' : '';
			}
			else
			{
				$this->user[$row['user_id']]['avatar'] = ($this->user[$row['user_id']]['user_avatar'] && $user->optionget('viewavatars')) ? '<img src="' . $phpbb_root_path . 'download.' . $phpEx . '?avatar=' . $this->user[$row['user_id']]['user_avatar'] . '" width="' . $this->user[$row['user_id']]['user_avatar_width'] . '" height="' . $this->user[$row['user_id']]['user_avatar_height'] . '" alt="" />' : '';
			}
	
			// Rank
			get_user_rank($this->user[$row['user_id']]['user_rank'], $this->user[$row['user_id']]['user_posts'], $this->user[$row['user_id']]['rank_title'], $this->user[$row['user_id']]['rank_img'], $this->user[$row['user_id']]['rank_img_src']);
	
			// IM Links
			$this->user[$row['user_id']]['msn_url'] = ($this->user[$row['user_id']]['user_msnm']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=msnm&amp;u=" . $this->user[$row['user_id']]['user_id']) : '';
			$this->user[$row['user_id']]['yim_url'] = ($this->user[$row['user_id']]['user_yim']) ? 'http://edit.yahoo.com/config/send_webmesg?.target=' . $this->user[$row['user_id']]['user_yim'] . '&amp;.src=pg' : '';
			$this->user[$row['user_id']]['aim_url'] = ($this->user[$row['user_id']]['user_aim']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=aim&amp;u=" . $this->user[$row['user_id']]['user_id']) : '';
			$this->user[$row['user_id']]['icq_url'] = ($this->user[$row['user_id']]['user_icq']) ? 'http://www.icq.com/people/webmsg.php?to=' . $this->user[$row['user_id']]['user_icq'] : '';
			$this->user[$row['user_id']]['jabber_url'] = ($this->user[$row['user_id']]['user_jabber']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=contact&amp;action=jabber&amp;u=" . $this->user[$row['user_id']]['user_id']) : '';
	
			// PM and email links
			$this->user[$row['user_id']]['pm_url'] = ($this->user[$row['user_id']]['user_id'] != ANONYMOUS && $config['allow_privmsg'] && $auth->acl_get('u_sendpm') && ($this->user[$row['user_id']]['user_allow_viewemail'] || $auth->acl_gets('a_', 'm_') || $auth->acl_getf_global('m_'))) ? append_sid("{$phpbb_root_path}ucp.$phpEx", 'i=pm&amp;mode=compose&amp;u=' . $this->user[$row['user_id']]['user_id']) : '';
			$this->user[$row['user_id']]['email_url'] = ($config['board_email_form'] && $config['email_enable']) ? append_sid("{$phpbb_root_path}memberlist.$phpEx", "mode=email&amp;u=" . $this->user[$row['user_id']]['user_id'])  : (($config['board_hide_emails'] && !$auth->acl_get('a_email')) ? '' : 'mailto:' . $this->user[$row['user_id']]['user_email']);

			// Signature
			if ($config['allow_sig'] && $user->optionget('viewsigs') && $row['user_sig'] != '')
			{
				$this->user[$row['user_id']]['user_sig'] = censor_text($this->user[$row['user_id']]['user_sig']);
				$this->user[$row['user_id']]['user_sig'] = str_replace("\n", '<br />', $this->user[$row['user_id']]['user_sig']);

				if ($this->user[$row['user_id']]['user_sig_bbcode_bitfield'])
				{
					$bbcode->bbcode_second_pass($this->user[$row['user_id']]['user_sig'], $this->user[$row['user_id']]['user_sig_bbcode_uid'], $this->user[$row['user_id']]['user_sig_bbcode_bitfield']);
				}

				$this->user[$row['user_id']]['user_sig'] = smiley_text($this->user[$row['user_id']]['user_sig']);
			}
			else
			{
				$this->user[$row['user_id']]['user_sig'] = '';
			}

			// get the custom profile fields if the admin wants them
			if ($config['download_custom_profile_enable'])
			{
				$this->user[$row['user_id']]['cp_row'] = (isset($profile_fields_cache[$row['user_id']])) ? $cp->generate_profile_fields_template('show', false, $profile_fields_cache[$row['user_id']]) : array();
			}
		}
		$db->sql_freeresult($result);

		// if we did use the queue, reset it
		if ($queue)
		{
			unset($this->queue);
			$this->queue = array();
		}
	}

	// prepares the user data for output to the template, and outputs the custom profile rows when requested
	// Mostly for shortenting up code
	function handle_user_data($user_id, $output_custom = false)
	{
		global $phpbb_root_path, $phpEx, $user, $auth, $config, $template;

		if ($output_custom === false)
		{
			$output_data = array(
				'USERNAME'			=> $this->user[$user_id]['username'],
				'USER_COLOUR'		=> $this->user[$user_id]['user_colour'],
				'USER_FULL'			=> $this->user[$user_id]['username_full'],
				'U_VIEW_PROFILE'	=> append_sid("{$phpbb_root_path}memberlist.$phpEx", 'mode=viewprofile&amp;u=' . $user_id),

				'SIGNATURE'			=> $this->user[$user_id]['user_sig'],

				'AVATAR'			=> $this->user[$user_id]['avatar'],

				'RANK_TITLE'		=> $this->user[$user_id]['rank_title'],
				'RANK_IMG'			=> $this->user[$user_id]['rank_img'],
				'RANK_IMG_SRC'		=> $this->user[$user_id]['rank_img_src'],

				'STATUS_IMG'		=> (($this->user[$user_id]['status']) ? $user->img('icon_user_online', 'ONLINE') : $user->img('icon_user_offline', 'OFFLINE')),
				'S_ONLINE'			=> $this->user[$user_id]['status'],

				'POSTER_POSTS'		=> $this->user[$user_id]['user_posts'],
				'POSTER_JOINED'		=> $user->format_date($this->user[$user_id]['user_regdate']),
				'POSTER_FROM'		=> $this->user[$user_id]['user_from'],

				'U_PM'				=> $this->user[$user_id]['pm_url'],
				'U_EMAIL'			=> $this->user[$user_id]['email_url'],
				'U_WWW'				=> $this->user[$user_id]['user_website'],
				'U_MSN'				=> $this->user[$user_id]['msn_url'],
				'U_YIM'				=> $this->user[$user_id]['yim_url'],
				'U_AIM'				=> $this->user[$user_id]['aim_url'],
				'U_ICQ'				=> $this->user[$user_id]['icq_url'],
				'U_JABBER'			=> $this->user[$user_id]['jabber_url'],

				'U_DELETED_LINK'	=> ($auth->acl_get('m_downloaddelete')) ? '<a href="' . append_sid("{$phpbb_root_path}downloads.$phpEx", "page=view&amp;mode=deleted&amp;u=" . $this->user[$user_id]['user_id']) . '">' . $user->lang['VIEW_DELETED_DOWNLOADS'] . '</a>' : '',

				'S_CUSTOM_FIELDS'	=> (isset($this->user[$user_id]['cp_row']['blockrow'])) ? true : false,
			);

			return ($output_data);
		}
		else if ($config['download_custom_profile_enable'])
		{	
			// output the custom profile fields
			if (isset($this->user[$user_id]['cp_row']['blockrow']))
			{
				foreach ($this->user[$user_id]['cp_row']['blockrow'] as $row)
				{
					$template->assign_block_vars($output_custom, array(
						'PROFILE_FIELD_NAME'	=> $row['PROFILE_FIELD_NAME'],
						'PROFILE_FIELD_VALUE'	=> $row['PROFILE_FIELD_VALUE'],
					));
				}
			}
		}
	}

	/*
	* -------------------------- OTHER SECTION -----------------------------
	*/

	/*
	* Updates the download and reply information to add edit and delete messages.
	* I have this seperate so I can grab the downloads, replies, users, then update the edit and delete data (to cut on SQL queries)
	*/
	function update_edit_delete($mode = 'all')
	{
		global $auth, $user, $phpbb_root_path, $phpEx;

		if (!isset($user->lang['EDITED_TIME_TOTAL']))
		{
			$user->add_lang('viewtopic');
		}

		if ($mode == 'all' || $mode == 'download')
		{
			foreach ($this->download as $row)
			{
				if (!$row['simple'] && (!isset($row['edited_message'])) && (!isset($row['deleted_message'])) )
				{
					// has the download been edited?
					if ($row['edit_count'] != 0)
					{	
						if ($row['edit_count'] == 1)
						{
							if ($auth->acl_get('u_viewprofile'))
							{
								$this->download[$row['download_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $this->user[$row['edit_user']]['username_full'], $user->format_date($row['edit_time']), $row['edit_count']);
							}
							else
							{
								if ($this->user[$row['edit_user']]['user_colour'] != '')
								{
									$this->download[$row['download_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], '<b style="color: ' . $this->user[$row['edit_user']]['user_colour'] . '">' . $this->user[$row['edit_user']]['username'] . '</b>', $user->format_date($row['edit_time']), $row['edit_count']);
								}
								else
								{
									$this->download[$row['download_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $this->user[$row['edit_user']]['username'], $user->format_date($row['edit_time']), $row['edit_count']);
								}
							}
						}
						else if ($row['edit_count'] > 1)
						{
							if ($auth->acl_get('u_viewprofile'))
							{
								$this->download[$row['download_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $this->user[$row['edit_user']]['username_full'], $user->format_date($row['edit_time']), $row['edit_count']);
							}
							else
							{
								if ($this->user[$row['edit_user']]['user_colour'] != '')
								{
									$this->download[$row['download_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], '<b style="color: ' . $this->user[$row['edit_user']]['user_colour'] . '">' . $this->user[$row['edit_user']]['username'] . '</b>', $user->format_date($row['edit_time']), $row['edit_count']);
								}
								else
								{
									$this->download[$row['download_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $this->user[$row['edit_user']]['username'], $user->format_date($row['edit_time']), $row['edit_count']);
								}
							}
						}
			
						$this->download[$row['download_id']]['edit_reason'] = censor_text($row['edit_reason']);
					}
					else
					{
						$this->download[$row['download_id']]['edited_message'] = '';
						$this->download[$row['download_id']]['edit_reason'] = '';
					}
		
					// has the download been deleted?
					if ($row['deleted'] != 0)
					{
						$this->download[$row['download_id']]['deleted_message'] = sprintf($user->lang['DOWNLOAD_IS_DELETED'], $this->user[$row['deleted']]['username_full'], $user->format_date($row['deleted_time']), '<a href="' . append_sid("{$phpbb_root_path}downloads.$phpEx", "page=download&amp;mode=undelete&amp;d=" . $row['download_id']) . '">', '</a>');
					}
					else
					{
						$this->download[$row['download_id']]['deleted_message'] = '';
					}
				}
			}
		}

		if ($mode == 'all' || $mode == 'reply')
		{
			foreach ($this->reply as $row)
			{
				if (!$row['simple'] && (!isset($row['edited_message'])) && (!isset($row['deleted_message'])) )
				{
					// has the reply been edited?
					if ($row['edit_count'] != 0)
					{	
						if ($row['edit_count'] == 1)
						{
							if ($auth->acl_get('u_viewprofile'))
							{
								$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $this->user[$row['edit_user']]['username_full'], $user->format_date($row['edit_time']), $row['edit_count']);
							}
							else
							{
								if ($this->user[$row['edit_user']]['user_colour'] != '')
								{
									$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], '<b style="color: ' . $this->user[$row['edit_user']]['user_colour'] . '">' . $this->user[$row['edit_user']]['username'] . '</b>', $user->format_date($row['edit_time']), $row['edit_count']);
								}
								else
								{
									$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIME_TOTAL'], $this->user[$row['edit_user']]['username'], $user->format_date($row['edit_time']), $row['edit_count']);
								}
							}
						}
						else if ($row['edit_count'] > 1)
						{
							if ($auth->acl_get('u_viewprofile'))
							{
								$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $this->user[$row['edit_user']]['username_full'], $user->format_date($row['edit_time']), $row['edit_count']);
							}
							else
							{
								if ($this->user[$row['edit_user']]['user_colour'] != '')
								{
									$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], '<b style="color: ' . $this->user[$row['edit_user']]['user_colour'] . '">' . $this->user[$row['edit_user']]['username'] . '</b>', $user->format_date($row['edit_time']), $row['edit_count']);
								}
								else
								{
									$this->reply[$row['reply_id']]['edited_message'] = sprintf($user->lang['EDITED_TIMES_TOTAL'], $this->user[$row['edit_user']]['username'], $user->format_date($row['edit_time']), $row['edit_count']);
								}
							}
						}
			
						$this->reply[$row['reply_id']]['edit_reason'] = censor_text($row['edit_reason']);
					}
					else
					{
						$this->reply[$row['reply_id']]['edited_message'] = '';
						$this->reply[$row['reply_id']]['edit_reason'] = '';
					}
		
					// has the reply been deleted?
					if ($row['deleted'] != 0)
					{
						$this->reply[$row['reply_id']]['deleted_message'] = sprintf($user->lang['REPLY_IS_DELETED'], $this->user[$row['deleted']]['username_full'], $user->format_date($row['deleted_time']), '<a href="' . append_sid("{$phpbb_root_path}downloads.$phpEx", "page=reply&amp;mode=undelete&amp;r=" . $row['reply_id']) . '">', '</a>');
					}
					else
					{
						$this->reply[$row['reply_id']]['deleted_message'] = '';
					}
				}
			}
		}
	}
}
?>