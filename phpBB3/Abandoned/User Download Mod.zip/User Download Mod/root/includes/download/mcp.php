<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// Check if they have the required permissions
if (!$auth->acl_gets('m_downloadapprove', 'acl_m_downloadreport'))
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}

// Add the language Variables for viewtopic
$user->add_lang('viewtopic');
$self_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=mcp');

generate_download_breadcrumbs(array($user->lang['USER_DOWNLOADS'] => append_sid("{$phpbb_root_path}downloads.$phpEx"), $user->lang['DOWNLOAD_MCP'] => $self_url));
page_header($user->lang['USER_DOWNLOADS']);
generate_categories_menu();

// Reported Downloads
$reported_download_ids = $download_data->get_download_data(array('reported' => true));

// Non-Approved downloads
$disapproved_download_ids = $download_data->get_download_data(array('disapproved' => true));

// Reported Replies
$reported_reply_ids = $download_data->get_reply_data(array('reported' => true));

// Non-Approved Replies
$disapproved_reply_ids = $download_data->get_reply_data(array('disapproved' => true));

$download_data->get_user_data(false, true);

// Output the reported downloads
if ($reported_download_ids !== false)
{
	foreach ($reported_download_ids as $id)
	{
		$user_row = $download_data->handle_user_data($download_data->download[$id]['user_id']);

		$download_row = array(
			'U_VIEW'		=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=view&amp;mode=download&amp;d=' . $id),
			'SUBJECT'		=> $download_data->download[$id]['name'],
			'DATE'			=> $user->format_date($download_data->download[$id]['time']),
	
			'TEXT'			=> $download_data->download[$id]['description'],
		);

		$template->assign_block_vars('download_reportedrow', $user_row + $download_row);
	}
}

// Output the non-approved downloads
if ($disapproved_download_ids !== false)
{
	foreach ($disapproved_download_ids as $id)
	{
		$user_row = $download_data->handle_user_data($download_data->download[$id]['user_id']);

		$download_row = array(
			'U_VIEW'		=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=view&amp;mode=download&amp;d=' . $id),
			'SUBJECT'		=> $download_data->download[$id]['name'],
			'DATE'			=> $user->format_date($download_data->download[$id]['time']),
	
			'TEXT'			=> $download_data->download[$id]['description'],
		);

		$template->assign_block_vars('download_disapprovedrow', $user_row + $download_row);
	}
}

// Output the reported replies
if ($reported_reply_ids !== false)
{
	foreach ($reported_reply_ids as $id)
	{
		$user_row = $download_data->handle_user_data($download_data->reply[$id]['user_id']);

		$reply_row = array(
			'U_VIEW'		=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=view&amp;mode=download&amp;d=' . $download_data->reply[$id]['download_id'] . '#' . $id),
			'SUBJECT'		=> $download_data->reply[$id]['subject'],
			'DATE'			=> $user->format_date($download_data->reply[$id]['time']),
	
			'TEXT'			=> $download_data->reply[$id]['text'],
		);

		$template->assign_block_vars('reply_reportedrow', $user_row + $reply_row);
	}
}

// Output the non-approved replies
if ($disapproved_reply_ids !== false)
{
	foreach ($disapproved_reply_ids as $id)
	{
		$user_row = $download_data->handle_user_data($download_data->reply[$id]['user_id']);

		$reply_row = array(
			'U_VIEW'		=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=view&amp;mode=download&amp;d=' . $download_data->reply[$id]['download_id'] . '#' . $id),
			'SUBJECT'		=> $download_data->reply[$id]['subject'],
			'DATE'			=> $user->format_date($download_data->reply[$id]['time']),
	
			'TEXT'			=> $download_data->reply[$id]['text'],
		);

		$template->assign_block_vars('reply_disapprovedrow', $user_row + $reply_row);
	}
}

// tell the template parser what template file to use
$template->set_filenames(array(
	'body' => 'mcp_download.html'
));
?>