<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

if ($category_id != 0 && !array_key_exists($category_id, $dl_cats))
{
	trigger_error('CATEGORY_NOT_EXIST');
}

// Add the language Variables for viewtopic
$user->add_lang('viewtopic');

// page variables
$random = ($mode == 'random') ? true : false;
$recent = ($mode == 'recent') ? true : false;
$popular = ($mode == 'popular') ? true : false;
$all = (!$random && !$recent && !$popular) ? true : false;
$deleted = ($category_id == -1) ? true : false;
$category = ($category_id > 0) ? true : false;

$sort_days	= request_var('st', ((!empty($user->data['user_post_show_days'])) ? $user->data['user_post_show_days'] : 0));
$sort_key	= request_var('sk', 'n');
$sort_dir	= request_var('sd', 'a');

$breadcrumbs[$user->lang['USER_DOWNLOADS']] = append_sid("{$phpbb_root_path}downloads.$phpEx");
if ($category_id != 0)
{
	$breadcrumbs[$dl_cats[$category_id]['category_name']] = append_sid("{$phpbb_root_path}downloads.$phpEx", "c=$category_id");
}
generate_download_breadcrumbs($breadcrumbs);
page_header($user->lang['USER_DOWNLOADS']);
generate_categories_menu();
build_code_lang_info_box();

$url_data = '&amp;c=' . $category_id . '&amp;start=' . $start . '&amp;limit=' . $limit;
$cat_template = false;

// output some data
$template->assign_vars(array(
	'S_TOPIC_ACTION'	=> append_sid("{$phpbb_root_path}downloads.$phpEx", $url_data),
	'DOWNLOAD_IMG'		=> $phpbb_root_path . 'styles/' . $user->theme['theme_path'] . '/theme/images/download.gif',

	'QUOTE_IMG'			=> $user->img('icon_post_quote', 'QUOTE'),
	'EDIT_IMG'			=> $user->img('icon_post_edit', 'EDIT_POST'),
	'DELETE_IMG'		=> $user->img('icon_post_delete', 'DELETE_POST'),
	'REPORT_IMG'		=> $user->img('icon_post_report', 'REPORT_POST'),
	'WARN_IMG'			=> $user->img('icon_user_warn', 'WARN_USER'),
	'UNAPPROVED_IMG'	=> $user->img('icon_topic_unapproved', 'POST_UNAPPROVED'),
	'REPORTED_IMG'		=> $user->img('icon_topic_reported', 'POST_REPORTED'),
	'MINI_POST_IMG'		=> $user->img('icon_post_target', 'POST'),

	'PROFILE_IMG'		=> $user->img('icon_user_profile', 'READ_PROFILE'),
	'PM_IMG'			=> $user->img('icon_contact_pm', 'SEND_PRIVATE_MESSAGE'),
	'EMAIL_IMG'			=> $user->img('icon_contact_email', 'SEND_EMAIL'),
	'WWW_IMG'			=> $user->img('icon_contact_www', 'VISIT_WEBSITE'),
	'MSN_IMG'			=> $user->img('icon_contact_msnm', 'MSNM'),
	'YIM_IMG'			=> $user->img('icon_contact_yahoo', 'YIM'),
	'AIM_IMG'			=> $user->img('icon_contact_aim', 'AIM'),
	'ICQ_IMG'			=> $user->img('icon_contact_icq', 'ICQ'),
	'JABBER_IMG'		=> $user->img('icon_contact_jabber', 'JABBER'),
));

// Output the random downloads
if (!$deleted && !$category && ($random || $all))
{
	$template->assign_block_vars('column', array(
		'SECTION_WIDTH'		=> ($all) ? '28' : '84',
		'U_VIEW'			=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'mode=random' . $url_data),
		'TITLE'				=> $user->lang['RANDOM_DOWNLOADS'],
	));

	$random_download_ids = $download_data->get_download_data(array('random' => true, 'category_id' => $category_id, 'limit' => $limit));

	if ($random_download_ids !== false)
	{
		foreach ($random_download_ids as $id)
		{
			$user_row = $download_data->handle_user_data($download_data->download[$id]['user_id']);

			$download_row = $download_data->handle_download_data($id, '', 'random');
		
			$template->assign_block_vars('column.row', $user_row + $download_row);
		}
	}
}

// Output the recent downloads
if (!$deleted && !$category && ($recent || $all))
{
	$template->assign_block_vars('column', array(
		'SECTION_WIDTH'		=> ($all) ? '28' : '84',
		'U_VIEW'			=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'mode=recent' . $url_data),
		'TITLE'				=> $user->lang['RECENT_DOWNLOADS'],
	));

	$recent_download_ids = $download_data->get_download_data(array('recent' => true, 'category_id' => $category_id, 'limit' => $limit));

	if ($recent_download_ids !== false)
	{
		foreach ($recent_download_ids as $id)
		{
			$user_row = $download_data->handle_user_data($download_data->download[$id]['user_id']);

			$download_row = $download_data->handle_download_data($id, '', 'recent');

			$template->assign_block_vars('column.row', $user_row + $download_row);
		}
	}
}

// Output the popular downloads
if (!$deleted && !$category && ($popular || $all))
{
	$template->assign_block_vars('column', array(
		'SECTION_WIDTH'		=> ($all) ? '28' : '84',
		'U_VIEW'			=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'mode=popular' . $url_data),
		'TITLE'				=> $user->lang['POPULAR_DOWNLOADS'],
	));

	$popular_download_ids = $download_data->get_download_data(array('popular' => true, 'category_id' => $category_id, 'limit' => $limit));

	if ($popular_download_ids !== false)
	{
		foreach ($popular_download_ids as $id)
		{
			$user_row = $download_data->handle_user_data($download_data->download[$id]['user_id']);

			$download_row = $download_data->handle_download_data($id, '', 'popular');

			$template->assign_block_vars('column.row', $user_row + $download_row);
		}
	}
}

// output the category
if ($category_id != 0)
{
	// for sorting and pagination
	$limit_days = array(0 => $user->lang['ALL_POSTS'], 1 => $user->lang['1_DAY'], 7 => $user->lang['7_DAYS'], 14 => $user->lang['2_WEEKS'], 30 => $user->lang['1_MONTH'], 90 => $user->lang['3_MONTHS'], 180 => $user->lang['6_MONTHS'], 365 => $user->lang['1_YEAR']);

	$sort_by_text = array('t' => $user->lang['POST_TIME'], 'n' => $user->lang['DOWNLOAD_NAME'], 'a' => $user->lang['AUTHOR'], 'd' => $user->lang['NUMBER_DOWNLOADS'], 'r' => $user->lang['DOWNLOAD_RATING'], 'c' => $user->lang['PROGRAM_COST']);
	$sort_by_sql = array('t' => 'time', 'n' => 'name', 'a' => 'author', 'd' => 'downloads', 'r' => 'rating', 'c' => 'cost');

	$s_limit_days = $s_sort_key = $s_sort_dir = $u_sort_param = '';
	gen_sort_selects($limit_days, $sort_by_text, $sort_days, $sort_key, $sort_dir, $s_limit_days, $s_sort_key, $s_sort_dir, $u_sort_param);

	$custom_sql = '';
	if ($sort_days)
	{
		$min_post_time = time() - ($sort_days * 86400);

		$sql = 'SELECT COUNT(download_id) AS num_posts
			FROM ' . DOWNLOADS_TABLE . "
			WHERE category_id = $category_id
				AND time >= $min_post_time
			" . (($auth->acl_get('m_downloadapprove')) ? '' : 'AND approved = 1') . 
			( ( ($auth->acl_get('m_downloaddelete')) || ($auth->acl_get('a_downloaddelete')) ) ? '' : 'AND deleted = 0');
		$result = $db->sql_query($sql);
		$total_posts = (int) $db->sql_fetchfield('num_posts');
		$db->sql_freeresult($result);

		$custom_sql .= "AND time >= $min_post_time ";

		if (isset($_POST['sort']))
		{
			$start = 0;
		}
	}
	else
	{
		if ($auth->acl_get('m_downloadapprove') && $auth->acl_gets('m_downloaddelete', 'a_downloadreplydelete'))
		{
			$sql = 'SELECT count(download_id) AS total FROM ' . DOWNLOADS_TABLE . ' WHERE approved = \'1\' AND category_id = \'' . $category_id . '\'';
			$result = $db->sql_query($sql);
			$total = $db->sql_fetchrow($result);
			$total_posts = $total['total'];		}
		else if ($auth->acl_get('m_downloadapprove'))
		{
			$sql = 'SELECT count(download_id) AS total FROM ' . DOWNLOADS_TABLE . ' WHERE deleted = \'0\' AND category_id = \'' . $category_id . '\'';
			$result = $db->sql_query($sql);
			$total = $db->sql_fetchrow($result);
			$total_posts = $total['total'];
		}
		else if ($auth->acl_gets('m_downloaddelete', 'a_downloaddelete'))
		{
			$sql = 'SELECT count(download_id) AS total FROM ' . DOWNLOADS_TABLE . ' WHERE approved = \'1\' AND category_id = \'' . $category_id . '\'';
			$result = $db->sql_query($sql);
			$total = $db->sql_fetchrow($result);
			$total_posts = $total['total'];
		}
		else
		{
			$total_posts = $dl_cats[$category_id]['downloads'];
		}
		$limit_posts_time = '';
	}

	if ($sort_key == 'd')
	{
		$show_popular = true;
	}
	else
	{
		$show_popular = false;
	}
	$order_dir = ($sort_dir == 'a') ? 'ASC' : 'DESC';

	$pagination = generate_pagination(append_sid("{$phpbb_root_path}downloads.$phpEx", $url_data), $total_posts, $limit, $start, false);

	$template->assign_vars(array(
		'PAGINATION'			=> $pagination,
		'PAGE_NUMBER' 			=> on_page($total_posts, $limit, $start),
		'TOTAL_POSTS'			=> ($total_posts == 1) ? $user->lang['DOWNLOAD_COUNT'] : sprintf($user->lang['DOWNLOADS_COUNT'], $total_posts),
		'S_SORT'				=> true,
		'S_SELECT_SORT_DIR' 	=> $s_sort_dir,
		'S_SELECT_SORT_KEY' 	=> $s_sort_key,
		'S_SELECT_SORT_DAYS' 	=> $s_limit_days,
	));

	$template->assign_block_vars('column', array(
		'SECTION_WIDTH'		=> '84',
		'U_VIEW'			=> append_sid("{$phpbb_root_path}downloads.$phpEx", $url_data),
		'TITLE'				=> $dl_cats[$category_id]['category_name'],
	));

	if ($show_popular)
	{
		$download_ids = $download_data->get_download_data(array('popular' => true, 'deleted' => $deleted, 'category_id' => $category_id, 'start' => $start, 'limit' => $limit, 'custom_sql' => $custom_sql, 'order_dir' => $order_dir));
	}
	else
	{
		$download_ids = $download_data->get_download_data(array('deleted' => $deleted, 'category_id' => $category_id, 'start' => $start, 'limit' => $limit, 'custom_sql' => $custom_sql, 'order_by' => $sort_by_sql[$sort_key], 'order_dir' => $order_dir));
	}

	if ($download_ids !== false)
	{
		foreach ($download_ids as $id)
		{
			$user_row = $download_data->handle_user_data($download_data->download[$id]['user_id']);

			$category_row = $download_data->handle_download_data($id);

			$template->assign_block_vars('column.row', $user_row + $category_row);
		}
	}

	$cat_template = true;
}

if ($cat_template)
{
	$template->set_filenames(array(
		'body' => 'view_download_cat.html'
	));
}
else
{
	$template->set_filenames(array(
		'body' => 'view_download_main.html'
	));
}
?>