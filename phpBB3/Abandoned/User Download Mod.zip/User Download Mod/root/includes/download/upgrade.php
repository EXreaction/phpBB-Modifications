<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// only founders are allowed here
if ($user->data['user_type'] != USER_FOUNDER)
{
	trigger_error('You must be a founder to access this page.');
}

// url to the main page and update page
$main_download_url = append_sid("{$phpbb_root_path}downloads.$phpEx");

// Was Cancel pressed? If so then redirect to the appropriate page
if ($cancel)
{
	redirect($main_download_url);
}

trigger_error('The upgrade page (used to upgrade from other download modifications) is not started yet.');
?>