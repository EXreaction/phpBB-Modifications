<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}


// Was Cancel pressed? If so then redirect to the appropriate page
if ($cancel)
{
	redirect($view_download_main);
}
	
// check permissions
if ($user->data['user_type'] != 3)
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}

$self_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=resync');

// Setup the page header and sent the title of the page that will go into the browser header
page_header($user->lang['RESYNC_DOWNLOAD']);

// Generate the breadcrumbs
$breadcrumbs = array(
	$user->lang['USER_DOWNLOADS']			=> $view_download_main,
	$user->lang['RESYNC_DOWNLOAD']			=> $self_url,
	);
generate_download_breadcrumbs($breadcrumbs);

if (confirm_box(true))
{
	$dl_data = array();
	$reply_data = array();

	// Start by selecting all download data that we will use
	$sql = 'SELECT download_id, reply_count, real_reply_count FROM ' . DOWNLOADS_TABLE . ' ORDER BY download_id ASC';
	$result = $db->sql_query($sql);
	while($row = $db->sql_fetchrow($result))
	{
		$dl_data[$row['download_id']] = $row;
	}
	$db->sql_freeresult($result);

	/*
	* Update & Resync the reply counts
	*/
	foreach($dl_data as $row)
	{
		// count all the replies (an SQL query seems the easiest way to do it)
		$sql = 'SELECT count(reply_id) AS total 
			FROM ' . DOWNLOADS_REPLY_TABLE . ' 
				WHERE download_id = \'' . $row['download_id'] . '\' 
					AND deleted = \'0\' 
					AND approved = \'1\'';
		$result = $db->sql_query($sql);
		$total = $db->sql_fetchrow($result);
		$db->sql_freeresult($result);

		if ($total['total'] != $row['reply_count'])
		{
			// Update the reply count
			$sql = 'UPDATE ' . DOWNLOADS_TABLE . ' SET reply_count = \'' . $total['total'] . '\' WHERE download_id = \'' . $row['download_id'] . '\'';
			$db->sql_query($sql);
		}
	}

	/*
	* Update & Resync the real reply counts
	*/
	foreach($dl_data as $row)
	{
		// count all the replies (an SQL query seems the easiest way to do it)
		$sql = 'SELECT count(reply_id) AS total 
			FROM ' . DOWNLOADS_REPLY_TABLE . ' 
				WHERE download_id = \'' . $row['download_id'] . '\'';
		$result = $db->sql_query($sql);
		$total = $db->sql_fetchrow($result);
		$db->sql_freeresult($result);

		if ($total['total'] != $row['real_reply_count'])
		{
			// Update the reply count
			$sql = 'UPDATE ' . DOWNLOADS_TABLE . ' SET real_reply_count = \'' . $total['total'] . '\' WHERE download_id = \'' . $row['download_id'] . '\'';
			$db->sql_query($sql);
		}
	}

	/*
	* Delete's all oprhaned replies (replies where the downloads they should go under have been deleted).
	*/
	// Now get all reply data we will use
	$sql = 'SELECT reply_id, download_id FROM ' . DOWNLOADS_REPLY_TABLE . ' ORDER BY reply_id ASC';
	$result = $db->sql_query($sql);
	while($row = $db->sql_fetchrow($result))
	{
		// if the download_id it attached to is not in $dl_data
		if (!(array_key_exists($row['download_id'], $dl_data)))
		{
			$sql2 = 'DELETE FROM ' . DOWNLOADS_REPLY_TABLE . ' WHERE reply_id = \'' . $row['reply_id'] . '\'';
			$db->sql_query($sql2);
		}
	}
	$db->sql_freeresult($result);

	/*
	* Updates the download_count for each user
	*/
	// select the users data we will need
	$sql = 'SELECT user_id, download_count FROM ' . USERS_TABLE;
	$result = $db->sql_query($sql);
	while($row = $db->sql_fetchrow($result))
	{
		// count all the replies (an SQL query seems the easiest way to do it)
		$sql2 = 'SELECT count(download_id) AS total 
			FROM ' . DOWNLOADS_TABLE . ' 
				WHERE user_id = \'' . $row['user_id'] . '\' 
					AND deleted = \'0\' 
					AND approved = \'1\'';
		$result2 = $db->sql_query($sql2);
		$total = $db->sql_fetchrow($result2);
		$db->sql_freeresult($result2);

		if ($total['total'] != $row['download_count'])
		{
			// Update the reply count
			$sql = 'UPDATE ' . USERS_TABLE . ' SET download_count = \'' . $total['total'] . '\' WHERE user_id = \'' . $row['user_id'] . '\'';
			$db->sql_query($sql);
		}
	}
	$db->sql_freeresult($result);

	/*
	* Updates the download_count for each category
	*/
	if ($dl_cats !== false)
	{
		foreach($dl_cats as $id => $val)
		{
			$sql = 'SELECT count(download_id) AS total 
				FROM ' . DOWNLOADS_TABLE . ' 
					WHERE category_id = \'' . $id . '\' 
						AND deleted = \'0\' 
						AND approved = \'1\'';
			$result = $db->sql_query($sql);
			$total = $db->sql_fetchrow($result);
			$db->sql_freeresult($result);

			if ($total['total'] != $val['downloads'])
			{
				// Update the reply count
				$sql = 'UPDATE ' . DOWNLOADS_CATEGORIES_TABLE . ' SET downloads = \'' . $total['total'] . '\' WHERE category_id = \'' . $id . '\'';
				$db->sql_query($sql);
			}
		}
		$db->sql_freeresult($result);
	}

	meta_refresh(3, $view_download_main);

	$message = $user->lang['RESYNC_DOWNLOAD_SUCESS'];

	$message .= '<br/><br/>' . sprintf($user->lang['RETURN_DOWNLOAD_MAIN'], '<a href="' . $view_download_main . '">', '</a>');

	trigger_error($message);
}
else
{
	confirm_box(false, 'RESYNC_DOWNLOAD');
}

// they pressed No, so redirect them
redirect($view_download_main);
?>