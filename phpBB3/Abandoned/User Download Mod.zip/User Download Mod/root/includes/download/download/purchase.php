<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

// If they did not include the $download_id give them an error...
if ($download_id == 0)
{
	trigger_error('NO_DOWNLOAD');
}

// Was Cancel pressed? If so then redirect to the appropriate page
if ($cancel)
{
	$redirect = append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $download_id);
	redirect($redirect);
}

// Get the download's data, and check if there is no download...
if ($download_data->get_download_data(array('download_id' => $download_id, 'simple' => true)) === false)
{
	trigger_error('NO_DOWNLOAD');
}

$mod_add = request_var('mod_add', false);
$mod_remove = request_var('mod_remove', false);

// check permissions
if ( ($user->data['user_id'] == 1 || $user->data['is_bot']) || (($mod_add || $mod_remove) && !$auth->acl_get('m_addpurchasedownload')) )
{
	if (!$user->data['is_registered'])
	{
		login_box();
	}
	else
	{
		trigger_error('NO_AUTH_OPERATION');
	}
}

if ($mod_add || $mod_remove)
{
	if ($mod_add)
	{
		$self_url = append_sid("{$phpbb_root_path}downloads.$phpEx", "page=download&amp;mode=purchase&amp;d={$download_id}&amp;u={$user_id}&amp;mod_add=true");
	}
	else
	{
		$self_url = append_sid("{$phpbb_root_path}downloads.$phpEx", "page=download&amp;mode=purchase&amp;d={$download_id}&amp;u={$user_id}&amp;mod_remove=true");
	}

	if ($submit)
	{
		redirect($self_url);
	}
}
else
{
	$self_url = append_sid("{$phpbb_root_path}downloads.$phpEx", "page=download&amp;mode=purchase&amp;d={$download_id}");
}
$view_download_url = append_sid("{$phpbb_root_path}downloads.$phpEx", 'd=' . $download_id);

// Setup the page header and sent the title of the page that will go into the browser header
page_header($user->lang['PURCHASE_DOWNLOAD']);

// Generate the breadcrumbs
$breadcrumbs = array(
	$user->lang['USER_DOWNLOADS']					=> $view_download_main,
	$download_data->download[$download_id]['name']	=> $view_download_url,
	$user->lang['PURCHASE_DOWNLOAD']				=> $self_url,
	);
generate_download_breadcrumbs($breadcrumbs);

if ($download_data->download[$download_id]['cost'] <= 0)
{
	trigger_error('DOWNLOAD_FREE');
}
else if (!$mod_remove && !$mod_add && (in_array($download_id, $purchased_data) ) )
{
	trigger_error('DOWNLOAD_ALREADY_PURCHASED');
}
else if (!$mod_remove && !$mod_add && $user->data['user_id'] == $download_data->download[$download_id]['user_id'])
{
	trigger_error('DOWNLOAD_NOT_NEED_PURCHASE_SUBMITTER');
}

if (confirm_box(true))
{
	if (!$mod_remove)
	{
		if (!$mod_add)
		{
			// make sure they have enough points
			$sql = 'SELECT cash_amt FROM ' . CASH_AMT_TABLE . ' WHERE user_id = \'' . $user->data['user_id'] . '\'';
			$result = $db->sql_query($sql);
			$amount = $db->sql_fetchrow($result);

			if ($amount['cash_amt'] < $download_data->download[$download_id]['cost'])
			{
				trigger_error('NOT_ENOUGH_POINTS');
			}

			// charge them
			$sql = 'UPDATE ' . CASH_AMT_TABLE . ' SET cash_amt = cash_amt - ' . $download_data->download[$download_id]['cost'] . ' WHERE user_id = \'' . $user->data['user_id'] . '\'';
			$db->sql_query($sql);

			// pay the submitter if it is set to
			if ($config['percent_cost_given_submitter'] > 0)
			{
				$sql = 'UPDATE ' . CASH_AMT_TABLE . ' SET cash_amt = cash_amt + ' . ($download_data->download[$download_id]['cost'] * $config['percent_cost_given_submitter'] / 100) . ' WHERE user_id = \'' . $download_data->download[$download_id]['user_id'] . '\'';
				$db->sql_query($sql);
			}
		}

		// insert into the purchases table
		$sql_data = array(
			'download_id'	=> $download_id,
			'user_id'		=> (!$mod_add) ? $user->data['user_id'] : $user_id,
		);

		$sql = 'INSERT INTO ' . DOWNLOADS_PURCHASES_TABLE . ' ' . $db->sql_build_array('INSERT', $sql_data);
		$db->sql_query($sql);

		// Update download count
		$sql = 'UPDATE ' . DOWNLOADS_TABLE . ' 
			SET download_count = download_count + 1 
			WHERE download_id = ' . $download_id;
		$db->sql_query($sql);

		$message = $user->lang['DOWNLOAD_PURCHASED'];
	}
	else
	{
		if ($user_id == 0)
		{
			tigger_error('USER_NOT_EXIST');
		}

		$sql = 'DELETE FROM ' . DOWNLOADS_PURCHASES_TABLE . ' WHERE download_id = \'' . $download_id . '\' AND user_id = \'' . $user_id . '\'';
		$db->sql_query($sql);

		$message = $user->lang['PURCHASE_REMOVED'];
	}

	meta_refresh(3, $view_download_url);

	$message .= '<br/><br/><a href="' . $view_download_url. '">' . $user->lang['VIEW_DOWNLOAD'] . '</a>';

	$message .= '<br/><br/>' . sprintf($user->lang['RETURN_DOWNLOAD_MAIN'], '<a href="' . $view_download_main . '">', '</a>');

	trigger_error($message);
}
else
{
	if (!$mod_remove)
	{
		confirm_box(false, 'PURCHASE_DOWNLOAD');
	}
	else
	{
		confirm_box(false, 'REMOVE_PURCHASE');
	}
}

// they pressed No, so redirect them
redirect($view_user_url);
?>