<?php
/** 
*
* @package phpBB3 User Download
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

// Stuff required to work with phpBB3, and include some function pages that we will use later on...
define('IN_PHPBB', true);
$phpbb_root_path = './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include($phpbb_root_path . 'includes/bbcode.' . $phpEx);
include($phpbb_root_path . 'includes/functions_display.' . $phpEx);
include($phpbb_root_path . 'includes/functions_posting.' . $phpEx);
include($phpbb_root_path . 'includes/message_parser.' . $phpEx);
include($phpbb_root_path . 'includes/functions_profile_fields.' . $phpEx);

include($phpbb_root_path . 'includes/download/functions.' . $phpEx);
include($phpbb_root_path . 'includes/download/download_data.' . $phpEx);
include($phpbb_root_path . 'includes/download/post_options.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('download', 1);

if (!$user->data['is_registered'])
{
	//login_box('', 'You must be logged in to view this page');
}

// get some initial data
$page = request_var('page', '');
$mode = request_var('mode', '');
$category_id = intval(request_var('c', 0));
$download_id = intval(request_var('d', 0));
$user_id = intval(request_var('u', 0));
$reply_id = intval(request_var('r', 0));
$limit = (($page != 'log') ? intval(request_var('limit', 10)) : intval(request_var('limit', 50)));
$start = intval(request_var('start', 0));

$submit = (isset($_POST['post'])) ? true : false;
$preview = (isset($_POST['preview'])) ? true : false;
$cancel = (isset($_POST['cancel'])) ? true : false;

// set some initial variables that we will (almost) always use
$download_data = array();
$breadcrumbs = array();
$error = array();

// setup our data classes
$download_data = new download_data();
$bbcode = new bbcode();
$cp = new custom_profile();

// Let us get all of the categories and code lang options now, they will almost always be used anyways
$dl_cats = get_dl_cats();
$code_lang = generate_code_lang(false);

$purchased_data = array();
if ($user->data['user_id'] != 1 && !$user->data['is_bot'])
{
	$sql = 'SELECT DISTINCT download_id FROM ' . DOWNLOADS_PURCHASES_TABLE . '
		WHERE user_id = \'' . $user->data['user_id'] . '\'';
	$result = $db->sql_query($sql);

	while ($row = $db->sql_fetchrow($result))
	{
		array_push($purchased_data, $row['download_id']);
	}
	$db->sql_freeresult($result);
}

$view_download_main = append_sid("{$phpbb_root_path}downloads.$phpEx");

if ($page == 'view' && ($mode == 'download' || $mode == 'category') && $limit == -1)
{
	$limit = 5;
}
else if ($limit == -1)
{
	$limit = 10;
}

switch ($page)
{
	case 'search' :
		include($phpbb_root_path . 'includes/download/search.' . $phpEx);
		break;
	case 'log' :
		include($phpbb_root_path . 'includes/download/purchase_log.' . $phpEx);
		break;
	case 'purchases' :
		include($phpbb_root_path . 'includes/download/purchases.' . $phpEx);
		break;
	case 'rate' :
		include($phpbb_root_path . 'includes/download/rate.' . $phpEx);
		include($phpbb_root_path . 'includes/download/view.' . $phpEx);
		break;
	case 'download' :
		switch ($mode)
		{
			case 'add' :
			case 'edit' :
			case 'delete' :
			case 'undelete' :
			case 'report' :
			case 'approve' :
			case 'purchase' :
			case 'download' :
			case 'resync' :
				include($phpbb_root_path . "includes/download/download/{$mode}.$phpEx");
				break;
			default :
				include($phpbb_root_path . 'includes/download/main.' . $phpEx);
		}
		break;
	case 'reply' :
		switch ($mode)
		{
			case 'add' :
			case 'edit' :
			case 'delete' :
			case 'undelete' :
			case 'report' :
			case 'approve' :
				include($phpbb_root_path . "includes/download/reply/{$mode}.$phpEx");
				break;
			case 'quote' :
				include($phpbb_root_path . "includes/download/reply/add.$phpEx");
				break;
			default :
				include($phpbb_root_path . 'includes/download/main.' . $phpEx);
		}
		break;
	case 'mcp' : // moderator control panel
		include($phpbb_root_path . 'includes/download/mcp.' . $phpEx);
		break;
	default :
		if ($download_id != 0)
		{
			include($phpbb_root_path . 'includes/download/view.' . $phpEx);
		}
		else
		{
			include($phpbb_root_path . 'includes/download/main.' . $phpEx);
		}
}

$user->add_lang('search');

// Add some data to the template
$template->assign_vars(array(
	'PAGE'					=> $page,
	'MODE'					=> $mode,

	'UA_GREY_STAR_SRC'		=> $phpbb_root_path . 'styles/' . $user->theme['imageset_path'] . '/imageset/download_mod/star.gif',
	'UA_GREEN_STAR_SRC'		=> $phpbb_root_path . 'styles/' . $user->theme['imageset_path'] . '/imageset/download_mod/star_p.gif',
	'UA_RED_STAR_SRC'		=> $phpbb_root_path . 'styles/' . $user->theme['imageset_path'] . '/imageset/download_mod/star_r.gif',
	'UA_ORANGE_STAR_SRC'	=> $phpbb_root_path . 'styles/' . $user->theme['imageset_path'] . '/imageset/download_mod/star_yes.gif',

	'U_DOWNLOAD_SEARCH'		=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=search'),
	'U_DOWNLOAD_MCP'		=> ($auth->acl_gets('m_downloadapprove', 'm_downloadreport')) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=mcp') : '',
	'U_VIEW_PURCHASE_LOG'	=> ($user->data['user_type'] == 3) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=log'): '',
	'U_ADD_DOWNLOAD'		=> ($auth->acl_get('u_downloadpost')) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=download&amp;mode=add&amp;c=' . $category_id) : '',
	'U_VIEW_PURCHASES'		=> ($user->data['user_id'] != 1 && !$user->data['is_bot']) ? append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=purchases') : '',
));

// setup the page footer
page_footer();

?>