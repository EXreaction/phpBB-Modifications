<?php
/**
 *
 * @package phpBB3 User Download Search
 * @copyright (c) 2007 EXreaction, Lithium Studios
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License 
 *
 */

// If the file that requested this does not have IN_PHPBB defined or the user requested this page directly exit.
if (!defined('IN_PHPBB'))
{
	exit;
}

$breadcrumbs = array(
	$user->lang['USER_DOWNLOADS']	=> $view_download_main,
	$user->lang['SEARCH']			=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=search'),
);
generate_download_breadcrumbs($breadcrumbs);
page_header($user->lang['SEARCH']);
generate_categories_menu();

$user->add_lang('search');

// Is user able to search? Has search been disabled?
if (!$auth->acl_get('u_search') || !$auth->acl_getf_global('f_search') || !$config['load_search'])
{
	$template->assign_var('S_NO_SEARCH', true);
	trigger_error('NO_SEARCH');
}

// Check search load limit
if ($user->load && $config['limit_search_load'] && ($user->load > doubleval($config['limit_search_load'])))
{
	$template->assign_var('S_NO_SEARCH', true);
	trigger_error('NO_SEARCH_TIME');
}

$keywords = request_var('keywords', '', true);
$author = request_var('author', '', true);

if ($keywords || $author)
{
	$highlight_match = $highlight = '';
	$highlight_words = $keywords;
	foreach (explode(' ', trim($highlight_words)) as $word)
	{
		if (trim($word))
		{
			$highlight_match .= (($highlight_match != '') ? '|' : '') . str_replace('*', '\w*?', preg_quote($word, '#'));
		}
	}
	$highlight = urlencode($highlight_words);

	$template->assign_block_vars('column', array(
		'SECTION_WIDTH'		=> '84',
		'U_VIEW'			=> '',
		'TITLE'				=> $user->lang['SEARCH'],
	));

	$ids = array();
	$i = 0;
	if ($author)
	{
		$sql = 'SELECT download_id FROM ' . DOWNLOADS_TABLE . ' WHERE author = \'' . $db->sql_escape($author) . '\'';
		$result = $db->sql_query($sql);
		while ($row = $db->sql_fetchrow($result))
		{
			$ids[] = $row['download_id'];
		}

		if (count($ids))
		{
			$ids = $download_data->get_download_data(array('download_id' => $ids));
			foreach ($ids as $id)
			{
				if ($i < $start)
				{
					$i++;
					continue;
				}
				else if ($i >= ($start + $limit))
				{
					break;
				}

				$user_row = $download_data->handle_user_data($download_data->download[$id]['user_id']);

				$download_row = $download_data->handle_download_data($id, '', 'search');

				$template->assign_block_vars('column.row', $user_row + $download_row);

				$i++;
			}
		}
	}
	else
	{	
		$keyword_list = explode(' ', $keywords);

		if (count($keyword_list))
		{
			$sql = '';
			foreach ($keyword_list as $word)
			{
				$sql .= ' OR name LIKE \'%' . $db->sql_escape($word) . '%\'';
			}

			$sql = 'SELECT download_id FROM ' . DOWNLOADS_TABLE . ' WHERE (' . substr($sql, 4) . ')';
			$result = $db->sql_query($sql);
			while ($row = $db->sql_fetchrow($result))
			{
				$ids[] = $row['download_id'];
			}

			if (count($ids))
			{
				$ids = $download_data->get_download_data(array('download_id' => $ids));
				foreach ($ids as $id)
				{
					if ($i < $start)
					{
						$i++;
						continue;
					}
					else if ($i >= ($start + $limit))
					{
						break;
					}

					$user_row = $download_data->handle_user_data($download_data->download[$id]['user_id']);

					$download_row = $download_data->handle_download_data($id, '', 'search');

					$template->assign_block_vars('column.row', $user_row + $download_row);

					$i++;
				}
			}
		}
	}

	$matches = count($ids);
	$pagination = generate_pagination(append_sid("{$phpbb_root_path}downloads.$phpEx", "page=search&amp;author={$author}&amp;keywords={$keywords}&amp;limit=$limit"), $matches, $limit, $start, false);

	$template->assign_vars(array(
		'PAGINATION'		=> $pagination,
		'PAGE_NUMBER' 		=> on_page($matches, $limit, $start),
		'TOTAL_POSTS'		=> ($matches == 1) ? $user->lang['DOWNLOAD_COUNT'] : sprintf($user->lang['DOWNLOADS_COUNT'], $matches),
		'SEARCH_MATCHES'	=> ($matches == 1) ? sprintf($user->lang['FOUND_SEARCH_MATCH'], $matches) : sprintf($user->lang['FOUND_SEARCH_MATCHES'], $matches),
		'U_SEARCH_WORDS'	=> append_sid("{$phpbb_root_path}downloads.$phpEx", "page=search&amp;author={$author}&amp;keywords={$keywords}"),
		'SEARCH_WORDS'		=> (($author) ? $author : $keywords),

		'DOWNLOAD_IMG'		=> $phpbb_root_path . 'styles/' . $user->theme['theme_path'] . '/theme/images/download.gif',

		'QUOTE_IMG'			=> $user->img('icon_post_quote', 'QUOTE'),
		'EDIT_IMG'			=> $user->img('icon_post_edit', 'EDIT_POST'),
		'DELETE_IMG'		=> $user->img('icon_post_delete', 'DELETE_POST'),
		'REPORT_IMG'		=> $user->img('icon_post_report', 'REPORT_POST'),
		'WARN_IMG'			=> $user->img('icon_user_warn', 'WARN_USER'),
		'UNAPPROVED_IMG'	=> $user->img('icon_topic_unapproved', 'POST_UNAPPROVED'),
		'REPORTED_IMG'		=> $user->img('icon_topic_reported', 'POST_REPORTED'),
		'MINI_POST_IMG'		=> $user->img('icon_post_target', 'POST'),

		'PROFILE_IMG'		=> $user->img('icon_user_profile', 'READ_PROFILE'),
		'PM_IMG'			=> $user->img('icon_contact_pm', 'SEND_PRIVATE_MESSAGE'),
		'EMAIL_IMG'			=> $user->img('icon_contact_email', 'SEND_EMAIL'),
		'WWW_IMG'			=> $user->img('icon_contact_www', 'VISIT_WEBSITE'),
		'MSN_IMG'			=> $user->img('icon_contact_msnm', 'MSNM'),
		'YIM_IMG'			=> $user->img('icon_contact_yahoo', 'YIM'),
		'AIM_IMG'			=> $user->img('icon_contact_aim', 'AIM'),
		'ICQ_IMG'			=> $user->img('icon_contact_icq', 'ICQ'),
		'JABBER_IMG'		=> $user->img('icon_contact_jabber', 'JABBER'),
	));

	$template->set_filenames(array(
		'body' => 'download_search_results.html'
	));
}
else
{
	$template->assign_vars(array(
		'U_DOWNLOAD_SEARCH'	=> append_sid("{$phpbb_root_path}downloads.$phpEx", 'page=search'),
	));

	$template->set_filenames(array(
		'body' => 'download_search_body.html'
	));
}
?>