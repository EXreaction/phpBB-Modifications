<?php
/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(
	'ACP_ENABLE_MONEY_TRACKER'				=> 'Enable Money Tracker',
	'ACP_MONEY_TRACKER_POINTS'				=> 'Give users points for submitting',
	'ACP_MONEY_TRACKER_POINTS_EXPLAIN'		=> 'For this you must have the simple points mod installed.  This enables the system to give <strong>1</strong> point for every bill submitted and <strong>10</strong> points for every bill submitted which has been submitted already (and also gives all users who\'ve submitted this bill before 10 points).',
	'ACP_MONEY_TRACKER_SETTINGS_EXPLAIN'	=> '',
	'ACP_MONEY_TRACKER_VIEWTOPIC'			=> 'Display bill count in viewtopic',

	'BILL_COUNT'					=> 'Number of Bills',
	'BILL_COUNT_INDEX'				=> 'Number of Bills in Money Tracker',
	'BILL_ENTRY_SUCCESS'			=> 'Bill Entered Successfully',
	'BILL_NOT_EXIST'				=> 'The selected bill does not exist.',
	'BILL_SERIAL'					=> 'Serial Number',
	'BILL_SERIAL_EXPLAIN'			=> 'Example: B60182779F',
	'BILL_SERIAL_DUPLICATE'			=> 'You can not enter the same bill twice.',
	'BILL_SERIAL_EMPTY'				=> 'You must enter a serial number.',
	'BILL_SERIAL_INVALID'			=> 'The serial number you entered in is invalid.',
	'BILL_TOTAL'					=> 'Value of Bills',
	'BILL_TOTAL_INDEX'				=> 'Value of Bills in Money Tracker',
	'BILL_VALUE'					=> 'Denomination',
	'BILL_VALUE_INCORRECT'			=> 'The bill value you entered is not acceptable.',
	'BILL_YEAR'						=> 'Bill Year',
	'BILL_YEAR_INCORRECT'			=> 'The bill year you entered is not acceptable.',

	'CLICK_RETURN'					=> 'Click here to return to the previous page.',
	'CLICK_RETURN_BILL'				=> 'Click here to view the entered bill.',

	'ENTER_A_BILL'					=> 'Enter a Bill',
	'ENTER_ANOTHER_BILL'			=> 'Enter another bill',

	'MONEY_TRACKER_DISABLED'		=> 'Money Tracker is disabled.',

	'LAST_BILLS'					=> 'Last Ten Bills',
	'LINKS'							=> 'Links',

	'MONEY_TRACKER'					=> 'Money Tracker',
	'MOST_BY_MEMBERS'				=> 'Top bill posting members',
	'MOST_HIT_BILLS'				=> 'Most Hit Bills',

	'NO_BILLS'						=> 'No Bills Entered',

	'VIEW_BILL'						=> 'View Bill',
	'VIEW_USER'						=> 'View User',

	'ZIP_CODE'						=> 'Zip Code',
));

?>