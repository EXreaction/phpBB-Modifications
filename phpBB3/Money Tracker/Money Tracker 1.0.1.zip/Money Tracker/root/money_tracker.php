<?php
define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);

$user->session_begin();
$auth->acl($user->data);
$user->setup(array('mods/money_tracker', 'posting'));

if (!$config['money_tracker_enable'])
{
	trigger_error('MONEY_TRACKER_DISABLED');
}

$mode = request_var('mode', '');
$bill_id = request_var('b', 0);
$bill_code = request_var('bc', 0);
$user_id = request_var('u', 0);

$base = "{$phpbb_root_path}money_tracker.$phpEx";
$self = (($mode) ? "mode=$mode" : '') . (($bill_id) ? "b=$bill_id" : '') . (($user_id) ? "u=$user_id" : '') . (($bill_code) ? "bc=$bill_code" : '');
$self = append_sid($base, (($self) ? $self : false));

define('MONEY_TRACKER_TABLE', $table_prefix . 'money_tracker');
define('BILL_SERIAL_MATCH', '/^([A-Z]{1,2})([0-9]{8})([A-Z*]{1})$/');
$bill_values = array(1, 2, 5, 10, 20, 50, 100);
$bill_years = array('2006', '2004A', '2004', '2003A', '2003', '2001', '1999', '1996', '1995', '1993', '1991', '1990', '1988A', '1988', '1985', '1981A', '1981', '1977A', '1977', '1974', '1969D', '1969C', '1969B', '1969A', '1963B', '1969A', '1969');

foreach ($bill_years as $year)
{
	$template->assign_block_vars('bill_years', array('VALUE' => $year));
}

$template->assign_vars(array(
	'U_ENTER_BILL'			=> append_sid($base, 'mode=add'),
	'U_LAST_BILLS'			=> append_sid($base),
	'U_MOST_HIT_BILLS'		=> append_sid($base, 'mode=most_hits'),
	'U_MOST_BY_MEMBERS'		=> append_sid($base, 'mode=most_by_members'),
	'U_SELF'				=> $self,
));

$money_tracker_result = $title = $error = false;
switch ($mode)
{
	case 'add' :
		if (!$user->data['is_registered'])
		{
			login_box();
		}

		include($phpbb_root_path . 'includes/functions_display.' . $phpEx);
		include($phpbb_root_path . 'includes/functions_posting.' . $phpEx);

		page_header($user->lang['ENTER_A_BILL']);

		$submit = (isset($_POST['submit'])) ? true : false;
		$bbcode = (isset($_POST['disable_bbcode'])) ? false : true;
		$smilies = (isset($_POST['disable_smilies'])) ? false : true;
		$magic_url = (isset($_POST['disable_magic_url'])) ? false : true;

		$bill = array(
			'user_id'				=> $user->data['user_id'],
			'bill_code'				=> strtoupper(request_var('bill_code', '')),
			'bill_value'			=> request_var('bill_value', 1),
			'bill_year'				=> request_var('bill_year', ''),
			'bill_zip'				=> request_var('bill_zip', ''),
			'bill_message'			=> utf8_normalize_nfc(request_var('message', '', true)),
			'bill_bbcode_uid'		=> '',
			'bill_bbcode_bitfield'	=> '',
			'bill_bbcode_options'	=> '',
			'bill_time'				=> time(),
		);

		$error = array();

		if ($submit)
		{
			if (!check_form_key('money_tracker'))
			{
				$error[] = $user->lang['FORM_INVALID'];
			}

			if (!$bill['bill_code'])
			{
				$error[] = $user->lang['BILL_SERIAL_EMPTY'];
			}
			else
			{
				if (BILL_SERIAL_MATCH && !preg_match(BILL_SERIAL_MATCH, $bill['bill_code']))
				{
					$error[] = $user->lang['BILL_SERIAL_INVALID'];
				}

				$result = $db->sql_query('SELECT bill_id FROM ' . MONEY_TRACKER_TABLE . '
					WHERE bill_code = \'' . $db->sql_escape($bill['bill_code']) . '\'
					AND user_id = ' . $user->data['user_id'] . '
					AND bill_year = \'' . $db->sql_escape($bill['bill_year']) . '\'');
				if ($db->sql_fetchrow($result))
				{
					$error[] = $user->lang['BILL_SERIAL_DUPLICATE'];
				}
				$db->sql_freeresult($result);
			}

			if(!in_array($bill['bill_value'], $bill_values))
			{
				$error[] = $user->lang['BILL_VALUE_INCORRECT'];
			}

			if (!in_array($bill['bill_year'], $bill_years))
			{
				$error[] = $user->lang['BILL_YEAR_INCORRECT'];
			}
		}

		if ($submit && !sizeof($error))
		{
			generate_text_for_storage($bill['bill_message'], $bill['bill_bbcode_uid'], $bill['bill_bbcode_bitfield'], $bill['bill_bbcode_options'], $bbcode, $magic_url, $smilies);

			$db->sql_query('INSERT INTO ' . MONEY_TRACKER_TABLE . ' ' . $db->sql_build_array('INSERT', $bill));
			$bill_id = $db->sql_nextid();

			if ($config['money_tracker_enable_points'] && isset($user->data['user_points']))
			{
				$dupes = array();
				$result = $db->sql_query('SELECT user_id FROM ' . MONEY_TRACKER_TABLE . '
					WHERE bill_code = \'' . $db->sql_escape($bill['bill_code']) . '\'
					AND user_id <> ' . $user->data['user_id'] . '
					AND bill_year = \'' . $db->sql_escape($bill['bill_year']) . '\'');
				while ($row = $db->sql_fetchrow($result))
				{
					$dupes[] = $row['user_id'];
				}
				$db->sql_freeresult($result);

				if (sizeof($dupes))
				{
					$db->sql_query('UPDATE ' . USERS_TABLE . ' SET bill_count = bill_count + 1, bill_total = bill_total + ' . $bill['bill_value'] . ', user_points = user_points + 10 WHERE user_id = ' . $user->data['user_id']);
					$db->sql_query('UPDATE ' . USERS_TABLE . ' SET user_points = user_points + 10 WHERE ' . $db->sql_in_set('user_id', $dupes));
				}
				else
				{
					$db->sql_query('UPDATE ' . USERS_TABLE . ' SET bill_count = bill_count + 1, bill_total = bill_total + ' . $bill['bill_value'] . ', user_points = user_points + 1 WHERE user_id = ' . $user->data['user_id']);
				}
			}
			else
			{
				$db->sql_query('UPDATE ' . USERS_TABLE . ' SET bill_count = bill_count + 1, bill_total = bill_total + ' . $bill['bill_value'] . ' WHERE user_id = ' . $user->data['user_id']);
			}
			set_config('money_tracker_count', ($config['money_tracker_count'] + 1), true);
			set_config('money_tracker_total', ($config['money_tracker_total'] + $bill['bill_value']), true);

			$msg = $user->lang['BILL_ENTRY_SUCCESS'];
			$msg .= '<br /><br /><a href="' . append_sid($base, 'bc=' . $bill_id) . '">' . $user->lang['CLICK_RETURN_BILL'] . '</a>';
			$msg .= '<br /><a href="' . append_sid($base) . '">' . $user->lang['CLICK_RETURN'] . '</a>';
			$msg .= '<br /><br /><a href="' . append_sid($base, 'mode=add') . '">' . $user->lang['ENTER_ANOTHER_BILL'] . '</a>';
			trigger_error($msg);
		}

		add_form_key('money_tracker');
		display_custom_bbcodes();
		generate_smilies('inline', false);
		$template->assign_vars(array(
			'ERROR'						=> (sizeof($error)) ? implode('<br />', $error) : '',
			'BILL_CODE'					=> $bill['bill_code'],
			'BILL_VALUE'				=> $bill['bill_value'],
			'BILL_YEAR'					=> $bill['bill_year'],
			'BILL_ZIP'					=> ($bill['bill_zip']) ? $bill['bill_zip'] : '',
			'BILL_MESSAGE'				=> $bill['bill_message'],

			'S_BBCODE_CHECKED'			=> ($bbcode) ? '' : ' selected="selected"',
			'S_SMILIES_CHECKED'			=> ($smilies) ? '' : ' selected="selected"',
			'S_MAGIC_URL_CHECKED'		=> ($magic_url) ? '' : ' selected="selected"',
			'S_BBCODE_ALLOWED'			=> true,
			'S_SMILIES_ALLOWED'			=> true,
			'S_LINKS_ALLOWED'			=> true,
			'S_BBCODE_IMG'				=> true,
			'S_BBCODE_URL'				=> true,
		));

		$template->set_filenames(array(
			'body' => 'mods/money_tracker_add.html',
		));

		page_footer();
	break;

	case 'most_by_members' :
		$sql = 'SELECT g.bill_id, g.user_id, g.bill_code, g.bill_value, g.bill_year, g.bill_zip, g.bill_time, u.username, u.user_colour, u.bill_count AS cnt FROM ' . USERS_TABLE . ' u
			LEFT JOIN ' . MONEY_TRACKER_TABLE . ' AS g ON g.user_id = u.user_id
			WHERE u.bill_count > 0
			GROUP BY u.user_id
			ORDER BY u.bill_count DESC';
		$money_tracker_result = $db->sql_query_limit($sql, 10);
		$title = 'MOST_BY_MEMBERS';
	break;

	case 'most_hits' :
		$sql = 'SELECT g.bill_id, g.user_id, g.bill_code, g.bill_value, g.bill_year, g.bill_zip, g.bill_time, u.username, u.user_colour, COUNT(g.bill_id) AS cnt FROM ' . MONEY_TRACKER_TABLE . ' g, ' . USERS_TABLE . ' u
			WHERE u.user_id = g.user_id
			GROUP BY g.bill_code, g.bill_year
			ORDER BY cnt DESC';
		$money_tracker_result = $db->sql_query_limit($sql, 10);
		$title = 'MOST_HIT_BILLS';
	break;
}

if ($bill_id)
{
	$sql = 'SELECT * FROM ' . MONEY_TRACKER_TABLE . ' g, ' . USERS_TABLE . ' u WHERE g.bill_id = ' . $bill_id . ' AND u.user_id = g.user_id';
	$money_tracker_result = $db->sql_query($sql);
	$title = 'VIEW_BILL';
}
else if ($bill_code)
{
	$result = $db->sql_query('SELECT bill_code, bill_year FROM ' . MONEY_TRACKER_TABLE . ' WHERE bill_id = ' . $bill_code);
	$row = $db->sql_fetchrow($result);
	if ($row)
	{
		$sql = 'SELECT * FROM ' . MONEY_TRACKER_TABLE . ' g, ' . USERS_TABLE . ' u
			WHERE g.bill_code = \'' . $row['bill_code'] . '\'
			AND g.bill_year = \'' . $row['bill_year'] . '\'
			AND u.user_id = g.user_id
			ORDER BY g.bill_time DESC';
		$money_tracker_result = $db->sql_query($sql);
		$title = 'VIEW_BILL';
	}
	$db->sql_freeresult($result);
}
else if ($user_id)
{
	$sql = 'SELECT * FROM ' . MONEY_TRACKER_TABLE . ' g, ' . USERS_TABLE . ' u WHERE g.user_id = ' . $user_id . ' AND u.user_id = g.user_id';
	$money_tracker_result = $db->sql_query($sql);
	$title = 'VIEW_USER';
}

if ($money_tracker_result === false)
{
	$template->assign_var('L_TITLE', $user->lang['LAST_BILLS']);
	$sql = 'SELECT * FROM ' . MONEY_TRACKER_TABLE . ' g, ' . USERS_TABLE . ' u
		WHERE u.user_id = g.user_id
		ORDER BY bill_time DESC';
	$money_tracker_result = $db->sql_query_limit($sql, 10);
}

page_header($user->lang[(($title) ? $title : 'MONEY_TRACKER')]);

while ($row = $db->sql_fetchrow($money_tracker_result))
{
	$template->assign_block_vars('bills', array(
		'CNT'			=> (isset($row['cnt'])) ? $row['cnt'] : '',

		'BILL_ID'		=> $row['bill_id'],
		'USER_ID'		=> $row['user_id'],
		'BILL_CODE'		=> substr($row['bill_code'], 0, 2) . '******' . substr($row['bill_code'], -3),
		'BILL_VALUE'	=> $row['bill_value'],
		'BILL_YEAR'		=> $row['bill_year'],
		'BILL_ZIP'		=> $row['bill_zip'],
		'BILL_MESSAGE'	=> (isset($row['bill_message'])) ? generate_text_for_display($row['bill_message'], $row['bill_bbcode_uid'], $row['bill_bbcode_bitfield'], $row['bill_bbcode_options']) : '',
		'BILL_TIME'		=> $user->format_date($row['bill_time']),
		'BILL_USERNAME'	=> get_username_string('full', $row['user_id'], $row['username'], $row['user_colour']),

		'U_VIEW_BILL'	=> append_sid($base, 'bc=' . $row['bill_id']),
	));
}
$db->sql_freeresult($money_tracker_result);

$template->assign_vars(array(
	'L_TITLE'		=> $user->lang[(($title) ? $title : 'MONEY_TRACKER')],
	'L_NO_BILLS'	=> ($bill_id || $bill_code) ? $user->lang['BILL_NOT_EXIST'] : $user->lang['NO_BILLS'],
));

$template->set_filenames(array(
	'body' => 'mods/money_tracker.html',
));

page_footer();

?>