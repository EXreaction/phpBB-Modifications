<?php
define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);

$user->session_begin();
$auth->acl($user->data);
$user->setup();

$total = $cnt = 0;
$result = $db->sql_query('SELECT bill_value FROM ' . $table_prefix . 'money_tracker');
while ($row = $db->sql_fetchrow($result))
{
	$cnt++;
	$total += $row['bill_value'];
}
$db->sql_freeresult($result);

set_config('money_tracker_count', $cnt, true);
set_config('money_tracker_total', $total, true);

$result = $db->sql_query('SELECT user_id FROM ' . USERS_TABLE);
while ($row = $db->sql_fetchrow($result))
{
	$total = $cnt = 0;
	$result2 = $db->sql_query('SELECT bill_value FROM ' . $table_prefix . 'money_tracker WHERE user_id = ' . $row['user_id']);
	while ($row2 = $db->sql_fetchrow($result2))
	{
		$cnt++;
		$total += $row2['bill_value'];
	}
	$db->sql_freeresult($result2);

	$db->sql_query('UPDATE ' . USERS_TABLE . ' SET bill_count = ' . $cnt . ', bill_total = ' . $total . ' WHERE user_id = ' . $row['user_id']);
}
$db->sql_freeresult($result);

echo 'Done';

garbage_collection();
exit_handler();
?>