<?php
/**
*
* @package phpBB3 Forum Sponsor
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'FORUM_SPONSOR'						=> 'Diskusij&#371; Lentos Laiduotoj&#371;',
	'FORUM_SPONSOR_EXPLAIN'				=> 'Bet koks tekstas kuris bus rodomas vir&#353; pasirinkto forumo',
	'FORUM_SPONSOR_INSTALL'				=> 'Diskusij&#371; Lentos Laiduotoj&#371; Modifikacija',
	'FORUM_SPONSOR_INSTALL_CONFIRM'		=> 'Ar J&#363;s esate pasiruo&#353;&#281; &#303;ra&#353;yti reikalingas bylas kad veiktu "Diskusij&#371; Lentos Laiduotoj&#371; Modifikacija"?',
	'FOUNDER_ONLY'						=> 'Tik Lentos Savininkai Gali matyti &#353;i puslap&#303;.',

	'INSTALL_COMPLETED'					=> 'Byl&#371; i&#353;pakavimas atliktas, dabar i&#353;trinkite install.php byl&#261; is phpBB3 &#353;aknin&#279;s.',
	'PARSE_HTML'						=> 'Patikrinti HTML',
));

?>