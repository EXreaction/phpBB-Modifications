<?php
/**
*
* @package phpBB3 Forum Sponsor
* @copyright (c) 2007 EXreaction, Lithium Studios
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/


/**
* @ignore
*/
define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);
$user->setup('mods/forum_sponsor');

// Must be a board founder
if ($user->data['user_type'] != USER_FOUNDER)
{
	trigger_error('FOUNDER_ONLY');
}

if (confirm_box(true))
{
	include($phpbb_root_path . 'includes/db/db_tools.' . $phpEx);
	$db_tool = new phpbb_db_tools($db);

	$db_tool->sql_column_add(FORUMS_TABLE, 'forum_sponsor', array('MTEXT_UNI', ''));
	$db_tool->sql_column_add(FORUMS_TABLE, 'forum_sponsor_html', array('BOOL', 0));
	$db_tool->sql_column_add(FORUMS_TABLE, 'forum_sponsor_uid', array('VCHAR:8', ''));
	$db_tool->sql_column_add(FORUMS_TABLE, 'forum_sponsor_bitfield', array('VCHAR:255', ''));
	$db_tool->sql_column_add(FORUMS_TABLE, 'forum_sponsor_options', array('UINT:11', 7));

	$cache->purge();

	trigger_error('INSTALL_COMPLETED');
}
else
{
	confirm_box(false, 'FORUM_SPONSOR_INSTALL');
}

redirect(append_sid("{$phpbb_root_path}index.$phpEx"));
?>